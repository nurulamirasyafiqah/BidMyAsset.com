// Types and static config for the admin console (the old demo data has been removed; lists are loaded from the backend).

export const ADMIN_NAV = [
  { href: "/admin/dashboard", label: "Dashboard", icon: "home" },
  { href: "/admin/auction-house", label: "Auction House", icon: "building" },
  { href: "/admin/company", label: "Company", icon: "briefcase" },
  { href: "/admin/auction-studio", label: "Auction Studio", icon: "layers" },
  { href: "/admin/admin-users", label: "Admin Users", icon: "users" },
  { href: "/admin/team", label: "Team", icon: "contact" },
  { href: "/admin/bidders", label: "Bidders", icon: "userCheck", divider: true },
  { href: "/admin/hammer-sales", label: "Hammer Sales", icon: "gavel" },
  { href: "/admin/invoice-management", label: "Invoice Management", icon: "file", divider: true },
  { href: "/admin/auction-intelligence", label: "Auction Intelligence", icon: "chart" },
  { href: "/admin/user-activity", label: "User Activity Analytics", icon: "activity" },
  { href: "/admin/crm-hub", label: "CRM Hub", icon: "inbox" },
] as const;

export type AdminNotice = { id: string; title: string; body: string; at: string; read: boolean; link?: string };

export type Img = { name: string; url: string };
export type StudioAuction = {
  id: string; title: string; company: string; code: string; status: "RUNNING" | "DRAFT" | "UPCOMING" | "CLOSED";
  lots: number; active: number; starts: string; ends: string; startsAtIso?: string; endsAtIso?: string; type: "Timed"; paused?: boolean; published?: boolean; images?: Img[]; tz?: string; currency?: string; auctionType?: string; description?: string;
  sequence?: number; updatedAt?: string; category?: string; subcategory?: string; approval?: "auto" | "manual"; hideBidders?: boolean; stagger?: boolean;
  builder?: Record<string, unknown>; documents?: Img[]; contactFiles?: Img[];
};
/** Filled from PocketBase by loadStudio() (lib/studioApi.tsx). Starts empty: there is no demo data. */
export const studioAuctions: StudioAuction[] = [];

export type StudioLot = { id: string; no: number; title: string; sku: string; qty: number; category: string; address: string; status: "Active" | "Draft" | "Closed"; closes: string; closeDate: string; closeTime: string;
  startBid: number; reserve: number; increment: number; tiers?: { from: number; increment: number }[]; overview: string; hashtags: string; highlights: string; consignor: string; images?: Img[] };
/** Filled from Admin → Company → Consignors by loadStudio(). */
export const consignors: { initials: string; name: string }[] = [];
/** Real lots are loaded per auction by loadStudio(); nothing is generated here. */
export const lotsFor = (_a: StudioAuction): StudioLot[] => [];

export type Registration = { id: string; status: "Awaiting" | "Approved" | "Rejected" | "Disabled" | "Incomplete"; name: string; email: string; phone: string; at: string };
/** Bidder registrations per auction are not stored yet, so this is always empty. */
export const registrationsFor = (_auctionId: string): Registration[] => [];

export const builderSections = [
  { name: "Auction Info", title: "Auction Information", sub: "Type, title, company, timezone", short: "Type, title, company,…", state: "Complete" },
  { name: "Lot Bid Details", title: "Lot Bid Details", sub: "Lot-level bidding configuration", short: "Lot-level bidding…", state: "Optional" },
  { name: "Contacts", title: "Contacts", sub: "Auction contacts", short: "Auction contacts", state: "Complete" },
  { name: "Legal Policy", title: "Legal Policy", sub: "Privacy and terms", short: "Privacy and terms", state: "Optional" },
  { name: "Address", title: "Address", sub: "Location details", short: "Location details", state: "Complete" },
  { name: "Documents", title: "Documents", sub: "Upload documents", short: "Upload documents", state: "Optional" },
  { name: "Financial Supplier", title: "Financial Supplier", sub: "Financial vendors", short: "Financial vendors", state: "Complete" },
  { name: "Bidder Registration", title: "Bidder Registration", sub: "Registration specifics", short: "Registration specifics", state: "Complete" },
  { name: "Commission & Tax", title: "Commission & Tax", sub: "Fees and taxes", short: "Fees and taxes", state: "Optional" },
  { name: "Payment Configuration", title: "Payment Configuration", sub: "Enable payment and set amount", short: "Enable payment an…", state: "Optional" },
  { name: "Consignors", title: "Consignors", sub: "Consignor assignments", short: "Consignor assignments", state: "Optional" },
  { name: "Catalog Notification", title: "Catalog Notification Emails", sub: "Manage email recipients", short: "Manage email recipients", state: "Optional" },
] as const;

export type AdminUserRow = { name: string; email: string; active: boolean; registered: string; onboarding: "Onboarded" | "Invited" };

export type BidderRow = { id: string; name: string; email: string; phone: string; registered: string; bids: number; registrations: number; completed: boolean; phoneCountry: string; country: string; notify: boolean };

export const categoryLibrary: Record<string, string[]> = {
  "Heavy Equipment": ["Excavators", "Misc.", "Lifts", "Forestry Equipment", "Dozers", "Trenchers", "Aggregate Equipment", "Skid Steers", "Telehandlers", "Concrete Equipment", "Sweepers", "Loader Backhoes", "Cranes", "Attachments & Implements", "Wheel Loaders", "Off Highway Trucks", "Pavers", "Motor Graders", "Asphalt", "Drills", "Forklifts", "Mini Excavators"],
  Trucks: ["Dump Trucks", "Flatbed Trucks", "Tipper Trucks", "Box Trucks", "Prime Movers", "Tankers"],
  Trailers: ["Flatbed Trailers", "Lowbed Trailers", "Tipper Trailers", "Tanker Trailers", "Container Trailers"],
  Vehicles: ["Pickups", "Vans", "Buses", "SUVs"],
  Agriculture: ["Tractors", "Harvesters", "Sprayers", "Planters", "Balers"],
  "Industrial & Business Equipment": ["CNC Machines", "Presses", "Slitters"],
  "Plant & Machinery": ["Process Plant"],
};
