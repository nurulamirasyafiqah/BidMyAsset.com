/**
 * Standard display: "(+60) 123456789" — dial code from the phone's country (users.phoneCountry; falls back to the
 * address country for older accounts), national number without spaces/dashes or the leading trunk "0".
 */
export function formatPhone(raw: string, iso: string, dialByIso: Record<string, string>): string {
  const p = (raw ?? "").trim();
  if (!p) return "—";
  const dial = dialByIso[iso];
  const digits = p.replace(/[^\d+]/g, "");
  if (!dial) return digits || p;
  const d = dial.replace("+", "");
  let n = digits;
  if (n.startsWith("+")) {
    n = n.slice(1);
    if (!n.startsWith(d)) return `+${n}`; // another country's international number: leave as typed
    n = n.slice(d.length);
  } else if (n.startsWith("00" + d)) n = n.slice(2 + d.length);
  n = n.replace(/^0+/, "");
  return n ? `(${dial}) ${n}` : "—";
}
