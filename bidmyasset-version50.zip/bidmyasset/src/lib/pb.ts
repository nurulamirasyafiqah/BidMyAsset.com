/**
 * Server-side PocketBase access. The browser never talks to PocketBase directly:
 * it calls /api/pb/* (same origin), which attaches the httpOnly session cookie.
 */
import { cookies } from "next/headers";

export const PB_URL = (process.env.PB_URL ?? "http://127.0.0.1:8090").replace(/\/$/, "");
export const TOKEN_COOKIE = "bma_token";

export async function getToken(): Promise<string | undefined> {
  return (await cookies()).get(TOKEN_COOKIE)?.value;
}

export class PBError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function pb<T>(
  path: string,
  opts: { token?: string; method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(`${PB_URL}${path}`, {
    method: opts.method ?? "GET",
    headers: {
      ...(opts.body ? { "Content-Type": "application/json" } : {}),
      ...(opts.token ? { Authorization: opts.token } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    cache: "no-store",
  });
  if (!res.ok) {
    const j = (await res.json().catch(() => null)) as { message?: string } | null;
    throw new PBError(res.status, j?.message ?? `PocketBase ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export type PBRecord = { id: string; [k: string]: unknown };

/** All records of a collection (pages through PocketBase's 500/page cap). */
export async function pbAll<T extends PBRecord = PBRecord>(
  collection: string,
  q: { filter?: string; sort?: string; expand?: string; token?: string } = {},
): Promise<T[]> {
  const out: T[] = [];
  for (let page = 1; ; page++) {
    const p = new URLSearchParams({ page: String(page), perPage: "500", skipTotal: "0" });
    if (q.filter) p.set("filter", q.filter);
    if (q.sort) p.set("sort", q.sort);
    if (q.expand) p.set("expand", q.expand);
    const r = await pb<{ items: T[]; totalPages: number }>(`/api/collections/${collection}/records?${p}`, { token: q.token });
    out.push(...r.items);
    if (page >= r.totalPages) return out;
  }
}

/** PocketBase dates look like "2026-10-16 12:00:00.000Z". */
export const iso = (s: unknown) => new Date(String(s).replace(" ", "T")).toISOString();

/** The signed-in user, or null (no cookie / expired token). */
export async function getSessionUser() {
  const token = await getToken();
  if (!token) return null;
  try {
    const r = await pb<{ record: PBRecord }>("/api/collections/users/auth-refresh", { method: "POST", token });
    return { token, record: r.record };
  } catch {
    return null;
  }
}

/** The signed-in user if they are an admin (users.isAdmin, set by a superuser in the PocketBase dashboard). */
export async function getAdminUser() {
  const me = await getSessionUser();
  return me && me.record.isAdmin === true ? me : null;
}
