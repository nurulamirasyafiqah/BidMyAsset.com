"use client";

/** Reports an admin-console action to the activity log (shown in Admin Users → activity). Fire-and-forget. */
export function trackAdmin(title: string) {
  void fetch("/api/admin/activity", {
    method: "POST", keepalive: true,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title }),
  }).catch(() => {});
}
