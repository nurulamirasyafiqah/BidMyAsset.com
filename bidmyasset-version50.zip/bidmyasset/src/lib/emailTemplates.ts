// Email templates for Auction House → Email Config.
// MOCK DATA. Keys/names follow the legacy admin screenshots (Email_Config_.docx); bodies are redrafted.
//
// Placeholder syntax is unified: {{VARIABLE}} in BOTH subject and body (legacy used #VAR in subject and
// Thymeleaf ${VAR} in body). Lists use {{#each LOT_INFO}}…{{this.field}}…{{/each}}.
// TODO: persist in an EmailTemplate table (auctionHouseId, key, scope, subject, body, enabled) and render
// server-side with Handlebars. Keep the allowed-variable check on save, and sanitize HTML before sending.

export type EmailTemplate = {
  key: string;
  name: string;
  description: string;
  scope: "Global" | "Application specific";
  enabled: boolean;
  variables: string[];
  subject: string;
  body: string;
};

const logo = `<img src="{{IMAGE_URL}}" style="height:auto;max-height:50px" alt=""><br>`;
const contact = `<p>If you have any questions please contact:<br>{{AUCTION_HOUSE_NAME}}<br>{{AUCTION_HOUSE_MOBILE_NO}}<br>{{SUPPORT_EMAIL}}</p>`;
const unsub = `<p style="font-size:12px;color:#666">Update your email preferences or unsubscribe <a href="{{UNSUBSCRIBE_URL}}">here</a>.</p>`;
const ahVars = ["AUCTION_HOUSE_NAME", "AUCTION_HOUSE_MOBILE_NO", "SUPPORT_EMAIL", "IMAGE_URL"];

const lotTable = `<table style="border:1px solid #000;border-collapse:collapse" cellpadding="5">
<thead><tr><th style="border:1px solid #000">#</th><th style="border:1px solid #000">Lot Name</th><th style="border:1px solid #000">Category</th><th style="border:1px solid #000">URL</th></tr></thead>
<tbody>{{#each LOT_INFO}}<tr><td style="border:1px solid #000">{{this.sequence}}</td><td style="border:1px solid #000">{{this.name}}</td><td style="border:1px solid #000">{{this.category}}</td><td style="border:1px solid #000"><a href="{{this.url}}">{{this.url}}</a></td></tr>{{/each}}</tbody></table>`;

const t = (key: string, name: string, scope: EmailTemplate["scope"], description: string, variables: string[], subject: string, body: string, enabled = true): EmailTemplate =>
  ({ key, name, scope, description, variables, subject, body, enabled });

export const defaultTemplates: EmailTemplate[] = [
  t("AUCTION_LIVE_NOTIFICATION", "Bidder Notification: Auction Live Notification", "Application specific",
    "Sent to registered bidders when an auction goes live.",
    ["AUCTION_NAME", "CATALOG_URL", "LOT_INFO", "UNSUBSCRIBE_URL", ...ahVars],
    "Auction Live Notification: {{AUCTION_NAME}}",
    `${logo}<p>Dear bidder,</p><p>The auction <b>{{AUCTION_NAME}}</b> is now live.</p><p>Catalog: <a href="{{CATALOG_URL}}">{{CATALOG_URL}}</a></p><p>Below are the details of the lots.</p>${lotTable}${contact}${unsub}`),
  t("BIDDER_AUCTION_REGISTRATION_PENDING", "Bidder Notification: Auction Registration Pending", "Global",
    "Sent to the bidder when their registration for an auction is pending approval.",
    ["BIDDER_NAME", "AUCTION_NAME", "AUCTION_COMPANY_NAME", ...ahVars],
    "Notice: Approval Pending for {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Your registration for this auction is complete, however your approval to bid is still pending. You will be notified once you are approved to place bids.</p>${contact}`),
  t("AUCTION_UPCOMING_NOTIFICATION", "Bidder Notification: Auction Upcoming Notification", "Application specific",
    "Sent to bidders ahead of an auction opening.",
    ["AUCTION_NAME", "CATALOG_URL", "LOT_INFO", "UNSUBSCRIBE_URL", ...ahVars],
    "Upcoming Auction: {{AUCTION_NAME}}",
    `${logo}<p>Dear bidder,</p><p><b>{{AUCTION_NAME}}</b> opens soon. Preview the lots now: <a href="{{CATALOG_URL}}">{{CATALOG_URL}}</a></p>${lotTable}${contact}${unsub}`),
  t("BIDDER_APPLICATION_REGISTRATION_INCOMPLETE", "Bidder Notification: Incomplete Application", "Application specific",
    "Reminds a bidder to finish an incomplete registration.",
    ["BIDDER_NAME", ...ahVars],
    "Complete your registration",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Your registration is incomplete. Please log in and finish the remaining steps so you can bid.</p>${contact}`),
  t("LOT_ALLOCATED_EMAIL_TEMPLATE", "Bidder Notification: Lot Allocated", "Global",
    "Sent to the winning bidder when a lot is allocated to them.",
    ["BIDDER_NAME", "AUCTION_NAME", "LOT_INFO", ...ahVars],
    "Lot allocated: {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Congratulations. The following lots in <b>{{AUCTION_NAME}}</b> have been allocated to you.</p>${lotTable}${contact}`),
  t("BIDDER_AUCTION_REGISTRATION_APPROVED", "Bidder Notification: Registration Approved", "Global",
    "Sent when a bidder is approved to bid in an auction.",
    ["BIDDER_NAME", "AUCTION_NAME", "CATALOG_URL", ...ahVars],
    "You are approved to bid in {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>You are approved to place bids in <b>{{AUCTION_NAME}}</b>. <a href="{{CATALOG_URL}}">View the catalog</a>.</p>${contact}`),
  t("BIDDER_AUCTION_REGISTRATION_REJECTED", "Bidder Notification: Registration Rejected", "Global",
    "Sent when a bidder's registration for an auction is rejected.",
    ["BIDDER_NAME", "AUCTION_NAME", ...ahVars],
    "Registration update for {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>We could not approve your registration for <b>{{AUCTION_NAME}}</b>.</p>${contact}`),
  t("AUCTION_WISHLIST_LIVE_NOTIFICATION", "Bidder Notification: Wishlist Auction Live", "Application specific",
    "Sent when an auction containing a bidder's wishlisted lots goes live.",
    ["BIDDER_NAME", "AUCTION_NAME", "CATALOG_URL", "LOT_INFO", "UNSUBSCRIBE_URL", ...ahVars],
    "Your wishlisted lots are live: {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Lots on your wishlist are now live in <b>{{AUCTION_NAME}}</b>.</p>${lotTable}${contact}${unsub}`),
  t("AUCTION_WISHLIST_UPCOMING_NOTIFICATION", "Bidder Notification: Wishlist Auction Upcoming", "Application specific",
    "Sent when an auction containing a bidder's wishlisted lots is about to open.",
    ["BIDDER_NAME", "AUCTION_NAME", "CATALOG_URL", "LOT_INFO", "UNSUBSCRIBE_URL", ...ahVars],
    "Your wishlisted lots open soon: {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Lots on your wishlist will open soon in <b>{{AUCTION_NAME}}</b>.</p>${lotTable}${contact}${unsub}`),
  t("CMS_CAREER_NOTIFICATION", "CMS: Career Inquiry", "Application specific",
    "Sent to staff when someone submits the careers form.",
    ["SENDER_NAME", "SENDER_EMAIL", "MESSAGE", "IMAGE_URL"],
    "New career inquiry from {{SENDER_NAME}}",
    `${logo}<p>New career inquiry.</p><p>Name: {{SENDER_NAME}}<br>Email: {{SENDER_EMAIL}}</p><p>{{MESSAGE}}</p>`),
  t("CMS_CONTACT_US_NOTIFICATION", "CMS: Contact Us Submission", "Application specific",
    "Sent to staff when someone submits the Contact Us form.",
    ["SENDER_NAME", "SENDER_EMAIL", "MESSAGE", "IMAGE_URL"],
    "New message from {{SENDER_NAME}}",
    `${logo}<p>New Contact Us submission.</p><p>Name: {{SENDER_NAME}}<br>Email: {{SENDER_EMAIL}}</p><p>{{MESSAGE}}</p>`),
  t("CMS_SUBSCRIPTION_NOTIFICATION", "CMS: Subscription Request", "Application specific",
    "Sent to staff when someone subscribes to updates.",
    ["SENDER_EMAIL", "IMAGE_URL"],
    "New subscription request",
    `${logo}<p>{{SENDER_EMAIL}} subscribed to auction updates.</p>`),
  t("FORGOT_PASSWORD_OTP_NOTIFICATION", "Forgot Password - Magic Link", "Application specific",
    "Sent with a one-time link to reset a forgotten password.",
    ["BIDDER_NAME", "RESET_URL", "EXPIRY_MINUTES", ...ahVars],
    "Reset your password",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p><a href="{{RESET_URL}}">Reset your password</a>. This link expires in {{EXPIRY_MINUTES}} minutes.</p>${contact}`),
  t("INVOICE_REVERT_TEMPLATE", "INVOICE REVERT TEMPLATE", "Global",
    "Sent when an invoice is reverted.",
    ["BIDDER_NAME", "INVOICE_NUMBER", ...ahVars],
    "Invoice {{INVOICE_NUMBER}} reverted",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Invoice {{INVOICE_NUMBER}} has been reverted. A corrected invoice will follow if applicable.</p>${contact}`),
  t("INVOICE_TEMPLATE", "INVOICE TEMPLATE", "Global",
    "Sent with a bidder's invoice after the auction closes.",
    ["BIDDER_NAME", "INVOICE_NUMBER", "INVOICE_URL", "AUCTION_NAME", ...ahVars],
    "Invoice {{INVOICE_NUMBER}} for {{AUCTION_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Your invoice {{INVOICE_NUMBER}} for <b>{{AUCTION_NAME}}</b> is ready: <a href="{{INVOICE_URL}}">view invoice</a>.</p>${contact}`),
  t("NEW_BIDDER_REGISTRATION_NOTIFICATION", "New Bidder Registration", "Global",
    "Sent to staff when a new bidder registers.",
    ["BIDDER_NAME", "BIDDER_EMAIL", "IMAGE_URL"],
    "New bidder registration: {{BIDDER_NAME}}",
    `${logo}<p>A new bidder has registered.</p><p>Name: {{BIDDER_NAME}}<br>Email: {{BIDDER_EMAIL}}</p>`),
  t("USER_ONBOARDING_NOTIFICATION", "Onboard Notification: User Onboarding", "Application specific",
    "Sent to a new admin user to set up their account.",
    ["USER_NAME", "SETUP_URL", ...ahVars],
    "Welcome to {{AUCTION_HOUSE_NAME}}",
    `${logo}<p>Hi {{USER_NAME}},</p><p>Your account is ready. <a href="{{SETUP_URL}}">Set your password</a> to get started.</p>${contact}`),
  t("APPLICATION_LOGIN_OTP_NOTIFICATION", "OTP Notification: Login", "Application specific",
    "Sent with a one-time password for login.",
    ["OTP", "EXPIRY_MINUTES", ...ahVars],
    "Your login code",
    `${logo}<p>Your login code is <b>{{OTP}}</b>. It expires in {{EXPIRY_MINUTES}} minutes.</p>`),
  t("APPLICATION_REGISTRATION_OTP_NOTIFICATION", "OTP Notification: Registration", "Application specific",
    "Sent with a one-time password to verify a new email during registration.",
    ["OTP", "EXPIRY_MINUTES", ...ahVars],
    "Verify your email",
    `${logo}<p>Your verification code is <b>{{OTP}}</b>. It expires in {{EXPIRY_MINUTES}} minutes.</p>`),
  t("BID_OUTPLACED_TEMPLATE", "Outbid Email Notification", "Global",
    "Sent to a bidder when someone outbids them.",
    ["BIDDER_NAME", "AUCTION_NAME", "LOT_NAME", "CURRENT_BID", "LOT_URL", ...ahVars],
    "You have been outbid on {{LOT_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>You have been outbid on <b>{{LOT_NAME}}</b> in {{AUCTION_NAME}}. The current bid is {{CURRENT_BID}}.</p><p><a href="{{LOT_URL}}">Bid again</a></p>${contact}`),
  t("SUCCESSFUL_APPLICATION_REGISTRATION", "Successful Registration", "Application specific",
    "Sent after a bidder completes registration.",
    ["BIDDER_NAME", ...ahVars],
    "Welcome to {{AUCTION_HOUSE_NAME}}",
    `${logo}<p>Dear {{BIDDER_NAME}},</p><p>Your registration is complete. You can now browse auctions and register to bid.</p>${contact}`),
  t("SUPER_ADMIN_ONBOARDING", "Super Admin Access Verification", "Global",
    "Sent to verify super admin access.",
    ["USER_NAME", "SETUP_URL", ...ahVars],
    "Verify your super admin access",
    `${logo}<p>Hi {{USER_NAME}},</p><p><a href="{{SETUP_URL}}">Verify your access</a> to finish setting up your super admin account.</p>${contact}`),
];

// ---------- validation + preview ----------

const SAMPLE: Record<string, string> = {
  AUCTION_NAME: "Forestry Heavy Machinery", AUCTION_COMPANY_NAME: "BidMyAsset Sdn Bhd", AUCTION_HOUSE_NAME: "BidMyAsset",
  AUCTION_HOUSE_MOBILE_NO: "6045024643", SUPPORT_EMAIL: "support@bidmyasset.com", CATALOG_URL: "https://bidmyasset.com/auctions/sample",
  IMAGE_URL: "/logo.png", UNSUBSCRIBE_URL: "https://bidmyasset.com/unsubscribe", BIDDER_NAME: "Aisyah Rahman", BIDDER_EMAIL: "aisyah@example.com",
  SENDER_NAME: "Aisyah Rahman", SENDER_EMAIL: "aisyah@example.com", MESSAGE: "Sample message text.", RESET_URL: "https://bidmyasset.com/reset/sample",
  EXPIRY_MINUTES: "10", INVOICE_NUMBER: "INV-0001", INVOICE_URL: "https://bidmyasset.com/invoice/sample", USER_NAME: "Aisyah Rahman",
  SETUP_URL: "https://bidmyasset.com/setup/sample", OTP: "482913", LOT_NAME: "Portal Crane (Dual Rail)", CURRENT_BID: "MYR 12,500", LOT_URL: "https://bidmyasset.com/auctions/sample/lot/1",
};
const SAMPLE_LOTS = [
  { sequence: "1", name: "Portal Crane (Dual Rail)", category: "Heavy Equipment", url: "https://bidmyasset.com/auctions/sample/lot/1" },
  { sequence: "2", name: "Plastic Crusher Machine", category: "Industrial", url: "https://bidmyasset.com/auctions/sample/lot/2" },
];

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** Variables used in the text that are not in the allowed list (empty = valid). */
export function unknownVariables(text: string, allowed: string[]): string[] {
  const bad = new Set<string>();
  for (const m of text.matchAll(/\{\{#each\s+(\w+)\}\}/g)) if (!allowed.includes(m[1])) bad.add(m[1]);
  const flat = text.replace(/\{\{#each\s+\w+\}\}|\{\{\/each\}\}|\{\{this\.\w+\}\}/g, "");
  for (const m of flat.matchAll(/\{\{\s*([^{}]*?)\s*\}\}/g)) if (!allowed.includes(m[1])) bad.add(m[1]);
  return [...bad];
}

/** Mock render with sample data. Server-side rendering must HTML-escape values and sanitize the template. */
export function renderPreview(text: string): string {
  return text
    .replace(/\{\{#each\s+LOT_INFO\}\}([\s\S]*?)\{\{\/each\}\}/g, (_, inner: string) =>
      SAMPLE_LOTS.map((l) => inner.replace(/\{\{this\.(\w+)\}\}/g, (_m, k: string) => esc((l as Record<string, string>)[k] ?? ""))).join(""))
    .replace(/\{\{\s*(\w+)\s*\}\}/g, (m, k: string) => (k in SAMPLE ? (k === "IMAGE_URL" || k.endsWith("_URL") ? SAMPLE[k] : esc(SAMPLE[k])) : m));
}
