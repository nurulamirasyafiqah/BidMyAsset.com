/** Tiered bid increments (Admin → Company → Lot Bid Details). A lot without tiers uses its single increment. */
export type Tier = { from: number; increment: number };

/** The increment that applies when the current bid is `at`. */
export function incrementAt(increment: number, tiers: Tier[] | undefined, at: number): number {
  if (!tiers || tiers.length === 0) return increment;
  const sorted = [...tiers].sort((a, b) => a.from - b.from);
  let inc = sorted[0].increment;
  for (const t of sorted) if (t.from <= at) inc = t.increment;
  return inc > 0 ? inc : increment;
}
