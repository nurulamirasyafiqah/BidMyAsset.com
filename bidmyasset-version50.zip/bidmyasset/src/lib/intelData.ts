/**
 * Auction Intelligence data model. Everything is computed from real records: the auction's lots (Studio), every bid
 * (`bids`), the bidder registrations and the invoices issued for the auction. Nothing here is generated or estimated.
 *
 * Definitions (kept in one place so every report agrees):
 *  - A lot is "closed" once its closing time has passed (draft lots are ignored everywhere).
 *  - Reserve only applies when the auction is not Absolute (same rule as the backend's reserveOf).
 *  - SOLD     = closed, has bids, and the top bid meets the reserve (or there is no reserve).
 *  - PENDING  = closed, has bids, reserve not met, and the auction is "Subject to Confirmation" (the seller decides).
 *  - NO_SALE  = closed with no bids, or reserve not met in a Reserve auction.
 *  - OPEN     = not closed yet.
 *  - Bidder no. follows registration order in this auction (1 = first to register).
 */
import type { StudioAuction, StudioLot } from "@/lib/admin";
import { loadBids, loadMaxBids, loadRegistrations, studioLots, type BidRow, type MaxBidRow, type RegRow } from "@/lib/studioApi";

export type Bidder = { no: number; name: string; email: string; reg: "PENDING" | "APPROVED" | "REJECTED" | "NONE"; regAt: string; phone: string };
export type BidEv = { id: string; lotId: string; lotNo: number; lotTitle: string; ms: number; at: string; amount: number; bidder: Bidder; state: string };
export type MaxBidEv = { id: string; lotNo: number; lotTitle: string; ms: number; at: string; amount: number; bidder: Bidder };
export type Outcome = "SOLD" | "PENDING" | "NO_SALE" | "OPEN";
export type LotStat = {
  id: string; no: number; title: string; category: string; consignor: string; startBid: number; increment: number; reserve: number; image: string;
  closed: boolean; bids: BidEv[]; high: number; winner: Bidder | null; bidderCount: number; outcome: Outcome;
  reserveStatus: "No reserve" | "Reserve met" | "Reserve not met" | "No bids";
};
export type Money = { hammer: number; fees: number; tax: number; invoices: number; paid: number };
export type Intel = {
  auction: StudioAuction; currency: string; tz: string; absolute: boolean; subject: boolean;
  lots: LotStat[]; bids: BidEv[]; maxBids: MaxBidEv[]; bidders: Bidder[]; regs: RegRow[]; invoices: Money; startMs: number; endMs: number;
  /** Registered bidders who signed in while the auction ran (from the activity feed, which only keeps the last 31 days). */
  logins: Login[];
};
export type Login = { bidder: Bidder; count: number; first: number; last: number };

type InvRow = { auction: string; status: string; hammer: number; commission: number; internetFee: number; tax: number; amount: number };

type ActRow = { email: string; action: string; at: string };
async function loadActivity(): Promise<ActRow[]> {
  try {
    const res = await fetch("/api/admin/user-activity", { cache: "no-store" });
    if (!res.ok) return [];
    const j = (await res.json()) as { items?: ActRow[] } | ActRow[];
    return Array.isArray(j) ? j : j.items ?? [];
  } catch { return []; }
}

const key = (email: string, name: string) => (email || name).toLowerCase();

async function loadInvoices(auctionId: string): Promise<Money> {
  const zero: Money = { hammer: 0, fees: 0, tax: 0, invoices: 0, paid: 0 };
  try {
    const res = await fetch("/api/admin/invoices", { cache: "no-store" });
    if (!res.ok) return zero;
    const rows = ((await res.json()) as { items?: InvRow[] }).items ?? [];
    return rows.filter((r) => r.auction === auctionId).reduce<Money>((m, r) => ({
      hammer: m.hammer + (r.hammer || 0), fees: m.fees + (r.commission || 0) + (r.internetFee || 0), tax: m.tax + (r.tax || 0),
      invoices: m.invoices + 1, paid: m.paid + (r.status === "PAID" ? 1 : 0),
    }), zero);
  } catch { return zero; }
}

export function buildIntel(a: StudioAuction, lots: StudioLot[], bidRows: BidRow[], regs: RegRow[], invoices: Money, activity: ActRow[] = [], maxRows: MaxBidRow[] = []): Intel {
  const absolute = a.auctionType === "Absolute", subject = a.auctionType === "Subject to Confirmation";

  // bidders: registration order first, then anyone who bid without a registration row
  const bidders = new Map<string, Bidder>();
  [...regs].sort((x, y) => Date.parse(x.at) - Date.parse(y.at)).forEach((r) => {
    bidders.set(key(r.email, r.name), { no: bidders.size + 1, name: r.name, email: r.email, reg: r.status, regAt: r.at, phone: r.phone });
  });
  [...bidRows].reverse().forEach((b) => {
    const k = key(b.email, b.bidder);
    if (!bidders.has(k)) bidders.set(k, { no: bidders.size + 1, name: b.bidder, email: b.email, reg: "NONE", regAt: "", phone: "" });
  });

  const evs: BidEv[] = bidRows.map((b) => ({
    id: b.id, lotId: b.lot, lotNo: b.lotNo, lotTitle: b.lotTitle, ms: Date.parse(b.at), at: b.at, amount: b.amount,
    bidder: bidders.get(key(b.email, b.bidder))!, state: b.state,
  })).sort((x, y) => x.ms - y.ms || x.amount - y.amount);

  const live = lots.filter((l) => l.status !== "Draft");
  const stats: LotStat[] = live.map((l): LotStat => {
    const bids = evs.filter((e) => e.lotId === l.id);
    const top = bids.reduce<BidEv | null>((t, e) => (!t || e.amount > t.amount || (e.amount === t.amount && e.ms < t.ms) ? e : t), null);
    const reserve = absolute ? 0 : l.reserve || 0;
    const closed = l.status === "Closed";
    const high = top?.amount ?? 0;
    const met = !!top && (reserve === 0 || high >= reserve);
    const outcome: Outcome = !closed ? "OPEN" : !top ? "NO_SALE" : met ? "SOLD" : subject ? "PENDING" : "NO_SALE";
    return {
      id: l.id, no: l.no, title: l.title, category: l.category, consignor: l.consignor, startBid: l.startBid, increment: l.increment, reserve, image: l.images?.[0]?.url ?? "", closed, bids, high,
      winner: top?.bidder ?? null, bidderCount: new Set(bids.map((b) => b.bidder.no)).size, outcome,
      reserveStatus: reserve === 0 ? "No reserve" : !top ? "No bids" : high >= reserve ? "Reserve met" : "Reserve not met",
    };
  }).sort((x, y) => x.no - y.no);

  const startMs = Date.parse(a.startsAtIso ?? ""), endMs = Date.parse(a.endsAtIso ?? "");
  const byEmail = new Map([...bidders.values()].filter((b) => b.email).map((b) => [b.email.toLowerCase(), b]));
  const lg = new Map<string, Login>();
  activity.filter((r) => r.action === "Logged In").forEach((r) => {
    const b = byEmail.get((r.email || "").toLowerCase()), ms = Date.parse(r.at);
    if (!b || !Number.isFinite(ms) || ms < startMs || ms > endMs) return;
    const cur = lg.get(b.email) ?? { bidder: b, count: 0, first: ms, last: ms };
    cur.count++; cur.first = Math.min(cur.first, ms); cur.last = Math.max(cur.last, ms); lg.set(b.email, cur);
  });

  const maxBids: MaxBidEv[] = maxRows.flatMap((m) => {
    const bidder = bidders.get(key(m.email, m.bidder));
    return bidder ? [{ id: m.id, lotNo: m.lotNo, lotTitle: m.lotTitle, ms: Date.parse(m.at), at: m.at, amount: m.amount, bidder }] : [];
  }).sort((x, y) => x.ms - y.ms);

  return {
    auction: a, currency: a.currency || "MYR", tz: a.tz || "Asia/Kuala_Lumpur", absolute, subject, lots: stats, bids: evs, maxBids, bidders: [...bidders.values()],
    regs, invoices, startMs, endMs, logins: [...lg.values()].sort((x, y) => x.bidder.no - y.bidder.no),
  };
}

/** Loads bids, registrations and invoices for one auction and builds the model. */
export async function loadIntel(a: StudioAuction): Promise<Intel> {
  const [bidRows, reg, inv, act, maxRows] = await Promise.all([loadBids(a.id), loadRegistrations(a.id).then((r) => r.items), loadInvoices(a.id), loadActivity(), loadMaxBids(a.id).catch(() => [] as MaxBidRow[])]);
  return buildIntel(a, studioLots.get(a.id) ?? [], bidRows, reg, inv, act, maxRows);
}

/* ---------- shared formatting ---------- */
export const fmtMoney = (n: number, cur = "MYR") => { try { return new Intl.NumberFormat("en-US", { style: "currency", currency: cur }).format(n); } catch { return `${cur} ${n.toLocaleString()}`; } };
export const fmtWhen = (ms: number, tz = "Asia/Kuala_Lumpur") => Number.isFinite(ms)
  ? new Date(ms).toLocaleString("en-GB", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).replace(",", "") : "—";
export const bidderLabel = (b: Bidder | null) => (b ? `#${b.no} ${b.name}` : "—");
export const pct = (n: number, d: number) => (d > 0 ? `${Math.round((n / d) * 1000) / 10}%` : "—");

/** Bids per bucket across the auction window (hourly if ≤ 3 days, else daily). */
export function bidsOverTime(m: Intel) {
  if (!m.bids.length) return [] as { label: string; n: number; ms: number }[];
  const first = m.bids[0].ms, last = m.bids[m.bids.length - 1].ms;
  const step = last - first <= 3 * 86400000 ? 3600000 : 86400000;
  const from = Math.floor(first / step) * step;
  const out: { label: string; n: number; ms: number }[] = [];
  for (let t = from; t <= last; t += step) out.push({ ms: t, n: 0, label: new Date(t).toLocaleString("en-GB", { timeZone: m.tz, day: "2-digit", month: "short", ...(step === 3600000 ? { hour: "2-digit", hourCycle: "h23" as const } : {}) }) });
  m.bids.forEach((b) => { out[Math.floor((b.ms - from) / step)].n++; });
  return out;
}
