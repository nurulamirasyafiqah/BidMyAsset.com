"use client";
/**
 * Admin → Company data layer. One GET loads the profile and every section; each edit is saved with a PUT
 * (/api/admin/company → PocketBase `company`). Edits show immediately, are sent in order, and are rolled back
 * to the server copy if a save fails.
 */
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { RefreshCw } from "lucide-react";
import { Btn } from "@/components/admin/ui";

export type CompanyInfo = { name: string; email: string; phone: string; line1: string; line2: string; city: string; state: string; postal: string; country: string };
export const BLANK_COMPANY: CompanyInfo = { name: "", email: "", phone: "", line1: "", line2: "", city: "", state: "", postal: "", country: "" };

type Doc = { exists: boolean; company: CompanyInfo; data: Record<string, unknown> };

type Ctx = {
  doc: Doc | null;
  loading: boolean;
  saving: boolean;
  error: string;
  clearError: () => void;
  reload: () => Promise<void>;
  /** "" on success, otherwise the reason it was not saved. */
  saveCompany: (c: CompanyInfo) => Promise<string>;
  setSection: (key: string, value: unknown) => void;
  read: (key: string) => unknown;
};

const Context = createContext<Ctx | null>(null);

export function useCompany(): Ctx {
  const c = useContext(Context);
  if (!c) throw new Error("useCompany must be used inside <CompanyProvider>");
  return c;
}

const normalize = (j: Partial<Doc> | null): Doc => ({ exists: !!j?.exists, company: { ...BLANK_COMPANY, ...(j?.company ?? {}) }, data: j?.data ?? {} });

async function request(method: "GET" | "PUT", body?: unknown): Promise<Doc> {
  const res = await fetch("/api/admin/company", {
    method, cache: "no-store",
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const j = (await res.json().catch(() => null)) as (Partial<Doc> & { message?: string }) | null;
  if (!res.ok) throw new Error(j?.message || `Request failed (${res.status})`);
  return normalize(j);
}

const msg = (e: unknown, fallback: string) => (e instanceof Error && e.message ? e.message : fallback);

export function CompanyProvider({ children }: { children: ReactNode }) {
  const [doc, setDoc] = useState<Doc | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const docRef = useRef<Doc | null>(null);
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const inflight = useRef(0);

  const apply = useCallback((d: Doc | null) => { docRef.current = d; setDoc(d); }, []);

  const reload = useCallback(async () => {
    setLoading(true);
    try { apply(await request("GET")); setError(""); }
    catch (e) { setError(msg(e, "Could not load the company.")); }
    finally { setLoading(false); }
  }, [apply]);

  useEffect(() => { void reload(); }, [reload]);

  const send = useCallback((body: Record<string, unknown>, optimistic: (d: Doc) => Doc, report: boolean): Promise<string> => {
    if (docRef.current) apply(optimistic(docRef.current));
    inflight.current++;
    setSaving(true);
    const run = queue.current.then(async () => {
      try {
        const d = await request("PUT", body);
        if (inflight.current === 1) apply(d);   // adopt the server copy (computed fields) once nothing newer is queued
        return "";
      } catch (e) {
        const m = msg(e, "Could not save.");
        if (report) setError(m);
        try { if (inflight.current === 1) apply(await request("GET")); } catch { /* keep what we have */ }
        return m;
      } finally {
        inflight.current--;
        if (inflight.current === 0) setSaving(false);
      }
    });
    queue.current = run;
    return run;
  }, [apply]);

  const setSection = useCallback((key: string, value: unknown) => {
    void send({ [key]: value }, (d) => ({ ...d, data: { ...d.data, [key]: value } }), true);
  }, [send]);

  const saveCompany = useCallback((c: CompanyInfo) => send({ company: c }, (d) => ({ ...d, exists: true, company: c }), false), [send]);
  const read = useCallback((key: string) => docRef.current?.data[key], []);

  return (
    <Context.Provider value={{ doc, loading, saving, error, clearError: () => setError(""), reload, saveCompany, setSection, read }}>
      {children}
    </Context.Provider>
  );
}

/** A stored Company section: [value, setter]. `empty` is used until something has been saved. The setter accepts a value or an updater. */
export function useSection<T>(key: string, empty: T): [T, (next: T | ((prev: T) => T)) => void] {
  const c = useCompany();
  const emptyRef = useRef(empty);
  const raw = c.doc?.data[key];
  const value = (raw === undefined ? empty : raw) as T;
  const { read, setSection } = c;
  const set = useCallback((next: T | ((prev: T) => T)) => {
    const cur = read(key);
    const prev = (cur === undefined ? emptyRef.current : cur) as T;
    setSection(key, typeof next === "function" ? (next as (p: T) => T)(prev) : next);
  }, [read, setSection, key]);
  return [value, set];
}

export function ReloadBtn({ small = false }: { small?: boolean }) {
  const { loading, reload } = useCompany();
  return (
    <Btn className={small ? "h-8 text-xs" : undefined} disabled={loading} onClick={() => void reload()}>
      <RefreshCw className={`${small ? "size-3.5" : "size-4"} ${loading ? "animate-spin" : ""}`} />Refresh
    </Btn>
  );
}
