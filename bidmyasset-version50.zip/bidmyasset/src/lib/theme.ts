// Server-safe (no "use client") so app/layout.tsx can inline the boot script.
export const THEME_KEY = "bma:theme";

/** Runs before first paint so dark mode doesn't flash. */
export const THEME_BOOT = `try{var t=localStorage.getItem("${THEME_KEY}")||"system";var d=t==="dark"||(t==="system"&&matchMedia("(prefers-color-scheme: dark)").matches);document.documentElement.dataset.theme=d?"dark":"light"}catch(e){}`;
