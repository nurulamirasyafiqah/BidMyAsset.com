/** Auctions + lots from the backend. Server-side only. */
import type { Auction, Lot, LocationLot } from "./data";
import { iso, pbAll, type PBRecord } from "./pb";

const num = (v: unknown) => Number(v ?? 0);
const str = (v: unknown) => String(v ?? "");
/** PocketBase file names → same-origin image URLs (served through /api/pb, cached; ?v busts the cache on change). */
const imgs = (col: string, r: PBRecord) =>
  (Array.isArray(r.images) ? (r.images as string[]) : []).map((f) => `/api/pb/api/files/${col}/${r.id}/${encodeURIComponent(f)}?v=${encodeURIComponent(str(r.updated))}`);

function toAuction(r: PBRecord): Auction {
  const lat = num(r.lat), lng = num(r.lng);
  return {
    slug: str(r.slug), sequence: num(r.sequence), title: str(r.title),
    startsAt: iso(r.startsAt), endsAt: iso(r.endsAt),
    timezone: str(r.timezone), currency: str(r.currency),
    city: str(r.city), region: str(r.region),
    coords: lat || lng ? { lat, lng } : undefined,
    lotCount: num(r.lotCount), bidCount: num(r.bidCount), imageCount: imgs("auctions", r).length || num(r.imageCount), images: imgs("auctions", r),
    tone: num(r.tone), category: str(r.category), subcategory: str(r.subcategory),
  };
}

function tiersOf(v: unknown): { from: number; increment: number }[] | undefined {
  let x = v;
  if (typeof x === "string") { try { x = JSON.parse(x); } catch { return undefined; } }
  if (!Array.isArray(x)) return undefined;
  const out = x.flatMap((t) => (t && typeof t === "object" && Number((t as { increment?: unknown }).increment) > 0 ? [{ from: Number((t as { from?: unknown }).from) || 0, increment: Number((t as { increment: unknown }).increment) }] : []));
  return out.length ? out.sort((a, b) => a.from - b.from) : undefined;
}

function toLot(r: PBRecord, auctionSlug: string): Lot {
  return {
    id: r.id, auctionSlug, lotNumber: num(r.lotNumber), title: str(r.title),
    description: str(r.description) || undefined,
    category: str(r.category), subcategory: str(r.subcategory), sku: str(r.sku),
    quantity: num(r.quantity), startingBid: num(r.startingBid), increment: num(r.increment),
    incrementMatrix: tiersOf(r.incrementMatrix),
    bidCount: num(r.bidCount), currentBid: r.bidCount ? num(r.currentBid) : undefined,
    addedOrder: num(r.addedOrder), images: imgs("lots", r),
  };
}

export async function listAuctions(): Promise<Auction[]> {
  return (await pbAll("auctions", { sort: "-sequence" })).map(toAuction);
}
/** Live + upcoming. */
export async function listActive(now = Date.now()) {
  return (await listAuctions()).filter((a) => new Date(a.endsAt).getTime() > now);
}
export async function listArchived(now = Date.now()) {
  return (await listAuctions()).filter((a) => new Date(a.endsAt).getTime() <= now);
}
export async function getAuction(slug: string) {
  const r = await pbAll("auctions", { filter: `slug="${slug.replace(/[^a-z0-9-]/gi, "")}"` });
  return r[0] ? toAuction(r[0]) : undefined;
}
export async function getLots(slug: string): Promise<Lot[]> {
  const a = (await pbAll("auctions", { filter: `slug="${slug.replace(/[^a-z0-9-]/gi, "")}"` }))[0];
  if (!a) return [];
  return (await pbAll("lots", { filter: `auction="${a.id}"`, sort: "addedOrder" })).map((r) => toLot(r, slug));
}
export async function getLot(slug: string, lotNumber: number) {
  return (await getLots(slug)).find((l) => l.lotNumber === lotNumber);
}

/**
 * Lots that have a physical location (the lot's address is set), in auctions that have not closed yet, for the
 * calendar's "Location Lots" tab. Draft lots are skipped; the address itself is not returned, only the auction's city / region.
 */
export async function listLocationLots(now = Date.now()): Promise<LocationLot[]> {
  const auctions = (await pbAll("auctions")).filter((a) => new Date(iso(a.endsAt)).getTime() > now);
  if (!auctions.length) return [];
  const byId = new Map(auctions.map((a) => [a.id, a]));
  const lots = await pbAll("lots", { filter: 'address != "" && draft != true', sort: "lotNumber" });
  const out: LocationLot[] = [];
  for (const l of lots) {
    const a = byId.get(str(l.auction));
    if (!a) continue;
    const own = str(l.endsAt).trim();
    const lotImgs = imgs("lots", l);
    out.push({
      id: l.id, auctionSlug: str(a.slug), auctionTitle: str(a.title), lotNumber: num(l.lotNumber), title: str(l.title), image: lotImgs[0],
      city: str(a.city), region: str(a.region), timezone: str(a.timezone), startsAt: iso(a.startsAt), endsAt: own ? iso(own) : iso(a.endsAt),
    });
  }
  return out;
}
