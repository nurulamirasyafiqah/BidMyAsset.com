// Auction House → Overview settings (see Auction_house.docx, legacy admin screenshots).
// PERSISTED (PocketBase `house` record): profile + branding, internet buying fee (`fee`), theming (`theme`),
//   legal policies (`legal`) and the category library selection (`categories`).
//   fee + theme + legal + categories: GET/PUT /api/admin/house/settings → backend/house_settings.go, which re-validates every value.
//   The public site reads both from the same record (lib/brand.ts → lib/themeCss.ts).
// SMTP and payment credentials are stored by backend/integrations.go (secrets never come back to the browser).
// (old note) SMTP, payment credentials. Secrets (SMTP password, payment secret key) must NEVER be
// returned to the browser: the API returns only "is set" flags, and an empty field on save means "keep the existing value".
// Everything that ends up on the public site (description, legal HTML, theme values) must be
// sanitized / validated server-side (HTML allowlist, CSS value allowlist), not only here.

export type ButtonStyle = {
  background: string; text: string; border: string; radius: string; fontSize: string; fontWeight: string;
  padding: string; shadow: string; hoverBackground: string; hoverText: string; hoverBorder: string; hoverShadow: string;
};
export type ButtonKey = "primary" | "secondary" | "outline";
// Dialog theme: how modals look on the public site. Values are CSS strings, validated with isCssValue.
export type DialogStyle = {
  background: string; border: string; text: string; radius: string; shadow: string;
  headerPadding: string; headerGap: string; titleFontSize: string; titleFontWeight: string;
  contentPadding: string; footerPadding: string; footerGap: string;
};
export const defaultDialog: DialogStyle = {
  background: "#ffffff", border: "rgba(226, 232, 240, 0.6)", text: "#0f172a", radius: "12px", shadow: "0 20px 60px rgba(15, 23, 42, 0.12)",
  headerPadding: "1.5rem", headerGap: "0.5rem", titleFontSize: "1.25rem", titleFontWeight: "600",
  contentPadding: "0 1.5rem 1.5rem 1.5rem", footerPadding: "0 1.5rem 1.5rem 1.5rem", footerGap: "0.5rem",
};
// Internet buying fee structures (legacy admin: Auction_house dialogs). Amounts (cap, upTo, from) are in the
// auction's own currency, which is applied when the auction is created, so no currency is stored here.
export type Fee =
  | { kind: "flat_pct"; rate: number }
  | { kind: "flat_cap"; rate: number; cap: number }
  | { kind: "flat_cap_online"; rate: number; cap: number; online: number }
  | { kind: "tier_pct"; first: number; upTo: number; balance: number }
  | { kind: "tier_pct_cap"; first: number; upTo: number; balance: number; cap: number }
  | { kind: "tier_flat"; first: number; upTo: number; second: number; from: number };
export type FeeKind = Fee["kind"];
export type FeeField = { key: string; label: string; pct?: boolean };

export const FEE_DEFS: { kind: FeeKind; label: string; fields: FeeField[] }[] = [
  { kind: "flat_pct", label: "Flat percentage rate", fields: [{ key: "rate", label: "Rate (%)", pct: true }] },
  { kind: "flat_cap", label: "Flat rate with cap (per item)", fields: [{ key: "rate", label: "Rate (%)", pct: true }, { key: "cap", label: "Cap per item" }] },
  { kind: "flat_cap_online", label: "Flat with cap + online fee", fields: [{ key: "rate", label: "Rate (%)", pct: true }, { key: "cap", label: "Cap" }, { key: "online", label: "Online fee (%)", pct: true }] },
  { kind: "tier_pct", label: "Tiered percentage rate", fields: [{ key: "first", label: "First tier %", pct: true }, { key: "upTo", label: "First tier up to" }, { key: "balance", label: "Balance %", pct: true }] },
  { kind: "tier_pct_cap", label: "Tiered % with cap", fields: [{ key: "first", label: "First tier %", pct: true }, { key: "upTo", label: "First tier up to" }, { key: "balance", label: "Balance %", pct: true }, { key: "cap", label: "Cap" }] },
  { kind: "tier_flat", label: "Tiered flat % rate", fields: [{ key: "first", label: "First tier %", pct: true }, { key: "upTo", label: "Up to" }, { key: "second", label: "Second tier %", pct: true }, { key: "from", label: "From amount" }] },
];

/** "" when valid; otherwise why this value is not accepted. */
export const feeValueError = (f: FeeField, v: string): string => {
  if (v.trim() === "") return "Required.";
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return "Enter a number of 0 or more.";
  if (f.pct && n > 100) return "A percentage can’t be more than 100.";
  return "";
};

export type LegalPolicy = { id: string; name: string; privacy: string; terms: string };

export type House = {
  name: string; website: string; domain: string; supportEmail: string; supportPhone: string;
  facebook: string; twitter: string; linkedin: string; whatsapp: string; gaId: string; description: string;
  logoName: string; faviconName: string; bannerCount: number;
  logoUrl?: string; faviconUrl?: string; bannerUrls?: string[];
  smtp: { host: string; port: string; username: string; passwordSet: boolean; from: string; fromName: string };
  fee: Fee | null;
  theme: { primary: string; secondary: string; ratings: boolean; buttons: Record<ButtonKey, ButtonStyle>; dialog: DialogStyle };
  payment: { defaultGateway: boolean; secretSet: boolean; categoryCode: string; sandbox: boolean };
  legal: LegalPolicy[];
  /** Category library selection: category → enabled subcategories. null = never configured (public filter shows everything). */
  categories: CategorySelection | null;
};
export type CategorySelection = Record<string, string[]>;

const base = { border: "transparent", radius: "12px", fontSize: "0.88rem", fontWeight: "600", padding: "10px 18px", shadow: "none" };
export const defaultButtons: Record<ButtonKey, ButtonStyle> = {
  primary: { ...base, background: "#0F172A", text: "#ffffff", hoverBackground: "#1D4ED8", hoverText: "#ffffff", hoverBorder: "transparent", hoverShadow: "0 16px 28px rgba(29,78,216,0.25)" },
  secondary: { ...base, background: "#475569", text: "#ffffff", hoverBackground: "rgba(71,85,105,0.9)", hoverText: "#ffffff", hoverBorder: "rgba(203,213,225,0.5)", hoverShadow: "none" },
  outline: { ...base, background: "transparent", text: "#0F172A", border: "#0F172A", hoverBackground: "#0F172A", hoverText: "#ffffff", hoverBorder: "#0F172A", hoverShadow: "0 10px 18px rgba(15,23,42,0.2)" },
};

export const initialHouse: House = {
  name: "BidMyAsset", website: "https://bidmyasset.com", domain: "bidmyasset.com",
  supportEmail: "support@bidmyasset.com", supportPhone: "6045024643",
  facebook: "", twitter: "", linkedin: "", whatsapp: "60178792246", gaId: "",
  description: "Malaysia’s Industrial Asset, Heavy Machinery & Auction Marketplace",
  logoName: "", faviconName: "", bannerCount: 0,
  smtp: { host: "", port: "", username: "", passwordSet: false, from: "", fromName: "" },
  fee: null,
  theme: { primary: "", secondary: "", ratings: false, buttons: defaultButtons, dialog: defaultDialog },
  payment: { defaultGateway: true, secretSet: false, categoryCode: "", sandbox: false },
  legal: [],
  categories: null,
};

// ---------- validators (return an error string, or "" when valid) ----------
export const isUrl = (v: string) => /^https?:\/\/[^\s/$.?#][^\s]*$/i.test(v);
export const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
export const isPhone = (v: string) => /^\+?[0-9]{6,15}$/.test(v.replace(/[\s-]/g, ""));
export const isColor = (v: string) => v === "" || /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v);
export const isGaId = (v: string) => v === "" || /^(G|UA|GTM)-[A-Z0-9-]+$/i.test(v);
// Theme values land in CSS on the public site: allow only simple tokens (no url(), no ;, no braces, no expression()).
export const isCssValue = (v: string) => v.length <= 80 && /^[#a-zA-Z0-9\s.,%()\-+/]*$/.test(v) && !/url\s*\(|expression\s*\(|import/i.test(v);

export const IMAGE_MAX_BYTES = 2 * 1024 * 1024;
export const imageError = (f: File | undefined) =>
  !f ? "" : !/^image\/(png|jpe?g|webp|svg\+xml)$/.test(f.type) ? "Use a PNG, JPG, WebP or SVG image." : f.size > IMAGE_MAX_BYTES ? "Image must be 2 MB or smaller." : "";

/** Button colours also accept transparent / none / rgb(a)(...) (hover fills, outline backgrounds). */
export const isButtonColor = (v: string) => isColor(v) || /^(transparent|none|rgba?\([\d\s.,%]+\))$/i.test(v);

const BTN_COLOR_KEYS: (keyof ButtonStyle)[] = ["background", "text", "border", "hoverBackground", "hoverText", "hoverBorder"];
const DLG_COLOR_KEYS: (keyof DialogStyle)[] = ["background", "border", "text"];
/** PocketBase may hand the setting back as a JSON string (text field) or as parsed JSON: accept both. */
const unjson = (v: unknown): unknown => { if (typeof v !== "string") return v; try { return JSON.parse(v); } catch { return null; } };
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

/** Saved fee (JSON from the server) → Fee, or null when nothing valid is stored. */
export function parseFee(raw: unknown): Fee | null {
  const v = unjson(raw);
  if (!isObj(v)) return null;
  const def = FEE_DEFS.find((d) => d.kind === v.kind);
  if (!def) return null;
  const out: Record<string, unknown> = { kind: def.kind };
  for (const f of def.fields) {
    const n = v[f.key];
    if (typeof n !== "number" || !Number.isFinite(n) || n < 0 || (f.pct && n > 100)) return null;
    out[f.key] = n;
  }
  return out as Fee;
}

/** Saved legal policies (JSON from the server; the backend already cleaned the HTML). */
export function parseLegal(raw: unknown): LegalPolicy[] {
  const v = unjson(raw);
  if (!Array.isArray(v)) return [];
  return v.flatMap((x) => {
    if (!isObj(x) || typeof x.id !== "string" || typeof x.name !== "string") return [];
    return [{ id: x.id, name: x.name, privacy: typeof x.privacy === "string" ? x.privacy : "", terms: typeof x.terms === "string" ? x.terms : "" }];
  });
}

/** Saved category selection → { category: [subcategory] }, or null when none was ever saved. */
export function parseCategories(raw: unknown): CategorySelection | null {
  const v = unjson(raw);
  if (!isObj(v)) return null;
  const out: CategorySelection = {};
  for (const [cat, subs] of Object.entries(v)) {
    if (Array.isArray(subs)) out[cat] = subs.filter((s): s is string => typeof s === "string");
  }
  return out;
}

/** Saved theme (JSON from the server) laid over the defaults. Invalid or missing values fall back to the default. */
export function mergeTheme(raw: unknown): House["theme"] {
  const v = unjson(raw);
  const base = initialHouse.theme;
  if (!isObj(v)) return { ...base, buttons: { ...defaultButtons }, dialog: { ...defaultDialog } };
  const buttons = { ...defaultButtons };
  const bv = isObj(v.buttons) ? v.buttons : {};
  for (const k of ["primary", "secondary", "outline"] as ButtonKey[]) {
    const src = bv[k];
    if (!isObj(src)) continue;
    const next = { ...defaultButtons[k] };
    for (const f of Object.keys(next) as (keyof ButtonStyle)[]) {
      const x = src[f];
      if (typeof x !== "string") continue;
      if (BTN_COLOR_KEYS.includes(f) ? isButtonColor(x) : isCssValue(x)) next[f] = x;
    }
    buttons[k] = next;
  }
  const dialog = { ...defaultDialog };
  if (isObj(v.dialog)) {
    for (const f of Object.keys(dialog) as (keyof DialogStyle)[]) {
      const x = v.dialog[f];
      if (typeof x !== "string") continue;
      if (DLG_COLOR_KEYS.includes(f) ? isButtonColor(x) : isCssValue(x)) dialog[f] = x;
    }
  }
  return {
    primary: typeof v.primary === "string" && isColor(v.primary) ? v.primary : "",
    secondary: typeof v.secondary === "string" && isColor(v.secondary) ? v.secondary : "",
    ratings: v.ratings === true,
    buttons, dialog,
  };
}

/** Server record (PocketBase `house` via /api/admin/house) → House fields. Image URLs go through the same-origin file proxy. */
export type HouseRecord = Partial<Pick<House, "name" | "website" | "supportEmail" | "supportPhone" | "facebook" | "twitter" | "linkedin" | "whatsapp" | "gaId" | "description" | "logoName" | "faviconName" | "logoUrl" | "faviconUrl" | "bannerUrls">> & { fee?: unknown; theme?: unknown; legal?: unknown; categories?: unknown };
export const fromRecord = (r: HouseRecord): Partial<House> => {
  const u = (x?: string) => (x ? `/api/pb${x}` : "");
  const out: Partial<House> = { logoUrl: u(r.logoUrl), faviconUrl: u(r.faviconUrl), bannerUrls: (r.bannerUrls ?? []).map(u), logoName: r.logoName ?? "", faviconName: r.faviconName ?? "" };
  out.bannerCount = out.bannerUrls!.length;
  for (const k of ["name", "website", "supportEmail", "supportPhone", "facebook", "twitter", "linkedin", "whatsapp", "gaId", "description"] as const) if (typeof r[k] === "string") out[k] = r[k] as string; // "" is a real value: a cleared field must stay cleared
  if ("fee" in r) out.fee = parseFee(r.fee);
  if ("theme" in r) out.theme = mergeTheme(r.theme);
  if ("legal" in r) out.legal = parseLegal(r.legal);
  if ("categories" in r) out.categories = parseCategories(r.categories);
  return out;
};

/** Response of GET/PUT /api/admin/house/settings → the two settings it carries (never touches logo / banners). */
export type SettingsDoc = { fee?: unknown; theme?: unknown; legal?: unknown; categories?: unknown; example?: { hammer: number; commission: number; internetFee: number; fees: number; total: number } };
export const settingsFromDoc = (r: SettingsDoc): Pick<House, "fee" | "theme" | "legal" | "categories"> => ({
  fee: parseFee(r.fee), theme: mergeTheme(r.theme), legal: parseLegal(r.legal), categories: parseCategories(r.categories),
});
