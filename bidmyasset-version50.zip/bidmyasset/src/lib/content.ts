/** Static marketing copy lifted from the design document. */

export const CONTACT = {
  phone: "6045024643",
  email: "support@bidmyasset.com",
};

export const services = [
  { title: "Buy Equipment", text: "Competitive machinery auctions across all industries.", icon: "arrow" },
  { title: "Sell Equipment", text: "Reach a global buyer base and maximise returns.", icon: "tag" },
  { title: "Dismantling Services", text: "Precision removal by certified dismantling crews.", icon: "wrench" },
  { title: "Insurance", text: "Full coverage from transit to operational risk.", icon: "shield" },
  { title: "Asset Valuation", text: "Professional appraisal for informed decisions.", icon: "scale" },
  { title: "Transportation", text: "Door-to-door logistics for every asset you win.", icon: "truck" },
  { title: "ESG Reporting", text: "Sustainability data to support compliant operations.", icon: "leaf" },
  { title: "Secure Payment", text: "Hardened rails and escrow for every transaction.", icon: "lock" },
] as const;

export const aboutStats = [
  { value: "20", label: "Years · Proven track record" },
  { value: "98%", label: "Customer satisfaction" },
  { value: "1,500+", label: "Projects completed" },
  { value: "3 min", label: "Avg. response time" },
];

export const aboutPillars = [
  { eyebrow: "Trusted platform", title: "Transparent & Secure", text: "Every auction is backed by hardened payment rails and clear manifests.", icon: "shield" },
  { eyebrow: "Global reach", title: "Southeast Asia & Beyond", text: "Connect with buyers and sellers across Malaysia, Thailand, and the wider region.", icon: "globe" },
  { eyebrow: "Sustainability", title: "Giving Assets a 2nd Life", text: "Reducing carbon footprint by keeping industrial equipment in active use longer.", icon: "leaf" },
] as const;

export const insights = [
  { tag: "BLOG", title: "Save Big with Quality: The Benefits of Buying Used Construction Equipment", text: "Explore how pre-owned machinery can lower costs while delivering the performance your business…" },
  { tag: "BLOG", title: "Heavy Equipment: The Foundation of Construction in Today’s World", text: "A deep dive into the machinery that keeps modern construction projects on schedule and on budget." },
  { tag: "NEWS", title: "Podcast at BFM 89.9", text: "BidMyAsset joined BFM 89.9 to introduce its innovative auction platform and discuss the future of industrial assets." },
];

export const numbers = [
  { label: "Countries sourced", value: "13+" },
  { label: "Industrial assets listed", value: "5,000+" },
  { label: "Qualified bidders worldwide", value: "12,000+" },
  { label: "Trusted by enterprise sellers", value: "200+" },
];

export const countries = [
  "Malaysia", "Thailand", "Vietnam", "Singapore", "Indonesia",
  "Philippines", "India", "Bangladesh", "China", "Japan",
  "Germany", "United Kingdom", "USA",
];

export const buyerPoints = [
  "No middlemen markup",
  "Photos, audits, site visits",
  "Competitive market pricing",
  "Direct from operators",
];

export const whyCards = [
  { title: "Verified quality & transparency", text: "Expert appraisals and fair market value estimations — you pay a competitive price grounded in real data, never guesswork.", icon: "eye" },
  { title: "Global sourcing made simple", text: "A network spanning 13+ countries including Malaysia, Thailand, Vietnam, India and Germany. We find the assets you need, wherever they are.", icon: "globe" },
  { title: "Full transaction security", text: "Buy with confidence using our secure escrow services. Your funds are protected until the deal is finalised and you have receipt.", icon: "lock" },
  { title: "End-to-end logistics", text: "Dismantling, packing, domestic delivery, export — we handle the heavy lifting so your new assets arrive at site ready to work.", icon: "truck" },
  { title: "A sustainable choice", text: "Buying used machinery is more than smart finance. It’s an ESG-aligned decision that advances the circular economy and reduces your carbon footprint.", icon: "leaf" },
  { title: "Built on professional standards", text: "Bidding governed by clear, audit-friendly processes. Compete on a level playing field with institutional and SME buyers alike.", icon: "award" },
] as const;

export const processSteps = [
  { title: "Discover", text: "Browse our dynamic online auction platform — CNC machines, injection molders, refrigeration plants, tire manufacturing lines and more.", icon: "compass" },
  { title: "Due diligence", text: "Schedule physical site visits and receive detailed asset audits. Verify the equipment before you place a single bid.", icon: "shield" },
  { title: "Bid & win", text: "Participate in live, competitive auctions where the process is clear, transparent, and governed by professional standards.", icon: "gavel" },
  { title: "Receive", text: "Once the transaction completes, our logistics team manages handover and site clearance — seamless from gavel to gate.", icon: "package" },
] as const;

/* Leadership ------------------------------------------------------ */

export type Person = { name: string; role: string; photo?: string; linkedin?: string };

/** Fallback only: the live list is Admin → Team (PocketBase `team_members`, see lib/team.ts). Used when the backend is unreachable. */

export const leadership: Person[] = [
  { name: "Jeevan Muniandy", role: "Group Managing Director" },
  { name: "Shaik Othman", role: "Group Executive Director" },
  { name: "Dato Mohd Hashim", role: "Group Director" },
  { name: "Siraj A. Razack", role: "Group Director" },
  { name: "A. Safwan Rashdan", role: "Group Technical Director" },
  { name: "Kevin Parmar", role: "Managing Director, BidMyAsset" },
  { name: "Amirul Annuar", role: "Regional Director, East Malaysia" },
  { name: "Nirmal Kumar", role: "India Coordinator" },
];

export const advisors: Person[] = [
  { name: "A. Vijayasuria", role: "Finance & Compliance Strategic Advisor" },
  { name: "Ashvin", role: "Business Processes Advisor" },
  { name: "JP Vincent", role: "MNC Strategic Advisor" },
];

export const management: Person[] = [
  { name: "S.N Janaki", role: "Operations & General Manager" },
  { name: "Wattanapong Sangkavadee", role: "Project & Decommissioning Manager" },
  { name: "Nur Dalila", role: "Project Manager" },
  { name: "Abdul Rahman Omar", role: "Technical Operations Manager" },
  { name: "Nurhayatee Arong", role: "Digital Presence Manager" },
  { name: "Arvindran Sandrasagran", role: "Business Development Manager" },
  { name: "Rajeev Rao", role: "Marketing & Communications Manager" },
  { name: "Nurul Mardhiya", role: "Sales & Marketing Executive" },
  { name: "Ira Fardina", role: "Sales & Marketing Executive" },
  { name: "Lekha Suresh", role: "Digital Platform & Systems Executive" },
];

export const groupEntities = [
  "BidMyAsset Resources (M) Sdn Bhd",
  "BidMyAsset Borneo Sdn Bhd",
  "BidMyAsset Thailand Co., Ltd",
  "BidMyAsset India",
  "BidMyAsset Vietnam",
];

export const regions = ["Malaysia", "Thailand", "Borneo", "India", "Vietnam"];

/** Where each region sits on the Leadership map (the city the operating entity is based in; approximate). */
export const regionPoints: { name: string; city: string; lat: number; lng: number }[] = [
  { name: "Malaysia", city: "Kuala Lumpur", lat: 3.139, lng: 101.687 },
  { name: "Thailand", city: "Bangkok", lat: 13.756, lng: 100.502 },
  { name: "Borneo", city: "Kuching", lat: 1.553, lng: 110.359 },
  { name: "India", city: "New Delhi", lat: 28.614, lng: 77.209 },
  { name: "Vietnam", city: "Ho Chi Minh City", lat: 10.823, lng: 106.63 },
];

export const coreOperations = [
  { title: "Industrial Asset Disposal", text: "Structured disposal programs for industrial, commercial and corporate assets." },
  { title: "Industrial Auctions", text: "Physical and online auction management for industrial asset sales." },
  { title: "Plant Decommissioning", text: "Safe, compliant and efficient plant retirement projects." },
  { title: "Valuation & Appraisal", text: "Professional valuation services for machinery, equipment and facilities." },
  { title: "Asset Recovery Solutions", text: "Maximizing value recovery from distressed and surplus assets." },
  { title: "Machinery & Equipment Remarketing", text: "Strategic remarketing programs for industrial assets." },
  { title: "Cross-Border Asset Solutions", text: "Regional asset sales and recovery across multiple jurisdictions." },
  { title: "Project & Plant Closure Management", text: "End-to-end management of plant shutdown and closure projects." },
  { title: "Industrial Asset Advisory", text: "Strategic advice on asset optimization and disposal planning." },
  { title: "Surplus Inventory Management", text: "Efficient management and monetization of excess inventory." },
  { title: "Distressed Asset Management", text: "Specialized solutions for insolvency and restructuring." },
  { title: "Salvage & Scrap Recovery", text: "Recovery and monetization of salvageable industrial materials." },
];

