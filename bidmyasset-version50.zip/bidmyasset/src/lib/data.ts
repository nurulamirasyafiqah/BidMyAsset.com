/**
 * Types + helpers shared with the UI. Auctions and lots come from the backend through lib/api-data.ts.
 * Shapes follow the blueprint: Project → Auction → Lot, with per-auction
 * currency + timezone (never hard-coded globally).
 */

export type AuctionStatus = "LIVE" | "UPCOMING" | "CLOSED";

export type Auction = {
  slug: string;
  sequence: number;
  title: string;
  startsAt: string; // ISO
  endsAt: string; // ISO
  timezone: string; // IANA
  currency: string; // ISO 4217
  city: string;
  region: string;
  coords?: { lat: number; lng: number };
  lotCount: number;
  bidCount: number;
  imageCount: number;
  tone: number; // placeholder gradient index
  images?: string[]; // uploaded cover images (same-origin URLs); first = cover
  category: string;
  subcategory: string;
};

export type Lot = {
  id: string;
  auctionSlug: string;
  lotNumber: number;
  title: string;
  description?: string;
  category: string;
  subcategory: string;
  sku: string;
  quantity: number;
  startingBid: number;
  increment: number;
  incrementMatrix?: { from: number; increment: number }[]; // tiered increments (Company → Lot Bid Details); empty = single increment
  bidCount: number;
  currentBid?: number; // highest bid so far (undefined = no bids yet)
  addedOrder: number;
  images?: string[]; // uploaded photos; first = main
};

/** A lot that has a physical location, for the bidder calendar. The street address is never exposed: only the auction's city / region. */
export type LocationLot = {
  id: string; auctionSlug: string; auctionTitle: string; lotNumber: number; title: string; image?: string;
  city: string; region: string; timezone: string;
  startsAt: string; // ISO: when the auction opens
  endsAt: string; // ISO: when this lot closes (its own closing time, else the auction's)
};

export function getStatus(a: Pick<Auction, "startsAt" | "endsAt">, now: number): AuctionStatus {
  if (now >= new Date(a.endsAt).getTime()) return "CLOSED";
  if (now < new Date(a.startsAt).getTime()) return "UPCOMING";
  return "LIVE";
}
