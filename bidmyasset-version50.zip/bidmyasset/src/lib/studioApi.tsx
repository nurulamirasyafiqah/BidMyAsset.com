"use client";

/**
 * Auction Studio ↔ PocketBase (via /api/admin/studio/*, admin only).
 * On load the real auctions + lots replace the mock lists in lib/admin.ts (mutated in place, so existing
 * components keep working). If the backend is unreachable or empty, the mock data stays and `studioLive` is false.
 */
import { Fragment, useEffect, useState, type ReactNode } from "react";
import { consignors, studioAuctions, type Img, type StudioAuction, type StudioLot } from "@/lib/admin";

export const studioLots = new Map<string, StudioLot[]>();
export type CompanyBid = { set: boolean; start: number; increment: number; tiers?: unknown[] | null };
export const studio = { live: false, error: "", company: "", companyBid: null as CompanyBid | null };
/** True while the backend could not be reached (the lists are empty and nothing can be saved). */
export const isDemo = () => !studio.live;

type SAuction = { id: string; slug: string; sequence: number; title: string; published: boolean; paused?: boolean; updated?: string; auctionType?: string; description?: string; approvalMode?: string; hideBidders?: boolean; stagger?: boolean; category?: string; subcategory?: string; startsAt: string; endsAt: string; timezone: string; currency: string; images: Img[];
  builder?: Record<string, unknown> | null; documents?: Img[]; contactFiles?: Img[] };
type SLot = { id: string; auction: string; lotNumber: number; title: string; sku: string; quantity: number; category: string; startingBid: number; increment: number; description: string; images: Img[];
  reserve?: number; endsAt?: string; hashtags?: string; highlights?: string; consignor?: string; address?: string; draft?: boolean; incrementMatrix?: { from: number; increment: number }[] | null };

const withBase = (list: Img[] = []): Img[] => list.map((i) => ({ name: i.name, url: `/api/pb${i.url}` }));

function parts(iso: string, tz: string) {
  const p = new Intl.DateTimeFormat("en-GB", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(new Date(iso));
  const g = (t: string) => p.find((x) => x.type === t)?.value ?? "00";
  return { dmy: `${g("day")}/${g("month")}/${g("year")}`, ymd: `${g("year")}-${g("month")}-${g("day")}`, hms: `${g("hour")}:${g("minute")}:${g("second")}` };
}

/** Wall-clock date (yyyy-mm-dd) + time (hh:mm[:ss]) in an IANA time zone → UTC ISO string. */
export function zonedIso(date: string, time: string, tz: string): string {
  const [y, mo, d] = date.split("-").map(Number);
  const [h, mi, s] = time.split(":").map(Number);
  const wall = Date.UTC(y, mo - 1, d, h || 0, mi || 0, s || 0);
  const offset = (at: number) => { const p = parts(new Date(at).toISOString(), tz); const [dd, mm, yy] = p.dmy.split("/").map(Number); const [hh, m2, ss] = p.hms.split(":").map(Number); return Date.UTC(yy, mm - 1, dd, hh, m2, ss) - Math.floor(at / 1000) * 1000; };
  let t = wall - offset(wall);
  t = wall - offset(t);
  return new Date(t).toISOString();
}

const TYPE_LABEL: Record<string, string> = { RESERVE: "Reserve", ABSOLUTE: "Absolute", SUBJECT: "Subject to Confirmation" };
const TYPE_KEY: Record<string, string> = { Reserve: "RESERVE", Absolute: "ABSOLUTE", "Subject to Confirmation": "SUBJECT", "Subject to confirmation": "SUBJECT" };

function mapAuction(a: SAuction, lots: SLot[]): StudioAuction {
  const now = Date.now(), s = Date.parse(a.startsAt), e = Date.parse(a.endsAt);
  const status: StudioAuction["status"] = !a.published ? "DRAFT" : now < s ? "UPCOMING" : now < e ? "RUNNING" : "CLOSED";
  const tz = a.timezone || "Asia/Kuala_Lumpur";
  const st = parts(a.startsAt, tz), en = parts(a.endsAt, tz);
  const live = lots.filter((l) => !l.draft && Date.parse(l.endsAt || a.endsAt) > now).length;
  return { id: a.id, title: a.title, company: studio.company || "BidMyAsset Group", code: a.slug, status, lots: lots.length, active: status === "RUNNING" ? live : 0,
    starts: `${st.dmy} ${st.hms}`, ends: `${en.dmy} ${en.hms}`, startsAtIso: a.startsAt, endsAtIso: a.endsAt, sequence: a.sequence, updatedAt: a.updated, type: "Timed", tz, currency: a.currency, published: a.published, paused: !!a.paused, images: withBase(a.images),
    auctionType: TYPE_LABEL[a.auctionType ?? ""], description: a.description || undefined, category: a.category || undefined, subcategory: a.subcategory || undefined,
    approval: a.approvalMode === "MANUAL" ? "manual" : a.approvalMode === "AUTO" ? "auto" : undefined, hideBidders: !!a.hideBidders, stagger: !!a.stagger,
    builder: a.builder ?? {}, documents: withBase(a.documents), contactFiles: withBase(a.contactFiles) };
}

function mapLot(l: SLot, a: StudioAuction, endsAt: string): StudioLot {
  const end = l.endsAt || endsAt; // a lot closes with its auction unless it has its own closing time
  const en = parts(end, a.tz ?? "Asia/Kuala_Lumpur");
  return { id: l.id, no: l.lotNumber, title: l.title, sku: l.sku, qty: l.quantity || 1, category: l.category, address: l.address ?? "",
    status: l.draft ? "Draft" : Date.parse(end) <= Date.now() ? "Closed" : "Active", closes: `${en.dmy} · ${en.hms}`, closeDate: en.ymd, closeTime: en.hms,
    startBid: l.startingBid, reserve: l.reserve ?? 0, increment: l.increment, tiers: l.incrementMatrix?.length ? l.incrementMatrix.map((t) => ({ from: t.from, increment: t.increment })) : undefined, overview: l.description, hashtags: l.hashtags ?? "", highlights: l.highlights ?? "", consignor: l.consignor ?? "", images: withBase(l.images) };
}

let pending: Promise<void> | null = null;
export function loadStudio(force = false): Promise<void> {
  if (pending && !force) return pending;
  pending = (async () => {
    try {
      const res = await fetch("/api/admin/studio/list", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = (await res.json()) as { auctions: SAuction[]; lots: SLot[]; company?: string; companyBid?: CompanyBid };
      studio.company = j.company ?? ""; studio.companyBid = j.companyBid ?? null;
      studioLots.clear();
      const mapped = j.auctions.map((a) => {
        const own = j.lots.filter((l) => l.auction === a.id);
        const sa = mapAuction(a, own);
        studioLots.set(sa.id, own.map((l) => mapLot(l, sa, a.endsAt)));
        return sa;
      });
      studioAuctions.splice(0, studioAuctions.length, ...mapped); // an empty database is real: show it empty, not demo data
      studio.live = true; studio.error = "";
      // consignors for the lot builder come from Admin → Company
      try {
        const c = await fetch("/api/admin/company", { cache: "no-store" });
        const d = (await c.json().catch(() => ({}))) as { consignors?: { first?: string; last?: string }[] | null };
        const names = (d.consignors ?? []).map((x) => `${x.first ?? ""} ${x.last ?? ""}`.trim()).filter(Boolean);
        consignors.splice(0, consignors.length, ...names.map((name) => ({ name, initials: name.split(/\s+/).map((w) => w[0]).join("").slice(0, 2).toUpperCase() })));
      } catch { /* the lot builder just shows no consignors */ }
    } catch (e) {
      studio.live = false; studio.error = e instanceof Error ? e.message : "Backend unreachable";
      studioAuctions.splice(0, studioAuctions.length); studioLots.clear();
    }
  })();
  return pending;
}

async function call<T>(path: string, init: RequestInit): Promise<T> {
  const res = await fetch(`/api/admin/studio/${path}`, { cache: "no-store", ...init });
  const j = (await res.json().catch(() => ({}))) as T & { message?: string; data?: Record<string, { message?: string }> };
  if (!res.ok) {
    const f = j.data ? Object.entries(j.data)[0] : undefined;
    throw new Error(f ? `${f[0]}: ${f[1]?.message ?? "invalid"}` : j.message || `Request failed (${res.status})`);
  }
  return j;
}
const json = (b: unknown): RequestInit => ({ method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });

export async function uploadImages(kind: "auction" | "lot", id: string, files: File[], remove: string[] = []): Promise<Img[]> {
  const fd = new FormData();
  fd.append("kind", kind); fd.append("id", id);
  files.forEach((f) => fd.append("images", f));
  remove.forEach((n) => fd.append("remove", n));
  const r = await call<{ images: Img[] }>("images", { method: "POST", body: fd });
  return withBase(r.images);
}
export async function reorderImages(kind: "auction" | "lot", id: string, order: string[]): Promise<Img[]> {
  return withBase((await call<{ images: Img[] }>("images-order", json({ kind, id, order }))).images);
}

const TZ_LABEL: Record<string, string> = { "Malaysia (MYT)": "Asia/Kuala_Lumpur", "Singapore (SGT)": "Asia/Singapore", "Thailand (ICT)": "Asia/Bangkok" };
const to24 = (t: string) => { const m = /^(\d+):(\d+)\s*(AM|PM)$/i.exec(t); if (!m) return t.padStart(5, "0"); const h = (Number(m[1]) % 12) + (m[3].toUpperCase() === "PM" ? 12 : 0); return `${String(h).padStart(2, "0")}:${m[2]}`; };

/** Creates a draft (unpublished) auction in PocketBase, with cover images, and returns it as a StudioAuction. */
export async function createAuction(f: { title: string; tz: string; currency: string; sd: string; st: string; ed: string; et: string;
  type?: string; desc?: string; approval?: "auto" | "manual"; hide?: boolean; stagger?: boolean; category?: string; subcategory?: string }, covers: File[]): Promise<StudioAuction> {
  const iana = TZ_LABEL[f.tz] ?? (f.tz || "Asia/Kuala_Lumpur"); // a friendly label or any IANA zone
  const fd = new FormData();
  fd.append("title", f.title); fd.append("timezone", iana);
  fd.append("currency", /\(([A-Z]{3})\)/.exec(f.currency)?.[1] ?? f.currency);
  fd.append("startsAt", zonedIso(f.sd, to24(f.st), iana)); // wall-clock time in the chosen zone → UTC (handles DST and every zone)
  fd.append("endsAt", zonedIso(f.ed, to24(f.et), iana));
  if (f.type && TYPE_KEY[f.type]) fd.append("auctionType", TYPE_KEY[f.type]);
  if (f.desc) fd.append("description", f.desc);
  if (f.approval) fd.append("approvalMode", f.approval === "manual" ? "MANUAL" : "AUTO");
  fd.append("hideBidders", String(!!f.hide)); fd.append("stagger", String(!!f.stagger));
  if (f.category) fd.append("category", f.category);
  if (f.subcategory) fd.append("subcategory", f.subcategory);
  covers.forEach((c) => fd.append("images", c));
  const r = await call<{ id: string; slug: string; images: Img[] }>("auctions", { method: "POST", body: fd });
  await loadStudio(true);
  return studioAuctions.find((a) => a.id === r.id)!;
}
/** Duplicates an auction as a draft (settings, cover images and, when `withLots`, every lot with its photos). */
export async function cloneAuction(src: StudioAuction, f: { title: string; sd: string; st: string; ed: string; et: string; withLots: boolean }): Promise<StudioAuction> {
  const tz = src.tz ?? "Asia/Kuala_Lumpur";
  const r = await call<{ id: string }>("auction-clone", json({ id: src.id, title: f.title, lots: f.withLots,
    startsAt: zonedIso(f.sd, to24(f.st), tz), endsAt: zonedIso(f.ed, to24(f.et), tz) }));
  await loadStudio(true);
  return studioAuctions.find((a) => a.id === r.id)!;
}
export const setPublished = async (id: string, published: boolean) => { await call("auction-publish", json({ id, published })); await loadStudio(true); };
/** Pauses / resumes bidding. Stored on the auction (server refuses bids while paused); when the backend is unreachable only the screen changes. */
export async function setAuctionPaused(a: StudioAuction, paused: boolean) {
  if (studio.live) await call("auction-pause", json({ id: a.id, paused }));
  a.paused = paused;
}
type LotPayload = Partial<{ id: string; auction: string; title: string; sku: string; quantity: number; category: string; startingBid: number; increment: number; description: string;
  lotNumber: number; reserve: number; endsAt: string; hashtags: string; highlights: string; consignor: string; address: string; draft: boolean; incrementMatrix: { from: number; increment: number }[] }>;
/** Everything the Lot Builder edits, in the shape the backend expects. A closing time equal to the auction's own end is sent as "" (= follow the auction). */
export function lotPayload(l: StudioLot, a: StudioAuction): LotPayload {
  const iso = l.closeDate && l.closeTime ? zonedIso(l.closeDate, l.closeTime.length === 5 ? `${l.closeTime}:00` : l.closeTime, a.tz ?? "Asia/Kuala_Lumpur") : "";
  const own = !!iso && Math.floor(Date.parse(iso) / 1000) !== Math.floor(Date.parse(a.endsAtIso ?? "") / 1000);
  return { id: l.id, title: l.title, sku: l.sku, quantity: l.qty, category: l.category, startingBid: l.startBid, increment: l.increment, description: l.overview,
    lotNumber: l.no, reserve: l.reserve, endsAt: own ? iso : "", hashtags: l.hashtags, highlights: l.highlights, consignor: l.consignor, address: l.address, draft: l.status === "Draft", incrementMatrix: l.tiers?.length ? l.tiers : [] };
}
export const saveLot = (lot: LotPayload) =>
  call<{ id: string; lotNumber: number }>("lots", json(lot));
export const deleteLots = (ids: string[]) => call("lots-delete", json({ ids }));

/** A spreadsheet / ZIP import that was refused: `rows` lists what to fix (nothing was saved). */
export class ImportError extends Error { rows: { row: number; message: string }[]; constructor(m: string, rows: { row: number; message: string }[] = []) { super(m); this.rows = rows; } }
async function upload<T>(path: string, fd: FormData): Promise<T> {
  const res = await fetch(`/api/admin/studio/${path}`, { method: "POST", body: fd, cache: "no-store" });
  const j = (await res.json().catch(() => ({}))) as T & { message?: string; errors?: { row: number; message: string }[] };
  if (!res.ok) throw new ImportError(j.message || `Upload failed (${res.status})`, j.errors ?? []);
  return j;
}
/** Creates new draft lots (and updates lots with the same lot number) from a .csv / .xlsx file. All or nothing. */
export function importLotsSheet(a: StudioAuction, file: File) {
  const fd = new FormData(); fd.append("auction", a.id); fd.append("sheet", file, file.name);
  return upload<{ created: number; updated: number; skipped: number }>("lots-import", fd);
}
/** Adds the photos in a ZIP to the lots their file / folder names point at (lot number or SKU). */
export function importLotImagesZip(a: StudioAuction, file: File) {
  const fd = new FormData(); fd.append("auction", a.id); fd.append("zip", file, file.name);
  return upload<{ lots: number; images: number; unmatched: string[]; skipped: string[] }>("lots-images-zip", fd);
}
/** Spreads closing times by a fixed gap, ending at the auction's end (all lots or none). */
export const staggerLots = (a: StudioAuction, o: { ids: string[]; gap: number; unit: "Seconds" | "Minutes" | "Hours"; reverse: boolean }) =>
  call<{ lots: number }>("lots-stagger", json({ auction: a.id, ids: o.ids, gap: o.gap, unit: o.unit, gapSeconds: Math.round(o.gap * { Seconds: 1, Minutes: 60, Hours: 3600 }[o.unit]), reverse: o.reverse }));
/** Re-reads the studio data and returns this auction's lots (after an import / stagger changed them on the server). */
export async function reloadLots(a: StudioAuction): Promise<StudioLot[]> { await loadStudio(true); return studioLots.get(a.id) ?? []; }

export type BidRow = { id: string; lot: string; lotNo: number; lotTitle: string; bidder: string; email: string; amount: number; state: string; at: string; auto?: boolean };
export type MaxBidRow = { id: string; lot: string; lotNo: number; lotTitle: string; bidder: string; email: string; amount: number; at: string };
export type QuestionStatus = "PENDING" | "PUBLISHED" | "HIDDEN";
export type QuestionRow = { id: string; lotNo: number; lotTitle: string; asker: string; email: string; question: string; answer: string; status: QuestionStatus; at: string };
/** Every bid placed in the auction, newest first. */
export const loadBids = async (auctionId: string) => (await call<{ items: BidRow[] }>(`bids?auction=${encodeURIComponent(auctionId)}`, {})).items;
/** Maximum (proxy / absentee) bids stored for the auction. */
export const loadMaxBids = async (auctionId: string) => (await call<{ items: MaxBidRow[] }>(`max-bids?auction=${encodeURIComponent(auctionId)}`, {})).items;
export const loadQuestions = async (auctionId: string) => (await call<{ items: QuestionRow[] }>(`questions?auction=${encodeURIComponent(auctionId)}`, {})).items;
/** Saves the answer and moves the question to PENDING / PUBLISHED / HIDDEN. Publishing needs an answer (the server enforces it). */
export const reviewQuestion = (id: string, answer: string, status: QuestionStatus) => call("question-review", json({ id, answer, status }));

/** Auction Builder → Auction Info. Dates are wall-clock in `tz`; the server stores UTC. */
export async function updateAuction(a: StudioAuction, f: { title: string; tz: string; type: string; sd: string; st: string; ed: string; et: string; desc: string; approval: string; mask: boolean; stagger: boolean; extras: Record<string, unknown> }) {
  if (!studio.live) throw new Error("Not connected to the backend, so nothing was saved.");
  const typeKey = f.type === "Reserve" ? "RESERVE" : f.type === "Absolute" ? "ABSOLUTE" : "SUBJECT";
  await call("auction-update", json({ id: a.id, title: f.title.trim(), startsAt: zonedIso(f.sd, f.st, f.tz), endsAt: zonedIso(f.ed, f.et, f.tz), timezone: f.tz, auctionType: typeKey,
    description: f.desc, approvalMode: f.approval === "Approve Automatically" ? "AUTO" : "MANUAL", hideBidders: f.mask, stagger: f.stagger, extras: f.extras }));
  await loadStudio(true);
}
/** Saves one Builder section (contacts, address, registration, commission, payment, catalog, bid). `applied`/`skipped` only come back for "bid" with applyExisting. */
export async function saveBuilder(a: StudioAuction, section: string, data: unknown) {
  if (!studio.live) throw new Error("Not connected to the backend, so nothing was saved.");
  const r = await call<{ applied?: number; skipped?: number }>("builder-save", json({ id: a.id, section, data }));
  a.builder = { ...(a.builder ?? {}), [section]: data };
  if (section === "bid" && (r.applied || r.skipped)) await loadStudio(true);
  return r;
}
/** Documents (kind "document") and contact photos (kind "avatar"). Returns the full file list and the names just added. */
export async function builderFiles(a: StudioAuction, kind: "document" | "avatar", add: File[], remove: string[] = []) {
  if (!studio.live) throw new Error("Not connected to the backend, so nothing was saved.");
  const fd = new FormData();
  fd.append("kind", kind); fd.append("id", a.id); // kind must come first: the proxy checks the files against it
  remove.forEach((n) => fd.append("remove", n));
  add.forEach((f) => fd.append("files", f));
  const r = await call<{ files: Img[]; added: string[] }>("builder-file", { method: "POST", body: fd });
  const files = withBase(r.files);
  if (kind === "document") a.documents = files; else a.contactFiles = files;
  return { files, added: r.added };
}
export async function notifyCatalog(a: StudioAuction) {
  const r = await call<{ sent: number; failed: number; sentAt: string }>("catalog-notify", json({ id: a.id }));
  const cat = (a.builder?.catalog ?? {}) as Record<string, unknown>;
  a.builder = { ...(a.builder ?? {}), catalog: { ...cat, sentAt: r.sentAt, sentCount: r.sent } };
  return r;
}

export type RegStatus = "PENDING" | "APPROVED" | "REJECTED";
export type RegRow = { id: string; status: RegStatus; name: string; email: string; phone: string; at: string; answers?: Record<string, unknown> | null };
export const loadRegistrations = (auctionId: string) => call<{ items: RegRow[]; questions?: { id: string; text: string }[] }>(`registrations?auction=${encodeURIComponent(auctionId)}`, {});
/** Sets a registration to APPROVED / REJECTED / PENDING. `leadingBids` = bids this bidder still leads after being un-approved. */
export const reviewRegistration = (id: string, status: RegStatus) => call<{ status: RegStatus; leadingBids: number }>("registration-review", json({ id, status }));

export const imageProblem = (f: File) => (!/^image\/(png|jpe?g|webp)$/.test(f.type) ? `${f.name}: use a JPG, PNG or WebP image.` : f.size > 10 * 1024 * 1024 ? `${f.name}: image must be 10 MB or smaller.` : "");

/** Renders children once the Studio data has been fetched (module-cached, so later screens open instantly). */
export function StudioGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [round, setRound] = useState(0);
  useEffect(() => { void loadStudio().then(() => setReady(true)); }, []);
  const retry = () => { setReady(false); void loadStudio(true).then(() => { setRound((n) => n + 1); setReady(true); }); };
  if (!ready) return <p role="status" className="py-10 text-center text-xs text-zinc-500">Loading auctions…</p>;
  return (
    <>
      {!studio.live && (
        <div role="alert" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-xs text-amber-900">
          <p><b>Not connected to the database.</b> {studio.error ? `(${studio.error}) ` : ""}Start the backend and retry; nothing can be added, edited or deleted until it is reachable.</p>
          <button onClick={retry} className="rounded-md border border-amber-400 bg-white px-3 py-1 font-semibold hover:bg-amber-100">Retry connection</button>
        </div>
      )}
      <Fragment key={round}>{children}</Fragment>
    </>
  );
}
