"use client";
import { parseLegal, settingsFromDoc, type Fee, type LegalPolicy, type SettingsDoc } from "@/lib/auctionHouse";

/**
 * One place for Auction House settings that several admin screens edit
 * (Auction House → Legal Policies and Company → Policies share the same `house.legal`).
 * Everything goes through PUT /api/admin/house/settings, which validates and sanitizes on the server.
 */
export async function putHouse(body: { fee?: unknown; theme?: unknown; legal?: unknown; categories?: unknown }) {
  const res = await fetch("/api/admin/house/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = (await res.json().catch(() => ({}))) as { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
  return j;
}

/** Same call shape the Company screens used before: `legal` arrives as a JSON string. */
export async function postHouse(fields: Record<string, string>) {
  const body: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fields)) body[k] = JSON.parse(v);
  await putHouse(body);
}

export async function fetchHouse(): Promise<{ legal: LegalPolicy[]; fee: Fee | null }> {
  const res = await fetch("/api/admin/house/settings", { cache: "no-store" });
  const j = (await res.json().catch(() => ({}))) as SettingsDoc & { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
  return { legal: parseLegal(j.legal), fee: settingsFromDoc(j).fee ?? null };
}
