/** Sub-pages reachable from an auction's actions menu in Auction Intelligence. Each one is built from the auction's real bids, registrations and invoices (lib/intelData.ts). */
export const INTEL_VIEWS = ["reports", "kpi-analytics", "unified-analytics", "analytics-dashboard", "bidder-analysis", "recordings"];
