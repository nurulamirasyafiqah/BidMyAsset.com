import { PB_URL } from "@/lib/pb";

export type PublicCompany = {
  name: string;
  contacts: { name: string; email: string; iso: string; phone: string }[];
  locations: { name: string; address: string; phone: string }[];
};

const DIAL: Record<string, string> = { MY: "+60", TH: "+66", SG: "+65", ID: "+62", BN: "+673", US: "+1", GB: "+44", AU: "+61" };
export const contactPhone = (c: { iso: string; phone: string }) => (c.phone.trim() ? `${DIAL[c.iso] ?? ""} ${c.phone.replace(/^0/, "").trim()}`.trim() : "");

/** Company → Contacts / Locations, as published by GET /api/bma/company-public (names, emails, phones and addresses only). */
export async function getPublicCompany(): Promise<PublicCompany | null> {
  try {
    const res = await fetch(`${PB_URL}/api/bma/company-public`, { next: { revalidate: 60 }, signal: AbortSignal.timeout(2500) });
    if (!res.ok) return null;
    const j = (await res.json()) as Partial<PublicCompany>;
    return { name: j.name ?? "", contacts: j.contacts ?? [], locations: j.locations ?? [] };
  } catch { return null; }
}
