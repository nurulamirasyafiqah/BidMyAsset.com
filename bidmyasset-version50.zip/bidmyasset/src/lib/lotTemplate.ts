/**
 * Lot import template. The columns are exactly what POST /lots-import understands (see backend/admin_studio_import.go):
 * only Title is required; empty cells keep the lot's current value (or the auction's bid defaults for new lots).
 * A row whose first cell starts with "#" is a note and is skipped.
 */
export const LOT_COLUMNS = [
  "Lot number", "Title", "SKU", "Quantity", "Category", "Starting bid", "Reserve price", "Increment",
  "Description", "Hashtags", "Highlights", "Consignor", "Address", "Closing date", "Closing time",
] as const;

const EXAMPLES: string[][] = [
  ["1", "Caterpillar D6D Bulldozer", "CAT-D6D-001", "1", "Heavy Machinery", "60000", "61000", "1000", "Make: Caterpillar\nModel: D6D\nYear: 2006\nCondition: Used", "#bulldozer, #cat", "Low hours, recently serviced", "", "Shah Alam, Selangor", "", ""],
  ["2", "SANY SY980H Excavator - 98 tons", "SANY-980H-002", "1", "Heavy Machinery", "250000", "", "5000", "Condition: Used", "#excavator", "", "", "", "", ""],
];
const NOTE = "# Notes: delete the example rows above. Only Title is required. Leave Lot number empty to add the lot at the end; an existing lot number updates that lot. Dates are dd/mm/yyyy or yyyy-mm-dd, times hh:mm or hh:mm:ss in the auction's time zone, and must fall within the auction. Empty cells change nothing.";

const q = (v: string) => (/[",\r\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);

export function lotTemplateCsv(): string {
  return "\uFEFF" + [[...LOT_COLUMNS], ...EXAMPLES, [NOTE]].map((r) => r.map(q).join(",")).join("\r\n") + "\r\n";
}

export function downloadLotTemplate() {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([lotTemplateCsv()], { type: "text/csv;charset=utf-8" }));
  a.download = "lot-import-template.csv";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
