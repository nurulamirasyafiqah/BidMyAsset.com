// Auction House → Theming & Config, turned into CSS for the public site. Pure (server + client safe).
// Only values that differ from the built-in defaults are emitted, so saving the untouched defaults never restyles
// the site; whatever the admin actually changed is applied. Every value was already validated (isColor / isCssValue,
// and again in backend/house_settings.go): the allowed characters cannot close a rule or a <style> tag.
import { defaultButtons, defaultDialog, isColor, isButtonColor, isCssValue, type ButtonKey, type ButtonStyle, type DialogStyle, type House } from "@/lib/auctionHouse";

type Theme = House["theme"];

const norm = (hex: string): string => {
  const h = hex.replace("#", "").toLowerCase();
  return "#" + (h.length === 3 ? h.split("").map((c) => c + c).join("") : h);
};
const rgb = (hex: string): [number, number, number] => { const h = norm(hex).slice(1); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number]; };
const toHex = (c: [number, number, number]) => "#" + c.map((x) => Math.round(Math.max(0, Math.min(255, x))).toString(16).padStart(2, "0")).join("");
/** `t` of the way from a to b. */
const mix = (a: string, b: string, t: number) => { const x = rgb(a), y = rgb(b); return toHex([0, 1, 2].map((i) => x[i] + (y[i] - x[i]) * t) as [number, number, number]); };

const BTN_NORMAL: [keyof ButtonStyle, string][] = [
  ["background", "background-color"], ["text", "color"], ["border", "border-color"], ["radius", "border-radius"],
  ["fontSize", "font-size"], ["fontWeight", "font-weight"], ["padding", "padding"], ["shadow", "box-shadow"],
];
const BTN_HOVER: [keyof ButtonStyle, string][] = [
  ["hoverBackground", "background-color"], ["hoverText", "color"], ["hoverBorder", "border-color"], ["hoverShadow", "box-shadow"],
];
const BTN_COLORS = new Set<keyof ButtonStyle>(["background", "text", "border", "hoverBackground", "hoverText", "hoverBorder"]);

const DLG: [keyof DialogStyle, string, "box" | "title" | "footer"][] = [
  ["background", "background-color", "box"], ["text", "color", "box"], ["border", "border-color", "box"], ["radius", "border-radius", "box"],
  ["shadow", "box-shadow", "box"], ["headerPadding", "padding", "box"],
  ["titleFontSize", "font-size", "title"], ["titleFontWeight", "font-weight", "title"], ["footerGap", "gap", "footer"],
];
const DLG_COLORS = new Set<keyof DialogStyle>(["background", "border", "text"]);

/** "" when the theme changes nothing. */
export function buildThemeCss(t: Theme): string {
  const rules: string[] = [];

  // 1) brand colours: Tailwind's utilities read these variables (bg-primary, text-primary, hover:bg-primary-700, bg-brand …)
  const p = isColor(t.primary) && t.primary ? norm(t.primary) : "";
  const s = isColor(t.secondary) && t.secondary ? norm(t.secondary) : "";
  const root: string[] = [];
  if (p) root.push(`--color-primary:${p}`, `--color-primary-700:${mix(p, "#000000", 0.22)}`, `--color-soft:${mix(p, "#ffffff", 0.88)}`);
  if (s) root.push(`--color-brand:${s}`);
  if (p || s) {
    const P = p || "#0037e1", S = s || "#15325d"; // gradient defaults = the original hero colours
    root.push(`--bma-hero-1:${P}`, `--bma-hero-2:${mix(P, S, 0.45)}`, `--bma-hero-3:${S}`, `--bma-cta-1:${S}`, `--bma-cta-2:${mix(S, P, 0.7)}`, `--bma-cta-3:${P}`);
  }
  // `:root:root` (higher specificity) so these variables win over Tailwind's own :root declarations whatever the stylesheet order
  if (root.length) rules.push(`:root:root{${root.join(";")}}`);

  // 2) buttons + dialogs: light mode only (dark mode keeps its own palette, so custom light colours can't make text unreadable)
  const L = ':root:not([data-theme="dark"])';
  for (const k of ["primary", "secondary", "outline"] as ButtonKey[]) {
    const cur = t.buttons[k], def = defaultButtons[k];
    const ok = (f: keyof ButtonStyle) => cur[f] !== def[f] && cur[f].trim() !== "" && (BTN_COLORS.has(f) ? isButtonColor(cur[f]) : isCssValue(cur[f]));
    const base = BTN_NORMAL.filter(([f]) => ok(f)).map(([f, css]) => `${css}:${cur[f]}`);
    if (ok("border")) base.push("border-style:solid", "border-width:1px");
    if (base.length) rules.push(`${L} [data-btn="${k}"]{${base.join(";")}}`);
    const hover = BTN_HOVER.filter(([f]) => ok(f)).map(([f, css]) => `${css}:${cur[f]}`);
    if (hover.length) rules.push(`${L} [data-btn="${k}"]:hover:not(:disabled){${hover.join(";")}}`);
  }
  const dOk = (f: keyof DialogStyle) => t.dialog[f] !== defaultDialog[f] && t.dialog[f].trim() !== "" && (DLG_COLORS.has(f) ? isButtonColor(t.dialog[f]) : isCssValue(t.dialog[f]));
  for (const [part, sel] of [["box", "[data-dialog]"], ["title", "[data-dialog] [data-dialog-title]"], ["footer", "[data-dialog] [data-dialog-footer]"]] as const) {
    const decl = DLG.filter(([f, , w]) => w === part && dOk(f)).map(([f, css]) => `${css}:${t.dialog[f]}`);
    if (part === "box" && dOk("border")) decl.push("border-style:solid", "border-width:1px");
    if (decl.length) rules.push(`${L} ${sel}{${decl.join(";")}}`);
  }
  return rules.join("\n");
}
