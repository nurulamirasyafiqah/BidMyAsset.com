import { PB_URL } from "@/lib/pb";
import { CONTACT } from "@/lib/content";
import { DEFAULT_BRAND, type Brand } from "@/lib/brandShared";
import { mergeTheme, parseCategories, parseLegal, type LegalPolicy } from "@/lib/auctionHouse";
import { buildThemeCss } from "@/lib/themeCss";

export { DEFAULT_BRAND, type Brand };

export async function getBrand(): Promise<Brand> {
  try {
    const res = await fetch(`${PB_URL}/api/collections/house/records?perPage=1&sort=-updated`, { next: { revalidate: 30, tags: ["house"] }, signal: AbortSignal.timeout(2500) });
    if (!res.ok) return DEFAULT_BRAND;
    const r = ((await res.json()) as { items?: Record<string, unknown>[] }).items?.[0];
    if (!r) return DEFAULT_BRAND;
    // files are served through the same-origin proxy (the browser never talks to PocketBase directly)
    const url = (f: unknown) => (typeof f === "string" && f ? `/api/pb/api/files/house/${r.id}/${encodeURIComponent(f)}?v=${encodeURIComponent(String(r.updated ?? ""))}` : "");
    const s = (k: string, d: string) => (typeof r[k] === "string" && (r[k] as string).trim() ? (r[k] as string).trim() : d);
    const theme = mergeTheme(r.theme); // validated again here: the record is public-read
    return {
      name: s("name", DEFAULT_BRAND.name), logo: url(r.logo), favicon: url(r.favicon),
      banners: Array.isArray(r.banners) ? (r.banners as string[]).map(url).filter(Boolean) : [],
      phone: s("supportPhone", CONTACT.phone), email: s("supportEmail", CONTACT.email), website: s("website", ""),
      gaId: /^(G|UA|GTM)-[A-Z0-9-]+$/i.test(s("gaId", "")) ? s("gaId", "") : "", description: s("description", ""),
      themeCss: buildThemeCss(theme), ratings: theme.ratings, categories: parseCategories(r.categories), version: String(r.updated ?? ""),
    };
  } catch { return DEFAULT_BRAND; }
}

/** Auction House → Legal Policies. The newest policy that has the requested text wins. Empty string = nothing published. */
export async function getLegalText(kind: "privacy" | "terms"): Promise<{ name: string; html: string; updated: string } | null> {
  try {
    const res = await fetch(`${PB_URL}/api/collections/house/records?perPage=1&sort=-updated`, { next: { revalidate: 30, tags: ["house"] }, signal: AbortSignal.timeout(2500) });
    if (!res.ok) return null;
    const r = ((await res.json()) as { items?: Record<string, unknown>[] }).items?.[0];
    if (!r) return null;
    const list: LegalPolicy[] = parseLegal(r.legal);
    const hit = [...list].reverse().find((p) => p[kind].trim());
    return hit ? { name: hit.name, html: hit[kind], updated: String(r.updated ?? "") } : null;
  } catch { return null; }
}
