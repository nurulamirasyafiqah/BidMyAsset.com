// Client-safe: no server imports here (PortalShell is a client component and must not pull in pb.ts / next/headers).
export const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "home" },
  { href: "/timed", label: "Timed Auctions", icon: "clock", divider: true },
  { href: "/favourites", label: "Favourite Lots", icon: "heart" },
  { href: "/my-bids", label: "My Bids", icon: "gavel" },
  { href: "/my-registrations", label: "My Registrations", icon: "file" },
  { href: "/my-invoices", label: "My Invoices", icon: "dollar" },
  { href: "/auction-calendar", label: "Auction Calendar", icon: "calendar" },
] as const;
