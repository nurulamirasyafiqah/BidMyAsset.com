"use client";

import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";

export type LotEvent = { lot: string; currentBid: number; bidCount: number; endsAt: string; reserveMet: boolean };

/** One shared EventSource per tab (GET /api/live), however many components listen. The browser reconnects by itself. */
const listeners = new Set<(e: LotEvent) => void>();
let source: EventSource | null = null;

function subscribe(cb: (e: LotEvent) => void) {
  listeners.add(cb);
  if (!source && typeof EventSource !== "undefined") {
    source = new EventSource("/api/live");
    source.onmessage = (m) => {
      try { const ev = JSON.parse(m.data as string) as LotEvent; listeners.forEach((l) => l(ev)); } catch { /* ignore a malformed event */ }
    };
  }
  return () => {
    listeners.delete(cb);
    if (!listeners.size && source) { source.close(); source = null; }
  };
}

/** Calls `onEvent` for every live update of the given lots (all lots when `lotIds` is omitted). */
export function useLotEvents(onEvent: (e: LotEvent) => void, lotIds?: string[], enabled = true) {
  const cb = useRef(onEvent);
  cb.current = onEvent;
  const key = lotIds ? lotIds.join(",") : "*";
  useEffect(() => {
    if (!enabled) return;
    const want = lotIds ? new Set(lotIds) : null;
    return subscribe((e) => { if (!want || want.has(e.lot)) cb.current(e); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, enabled]);
}

/** Re-renders the server-rendered page (prices, counts, countdown) shortly after any of these lots change; at most once every 2 s. */
export function LiveRefresh({ lotIds, enabled = true }: { lotIds: string[]; enabled?: boolean }) {
  const router = useRouter();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useLotEvents(() => {
    if (timer.current) return;
    timer.current = setTimeout(() => { timer.current = null; router.refresh(); }, 2000);
  }, lotIds, enabled);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  return null;
}
