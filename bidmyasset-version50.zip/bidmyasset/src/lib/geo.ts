/**
 * Country → State → City data, loaded lazily (the dataset is large, so it is
 * kept out of the initial bundle and fetched only when a form needs it).
 */
export type Option = { value: string; label: string };
export type CountryOption = Option & { dial: string };

let lib: Promise<typeof import("country-state-city")> | null = null;
const load = () => (lib ??= import("country-state-city"));

export async function getCountries(): Promise<CountryOption[]> {
  const { Country } = await load();
  return Country.getAllCountries()
    .map((c) => ({ value: c.isoCode, label: c.name, dial: `+${c.phonecode.replace(/^\+/, "")}` }))
    .sort((a, b) => a.label.localeCompare(b.label));
}

export async function getStates(countryIso: string): Promise<Option[]> {
  const { State } = await load();
  return State.getStatesOfCountry(countryIso)
    .map((s) => ({ value: s.isoCode, label: s.name }))
    .sort((a, b) => a.label.localeCompare(b.label));
}

export async function getCities(countryIso: string, stateIso: string): Promise<Option[]> {
  const { City } = await load();
  const seen = new Set<string>();
  return City.getCitiesOfState(countryIso, stateIso)
    .filter((c) => (seen.has(c.name) ? false : (seen.add(c.name), true)))
    .map((c) => ({ value: c.name, label: c.name }))
    .sort((a, b) => a.label.localeCompare(b.label));
}
