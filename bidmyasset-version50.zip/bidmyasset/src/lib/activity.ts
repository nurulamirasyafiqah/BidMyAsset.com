import { PB_URL } from "@/lib/pb";

/** Best-effort client IP (behind a proxy/CDN the first x-forwarded-for entry), without the port. */
export function clientIp(req: Request): string {
  const raw = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
  return raw.replace(/^(\d+\.\d+\.\d+\.\d+):\d+$/, "$1");
}

/** "Desktop" / "Mobile" / "Tablet" from the User-Agent. */
export function clientDevice(req: Request): string {
  const ua = req.headers.get("user-agent") ?? "";
  return /iPad|Tablet/i.test(ua) ? "Tablet" : /Mobi|Android|iPhone/i.test(ua) ? "Mobile" : "Desktop";
}

/** Records an account event (login, logout, admin action). Fire-and-forget: never breaks the request; emails with no account are ignored by the backend. */
export async function logActivity(email: string, title: string, ok: boolean, ip: string, device = "") {
  const key = process.env.BMA_ADMIN_KEY;
  if (!key || !email) return;
  await fetch(`${PB_URL}/api/bma/admin/activity`, {
    method: "POST", cache: "no-store", signal: AbortSignal.timeout(3000),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key },
    body: JSON.stringify({ email, title, ip, ok, device }),
  }).catch(() => {});
}
