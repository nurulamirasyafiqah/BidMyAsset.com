import { PB_URL } from "@/lib/pb";
import { advisors as dAdvisors, leadership as dLeadership, management as dManagement, type Person } from "@/lib/content";

export type Team = { leadership: Person[]; advisors: Person[]; management: Person[] };
export const TEAM_GROUPS = ["leadership", "advisor", "management"] as const;
export type TeamGroup = (typeof TEAM_GROUPS)[number];

/**
 * Leadership page people, managed in Admin → Team (PocketBase `team_members`, public read of visible people only).
 * Only when the backend cannot be reached do we fall back to the lists in lib/content.ts.
 */
export async function getTeam(): Promise<Team> {
  try {
    const res = await fetch(`${PB_URL}/api/collections/team_members/records?perPage=200&sort=sort,created`, { next: { revalidate: 30, tags: ["team"] }, signal: AbortSignal.timeout(2500) });
    if (!res.ok) throw new Error(String(res.status));
    const items = ((await res.json()) as { items?: Record<string, unknown>[] }).items ?? [];
    const out: Team = { leadership: [], advisors: [], management: [] };
    for (const r of items) {
      const name = typeof r.name === "string" ? r.name.trim() : "";
      if (!name) continue;
      const photo = typeof r.photo === "string" && r.photo
        ? `/api/pb/api/files/team_members/${r.id}/${encodeURIComponent(r.photo)}?v=${encodeURIComponent(String(r.updated ?? ""))}` : undefined;
      const link = typeof r.linkedin === "string" && /^https?:\/\//i.test(r.linkedin) ? r.linkedin : undefined; // record is public-read: re-check
      const p: Person = { name, role: typeof r.role === "string" ? r.role : "", photo, linkedin: link };
      if (r.grp === "leadership") out.leadership.push(p);
      else if (r.grp === "advisor") out.advisors.push(p);
      else if (r.grp === "management") out.management.push(p);
    }
    return out;
  } catch {
    return { leadership: dLeadership, advisors: dAdvisors, management: dManagement };
  }
}
