"use client";
import { useEffect, useState } from "react";
import { categoryLibrary } from "@/lib/admin";
import { parseCategories } from "@/lib/auctionHouse";

/** Category library limited to what the admin selected in Auction House → Categories (full library until something is saved). */
export function useCategoryLibrary(): Record<string, string[]> {
  const [lib, setLib] = useState<Record<string, string[]>>(categoryLibrary);
  useEffect(() => {
    let live = true;
    fetch("/api/admin/house", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((j: { categories?: unknown } | null) => {
      const c = parseCategories(j?.categories);
      if (!live || !c) return;
      const next: Record<string, string[]> = {};
      for (const [g, items] of Object.entries(categoryLibrary)) { const keep = items.filter((i) => c[g]?.includes(i)); if (keep.length) next[g] = keep; }
      if (Object.keys(next).length) setLib(next);
    }).catch(() => {});
    return () => { live = false; };
  }, []);
  return lib;
}
