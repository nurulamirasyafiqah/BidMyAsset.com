"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";

/** router.refresh() with a `busy` flag that stays on briefly, so a spinner is visible even when the refetch is instant. */
export function useRefresh() {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [hold, setHold] = useState(false);
  const refresh = () => { setHold(true); setTimeout(() => setHold(false), 600); start(() => router.refresh()); };
  return { refresh, busy: pending || hold };
}
