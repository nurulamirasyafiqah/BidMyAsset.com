const SYMBOLS: Record<string, string> = { MYR: "RM ", THB: "฿", SGD: "S$", USD: "$" };

export function formatMoney(amount: number, currency: string): string {
  const prefix = SYMBOLS[currency] ?? `${currency} `;
  return `${prefix}${amount.toLocaleString("en-US")}`;
}

/** "SEP 30" style, rendered in the auction's own timezone (blueprint: timezone is per project). */
export function formatDay(iso: string, timeZone: string): string {
  return new Date(iso)
    .toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone })
    .toUpperCase();
}

export function formatRange(startIso: string, endIso: string, timeZone: string): string {
  return `${formatDay(startIso, timeZone)} – ${formatDay(endIso, timeZone)}`;
}

/** "10/31/2026 @ 12:00 PM" */
export function formatDateTime(iso: string, timeZone: string): string {
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-US", {
    timeZone,
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
  });
  const time = d.toLocaleTimeString("en-US", { timeZone, hour: "numeric", minute: "2-digit" });
  return `${date} @ ${time}`;
}

/** 39d 20h 10m  →  5h 12m 03s  →  12m 03s */
export function formatRemaining(ms: number): string {
  if (ms <= 0) return "0s";
  const total = Math.floor(ms / 1000);
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${pad(m)}m ${pad(s)}s`;
  return `${m}m ${pad(s)}s`;
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** "2026-10-07" — the calendar day of an instant in a given IANA timezone. */
export function dayKey(when: number | string, timeZone: string): string {
  return new Date(when).toLocaleDateString("en-CA", { timeZone });
}

/** "Wed, 10/07/2026" from a "2026-10-07" key. */
export function formatKeyLong(key: string): string {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString("en-US", {
    weekday: "short", month: "2-digit", day: "2-digit", year: "numeric", timeZone: "UTC",
  });
}

/** "Tue, 09/01/2026 • 10:00 AM (Asia/Kuala_Lumpur)" */
export function formatStamp(iso: string, timeZone: string): string {
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-US", { weekday: "short", month: "2-digit", day: "2-digit", year: "numeric", timeZone });
  const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone });
  return `${date} • ${time} (${timeZone})`;
}
