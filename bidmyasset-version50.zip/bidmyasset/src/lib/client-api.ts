"use client";

/** Browser → same-origin /api/pb/* proxy (adds the httpOnly session cookie). Throws Error(message). */
export async function api<T = unknown>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(`/api/pb/${path.replace(/^\//, "")}`, {
    method: init.method ?? (init.body ? "POST" : "GET"),
    headers: init.body ? { "Content-Type": "application/json" } : undefined,
    body: init.body ? JSON.stringify(init.body) : undefined,
    cache: "no-store",
  });
  const text = await res.text();
  const json = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  if (!res.ok) {
    const fields = json.data && typeof json.data === "object" ? Object.entries(json.data as Record<string, { message?: string }>) : [];
    const detail = fields.length ? `${fields[0][0]}: ${fields[0][1]?.message ?? "invalid"}` : "";
    throw new Error(detail || (typeof json.message === "string" && json.message ? json.message : `Request failed (${res.status})`));
  }
  return json as T;
}

/** Only allow same-site relative redirects; public /auctions/* links map to the member /timed/* area. */
export function safeNext(raw: string | null): string {
  if (!raw || !raw.startsWith("/") || raw.startsWith("//")) return "/dashboard";
  return raw.startsWith("/auctions/") ? raw.replace("/auctions/", "/timed/") : raw;
}

/** Where to land after login: an explicit ?next= wins; otherwise admins go to the admin console, bidders to the portal. */
export function landingFor(raw: string | null, res: unknown): string {
  const isAdmin = (res as { record?: { isAdmin?: boolean } } | null)?.record?.isAdmin === true;
  return raw ? safeNext(raw) : isAdmin ? "/admin/dashboard" : safeNext(null);
}
