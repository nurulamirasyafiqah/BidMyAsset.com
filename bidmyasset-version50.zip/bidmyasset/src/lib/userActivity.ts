/** Types for Admin → User Activity Analytics (data comes from GET /api/admin/user-activity). */
export const ACTION_TYPES = ["Logged In", "Logged Out", "Failed Login", "Account Created", "Register Auction", "Add Watchlist", "Remove Watchlist", "Place Bid", "Update Profile", "Change Password", "Request Deletion", "Export Data", "Admin Action"] as const;
export type ActionType = (typeof ACTION_TYPES)[number];
export type ActivityCategory = "Authentication" | "Account" | "Registration" | "Watchlist" | "Bidding" | "Admin";
export type ActivityEntry = {
  id: string; user: string; email: string; action: ActionType; category: ActivityCategory; details: string;
  device: string; amount: number | null; currency: string; at: string; ip: string; lotId?: string; auctionId?: string;
};
