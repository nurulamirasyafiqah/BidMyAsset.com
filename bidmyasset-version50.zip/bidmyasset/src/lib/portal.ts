/**
 * Portal data for the signed-in bidder, read from PocketBase.
 * A new account simply has empty lists.
 */
import { getToken, iso, pbAll, type PBRecord } from "./pb";

export type UserProfile = {
  id: string; name: string; email: string; firstName: string; lastName: string; phone: string; phoneCountry: string;
  company: string; designation: string; website: string; signatureName: string;
  address1: string; address2: string; city: string; state: string; postalCode: string; country: string;
};

export type BidState = "LEADING" | "OUTBID" | "TRACKED";

export type Bid = {
  id: string;
  auctionSlug: string;
  auctionTitle: string;
  lotNumber: number;
  lotTitle: string;
  currency: string;
  amount: number;
  state: BidState;
  placedAt: string; // ISO
};

export type Registration = {
  auctionSlug: string;
  auctionTitle: string;
  status: "APPROVED" | "PENDING";
  registeredAt: string;
};

export type Invoice = {
  id: string;
  recordId?: string; // PocketBase record id, used to start an online payment
  auctionTitle: string;
  lotTitle: string;
  currency: string;
  amount: number;
  hammer?: number; // winning bid, when the invoice was issued from it
  commission?: number;
  internetFee?: number; // Auction House → internet buying fee
  tax?: number; // Company → Taxes (federal + state)
  status: "UNPAID" | "PAID";
  issuedAt: string;
};

export type Notice = { id: string; title: string; body: string; at: string; read: boolean };

export type PortalData = {
  bids: Bid[];
  favourites: { auctionSlug: string; auctionTitle: string; lotNumber: number; lotTitle: string; startingBid: number; currency: string }[];
  registrations: Registration[];
  invoices: Invoice[];
  notices: Notice[];
};

const str = (v: unknown) => String(v ?? "");
type Exp = Record<string, PBRecord | undefined>;

/** Signed-in user's data from the backend (empty when signed out). */
export async function getPortalData(): Promise<PortalData> {
  const token = await getToken();
  const empty: PortalData = { bids: [], favourites: [], registrations: [], invoices: [], notices: [] };
  if (!token) return empty;
  const q = (expand?: string, sort = "-created") => ({ token, sort, expand });
  const [bids, regs, favs, invs, notes] = await Promise.all([
    pbAll("bids", q("lot,auction")), pbAll("registrations", q("auction")), pbAll("favourites", q("lot,lot.auction")),
    pbAll("invoices", q("auction,lot")), pbAll("notifications", q()),
  ]);
  const ex = (r: PBRecord) => (r.expand ?? {}) as Exp;
  return {
    bids: bids.map((r) => ({
      id: r.id, auctionSlug: str(ex(r).auction?.slug), auctionTitle: str(ex(r).auction?.title),
      lotNumber: Number(ex(r).lot?.lotNumber ?? 0), lotTitle: str(ex(r).lot?.title), currency: str(ex(r).auction?.currency),
      amount: Number(r.amount), state: r.state === "OUTBID" ? "OUTBID" : r.state === "TRACKED" ? "TRACKED" : "LEADING", placedAt: iso(r.created),
    })),
    registrations: regs.filter((r) => r.status !== "REJECTED").map((r) => ({
      auctionSlug: str(ex(r).auction?.slug), auctionTitle: str(ex(r).auction?.title),
      status: r.status === "APPROVED" ? "APPROVED" : "PENDING", registeredAt: iso(r.created),
    })),
    favourites: favs.map((r) => {
      const lot = ex(r).lot;
      const a = (lot?.expand as Exp | undefined)?.auction;
      return { auctionSlug: str(a?.slug), auctionTitle: str(a?.title), lotNumber: Number(lot?.lotNumber ?? 0), lotTitle: str(lot?.title), startingBid: Number(lot?.startingBid ?? 0), currency: str(a?.currency) };
    }),
    invoices: invs.map((r) => ({
      id: str(r.number), recordId: r.id, auctionTitle: str(ex(r).auction?.title), lotTitle: str(ex(r).lot?.title),
      currency: str(r.currency), amount: Number(r.amount), hammer: Number(r.hammer ?? 0) || undefined, commission: Number(r.commission ?? 0) || undefined, internetFee: Number(r.internetFee ?? 0) || undefined, tax: Number(r.tax ?? 0) || undefined, status: r.status === "PAID" ? "PAID" : "UNPAID", issuedAt: iso(r.created),
    })),
    notices: notes.map((r) => ({ id: r.id, title: str(r.title), body: str(r.body), at: iso(r.created), read: Boolean(r.read) })),
  };
}

/** PocketBase user record → the profile shape the settings UI uses. */
export function toProfile(r: PBRecord): UserProfile {
  const g = (k: string) => str(r[k]);
  const name = `${g("firstName")} ${g("lastName")}`.trim() || g("name") || g("email");
  return {
    id: r.id, name, email: g("email"), firstName: g("firstName"), lastName: g("lastName"), phone: g("phone"), phoneCountry: g("phoneCountry"),
    company: g("company"), designation: g("designation"), website: g("website"), signatureName: g("signatureName"),
    address1: g("address1"), address2: g("address2"), city: g("city"), state: g("state"), postalCode: g("postalCode"), country: g("country"),
  };
}

/** Bids per day for the last N days (oldest → newest). */
export function momentum(bids: Bid[], days = 14) {
  const out = Array.from({ length: days }, (_, i) => ({ day: i, count: 0 }));
  const now = Date.now();
  for (const b of bids) {
    const ago = Math.floor((now - new Date(b.placedAt).getTime()) / 86400000);
    if (ago >= 0 && ago < days) out[days - 1 - ago].count++;
  }
  return out;
}

export { NAV } from "./portalNav";
