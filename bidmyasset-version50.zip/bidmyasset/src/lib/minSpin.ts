/** Runs `fn` and resolves only after at least `ms` have passed, so a refresh spinner is actually visible on fast local requests. */
export async function withMinSpin<T>(fn: () => Promise<T>, ms = 600): Promise<T> {
  const t0 = Date.now();
  try {
    return await fn();
  } finally {
    const wait = ms - (Date.now() - t0);
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  }
}
