// Server-side validation for Auction House settings (fee, theme, legal, categories) before they are stored.
// The browser also validates, but nothing here trusts it: values end up in CSS and HTML on the public site.
import { defaultButtons, defaultDialog, FEE_DEFS, isColor, isCssValue, type ButtonKey, type Fee } from "@/lib/auctionHouse";
import { categoryLibrary } from "@/lib/admin";
import { sanitizeHtml } from "@/lib/sanitizeHtml";

type R = { ok: true; json: string } | { ok: false; msg: string };
const fail = (msg: string): R => ({ ok: false, msg });
const isObj = (x: unknown): x is Record<string, unknown> => !!x && typeof x === "object" && !Array.isArray(x);
const str = (x: unknown, d: string) => (typeof x === "string" ? x : d);

function theme(x: unknown): R {
  if (!isObj(x)) return fail("Invalid theme.");
  const primary = str(x.primary, ""), secondary = str(x.secondary, "");
  if (!isColor(primary) || !isColor(secondary)) return fail("Primary and secondary colors must be hex values like #0037E1.");
  const pick = <T extends Record<string, string>>(def: T, src: unknown, label: string): T | string => {
    const o: Record<string, string> = {};
    for (const k of Object.keys(def)) {
      const v = str(isObj(src) ? src[k] : undefined, def[k]);
      if (!isCssValue(v)) return `${label}: “${k}” has an unsupported value.`;
      o[k] = v;
    }
    return o as T;
  };
  const buttons: Record<string, unknown> = {};
  for (const k of ["primary", "secondary", "outline"] as ButtonKey[]) {
    const b = pick(defaultButtons[k] as unknown as Record<string, string>, isObj(x.buttons) ? x.buttons[k] : undefined, `${k} button`);
    if (typeof b === "string") return fail(b);
    buttons[k] = b;
  }
  const dialog = pick(defaultDialog as unknown as Record<string, string>, x.dialog, "Dialog");
  if (typeof dialog === "string") return fail(dialog);
  return { ok: true, json: JSON.stringify({ primary, secondary, ratings: x.ratings === true, buttons, dialog }) };
}

function fee(x: unknown): R {
  if (x === null) return { ok: true, json: "null" };
  if (!isObj(x)) return fail("Invalid fee configuration.");
  const def = FEE_DEFS.find((d) => d.kind === x.kind);
  if (!def) return fail("Unknown fee type.");
  const out: Record<string, unknown> = { kind: def.kind };
  for (const f of def.fields) {
    const n = Number(x[f.key]);
    if (x[f.key] === "" || x[f.key] === null || !Number.isFinite(n) || n < 0) return fail(`${f.label}: enter a number of 0 or more.`);
    if (f.pct && n > 100) return fail(`${f.label}: a percentage can’t be more than 100.`);
    out[f.key] = n;
  }
  return { ok: true, json: JSON.stringify(out as Fee) };
}

function legal(x: unknown): R {
  if (!Array.isArray(x) || x.length > 20) return fail("Invalid legal policies (max 20).");
  const out = [];
  for (const p of x) {
    if (!isObj(p)) return fail("Invalid legal policy.");
    const id = str(p.id, ""), name = str(p.name, "").trim().slice(0, 200);
    const privacy = sanitizeHtml(str(p.privacy, "").slice(0, 60000)), terms = sanitizeHtml(str(p.terms, "").slice(0, 60000));
    if (!/^[A-Za-z0-9_-]{1,40}$/.test(id) || !name) return fail("Each policy needs a name.");
    if (!privacy.trim() && !terms.trim()) return fail(`“${name}” needs a privacy policy, terms of use, or both.`);
    out.push({ id, name, privacy, terms });
  }
  return { ok: true, json: JSON.stringify(out) };
}

function categories(x: unknown): R {
  if (!isObj(x)) return fail("Invalid categories.");
  const out: Record<string, string[]> = {};
  for (const [g, items] of Object.entries(categoryLibrary)) {
    const v = x[g];
    if (Array.isArray(v)) out[g] = items.filter((i) => v.includes(i)); // only subcategories that exist in the library
  }
  return { ok: true, json: JSON.stringify(out) };
}

export const SETTING_LABELS: Record<string, string> = { fee: "fees & commissions", theme: "theme", legal: "legal policies", categories: "categories" };

/** Validates one JSON setting sent as a string; returns the cleaned JSON string to store. */
export function cleanSetting(key: string, raw: string): R {
  if (raw.length > 200000) return fail("Settings are too large.");
  let x: unknown;
  try { x = JSON.parse(raw); } catch { return fail("Invalid settings data."); }
  return key === "theme" ? theme(x) : key === "fee" ? fee(x) : key === "legal" ? legal(x) : key === "categories" ? categories(x) : fail("Unknown setting.");
}
