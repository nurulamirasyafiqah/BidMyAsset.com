/**
 * UI translations. English is the source text: `tr("ms", "My Bids")` → "Bida Saya"; any string that is not in the
 * dictionary stays in English (so a missing entry is never blank). The language comes from Settings → Preferences
 * (`prefs.language`, saved on the account, cached in the browser). Add a language: extend `Language` in preferences.ts
 * and add one dictionary here.
 */
import type { Language } from "@/lib/preferences";

const MS: Record<string, string> = {
  // header / footer / shell
  "About": "Tentang Kami", "Leadership": "Kepimpinan", "Login": "Log Masuk", "Register": "Daftar",
  "Terms & Conditions": "Terma & Syarat", "Privacy Policy": "Dasar Privasi", "All rights reserved.": "Hak cipta terpelihara.",
  "Notifications": "Notifikasi", "Mark all read": "Tandakan semua dibaca", "No notifications yet.": "Belum ada notifikasi.", "View all": "Lihat semua",
  "Signed in": "Log masuk sebagai", "Logout": "Log Keluar", "Open menu": "Buka menu", "Close menu": "Tutup menu", "Refresh": "Muat semula",
  // portal navigation
  "Dashboard": "Papan Pemuka", "Timed Auctions": "Lelongan Bermasa", "Favourite Lots": "Lot Kegemaran", "My Bids": "Bida Saya",
  "My Registrations": "Pendaftaran Saya", "My Invoices": "Invois Saya", "Auction Calendar": "Kalendar Lelongan", "Settings": "Tetapan", "Profile": "Profil",
  // invoices
  "View invoice details for your awarded lots.": "Lihat butiran invois untuk lot yang anda menangi.", "Search by auction name or lot sequence / lot name": "Cari mengikut nama lelongan atau urutan / nama lot",
  "No invoices found.": "Tiada invois dijumpai.", "Invoice": "Invois", "Auction / Lot": "Lelongan / Lot", "Amount": "Jumlah", "Status": "Status", "Issued": "Dikeluarkan",
  "Paid": "Dibayar", "Unpaid": "Belum dibayar", "Pay now": "Bayar sekarang", "Opening…": "Membuka…",
  // lot page
  "Live": "Siaran Langsung", "Upcoming": "Akan Datang", "Closed": "Ditutup", "Ending in": "Tamat dalam", "Starting in": "Bermula dalam",
  "Bidding summary": "Ringkasan bidaan", "Starting bid": "Bidaan permulaan", "Lot overview": "Gambaran lot", "Lot details": "Butiran lot", "Location": "Lokasi",
  "Lot sequence": "Urutan lot", "Lot number": "Nombor lot", "Auction name": "Nama lelongan", "Category": "Kategori", "Subcategory": "Subkategori", "Quantity": "Kuantiti",
  "Time zone": "Zon waktu", "Currency": "Mata wang", "Need help?": "Perlukan bantuan?", "Bidding is closed": "Bidaan telah ditutup", "Bidding opens when the auction starts": "Bidaan dibuka apabila lelongan bermula",
  "Get approved to start bidding on this lot.": "Dapatkan kelulusan untuk mula membida lot ini.", "+ Set Max Bid": "+ Tetapkan Bidaan Maksimum", "Open in Google Maps": "Buka dalam Google Maps",
  "Exact pickup details will be shared with registered bidders.": "Butiran pengambilan yang tepat akan dikongsi dengan pembida berdaftar.",
  "Bidder ranking": "Kedudukan pembida", "Bid history": "Sejarah bidaan", "No bids yet.": "Belum ada bidaan.", "Bidder": "Pembida", "Time": "Masa",
  "The bid history is shown after bidding closes.": "Sejarah bidaan dipaparkan selepas bidaan ditutup.", "The bid history is not shown for this auction.": "Sejarah bidaan tidak dipaparkan untuk lelongan ini.",
  // regional map
  "Regional presence": "Kehadiran serantau", "Operating Across Asia": "Beroperasi Merentasi Asia",
};

const DICT: Partial<Record<Language, Record<string, string>>> = { ms: MS };

export function tr(lang: Language, text: string): string {
  return DICT[lang]?.[text] ?? text;
}
