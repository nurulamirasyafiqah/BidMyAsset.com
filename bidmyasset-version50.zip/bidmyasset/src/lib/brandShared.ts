import { CONTACT } from "@/lib/content";

/** Public branding (client-safe types + defaults). Server loader: lib/brand.ts, reads the PocketBase `house` record. */
export type Brand = {
  name: string; logo: string; favicon: string; banners: string[]; phone: string; email: string; website: string;
  /** Auction House → Analytics & tracking / site description (kept from the original build). */
  gaId: string; description: string;
  /** Auction House → Theming & Config: CSS for the public site ("" = built-in look) and the "Allow questions & rating" switch. */
  themeCss: string; ratings: boolean;
  /** Auction House → Categories: category → enabled subcategories. null = not configured, show every category. */
  categories: Record<string, string[]> | null;
  /** `updated` stamp of the house record: ThemeSync compares it to know when the admin changed something. */
  version: string;
};

export const DEFAULT_BRAND: Brand = { name: "BidMyAsset", logo: "", favicon: "", banners: [], phone: CONTACT.phone, email: CONTACT.email, website: "", gaId: "", description: "", themeCss: "", ratings: false, categories: null, version: "" };
