// Allowlist HTML sanitizer for admin-entered legal text (privacy / terms). Runs on the server before saving AND again before rendering.
// Every tag is rebuilt from the allowlist (no attributes except a safe <a href>), all other markup is dropped and stray < > are escaped.
const ALLOWED = new Set(["p", "br", "hr", "ul", "ol", "li", "strong", "b", "em", "i", "u", "small", "sub", "sup", "span", "div", "blockquote",
  "h1", "h2", "h3", "h4", "h5", "h6", "a", "table", "thead", "tbody", "tr", "th", "td"]);
const VOID = new Set(["br", "hr"]);
const TAG = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g;
const escText = (t: string) => t.replace(/</g, "&lt;").replace(/>/g, "&gt;");

const hrefOf = (attrs: string) => {
  const m = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
  const v = (m?.[1] ?? m?.[2] ?? m?.[3] ?? "").trim();
  return /^(https?:\/\/|mailto:|tel:|\/|#)/i.test(v) && !/[\s"'<>`\\]/.test(v) ? v : "";
};

export function sanitizeHtml(input: string): string {
  const src = String(input ?? "").replace(/<(script|style|iframe|object|embed|noscript|template)\b[\s\S]*?<\/\1\s*>/gi, "");
  let out = "", last = 0;
  const stack: string[] = [];
  for (const m of src.matchAll(TAG)) {
    out += escText(src.slice(last, m.index));
    last = (m.index ?? 0) + m[0].length;
    const closing = m[1] === "/", name = m[2].toLowerCase();
    if (!ALLOWED.has(name)) continue;
    if (closing) {
      const at = stack.lastIndexOf(name);
      if (at === -1) continue;
      while (stack.length > at) out += `</${stack.pop()}>`;
    } else if (VOID.has(name)) out += `<${name}>`;
    else {
      stack.push(name);
      const href = name === "a" ? hrefOf(m[3]) : "";
      out += href ? `<a href="${href}"${/^https?:/i.test(href) ? ' target="_blank" rel="noopener noreferrer"' : ""}>` : `<${name}>`;
    }
  }
  out += escText(src.slice(last));
  while (stack.length) out += `</${stack.pop()}>`;
  return out;
}

const HAS_TAG = /<\/?[a-zA-Z][a-zA-Z0-9]*\b[^>]*>/;
/** Policy text for display: HTML is sanitized; plain text (no tags) keeps its paragraphs and line breaks. */
export function legalToHtml(text: string): string {
  const t = String(text ?? "");
  if (HAS_TAG.test(t)) return sanitizeHtml(t);
  return t.trim().split(/\n{2,}/).filter((p) => p.trim()).map((p) => `<p>${sanitizeHtml(p.trim()).replace(/\n/g, "<br>")}</p>`).join("");
}
