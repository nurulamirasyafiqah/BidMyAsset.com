import { PB_URL } from "@/lib/pb";
import type { AdminNotice } from "@/lib/admin";

/** Admin bell: pending registrations, enquiries, new bidder accounts and deletion requests, derived by the backend. Never throws. */
export async function fetchAdminNotices(uid: string): Promise<AdminNotice[]> {
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return [];
  try {
    const res = await fetch(`${PB_URL}/api/bma/admin/notices?uid=${encodeURIComponent(uid)}`, { headers: { "X-BMA-Admin-Key": key }, cache: "no-store" });
    if (!res.ok) return [];
    const j = (await res.json()) as { items?: AdminNotice[] };
    return (j.items ?? []).map((n) => ({ ...n, read: n.read === true }));
  } catch { return []; }
}
