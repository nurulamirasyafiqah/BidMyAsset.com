"use client";

import { useCallback, useEffect, useReducer } from "react";
import { THEME_KEY } from "@/lib/theme";
import { api } from "@/lib/client-api";

/**
 * Per-user account preferences. Saved on the account (users.prefs via GET/PUT /api/bma/me/preferences, validated by the
 * backend), so they follow the person across devices. localStorage is only a fast cache (and what the no-flash theme
 * boot script reads); the first time an existing browser connects, its saved choices are uploaded to the account.
 *
 * NOTE: the personal timezone is a DISPLAY preference only (notices, activity times). Auction open/close times,
 * countdowns and currency stay in each auction's own timezone — the blueprint makes timezone a project/company
 * setting, never a personal one (see lib/format.ts).
 */

export type Scope = "portal" | "admin";
export type Theme = "light" | "dark" | "system";
export type Language = "en" | "ms";

export type NotifyChannels = { inApp: boolean; email: boolean };
export type NotifyKey =
  | "outbid" | "won" | "registration" | "invoice" | "auctionReminder" | "marketing"   // portal (bidder)
  | "newRegistration" | "newBid" | "auctionEnding" | "invoicePaid" | "systemAlerts";  // admin

export type Prefs = {
  language: Language;
  timezone: string; // IANA zone, or "auto" = follow the device
  theme: Theme;
  notify: Partial<Record<NotifyKey, NotifyChannels>>;
};

export const LANGUAGES: { id: Language; label: string }[] = [
  { id: "en", label: "English" },
  { id: "ms", label: "Bahasa Malaysia" },
];

export const TIMEZONES: [string, string][] = [
  ["auto", "Automatic (use my device)"],
  ["Asia/Kuala_Lumpur", "Kuala Lumpur (UTC+8)"],
  ["Asia/Singapore", "Singapore (UTC+8)"],
  ["Asia/Bangkok", "Bangkok (UTC+7)"],
  ["Asia/Jakarta", "Jakarta (UTC+7)"],
  ["Asia/Manila", "Manila (UTC+8)"],
  ["Asia/Dubai", "Dubai (UTC+4)"],
  ["Asia/Kolkata", "India (UTC+5:30)"],
  ["Europe/London", "London"],
  ["America/New_York", "New York"],
  ["Australia/Sydney", "Sydney"],
  ["UTC", "UTC"],
];

export type NotifyRow = { key: NotifyKey; label: string; hint: string; locked?: boolean };

/** `locked` = transactional, always sent (cannot be switched off). Email Templates (admin) controls the WORDING; these control WHETHER. */
export const PORTAL_NOTIFY: NotifyRow[] = [
  { key: "outbid", label: "Outbid alerts", hint: "When another bidder passes your bid." },
  { key: "won", label: "Won lots", hint: "When you win a lot at close." },
  { key: "registration", label: "Registration status", hint: "Approved / rejected auction registrations.", locked: true },
  { key: "invoice", label: "Invoices & payments", hint: "New invoices and payment confirmations.", locked: true },
  { key: "auctionReminder", label: "Auction reminders", hint: "Opening and closing reminders for auctions you follow." },
  { key: "marketing", label: "News & new auctions", hint: "Newsletter and new auction announcements." },
];
export const ADMIN_NOTIFY: NotifyRow[] = [
  { key: "newRegistration", label: "New bidder registrations", hint: "A bidder asks to join an auction." },
  { key: "newBid", label: "Bid activity", hint: "New bids on your auctions." },
  { key: "auctionEnding", label: "Auctions ending soon", hint: "Closing reminders for live auctions." },
  { key: "invoicePaid", label: "Invoice payments", hint: "Payments received or overdue." },
  { key: "systemAlerts", label: "Security & system alerts", hint: "Sign-ins from new devices, failed logins, role changes.", locked: true },
];

const DEFAULT_CH: NotifyChannels = { inApp: true, email: true };
export const defaultPrefs = (scope: Scope): Prefs => ({
  language: "en",
  timezone: "auto",
  theme: "system",
  notify: Object.fromEntries((scope === "portal" ? PORTAL_NOTIFY : ADMIN_NOTIFY).map((r) => [r.key, { ...DEFAULT_CH, email: r.key !== "marketing" }])),
});

const key = (s: Scope) => `bma:prefs:${s}`;

export function resolveTimezone(tz: string): string {
  return tz === "auto" ? Intl.DateTimeFormat().resolvedOptions().timeZone : tz;
}

export function applyTheme(t: Theme) {
  const dark = t === "dark" || (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
}

const mergePrefs = (scope: Scope, p: Partial<Prefs> | null | undefined): Prefs => {
  const d = defaultPrefs(scope);
  return p ? { ...d, ...p, notify: { ...d.notify, ...p.notify } } : d;
};

const readLocal = (scope: Scope): Partial<Prefs> | null => {
  try { const raw = localStorage.getItem(key(scope)); return raw ? (JSON.parse(raw) as Partial<Prefs>) : null; } catch { return null; }
};
const writeLocal = (scope: Scope, p: Prefs) => {
  try { localStorage.setItem(key(scope), JSON.stringify(p)); localStorage.setItem(THEME_KEY, p.theme); } catch { /* storage unavailable */ }
};

/** One server read per scope per page load, shared by every usePrefs() caller. null = nothing saved on the server yet. */
const serverRead: Partial<Record<Scope, Promise<Partial<Prefs> | null | undefined>>> = {};
function loadServer(scope: Scope) {
  return (serverRead[scope] ??= api<{ prefs: Partial<Prefs> | null }>(`api/bma/me/preferences?scope=${scope}`)
    .then((r) => r.prefs)
    .catch(() => { delete serverRead[scope]; return undefined; })); // undefined = could not reach the server: keep what the browser has
}
const saveServer = (scope: Scope, prefs: Prefs) => api("api/bma/me/preferences", { method: "PUT", body: { scope, prefs } });

/** One shared copy per scope, so the Notification and Preferences panels (and the timezone readers) never overwrite each other. */
type Store = { prefs: Prefs; ready: boolean; started: boolean; saveError: string; subs: Set<() => void>; timer?: ReturnType<typeof setTimeout> };
const stores: Partial<Record<Scope, Store>> = {};
const storeOf = (scope: Scope): Store => (stores[scope] ??= { prefs: defaultPrefs(scope), ready: false, started: false, saveError: "", subs: new Set() });
const publish = (st: Store) => st.subs.forEach((f) => f());

function setPrefsIn(st: Store, next: Prefs) {
  const prev = st.prefs;
  st.prefs = next;
  if (next.theme !== prev.theme) applyTheme(next.theme);
  if (next.language !== prev.language) document.documentElement.lang = next.language;
  publish(st);
}

function start(scope: Scope) {
  const st = storeOf(scope);
  if (st.started) return;
  st.started = true;
  const local = readLocal(scope);
  if (local) setPrefsIn(st, mergePrefs(scope, local)); // instant: no flash while the server answers
  loadServer(scope).then((server) => {
    if (server) { const n = mergePrefs(scope, server); writeLocal(scope, n); setPrefsIn(st, n); }
    else if (server === null && local) void saveServer(scope, mergePrefs(scope, local)).catch(() => {}); // first run after the upgrade: move this browser's choices to the account
    st.ready = true;
    publish(st);
  });
}

export function usePrefs(scope: Scope) {
  const st = storeOf(scope);
  const [, rerender] = useReducer((n: number) => n + 1, 0);

  useEffect(() => {
    st.subs.add(rerender);
    start(scope);
    rerender(); // pick up a store that another component already filled
    return () => { st.subs.delete(rerender); };
  }, [scope, st]);

  // follow the OS when theme = "system"
  useEffect(() => {
    if (st.prefs.theme !== "system") return;
    const mq = matchMedia("(prefers-color-scheme: dark)");
    const h = () => applyTheme("system");
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, [st.prefs.theme, st]);

  const update = useCallback((patch: (p: Prefs) => Prefs) => {
    const next = patch(st.prefs);
    writeLocal(scope, next);
    setPrefsIn(st, next);
    clearTimeout(st.timer);
    st.timer = setTimeout(() => {
      st.saveError = ""; publish(st);
      saveServer(scope, st.prefs).catch((e) => { st.saveError = e instanceof Error ? e.message : "Could not save your preferences"; publish(st); });
    }, 400); // several quick toggles become one request
  }, [scope, st]);

  return { prefs: st.prefs, update, ready: st.ready, saveError: st.saveError };
}

/** Read the saved personal timezone (client only). Falls back to the device zone. */
export function useDisplayTimezone(scope: Scope): string {
  const { prefs } = usePrefs(scope);
  return resolveTimezone(prefs.timezone);
}
