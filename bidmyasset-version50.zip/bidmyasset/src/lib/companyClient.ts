"use client";
import { useCallback, useEffect, useRef, useState } from "react";

/** Admin → Company data lives in PocketBase (`company` record) via /api/admin/company. */
export async function loadCompany(): Promise<Record<string, unknown>> {
  const res = await fetch("/api/admin/company", { cache: "no-store" });
  const j = (await res.json().catch(() => ({}))) as Record<string, unknown> & { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
  return j;
}

export async function saveCompany(body: Record<string, unknown>): Promise<Record<string, unknown>> {
  const res = await fetch("/api/admin/company", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = (await res.json().catch(() => ({}))) as Record<string, unknown> & { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
  return j;
}

export const COMPANY_ERROR_EVENT = "company-save-error";

/**
 * Like useState, but the value is loaded from and saved to one Company section.
 * `init` is only shown while nothing has been saved yet; every change is saved right away.
 */
export function usePersisted<T>(section: string, init: T): [T, (next: T | ((prev: T) => T)) => void, boolean] {
  const [value, setValue] = useState<T>(init);
  const latest = useRef<T>(init);
  latest.current = value;
  const [loading, setLoading] = useState(true);
  const live = useRef(true);
  useEffect(() => {
    live.current = true;
    loadCompany()
      .then((d) => { if (live.current && d[section] !== null && d[section] !== undefined) setValue(d[section] as T); })
      .catch((e) => window.dispatchEvent(new CustomEvent(COMPANY_ERROR_EVENT, { detail: e instanceof Error ? e.message : "Failed to load" })))
      .finally(() => { if (live.current) setLoading(false); });
    return () => { live.current = false; };
  }, [section]);
  const set = useCallback((arg: T | ((prev: T) => T)) => {
    const next = typeof arg === "function" ? (arg as (prev: T) => T)(latest.current) : arg;
    latest.current = next;
    setValue(next);
    saveCompany({ [section]: next }).then((d) => { if (live.current && d[section] !== null && d[section] !== undefined) setValue(d[section] as T); })
      .catch((e) => {
        window.dispatchEvent(new CustomEvent(COMPANY_ERROR_EVENT, { detail: e instanceof Error ? e.message : "Failed to save" }));
        // the server refused the change: show what is really saved instead of the optimistic edit
        loadCompany().then((d) => { const v = d[section]; if (live.current && v !== null && v !== undefined) { latest.current = v as T; setValue(v as T); } }).catch(() => {});
      });
  }, [section]);
  return [value, set, loading];
}
