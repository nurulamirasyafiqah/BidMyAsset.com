"use client";

import { useCallback } from "react";
import { tr } from "@/lib/i18n";
import { usePrefs } from "@/lib/preferences";

/** Translate a UI string into the language chosen in Settings → Preferences (English when nothing is saved). */
export function useT() {
  const lang = usePrefs("portal").prefs.language;
  return useCallback((text: string) => tr(lang, text), [lang]);
}
