import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ProfileView } from "@/components/admin/InsightViews";
import { getAdminUser } from "@/lib/pb";
import { toProfile } from "@/lib/portal";
export const metadata: Metadata = { title: "Profile Settings" };
export const dynamic = "force-dynamic";
export default async function Page() {
  const me = await getAdminUser();
  if (!me) redirect("/login?next=/admin/profile");
  return <ProfileView mode="profile" profile={toProfile(me.record)} />;
}
