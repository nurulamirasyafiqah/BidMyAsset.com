import type { Metadata } from "next";
import { InvoiceMgmtView } from "@/components/admin/PeopleViews";
export const metadata: Metadata = { title: "Invoice Management" };
export default function Page() { return <InvoiceMgmtView />; }
