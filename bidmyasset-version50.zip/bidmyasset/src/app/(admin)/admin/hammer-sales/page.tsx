import type { Metadata } from "next";
import { HammerSalesView } from "@/components/admin/PeopleViews";
export const metadata: Metadata = { title: "Hammer Sales" };
export default function Page() { return <HammerSalesView />; }
