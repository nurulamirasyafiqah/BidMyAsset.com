import type { Metadata } from "next";
import { AdminNotificationsView } from "@/components/admin/InsightViews";
export const metadata: Metadata = { title: "Notifications" };
export default function Page() { return <AdminNotificationsView />; }
