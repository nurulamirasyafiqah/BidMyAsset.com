import type { Metadata } from "next";
import { CompanyView } from "@/components/admin/CompanyView";
export const metadata: Metadata = { title: "Company" };
export default function Page() { return <CompanyView />; }
