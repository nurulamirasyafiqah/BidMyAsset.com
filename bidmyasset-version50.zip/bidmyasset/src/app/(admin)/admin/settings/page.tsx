import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ProfileView } from "@/components/admin/InsightViews";
import { getAdminUser } from "@/lib/pb";
import { toProfile } from "@/lib/portal";
export const metadata: Metadata = { title: "Account Settings" };
export const dynamic = "force-dynamic";
export default async function Page() {
  const me = await getAdminUser();
  if (!me) redirect("/login?next=/admin/settings");
  return <ProfileView mode="settings" profile={toProfile(me.record)} />;
}
