import type { Metadata } from "next";
import { AuctionHouseView } from "@/components/admin/AuctionHouseView";
export const metadata: Metadata = { title: "Auction House" };
export default function Page() { return <AuctionHouseView />; }
