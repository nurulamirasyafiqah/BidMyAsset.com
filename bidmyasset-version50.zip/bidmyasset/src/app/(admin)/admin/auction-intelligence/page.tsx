import type { Metadata } from "next";
import { IntelligenceView } from "@/components/admin/IntelligenceViews";
export const metadata: Metadata = { title: "Auction Intelligence" };
export default async function Page({ searchParams }: { searchParams: Promise<{ mode?: string }> }) {
  const { mode } = await searchParams;
  return <IntelligenceView initialMode={mode === "closed" ? "CLOSED" : "RUNNING"} />;
}
