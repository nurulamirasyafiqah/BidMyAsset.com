import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ReportsWorkspace } from "@/components/admin/IntelligenceReports";
import { AnalyticsDashboard, BidderAnalysis, KpiAnalytics, Recordings, UnifiedAnalytics } from "@/components/admin/IntelligenceAnalytics";
import { INTEL_VIEWS } from "@/lib/intelligence";
export const metadata: Metadata = { title: "Auction Intelligence" };

const VIEWS = { "kpi-analytics": KpiAnalytics, "unified-analytics": UnifiedAnalytics, "analytics-dashboard": AnalyticsDashboard, "bidder-analysis": BidderAnalysis, recordings: Recordings } as const;

export default async function Page({ params }: { params: Promise<{ id: string; view: string }> }) {
  const { id, view } = await params;
  if (view === "reports") return <ReportsWorkspace id={id} />;
  if (!INTEL_VIEWS.includes(view)) notFound();
  const View = VIEWS[view as keyof typeof VIEWS];
  return View ? <View id={id} /> : notFound();
}
