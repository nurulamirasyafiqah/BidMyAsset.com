import type { Metadata } from "next";
import { ActivityView } from "@/components/admin/InsightViews";
export const metadata: Metadata = { title: "User Activity Analytics" };
export default function Page() { return <ActivityView />; }
