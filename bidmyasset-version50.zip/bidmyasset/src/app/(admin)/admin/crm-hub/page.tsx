import type { Metadata } from "next";
import { CrmHubView } from "@/components/admin/InsightViews";
export const metadata: Metadata = { title: "CRM Hub" };
export default function Page() { return <CrmHubView />; }
