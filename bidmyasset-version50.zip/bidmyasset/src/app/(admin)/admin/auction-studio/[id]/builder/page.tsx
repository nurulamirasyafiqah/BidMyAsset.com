import type { Metadata } from "next";
import { StudioBuilder } from "@/components/admin/StudioViews";
export const metadata: Metadata = { title: "Auction Builder" };
export default async function Page({ params }: { params: Promise<{ id: string }> }) { return <StudioBuilder id={(await params).id} />; }
