import type { Metadata } from "next";
import { StudioDetail } from "@/components/admin/StudioViews";
export const metadata: Metadata = { title: "Auction details" };
export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ tab?: string }> }) {
  const [{ id }, { tab }] = await Promise.all([params, searchParams]);
  return <StudioDetail id={id} initialTab={tab} />;
}
