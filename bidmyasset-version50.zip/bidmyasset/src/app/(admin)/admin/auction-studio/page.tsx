import type { Metadata } from "next";
import { StudioList } from "@/components/admin/StudioViews";
export const metadata: Metadata = { title: "Auction Studio" };
export default function Page() { return <StudioList />; }
