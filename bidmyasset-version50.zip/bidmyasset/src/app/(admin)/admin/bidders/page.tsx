import type { Metadata } from "next";
import { BiddersView } from "@/components/admin/PeopleViews";
export const metadata: Metadata = { title: "Bidders" };
export default function Page() { return <BiddersView />; }
