import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AdminShell } from "@/components/admin/AdminShell";
import { fetchAdminNotices } from "@/lib/adminNotices";
import { getSessionUser } from "@/lib/pb";
import { toProfile } from "@/lib/portal";

export const metadata: Metadata = { title: { default: "Admin", template: "%s · BidMyAsset Admin" } };
export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const me = await getSessionUser();
  if (!me) redirect("/login?next=/admin/dashboard"); // no / expired session
  if (me.record.isAdmin !== true) redirect("/dashboard"); // signed in, but not staff
  const adminNotices = await fetchAdminNotices(String(me.record.id));
  return <AdminShell notices={adminNotices} user={{ name: toProfile(me.record).name, email: toProfile(me.record).email }}>{children}</AdminShell>;
}
