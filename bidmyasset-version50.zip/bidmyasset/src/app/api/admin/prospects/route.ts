import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/** Non-registered bidders ("prospects"), admin only. Next calls PocketBase server-side with BMA_ADMIN_KEY. */
async function forward(path: string, method: "GET" | "POST", body?: unknown) {
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const res = await fetch(`${PB_URL}/api/bma/admin/prospects${path}`, {
    method, cache: "no-store",
    headers: { "X-BMA-Admin-Key": key, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}
const emailOf = async (res: Response) => {
  try { const j = (await res.clone().json()) as { item?: { email?: string }; email?: string }; return j.item?.email ?? j.email ?? ""; } catch { return ""; }
};

export async function GET() {
  if (!(await getAdminUser())) return Response.json({ message: "Forbidden" }, { status: 403 });
  return forward("", "GET");
}

/** Add a prospect. */
export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return Response.json({ message: "Invalid request" }, { status: 400 });
  const res = await forward("", "POST", body);
  if (res.ok) await logActivity(String(me.record.email), `Added prospect ${await emailOf(res)}`, true, clientIp(req));
  return res;
}

/** Mark a prospect as invited. */
export async function PATCH(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const { id } = ((await req.json().catch(() => ({}))) as { id?: unknown });
  if (typeof id !== "string" || !id) return Response.json({ message: "id required" }, { status: 400 });
  const res = await forward("/invite", "POST", { id });
  if (res.ok) await logActivity(String(me.record.email), `Invited prospect ${await emailOf(res)}`, true, clientIp(req));
  return res;
}

/** Remove a prospect: DELETE /api/admin/prospects?id=... */
export async function DELETE(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return Response.json({ message: "id required" }, { status: 400 });
  const res = await forward("/remove", "POST", { id });
  if (res.ok) await logActivity(String(me.record.email), `Removed prospect ${await emailOf(res)}`, true, clientIp(req));
  return res;
}
