import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/** Admin team management: only signed-in admins; Next talks to PocketBase server-side with BMA_ADMIN_KEY. */
async function forward(method: "GET" | "POST", body?: string) {
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const res = await fetch(`${PB_URL}/api/bma/admin/users`, {
    method, body, cache: "no-store",
    headers: { "X-BMA-Admin-Key": key, ...(body ? { "Content-Type": "application/json" } : {}) },
  }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

export async function GET() {
  if (!(await getAdminUser())) return Response.json({ message: "Forbidden" }, { status: 403 });
  return forward("GET");
}

export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const text = await req.text();
  let email = "", isAdmin = true, disabled: boolean | undefined;
  try {
    const j = JSON.parse(text) as { email?: string; isAdmin?: boolean; disabled?: unknown };
    email = String(j.email ?? "").toLowerCase().trim(); isAdmin = j.isAdmin !== false;
    if (typeof j.disabled === "boolean") disabled = j.disabled;
  } catch { /* fall through */ }
  if (disabled !== undefined) {
    if (disabled && email === String(me.record.email).toLowerCase()) return Response.json({ message: "You can't disable your own account." }, { status: 400 });
    const res = await forward("POST", JSON.stringify({ email, disabled }));
    if (res.ok) await logActivity(String(me.record.email), disabled ? `Disabled auctioneer ${email}` : `Enabled auctioneer ${email}`, true, clientIp(req));
    return res;
  }
  if (!isAdmin && email === String(me.record.email).toLowerCase()) return Response.json({ message: "You can't remove your own admin access." }, { status: 400 });
  const res = await forward("POST", text);
  if (res.ok) await logActivity(String(me.record.email), isAdmin ? `Granted admin access to ${email}` : `Removed admin access from ${email}`, true, clientIp(req));
  return res;
}
