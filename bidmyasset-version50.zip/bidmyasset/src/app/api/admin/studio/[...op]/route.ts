import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/**
 * Auction Studio → PocketBase (admin only). One catch-all so the browser has a single same-origin entry:
 *   GET  /api/admin/studio/list            auctions + lots (+ image URLs)
 *   POST /api/admin/studio/auctions        create draft auction (multipart: title, startsAt, endsAt, timezone, currency, images[])
 *   POST /api/admin/studio/auction-publish {id, published}
 *   POST /api/admin/studio/auction-clone   {id, title, startsAt, endsAt, lots}
 *   POST /api/admin/studio/auction-pause   {id, paused}
 *   GET  /api/admin/studio/bids?auction=ID       every bid placed in one auction
 *   GET  /api/admin/studio/questions?auction=ID  bidder questions about that auction's lots
 *   GET  /api/admin/studio/registrations?auction=ID   bidder registrations for that auction
 *   POST /api/admin/studio/registration-review {id, status}  approve / reject a registration
 *   POST /api/admin/studio/question-review {id, answer, status}  answer / publish / hide a question
 *   POST /api/admin/studio/auction-update  {id, title, startsAt, endsAt, timezone, auctionType, description, approvalMode, hideBidders, stagger, extras}
 *   POST /api/admin/studio/builder-save    {id, section, data}   contacts | address | registration | commission | payment | catalog | bid
 *   POST /api/admin/studio/builder-file    multipart: kind=document|avatar, id, remove[]?, files[]?   (kind first!)
 *   POST /api/admin/studio/catalog-notify  {id}   email the saved catalog recipients
 *   POST /api/admin/studio/lots            create / update a lot (json)
 *   POST /api/admin/studio/lots-delete     {ids[]}
 *   POST /api/admin/studio/lots-import     multipart: auction, sheet (.csv / .xlsx)   create / update lots from a spreadsheet
 *   POST /api/admin/studio/lots-images-zip multipart: auction, zip   attach photos to lots by file / folder name (lot number or SKU)
 *   POST /api/admin/studio/lots-stagger    {auction, ids?, gapSeconds, reverse?, unit?, gap?}   spread lot closing times
 *   POST /api/admin/studio/images          multipart: kind=auction|lot, id, remove[]?, images[]?
 * Next checks the caller is an admin, validates uploads (type/size), then forwards with BMA_ADMIN_KEY.
 * PocketBase stores the files and validates again; the browser never talks to PocketBase directly.
 */
const MAX = 10 * 1024 * 1024;
const MAX_DOC = 25 * 1024 * 1024;
const OK_DOC = /\.(pdf|docx?|xlsx?|png|jpe?g)$/i;
const OK_TYPE = /^image\/(png|jpe?g|webp)$/;
const MAX_SHEET = 10 * 1024 * 1024;
const MAX_ZIP = 100 * 1024 * 1024;
const OPS: Record<string, { backend: string; multipart: boolean; label: string }> = {
  auctions: { backend: "auctions", multipart: true, label: "Created auction" },
  "auction-publish": { backend: "auction-publish", multipart: false, label: "Changed auction visibility" },
  "auction-clone": { backend: "auction-clone", multipart: false, label: "Cloned auction" },
  "auction-pause": { backend: "auction-pause", multipart: false, label: "Paused / resumed bidding" },
  "auction-update": { backend: "auction-update", multipart: false, label: "Edited auction details" },
  "builder-save": { backend: "builder-save", multipart: false, label: "Saved an Auction Builder section" },
  "builder-file": { backend: "builder-file", multipart: true, label: "Changed auction documents / contact photos" },
  "catalog-notify": { backend: "catalog-notify", multipart: false, label: "Emailed catalog recipients" },
  "registration-review": { backend: "registration-review", multipart: false, label: "Reviewed a bidder registration" },
  "question-review": { backend: "question-review", multipart: false, label: "Reviewed a lot question" },
  lots: { backend: "lots", multipart: false, label: "Saved lot" },
  "lots-delete": { backend: "lots-delete", multipart: false, label: "Deleted lots" },
  "lots-import": { backend: "lots-import", multipart: true, label: "Imported lots from a spreadsheet" },
  "lots-images-zip": { backend: "lots-images-zip", multipart: true, label: "Imported lot photos from a ZIP" },
  "lots-stagger": { backend: "lots-stagger", multipart: false, label: "Staggered lot closing times" },
  "images-order": { backend: "images-order", multipart: false, label: "Reordered images" },
  images: { backend: "images", multipart: true, label: "Uploaded auction images" },
};
const bad = (message: string, status = 400) => Response.json({ message }, { status });
const key = () => process.env.BMA_ADMIN_KEY;

const READS: Record<string, string> = { list: "studio", bids: "studio-bids", "max-bids": "studio-max-bids", questions: "studio-questions", registrations: "studio-registrations" };

export async function GET(req: Request, ctx: { params: Promise<{ op: string[] }> }) {
  const path = READS[(await ctx.params).op.join("/")];
  if (!path) return bad("Not found", 404);
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  const auction = new URL(req.url).searchParams.get("auction");
  const qs = path === "studio" ? "" : `?auction=${encodeURIComponent(auction ?? "")}`;
  if (path !== "studio" && !auction) return bad("auction is required");
  const res = await fetch(`${PB_URL}/api/bma/admin/${path}${qs}`, { headers: { "X-BMA-Admin-Key": key()! }, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

export async function POST(req: Request, ctx: { params: Promise<{ op: string[] }> }) {
  const op = OPS[(await ctx.params).op.join("/")];
  if (!op) return bad("Not found", 404);
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);

  let body: BodyInit, headers: Record<string, string> = { "X-BMA-Admin-Key": key()! };
  let uploaded = 0;
  if (op.multipart) {
    let incoming: FormData;
    try { incoming = await req.formData(); } catch { return bad("Expected multipart/form-data"); }
    const out = new FormData();
    const kind = String(incoming.get("kind") ?? "");
    for (const [k, v] of incoming.entries()) {
      if (typeof v === "string") { out.append(k, v); continue; }
      if (v.size === 0) continue;
      if (k === "images" || (k === "files" && kind === "avatar")) {
        if (!OK_TYPE.test(v.type)) return bad(`${v.name}: use a JPG, PNG or WebP image.`);
        if (v.size > MAX) return bad(`${v.name}: image must be 10 MB or smaller.`);
      } else if (k === "sheet") {
        if (!/\.(csv|xlsx)$/i.test(v.name)) return bad(`${v.name}: use a .csv or .xlsx file.`);
        if (v.size > MAX_SHEET) return bad(`${v.name}: spreadsheet must be 10 MB or smaller.`);
        out.append(k, v, v.name); continue;
      } else if (k === "zip") {
        if (!/\.zip$/i.test(v.name)) return bad(`${v.name}: use a .zip file.`);
        if (v.size > MAX_ZIP) return bad(`${v.name}: ZIP must be 100 MB or smaller.`);
        out.append(k, v, v.name); continue;
      } else if (k === "files" && kind === "document") {
        if (!OK_DOC.test(v.name)) return bad(`${v.name}: use a PDF, Word, Excel, PNG or JPG file.`);
        if (v.size > MAX_DOC) return bad(`${v.name}: file must be 25 MB or smaller.`);
      } else continue;
      out.append(k, v, v.name); uploaded++;
    }
    body = out; // fetch sets the multipart boundary itself
  } else {
    body = await req.text();
    headers = { ...headers, "Content-Type": "application/json" };
  }

  const res = await fetch(`${PB_URL}/api/bma/admin/${op.backend}`, { method: "POST", body, headers, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) await logActivity(String(me.record.email), uploaded ? `${op.label} (${uploaded} image${uploaded === 1 ? "" : "s"})` : op.label, true, clientIp(req));
  return new Response(text, { status: res.status, headers: { "Content-Type": "application/json" } });
}
