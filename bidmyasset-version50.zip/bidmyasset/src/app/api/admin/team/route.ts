import { revalidatePath, revalidateTag } from "next/cache";
import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/**
 * Admin → Team → PocketBase `team_members` (the people on the public /leadership page). Admin-only; forwarded with
 * BMA_ADMIN_KEY and validated again by the backend (backend/team.go).
 *   GET                         → { items: [...] }
 *   POST multipart              id?, name, role, group, linkedin, visible, photo?, removePhoto?
 *   PUT { ids: [...] }          → new order inside a group
 *   DELETE { id }
 */
const MAX = 2 * 1024 * 1024;
const OK_TYPE = /^image\/(png|jpe?g|webp)$/;
const key = () => process.env.BMA_ADMIN_KEY;
const bad = (message: string, status = 400) => Response.json({ message }, { status });
const base = () => `${PB_URL}/api/bma/admin`;
const json = (text: string, status: number) => new Response(text, { status, headers: { "Content-Type": "application/json" } });
const changed = () => { revalidateTag("team"); revalidatePath("/leadership"); };

export async function GET() {
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  const res = await fetch(`${base()}/team`, { headers: { "X-BMA-Admin-Key": key()! }, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return json(await res.text(), res.status);
}

export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  let incoming: FormData;
  try { incoming = await req.formData(); } catch { return bad("Expected multipart/form-data"); }

  const out = new FormData();
  for (const [k, v] of incoming.entries()) {
    if (typeof v === "string") { out.append(k, v); continue; }
    if (k !== "photo" || v.size === 0) continue;
    if (!OK_TYPE.test(v.type)) return bad("photo: use a PNG, JPG or WebP image.");
    if (v.size > MAX) return bad("photo: image must be 2 MB or smaller.");
    out.append("photo", v, v.name);
  }
  const res = await fetch(`${base()}/team`, { method: "POST", body: out, cache: "no-store", headers: { "X-BMA-Admin-Key": key()! } }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) {
    changed();
    const id = String(incoming.get("id") ?? "");
    await logActivity(String(me.record.email), `Team: ${id ? "updated" : "added"} ${String(incoming.get("name") ?? "").slice(0, 80)}`, true, clientIp(req));
  }
  return json(text, res.status);
}

export async function PUT(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  let body: { ids?: unknown };
  try { body = (await req.json()) as { ids?: unknown }; } catch { return bad("Invalid request"); }
  if (!Array.isArray(body.ids) || body.ids.some((i) => typeof i !== "string")) return bad("Invalid request");
  const res = await fetch(`${base()}/team-order`, {
    method: "POST", cache: "no-store", body: JSON.stringify({ ids: body.ids }),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key()! },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) { changed(); await logActivity(String(me.record.email), "Team: changed the order", true, clientIp(req)); }
  return json(text, res.status);
}

export async function DELETE(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  let body: { id?: unknown; name?: unknown };
  try { body = (await req.json()) as { id?: unknown; name?: unknown }; } catch { return bad("Invalid request"); }
  if (typeof body.id !== "string" || !body.id) return bad("Invalid request");
  const res = await fetch(`${base()}/team-delete`, {
    method: "POST", cache: "no-store", body: JSON.stringify({ id: body.id }),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key()! },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) { changed(); await logActivity(String(me.record.email), `Team: removed ${typeof body.name === "string" ? body.name.slice(0, 80) : "a person"}`, true, clientIp(req)); }
  return json(text, res.status);
}
