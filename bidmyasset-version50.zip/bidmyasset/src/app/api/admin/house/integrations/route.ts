import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/**
 * Auction House → Email Configuration (SMTP) and Payment Credentials (Toyyibpay). Admin-only; forwarded with BMA_ADMIN_KEY.
 * The backend keeps the secrets in a collection with no API rules and never returns them: only `passwordSet` / `secretSet`.
 *   GET → { smtp: {host, port, username, passwordSet, from, fromName}, payment: {defaultGateway, secretSet, categoryCode, sandbox} }
 *   PUT { smtp?: {host, port, username, password?, from, fromName}, payment?: {secret?, categoryCode, sandbox} } → same shape as GET
 */
const key = () => process.env.BMA_ADMIN_KEY;
const bad = (message: string, status = 400) => Response.json({ message }, { status });
const URL_ = () => `${PB_URL}/api/bma/admin/house/integrations`;

export async function GET() {
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  const res = await fetch(URL_(), { headers: { "X-BMA-Admin-Key": key()! }, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

export async function PUT(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  let body: Record<string, unknown>;
  try { body = (await req.json()) as Record<string, unknown>; } catch { return bad("Invalid request"); }
  if (!body || typeof body !== "object" || Array.isArray(body)) return bad("Invalid request");
  const parts = Object.keys(body).filter((k) => k === "smtp" || k === "payment");
  if (parts.length === 0 || parts.length !== Object.keys(body).length) return bad("Send smtp and/or payment.");
  const res = await fetch(URL_(), {
    method: "PUT", cache: "no-store", body: JSON.stringify(body),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key()! },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) await logActivity(String(me.record.email), `Auction house: updated ${parts.map((p) => (p === "smtp" ? "email (SMTP)" : "payment")).join(" and ")} settings`, true, clientIp(req));
  return new Response(text, { status: res.status, headers: { "Content-Type": "application/json" } });
}
