import { revalidatePath, revalidateTag } from "next/cache";
import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/**
 * Auction House → Fees & Commissions (internet buying fee), Theming & Config, Legal Policies and Categories → PocketBase `house` record.
 * Admin-only; forwarded with BMA_ADMIN_KEY. The backend validates every value again (backend/house_settings.go),
 * because theme values end up in CSS on the public site.
 *   GET → { fee, theme }        PUT { fee?: Fee | null, theme?: Theme, legal?: LegalPolicy[], categories?: Record<string,string[]> | null } → { fee, theme, legal, categories, example }
 */
const key = () => process.env.BMA_ADMIN_KEY;
const bad = (message: string, status = 400) => Response.json({ message }, { status });
const URL_ = () => `${PB_URL}/api/bma/admin/house/settings`;

export async function GET() {
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  const res = await fetch(URL_(), { headers: { "X-BMA-Admin-Key": key()! }, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

export async function PUT(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);

  let body: Record<string, unknown>;
  try { body = (await req.json()) as Record<string, unknown>; } catch { return bad("Invalid request"); }
  if (!body || typeof body !== "object" || Array.isArray(body)) return bad("Invalid request");
  const parts = Object.keys(body).filter((k) => k === "fee" || k === "theme" || k === "legal" || k === "categories");
  if (parts.length === 0 || parts.length !== Object.keys(body).length) return bad("Send fee, theme, legal and/or categories.");

  const res = await fetch(URL_(), {
    method: "PUT", cache: "no-store", body: JSON.stringify(body),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key()! },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) {
    // the public site caches the house record (lib/brand.ts): refresh it now instead of waiting for the 30 s window
    revalidateTag("house");
    revalidatePath("/", "layout");
    revalidatePath("/privacy"); revalidatePath("/terms");
    const what = parts.map((p) => (p === "fee" ? (body.fee === null ? "removed the internet buying fee" : "updated the internet buying fee") : p === "theme" ? "updated the theme" : p === "legal" ? "updated the legal policies" : body.categories === null ? "reset the category library" : "updated the category library")).join(" and ");
    await logActivity(String(me.record.email), `Auction house: ${what}`, true, clientIp(req));
  }
  return new Response(text, { status: res.status, headers: { "Content-Type": "application/json" } });
}
