import { revalidatePath, revalidateTag } from "next/cache";
import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/**
 * Auction house profile + branding uploads (logo, favicon, banners) → PocketBase `house` collection.
 * Admin-only. Multipart is forwarded to PocketBase with BMA_ADMIN_KEY; PocketBase stores the files and
 * re-validates type/size, so the browser never talks to it directly.
 */
const MAX = 2 * 1024 * 1024;
const OK_TYPE = /^image\/(png|jpe?g|webp|svg\+xml)$/;
const key = () => process.env.BMA_ADMIN_KEY;
const bad = (message: string, status = 400) => Response.json({ message }, { status });

export async function GET() {
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);
  const res = await fetch(`${PB_URL}/api/bma/admin/house`, { headers: { "X-BMA-Admin-Key": key()! }, cache: "no-store" }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return bad("Forbidden", 403);
  if (!key()) return bad("BMA_ADMIN_KEY is not configured", 500);

  let incoming: FormData;
  try { incoming = await req.formData(); } catch { return bad("Expected multipart/form-data"); }

  const out = new FormData();
  for (const [k, v] of incoming.entries()) {
    if (typeof v === "string") { out.append(k, v); continue; }
    if (!["logo", "favicon", "banners"].includes(k)) continue;
    if (v.size === 0) continue;
    if (!OK_TYPE.test(v.type)) return bad(`${k}: use a PNG, JPG, WebP or SVG image.`);
    if (v.size > MAX) return bad(`${k}: image must be 2 MB or smaller.`);
    out.append(k, v, v.name);
  }

  const res = await fetch(`${PB_URL}/api/bma/admin/house`, {
    method: "POST", body: out, cache: "no-store", headers: { "X-BMA-Admin-Key": key()! },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  const text = await res.text();
  if (res.ok) {
    revalidateTag("house");
    revalidatePath("/", "layout");
    const parts = ["logo", "favicon", "banners"].filter((k) => incoming.getAll(k).some((f) => typeof f !== "string" && f.size > 0));
    await logActivity(String(me.record.email), parts.length ? `Updated auction house (uploaded ${parts.join(", ")})` : "Updated auction house profile", true, clientIp(req));
  }
  return new Response(text, { status: res.status, headers: { "Content-Type": "application/json" } });
}
