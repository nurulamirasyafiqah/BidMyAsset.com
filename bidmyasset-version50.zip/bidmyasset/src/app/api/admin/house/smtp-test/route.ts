import { getAdminUser, PB_URL } from "@/lib/pb";

/** POST { to } → sends a test email through the saved SMTP settings (admin only). */
export async function POST(req: Request) {
  const bad = (message: string, status = 400) => Response.json({ message }, { status });
  if (!(await getAdminUser())) return bad("Forbidden", 403);
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return bad("BMA_ADMIN_KEY is not configured", 500);
  let body: { to?: unknown; subject?: unknown; html?: unknown };
  try { body = (await req.json()) as { to?: unknown; subject?: unknown; html?: unknown }; } catch { return bad("Invalid request"); }
  const res = await fetch(`${PB_URL}/api/bma/admin/house/smtp-test`, {
    method: "POST", cache: "no-store", body: JSON.stringify({ to: String(body?.to ?? ""), subject: String(body?.subject ?? ""), html: String(body?.html ?? "") }),
    headers: { "Content-Type": "application/json", "X-BMA-Admin-Key": key },
  }).catch(() => null);
  if (!res) return bad("Service unavailable", 502);
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}
