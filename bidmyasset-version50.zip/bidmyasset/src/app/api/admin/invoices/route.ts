import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/** Admin → Invoice Management (admin only) → PocketBase /api/bma/admin/invoices, /invoice-status. */
async function forward(path: string, method: "GET" | "POST", body?: string) {
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const res = await fetch(`${PB_URL}/api/bma/admin/${path}`, {
    method, body, cache: "no-store",
    headers: { "X-BMA-Admin-Key": key, ...(body ? { "Content-Type": "application/json" } : {}) },
  }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return res;
}
const pass = async (res: Response) => new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });

export async function GET() {
  if (!(await getAdminUser())) return Response.json({ message: "Forbidden" }, { status: 403 });
  const res = await forward("invoices", "GET");
  return res instanceof Response ? pass(res) : res;
}

/** Create an invoice: {auction, lot?, email, hammer}. */
export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const res = await forward("invoices", "POST", await req.text());
  if (res.ok) {
    const copy = res.clone();
    try { const j = (await copy.json()) as { number?: string }; await logActivity(String(me.record.email), `Created invoice ${j.number ?? ""}`.trim(), true, clientIp(req)); } catch { /* logging must never break the request */ }
  }
  return pass(res);
}

/** Mark an invoice paid / unpaid: {id, status}. */
export async function PATCH(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const res = await forward("invoice-status", "POST", await req.text());
  if (res.ok) {
    const copy = res.clone();
    try { const j = (await copy.json()) as { number?: string; status?: string }; await logActivity(String(me.record.email), `Marked invoice ${j.number ?? ""} as ${j.status === "PAID" ? "paid" : "unpaid"}`, true, clientIp(req)); } catch { /* ignore */ }
  }
  return pass(res);
}
