import { getAdminUser, PB_URL } from "@/lib/pb";

/** Marks admin-bell notices as read for the signed-in admin (stored in the database, not the browser). The account comes from the session, never the body. */
export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const { ids } = (await req.json().catch(() => ({}))) as { ids?: unknown };
  const list = Array.isArray(ids) ? ids.filter((i): i is string => typeof i === "string").slice(0, 100) : [];
  if (!list.length) return Response.json({ message: "ids required" }, { status: 400 });
  const res = await fetch(`${PB_URL}/api/bma/admin/notices/read`, {
    method: "POST", headers: { "X-BMA-Admin-Key": key, "Content-Type": "application/json" },
    body: JSON.stringify({ uid: String(me.record.id), ids: list }), cache: "no-store",
  }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}
