import { getAdminUser, PB_URL } from "@/lib/pb";

/** Admin-only CRM feed: Next calls PocketBase server-side with a shared secret, only for signed-in admins (never exposed to the browser). */
export async function GET() {
  if (!(await getAdminUser())) return Response.json({ message: "Forbidden" }, { status: 403 });
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const res = await fetch(`${PB_URL}/api/bma/admin/crm`, { headers: { "X-BMA-Admin-Key": key }, cache: "no-store" }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}
