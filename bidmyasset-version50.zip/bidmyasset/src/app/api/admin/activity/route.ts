import { getAdminUser } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/** Records an admin action reported by the console UI. The account and IP come from the session/request, never from the body. */
export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const { title } = (await req.json().catch(() => ({}))) as { title?: unknown };
  const t = typeof title === "string" ? title.trim().slice(0, 200) : "";
  if (!t) return Response.json({ message: "title required" }, { status: 400 });
  await logActivity(String(me.record.email), t, true, clientIp(req));
  return Response.json({ ok: true });
}
