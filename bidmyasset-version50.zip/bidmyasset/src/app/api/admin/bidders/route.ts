import { getAdminUser, PB_URL } from "@/lib/pb";
import { clientIp, logActivity } from "@/lib/activity";

/** Registered bidders (admin only). Next calls PocketBase server-side with BMA_ADMIN_KEY. */
export async function GET() {
  if (!(await getAdminUser())) return Response.json({ message: "Forbidden" }, { status: 403 });
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const res = await fetch(`${PB_URL}/api/bma/admin/bidders`, { headers: { "X-BMA-Admin-Key": key }, cache: "no-store" }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}

/** Switch a bidder's in-app notifications on/off. */
export async function POST(req: Request) {
  const me = await getAdminUser();
  if (!me) return Response.json({ message: "Forbidden" }, { status: 403 });
  const key = process.env.BMA_ADMIN_KEY;
  if (!key) return Response.json({ message: "BMA_ADMIN_KEY is not configured" }, { status: 500 });
  const body = (await req.json().catch(() => ({}))) as { id?: unknown; notify?: unknown };
  if (typeof body.id !== "string" || typeof body.notify !== "boolean") return Response.json({ message: "id and notify required" }, { status: 400 });
  const res = await fetch(`${PB_URL}/api/bma/admin/bidders`, {
    method: "POST", cache: "no-store",
    headers: { "X-BMA-Admin-Key": key, "Content-Type": "application/json" },
    body: JSON.stringify({ id: body.id, notify: body.notify }),
  }).catch(() => null);
  if (!res) return Response.json({ message: "Service unavailable" }, { status: 502 });
  const text = await res.text();
  if (res.ok) {
    const email = (JSON.parse(text) as { email?: string }).email ?? body.id;
    await logActivity(String(me.record.email), `${body.notify ? "Turned on" : "Turned off"} notifications for ${email}`, true, clientIp(req));
  }
  return new Response(text, { status: res.status, headers: { "Content-Type": "application/json" } });
}
