/**
 * Same-origin proxy to PocketBase for browser calls.
 *  - adds the session token from the httpOnly cookie (JS never sees it)
 *  - stores the token on successful login (password / OTP) and strips it from the response
 *  - only exposes what the site needs: custom /api/bma/* routes and non-system collections
 */
import { NextRequest, NextResponse } from "next/server";
import { getSessionUser, PB_URL, TOKEN_COOKIE } from "@/lib/pb";
import { clientDevice, clientIp, logActivity } from "@/lib/activity";

const ALLOWED = [/^api\/bma\//, /^api\/files\/(house|auctions|lots|team_members)\/[A-Za-z0-9]+\/[^/]+$/, /^api\/collections\/(?!_)[a-z_]+\/(records|request-otp|auth-with-otp|auth-with-password|request-password-reset|confirm-password-reset)(\/|$)/];
const LOGIN = /^api\/collections\/users\/(auth-with-password|auth-with-otp)$/;
const FAV_DELETE = /^api\/collections\/favourites\/records\/[A-Za-z0-9]+$/;
const USER_PATCH = /^api\/collections\/users\/records\/[A-Za-z0-9]+$/;

/** Records account actions a signed-in user does themselves (shown in Admin → User Activity Analytics). Never throws. */
async function trackSelfService(req: NextRequest, path: string, bodyText: string | undefined, resText: string, favLabel: string) {
  try {
    const ip = clientIp(req), device = clientDevice(req);
    if (req.method === "PATCH" && USER_PATCH.test(path)) {
      // The password change invalidates the old token, so the email comes from the response, not the session.
      const email = String((JSON.parse(resText) as { email?: string }).email ?? "");
      const changedPw = Object.prototype.hasOwnProperty.call(JSON.parse(bodyText ?? "{}"), "password");
      if (email) await logActivity(email, changedPw ? "Changed password" : "Updated profile", true, ip, device);
      return;
    }
    let title = "";
    if (req.method === "DELETE" && FAV_DELETE.test(path)) title = favLabel ? `Removed from watchlist: ${favLabel}` : "Removed from watchlist";
    else if (req.method === "POST" && path === "api/bma/me/delete-request") title = "Requested account deletion";
    else if (req.method === "GET" && path === "api/bma/me/export") title = "Exported personal data";
    if (!title) return;
    const me = await getSessionUser();
    if (me) await logActivity(String(me.record.email), title, true, ip, device);
  } catch { /* logging must never break the request */ }
}

async function handle(req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  const path = (await ctx.params).path.join("/");
  if (!ALLOWED.some((r) => r.test(path))) return NextResponse.json({ message: "Not found" }, { status: 404 });

  const token = req.cookies.get(TOKEN_COOKIE)?.value;
  const hasBody = !["GET", "HEAD", "DELETE"].includes(req.method);
  if (path.startsWith("api/files/") && req.method !== "GET") return NextResponse.json({ message: "Not found" }, { status: 404 });
  const bodyText = hasBody ? await req.text() : undefined;

  // Watchlist removal: remember which lot it was before the record disappears (for the activity log).
  let favLabel = "";
  if (req.method === "DELETE" && FAV_DELETE.test(path) && token) {
    try {
      const r = await fetch(`${PB_URL}/${path}?expand=lot`, { headers: { Authorization: token }, cache: "no-store" });
      if (r.ok) favLabel = String(((await r.json()) as { expand?: { lot?: { title?: string } } }).expand?.lot?.title ?? "");
    } catch { /* label is optional */ }
  }

  const upstream = await fetch(`${PB_URL}/${path}${req.nextUrl.search}`, {
    method: req.method,
    headers: {
      ...(hasBody ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: token } : {}),
    },
    body: bodyText,
    cache: "no-store",
  });

  if (path.startsWith("api/files/")) { // binary: don't pass through text()
    return new NextResponse(upstream.ok ? await upstream.arrayBuffer() : null, {
      status: upstream.status,
      headers: { "Content-Type": upstream.headers.get("Content-Type") ?? "application/octet-stream", "Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox" },
    });
  }
  const text = await upstream.text();
  if (LOGIN.test(path) && !upstream.ok && path.endsWith("auth-with-password")) {
    try { const id = (JSON.parse(bodyText ?? "{}") as { identity?: string }).identity; if (id) await logActivity(id, "Failed login attempt", false, clientIp(req), clientDevice(req)); } catch { /* ignore */ }
  }
  if (LOGIN.test(path) && upstream.ok) {
    const j = JSON.parse(text) as { token: string; record: { email?: string } };
    await logActivity(String(j.record?.email ?? ""), "Successfully logged in", true, clientIp(req), clientDevice(req));
    const res = NextResponse.json({ record: j.record });
    res.cookies.set(TOKEN_COOKIE, j.token, {
      httpOnly: true, sameSite: "lax", path: "/",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 14,
    });
    return res;
  }
  if (upstream.ok) await trackSelfService(req, path, bodyText, text, favLabel);
  return new NextResponse(text || null, {
    status: upstream.status,
    headers: { "Content-Type": upstream.headers.get("Content-Type") ?? "application/json" },
  });
}

export { handle as GET, handle as POST, handle as PUT, handle as PATCH, handle as DELETE };
