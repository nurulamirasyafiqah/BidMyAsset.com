import { revalidateTag } from "next/cache";
import { PB_URL } from "@/lib/pb";

export const dynamic = "force-dynamic";

/**
 * GET /api/brand/version?v=<version the page was rendered with> → { version }.
 * `version` is the `updated` stamp of the house record (lib/brand.ts). When it differs from what the page has,
 * the cached copy of the record is dropped first, so the router.refresh() that ThemeSync does next renders fresh data
 * (not the up-to-30 s old cache).
 */
export async function GET(req: Request) {
  const none = () => Response.json({ version: null }, { headers: { "Cache-Control": "no-store" } });
  try {
    const res = await fetch(`${PB_URL}/api/collections/house/records?perPage=1&sort=-updated&fields=updated`, { cache: "no-store", signal: AbortSignal.timeout(2500) });
    if (!res.ok) return none();
    const version = String(((await res.json()) as { items?: { updated?: string }[] }).items?.[0]?.updated ?? "");
    const seen = new URL(req.url).searchParams.get("v") ?? "";
    if (version !== seen) revalidateTag("house");
    return Response.json({ version }, { headers: { "Cache-Control": "no-store" } });
  } catch { return none(); }
}
