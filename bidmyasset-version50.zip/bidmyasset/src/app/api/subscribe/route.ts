import { PB_URL } from "@/lib/pb";

/** Forwards the public form to the Go/PocketBase backend (validation + storage happen there). */
export async function POST(req: Request) {
  const res = await fetch(`${PB_URL}/api/bma/subscribe`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: await req.text(),
    cache: "no-store",
  }).catch(() => null);
  if (!res) return Response.json({ ok: false, error: "Service unavailable" }, { status: 502 });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
}
