import { NextResponse } from "next/server";
import { getSessionUser, TOKEN_COOKIE } from "@/lib/pb";
import { clientDevice, clientIp, logActivity } from "@/lib/activity";

export async function POST(req: Request) {
  const me = await getSessionUser();
  if (me) await logActivity(String(me.record.email), "Logged out", true, clientIp(req), clientDevice(req));
  const res = NextResponse.json({ ok: true });
  res.cookies.set(TOKEN_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
