import { PB_URL } from "@/lib/pb";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** Realtime lot updates for the browser (Server-Sent Events). Streams PocketBase's public GET /api/bma/stream through unchanged. */
export async function GET(req: Request) {
  const upstream = await fetch(`${PB_URL}/api/bma/stream`, { headers: { Accept: "text/event-stream" }, cache: "no-store", signal: req.signal }).catch(() => null);
  if (!upstream || !upstream.ok || !upstream.body) return new Response("Service unavailable", { status: 502 });
  return new Response(upstream.body, {
    headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no" },
  });
}
