import { getLegalText } from "@/lib/brand";

/** Public: the published Privacy Policy / Terms text (Auction House → Legal Policies) for the pop-ups. */
export async function GET(req: Request) {
  const kind = new URL(req.url).searchParams.get("kind");
  if (kind !== "privacy" && kind !== "terms") return Response.json({ message: "Unknown policy" }, { status: 400 });
  const doc = await getLegalText(kind);
  return Response.json({ name: doc?.name ?? "", html: doc?.html ?? "" });
}
