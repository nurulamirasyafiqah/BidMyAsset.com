import type { Metadata } from "next";
import "@fontsource-variable/inter";
import "./globals.css";
import { THEME_BOOT } from "@/lib/theme";
import Script from "next/script";
import { ThemeSync } from "@/components/ThemeSync";
import { getBrand } from "@/lib/brand";
import { BrandProvider } from "@/components/BrandProvider";

export async function generateMetadata(): Promise<Metadata> {
  const b = await getBrand();
  return {
    title: { default: `${b.name} — Industrial Asset Auctions`, template: `%s · ${b.name}` },
    description: b.description.replace(/<[^>]*>/g, "").trim().slice(0, 300) ||
      "Southeast Asia’s industrial asset disposal and auction platform. Buy and sell machinery, heavy equipment and plant assets.",
    ...(b.favicon ? { icons: { icon: b.favicon } } : {}),
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const brand = await getBrand();
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: THEME_BOOT }} />{brand.themeCss && <style id="bma-theme" dangerouslySetInnerHTML={{ __html: brand.themeCss }} />}</head>
      <body className="flex min-h-screen flex-col"><BrandProvider brand={brand}>{children}</BrandProvider><ThemeSync version={brand.version} />
        {/* Google Analytics / Tag Manager from Auction House → Analytics & tracking (id is validated, only [A-Z0-9-]) */}
        {brand.gaId.toUpperCase().startsWith("GTM-")
          ? <Script id="gtm" strategy="afterInteractive" dangerouslySetInnerHTML={{ __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s);j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${brand.gaId}');` }} />
          : brand.gaId && <>
              <Script src={`https://www.googletagmanager.com/gtag/js?id=${brand.gaId}`} strategy="afterInteractive" />
              <Script id="ga-init" strategy="afterInteractive" dangerouslySetInnerHTML={{ __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${brand.gaId}');` }} />
            </>}
      </body>
    </html>
  );
}
