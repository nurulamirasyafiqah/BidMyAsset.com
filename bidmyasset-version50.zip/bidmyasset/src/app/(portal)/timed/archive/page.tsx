import type { Metadata } from "next";
import { AuctionCard } from "@/components/AuctionCard";
import { AuctionTabs } from "@/components/AuctionTabs";
import { PageHero } from "@/components/PageHero";
import { listArchived } from "@/lib/api-data";

export const metadata: Metadata = { title: "Auction Archive" };
export const dynamic = "force-dynamic";

export default async function Page() {
  const serverNow = Date.now();
  const archivedAuctions = await listArchived(serverNow);
  return (
    <>
      <PageHero
        crumbs={[{ label: "Home", href: "/dashboard" }, { label: "Timed" }]}
        title="Timed Auctions"
        sub="Browse live and upcoming timed events, or explore closed auctions in the archive."
      >
        <AuctionTabs active="archive" base="/timed" />
      </PageHero>
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-8 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        {archivedAuctions.map((a) => <AuctionCard key={a.slug} auction={a} serverNow={serverNow} base="/timed" />)}
      </div>
    </>
  );
}
