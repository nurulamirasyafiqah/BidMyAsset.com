import type { Metadata } from "next";
import { LotView } from "@/components/LotView";
import { getLot } from "@/lib/api-data";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string; lot: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug, lot } = await params;
  const l = await getLot(slug, Number(lot));
  return { title: l ? `Lot ${l.lotNumber} — ${l.title}` : "Lot" };
}

export default async function Page({ params }: Params) {
  const { slug, lot } = await params;
  return <LotView slug={slug} lot={lot} member />;
}
