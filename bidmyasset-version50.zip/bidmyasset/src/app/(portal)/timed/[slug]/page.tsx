import type { Metadata } from "next";
import { AuctionView } from "@/components/AuctionView";
import { getAuction } from "@/lib/api-data";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  return { title: (await getAuction((await params).slug))?.title ?? "Auction" };
}

export default async function Page({ params }: Params) {
  return <AuctionView slug={(await params).slug} member />;
}
