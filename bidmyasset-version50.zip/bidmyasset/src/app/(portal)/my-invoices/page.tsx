import type { Metadata } from "next";
import { InvoicesView } from "@/components/portal/InvoicesView";
import { getPortalData } from "@/lib/portal";

export const metadata: Metadata = { title: "My Invoices" };

export default async function Invoices() {
  const { invoices } = await getPortalData();
  return <InvoicesView invoices={invoices} />;
}
