import type { Metadata } from "next";
import Link from "next/link";
import { FileText } from "lucide-react";
import { EmptyState, PageTitle, Panel, Pill, Table } from "@/components/portal/ui";
import { getPortalData } from "@/lib/portal";

export const metadata: Metadata = { title: "My Registrations" };

export default async function Registrations() {
  const { registrations } = await getPortalData();
  return (
    <>
      <PageTitle title="My Registrations" sub="Auctions you’ve registered to bid in." />
      <Panel>
        {registrations.length === 0
          ? <EmptyState icon={FileText} title="No registrations yet" text="Register for an auction to start bidding on its lots." href="/timed" cta="Browse Timed Auctions" />
          : <Table head={["Auction", "Status", "Registered"]} rows={registrations.map((r) => [
              <Link key="a" href={`/timed/${r.auctionSlug}`} className="font-semibold hover:text-primary">{r.auctionTitle}</Link>,
              <Pill key="s" tone={r.status === "APPROVED" ? "green" : "amber"}>{r.status === "APPROVED" ? "Approved" : "Pending approval"}</Pill>,
              new Date(r.registeredAt).toLocaleDateString("en-GB"),
            ])} />}
      </Panel>
    </>
  );
}
