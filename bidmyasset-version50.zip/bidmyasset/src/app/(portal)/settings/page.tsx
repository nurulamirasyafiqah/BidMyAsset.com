import type { Metadata } from "next";
import { AccountView } from "@/components/portal/AccountView";
import { getPortalData, toProfile } from "@/lib/portal";
import { getSessionUser } from "@/lib/pb";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const data = await getPortalData();
  const me = await getSessionUser(); // layout already guarantees a session
  return <AccountView user={toProfile(me!.record)} data={data} />;
}
