import { redirect } from "next/navigation";
import { PortalShell } from "@/components/portal/PortalShell";
import { UserProvider } from "@/components/portal/UserContext";
import { getPortalData, toProfile } from "@/lib/portal";
import { getSessionUser } from "@/lib/pb";

export const dynamic = "force-dynamic";

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const me = await getSessionUser();
  if (!me) redirect("/login"); // no / expired session
  const user = toProfile(me.record);
  const { notices } = await getPortalData();
  return (
    <UserProvider user={{ name: user.name, email: user.email, state: user.state, company: user.company }}>
      <PortalShell notices={notices} user={{ name: user.name, email: user.email }} isAdmin={me.record.isAdmin === true}>{children}</PortalShell>
    </UserProvider>
  );
}
