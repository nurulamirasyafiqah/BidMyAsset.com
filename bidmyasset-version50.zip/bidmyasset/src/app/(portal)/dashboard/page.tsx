import type { Metadata } from "next";
import Link from "next/link";
import { ClipboardList, Heart, Target, Trophy, RefreshCw } from "lucide-react";
import { Momentum } from "@/components/portal/Momentum";
import { EmptyState, PageTitle, Panel, StatCard } from "@/components/portal/ui";
import { getPortalData, momentum, type BidState } from "@/lib/portal";
import { formatMoney } from "@/lib/format";

export const metadata: Metadata = { title: "My Dashboard" };

const KEY: { s: BidState; label: string; text: string; cls: string }[] = [
  { s: "LEADING", label: "Leading", text: "Your bid is currently the highest for the lot.", cls: "border-sky-200 bg-sky-50 text-sky-700" },
  { s: "OUTBID", label: "Outbid", text: "Another bidder has surpassed your bid.", cls: "border-rose-200 bg-rose-50 text-rose-600" },
  { s: "TRACKED", label: "Tracked", text: "Lots you’ve interacted with but are not winning.", cls: "border-zinc-200 bg-zinc-50 text-zinc-600" },
];

export default async function Dashboard() {
  const d = await getPortalData();
  const count = (s: BidState) => d.bids.filter((b) => b.state === s).length;
  const active = d.bids.filter((b) => b.state !== "TRACKED").length;

  return (
    <>
      <PageTitle
        title="My Dashboard"
        sub="Track your bidding performance, registrations, and watchlist hotspots at a glance."
        action={<Link href="/dashboard" className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-white px-4 py-2 text-sm font-semibold text-primary hover:bg-primary/5"><RefreshCw className="size-4" />Refresh</Link>}
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Active bids" value={active} hint="Bids on lots in live auctions." icon={Target} />
        <StatCard label="Leading lots" value={count("LEADING")} hint="Lots where your bid is highest." icon={Trophy} />
        <StatCard label="Watchlist lots" value={d.favourites.length} hint="Lots you’ve added to favourites." icon={Heart} />
        <StatCard label="Registrations" value={d.registrations.length} hint="Auctions you’ve registered for." icon={ClipboardList} />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_340px]">
        <Panel title="Bidding momentum" sub="Track how your bids are trending over time to anticipate activity before auction close." action={<span className="rounded-full border border-zinc-300 px-2.5 py-1 text-[11px] font-medium">Last 14 days</span>}>
          {d.bids.length === 0
            ? <EmptyState icon={ClipboardList} title="No bidding activity yet" text="Once you place bids, your activity will be charted here to help you track momentum." />
            : <Momentum data={momentum(d.bids)} />}
        </Panel>

        <Panel title="Bid status breakdown">
          {d.bids.length === 0 && <EmptyState icon={Target} title="No bids placed yet" text="Place your first bid to see how your activity stacks up." />}
          <ul className="mt-3 space-y-2">
            {KEY.map((k) => (
              <li key={k.s} className={`flex items-center justify-between gap-3 rounded-lg border px-3 py-2 text-xs ${k.cls}`}>
                <span className="font-semibold">{k.label}{d.bids.length > 0 && <b className="ml-2 rounded bg-white/70 px-1.5">{count(k.s)}</b>}</span>
                <span className="text-right">{k.text}</span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Lot shortlist" sub="Highlights from your favourites and saved searches to revisit quickly." action={<Link href="/favourites" className="text-xs font-medium text-primary">View favourites ↗</Link>}>
          {d.favourites.length === 0
            ? <EmptyState icon={Heart} title="No favourites yet" text="Save lots to your favourites to build a quick shortlist of items to watch." />
            : <ul className="divide-y divide-zinc-100">{d.favourites.map((f) => (
                <li key={f.lotNumber} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                  <Link href={`/timed/${f.auctionSlug}/lot/${f.lotNumber}`} className="font-semibold hover:text-primary">Lot {f.lotNumber} · {f.lotTitle}</Link>
                  <span className="text-zinc-500">from {formatMoney(f.startingBid, f.currency)}</span>
                </li>))}</ul>}
        </Panel>

        <Panel title="Auction highlights" sub="Auctions you’re registered for or have active bids in." action={<Link href="/my-registrations" className="text-xs font-medium text-primary">Manage registrations ↗</Link>}>
          {d.registrations.length === 0
            ? <EmptyState icon={Trophy} title="No active auctions" text="Complete a registration or place a bid to see relevant auctions here." />
            : <ul className="divide-y divide-zinc-100">{d.registrations.map((r) => (
                <li key={r.auctionSlug} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                  <Link href={`/timed/${r.auctionSlug}`} className="font-semibold hover:text-primary">{r.auctionTitle}</Link>
                  <span className={r.status === "APPROVED" ? "text-emerald-600" : "text-amber-600"}>{r.status === "APPROVED" ? "Approved" : "Pending"}</span>
                </li>))}</ul>}
        </Panel>
      </div>
    </>
  );
}
