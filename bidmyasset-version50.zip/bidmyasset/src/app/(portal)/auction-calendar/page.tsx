import type { Metadata } from "next";
import { CalendarView } from "@/components/portal/CalendarView";
import { listActive, listLocationLots } from "@/lib/api-data";

export const metadata: Metadata = { title: "Auction Calendar" };
export const dynamic = "force-dynamic";

export default async function AuctionCalendarPage() {
  const serverNow = Date.now();
  const [auctions, locationLots] = await Promise.all([listActive(serverNow), listLocationLots(serverNow)]);
  return <CalendarView auctions={auctions} locationLots={locationLots} serverNow={serverNow} />;
}
