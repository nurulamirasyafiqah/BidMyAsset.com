import type { Metadata } from "next";
import Link from "next/link";
import { Gavel } from "lucide-react";
import { EmptyState, PageTitle, Panel, StateChip, Table } from "@/components/portal/ui";
import { getPortalData } from "@/lib/portal";
import { formatMoney } from "@/lib/format";

export const metadata: Metadata = { title: "My Bids" };

export default async function MyBids() {
  const { bids } = await getPortalData();
  return (
    <>
      <PageTitle title="My Bids" sub="Every lot you’ve bid on, with your latest position." />
      <Panel>
        {bids.length === 0
          ? <EmptyState icon={Gavel} title="No bids placed yet" text="Browse live auctions and place your first bid." href="/timed" cta="Browse Timed Auctions" />
          : <Table head={["Lot", "Auction", "Your bid", "Status", "Placed"]} rows={bids.map((b) => [
              <Link key="l" href={`/timed/${b.auctionSlug}/lot/${b.lotNumber}`} className="font-semibold hover:text-primary">Lot {b.lotNumber} · {b.lotTitle}</Link>,
              b.auctionTitle, formatMoney(b.amount, b.currency), <StateChip key="s" state={b.state} />,
              new Date(b.placedAt).toLocaleDateString("en-GB"),
            ])} />}
      </Panel>
    </>
  );
}
