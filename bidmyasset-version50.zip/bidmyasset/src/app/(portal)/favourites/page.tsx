import type { Metadata } from "next";
import { FavouritesView } from "@/components/portal/FavouritesView";
import { getPortalData } from "@/lib/portal";

export const metadata: Metadata = { title: "Favourite Lots" };

export default async function FavouritesPage() {
  const { favourites } = await getPortalData();
  return <FavouritesView items={favourites} />;
}
