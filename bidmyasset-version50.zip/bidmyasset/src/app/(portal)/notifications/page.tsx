import type { Metadata } from "next";
import { NotificationsView } from "@/components/portal/NotificationsView";
import { getPortalData } from "@/lib/portal";

export const metadata: Metadata = { title: "Notifications" };

export default async function NotificationsPage() {
  const { notices } = await getPortalData();
  return <NotificationsView initial={notices} />;
}
