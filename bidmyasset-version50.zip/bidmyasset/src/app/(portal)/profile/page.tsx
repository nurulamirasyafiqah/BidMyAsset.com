import { redirect } from "next/navigation";

// "My Profile" and "Settings" are the same page in the design.
export default function ProfilePage() {
  redirect("/settings");
}
