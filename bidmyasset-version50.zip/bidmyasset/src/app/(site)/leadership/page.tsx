import { T } from "@/components/T";
import { RegionalMap } from "@/components/RegionalMap";
import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Building2, Globe, Link2, MapPin } from "lucide-react";
import { coreOperations, groupEntities, regions, type Person } from "@/lib/content";
import { getTeam } from "@/lib/team";

export const metadata: Metadata = { title: "Leadership" };

function initials(name: string) {
  return name.replace(/^(Dato|A\.)\s+/i, "").split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
}

/** Photo uploaded in Admin → Team; initials until one is added. */
function Avatar({ name, photo, className }: { name: string; photo?: string; className: string }) {
  if (photo) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={photo} alt={name} loading="lazy" className={`bg-zinc-200 object-cover object-top ${className}`} />;
  }
  return (
    <div className={`flex items-center justify-center bg-gradient-to-b from-zinc-300 to-zinc-400 text-2xl font-bold text-white/80 ${className}`}>
      {initials(name)}
    </div>
  );
}

function PersonCard({ p, tone = "light", size = "lg" }: { p: Person; tone?: "light" | "blue"; size?: "lg" | "sm" }) {
  return (
    <article className={`overflow-hidden rounded-xl border shadow-sm ${tone === "blue" ? "border-white/20 bg-primary/70 text-white" : "border-zinc-200 bg-white"}`}>
      <Avatar name={p.name} photo={p.photo} className={`w-full ${size === "lg" ? "aspect-[4/5]" : "aspect-square"}`} />
      <div className="p-3">
        <h3 className="text-xs font-semibold leading-tight">{p.name}</h3>
        <p className={`mt-1 text-[10px] font-semibold leading-snug ${tone === "blue" ? "text-blue-100" : "text-primary"}`}>{p.role}</p>
        {p.linkedin && <a href={p.linkedin} target="_blank" rel="noopener noreferrer" className={`mt-1 inline-block text-[10px] font-medium underline-offset-2 hover:underline ${tone === "blue" ? "text-white" : "text-zinc-500"}`}>LinkedIn</a>}
      </div>
    </article>
  );
}

function Heading({ eyebrow, title, sub, light = false }: { eyebrow: string; title: string; sub: string; light?: boolean }) {
  return (
    <div className="text-center">
      <p className={`eyebrow ${light ? "!text-blue-200" : ""}`}>{eyebrow}</p>
      <h2 className={`mt-1.5 text-2xl font-extrabold ${light ? "text-white" : ""}`}>{title}</h2>
      <p className={`mx-auto mt-2 max-w-lg text-xs leading-relaxed ${light ? "text-blue-100" : "text-zinc-500"}`}>{sub}</p>
    </div>
  );
}

export default async function LeadershipPage() {
  const { leadership, advisors, management } = await getTeam();
  return (
    <>
      <section className="hero-blue text-center text-white">
        <div className="mx-auto max-w-3xl px-4 py-14">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-[9px] font-bold uppercase tracking-wider">
            <Link2 className="size-3" /> Leadership &amp; organization
          </span>
          <h1 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl">Driving Industrial Asset Solutions Across Asia</h1>
          <p className="mx-auto mt-4 max-w-xl text-xs leading-relaxed text-blue-50">
            BidMyAsset Group is a regional industrial asset solutions ecosystem operating across Malaysia and Asia through specialized operating entities, strategic partnerships, and experienced leadership teams.
          </p>
        </div>
      </section>

      {leadership.length > 0 && (
      <section className="bg-white py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <Heading eyebrow="Leadership" title="Leadership Team" sub="Our leadership team provides strategic direction, operational oversight, technical expertise and regional market leadership across the BidMyAsset Group ecosystem." />
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {leadership.map((p) => <PersonCard key={p.name} p={p} />)}
          </div>
        </div>
      </section>
      )}

      {advisors.length > 0 && (
      <section className="cta-blue py-12">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <Heading light eyebrow="Advisory board" title="Strategic Advisors" sub="Industry professionals supporting business growth, technical direction, international expansion and strategic decision-making." />
          <div className="mx-auto mt-8 grid max-w-xl grid-cols-1 gap-4 sm:grid-cols-3">
            {advisors.map((p) => <PersonCard key={p.name} p={p} tone="blue" />)}
          </div>
        </div>
      </section>
      )}

      {management.length > 0 && (
      <section className="bg-canvas py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <Heading eyebrow="Management" title="Management Team" sub="Supporting project execution, valuation services, auction operations, compliance, business development, and client management." />
          <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-5">
            {management.map((p) => <PersonCard key={p.name} p={p} size="sm" />)}
          </div>
        </div>
      </section>
      )}

      <section className="bg-white py-12">
        <div className="mx-auto grid max-w-4xl gap-8 px-4 sm:px-6 md:grid-cols-2">
          <div>
            <div className="flex items-center gap-3">
              <span className="inline-flex size-9 items-center justify-center rounded-lg bg-primary text-white"><Building2 className="size-4" /></span>
              <div>
                <p className="text-[9px] font-semibold uppercase tracking-[0.2em] text-primary">Corporate structure</p>
                <h2 className="text-lg font-extrabold">Group Structure</h2>
              </div>
            </div>
            <p className="mt-3 text-xs text-zinc-500">A regional industrial asset solutions ecosystem operating through specialized operating entities and strategic partnerships across Asia.</p>
            <div className="mt-4 rounded-xl border border-zinc-200 p-3 shadow-sm">
              <div className="rounded-md bg-primary py-2 text-center text-xs font-bold text-white">BidMyAsset Group</div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {groupEntities.map((e) => (
                  <div key={e} className="rounded-md border border-zinc-200 bg-zinc-50 px-2 py-2 text-center text-[10px] font-medium">{e}</div>
                ))}
              </div>
              <div className="mt-3 border-t border-dashed border-zinc-300 pt-2">
                <p className="text-[9px] font-semibold uppercase tracking-wider text-zinc-400">Associate company</p>
                <div className="mt-1.5 rounded-md border border-indigo-200 bg-soft py-2 text-center text-[10px] font-semibold text-primary">Khoshee Auctioneers Sdn Bhd</div>
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3">
              <span className="inline-flex size-9 items-center justify-center rounded-lg bg-primary text-white"><Globe className="size-4" /></span>
              <div>
                <p className="text-[9px] font-semibold uppercase tracking-[0.2em] text-primary"><T>Regional presence</T></p>
                <h2 className="text-lg font-extrabold"><T>Operating Across Asia</T></h2>
              </div>
            </div>
            <RegionalMap />
            <ul className="mt-3 grid grid-cols-2 gap-2">
              {regions.map((r) => (
                <li key={r} className="flex items-center gap-1.5 rounded-md border border-zinc-200 px-2.5 py-1.5 text-[10px] font-medium"><MapPin className="size-3 text-primary" />{r}</li>
              ))}
            </ul>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {["5 Countries", "Regional Coverage", "Cross-Border Operations"].map((t) => (
                <span key={t} className="rounded-full border border-indigo-200 bg-soft px-2.5 py-1 text-[9px] font-semibold text-primary">{t}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-zinc-50 py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <Heading eyebrow="Capabilities" title="Core Operations" sub="BidMyAsset Group provides end-to-end industrial asset solutions covering valuation, recovery, disposal, auctions, decommissioning, remarketing and project-based asset management across multiple industries and jurisdictions." />
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {coreOperations.map((o, i) => (
              <article key={o.title} className="rounded-xl border border-zinc-200 bg-white p-4 shadow-sm">
                <p className="text-[9px] text-zinc-300">{String(i + 1).padStart(2, "0")}</p>
                <h3 className="mt-2 text-xs font-bold">{o.title}</h3>
                <p className="mt-1.5 text-[10px] leading-relaxed text-primary/80">{o.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-blue py-14 text-center text-white">
        <div className="mx-auto max-w-2xl px-4">
          <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-blue-100">Regional industrial asset solutions</p>
          <h2 className="mt-2 text-3xl font-extrabold">Ready To Maximize The Value Of Your Industrial Assets?</h2>
          <p className="mt-3 text-xs leading-relaxed text-blue-100">From machinery disposals and industrial auctions to plant closures, asset recovery and cross-border projects, BidMyAsset Group delivers integrated industrial asset solutions across Asia through our regional network and specialist operating teams.</p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {[["5+", "Countries"], ["Regional", "Coverage"], ["Industrial", "Asset specialists"], ["Cross-Border", "Capabilities"]].map(([a, b]) => (
              <div key={a} className="min-w-24 rounded-lg border border-white/20 bg-white/10 px-3 py-2">
                <p className="text-xs font-bold">{a}</p>
                <p className="text-[8px] font-semibold uppercase tracking-wider text-blue-200">{b}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Link href="/#contact" className="inline-flex items-center gap-2 rounded bg-white px-4 py-2 text-xs font-semibold text-primary">Speak With Our Team <ArrowRight className="size-3.5" /></Link>
            <Link href="/auctions" className="rounded border border-white/50 px-4 py-2 text-xs font-semibold">Explore Our Auctions</Link>
          </div>
        </div>
      </section>
    </>
  );
}
