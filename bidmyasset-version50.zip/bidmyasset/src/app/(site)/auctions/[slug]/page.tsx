import type { Metadata } from "next";
import { AuctionView } from "@/components/AuctionView";
import { getAuction } from "@/lib/api-data";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const a = await getAuction((await params).slug);
  return { title: a?.title ?? "Auction" };
}

export default async function AuctionPage({ params }: Params) {
  return <AuctionView slug={(await params).slug} />;
}
