import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { AuctionCard } from "@/components/AuctionCard";
import { ContactForm, SubscribeForm } from "@/components/ContactForms";
import { Icon } from "@/components/Icon";
import { SectionHeading } from "@/components/SectionHeading";
import { ServicesGrid } from "@/components/ServicesGrid";
import { BannerHero } from "@/components/BannerHero";
import { aboutPillars, aboutStats, insights } from "@/lib/content";
import { listActive } from "@/lib/api-data";
import { contactPhone, getPublicCompany } from "@/lib/companyPublic";

export const dynamic = "force-dynamic"; // countdowns use the server clock

function Waves() {
  return (
    <svg aria-hidden className="pointer-events-none absolute inset-0 size-full" preserveAspectRatio="none" viewBox="0 0 1400 400" fill="none">
      <path d="M0 120 C 300 60, 500 200, 800 140 S 1200 100, 1400 150" stroke="#f9a8d4" strokeOpacity=".5" />
      <path d="M0 180 C 300 120, 600 260, 900 190 S 1250 160, 1400 220" stroke="#a5b4fc" strokeOpacity=".6" />
      <path d="M0 240 C 350 200, 600 320, 950 250 S 1250 230, 1400 290" stroke="#93c5fd" strokeOpacity=".5" />
    </svg>
  );
}

export default async function HomePage() {
  const serverNow = Date.now();
  const latest = (await listActive(serverNow)).slice(0, 6);
  const company = await getPublicCompany(); // Company → Contacts / Locations

  return (
    <>
      <BannerHero>
        <div className="mx-auto max-w-5xl px-4 py-8 text-center sm:py-10">
          <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Invest In Your Ideal Asset.</h1>
        </div>
      </BannerHero>

      <section className="bg-white py-10">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="flex items-end justify-between gap-4">
            <SectionHeading eyebrow="Latest machinery" title="Latest machinery added to auction" sub="Explore new assets landing in upcoming BidMyAsset events." />
            <Link href="/auctions" className="hidden shrink-0 items-center gap-1 text-xs font-semibold text-primary sm:inline-flex">
              View all auctions <ArrowUpRight className="size-3" />
            </Link>
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {latest.map((a) => <AuctionCard key={a.slug} auction={a} serverNow={serverNow} />)}
          </div>
          <Link href="/auctions" className="mt-5 inline-flex items-center gap-1 text-xs font-semibold text-primary sm:hidden">View all auctions →</Link>
        </div>
      </section>

      <section id="services" className="relative overflow-hidden bg-soft py-12">
        <Waves />
        <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
          <SectionHeading eyebrow="Our services" title="End-to-end asset solutions" sub="From buying and selling to logistics, insurance, and sustainability." />
          <div className="mt-6"><ServicesGrid /></div>
          <div className="mt-6 text-right">
            <Link href="#" className="text-xs font-semibold text-primary">View All Services →</Link>
          </div>
        </div>
      </section>

      <section id="about" className="relative overflow-hidden bg-gradient-to-br from-white via-indigo-50/40 to-emerald-50/40 py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <SectionHeading eyebrow="About us" title="Giving 2nd life to your assets" sub="Over 20 years of expertise in disposal of movable industrial assets. Headquartered in Penang with offices in Kuala Lumpur and Bangkok." />
          <div className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-200 shadow-md lg:grid-cols-4">
            {aboutStats.map((s) => (
              <div key={s.label} className="bg-white/90 px-4 py-6 text-center">
                <p className="text-3xl font-extrabold text-indigo-600 sm:text-4xl">{s.value}</p>
                <p className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-zinc-400">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-3">
            {aboutPillars.map((p, i) => (
              <div key={p.title} className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
                <div className="flex items-start justify-between">
                  <span className="inline-flex size-8 items-center justify-center rounded-lg bg-soft text-primary"><Icon name={p.icon} className="size-4" /></span>
                  <span className="text-[10px] font-bold text-primary">#{String(i + 1).padStart(2, "0")}</span>
                </div>
                <p className="mt-3 text-[9px] font-semibold uppercase tracking-wider text-zinc-400">{p.eyebrow}</p>
                <h3 className="mt-1 text-sm font-bold">{p.title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-zinc-500">{p.text}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 text-right">
            <Link href="/about" className="inline-flex items-center gap-1 text-xs font-semibold text-primary">Learn About Us <ArrowUpRight className="size-3" /></Link>
          </div>
        </div>
      </section>

      <section id="insights" className="bg-white py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="flex items-end justify-between gap-4">
            <SectionHeading eyebrow="Latest insights" title="News, guides & industry insights" />
            <Link href="#" className="shrink-0 text-xs font-semibold text-primary">View All Articles →</Link>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {insights.map((p) => (
              <article key={p.title} className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
                <div className="h-0.5 w-8 bg-primary" />
                <span className="mt-4 inline-block rounded-full bg-soft px-2 py-0.5 text-[9px] font-bold text-primary">{p.tag}</span>
                <h3 className="mt-2 text-base font-bold leading-snug">{p.title}</h3>
                <p className="mt-2 text-xs leading-relaxed text-zinc-500">{p.text}</p>
                <Link href="#" className="mt-3 inline-flex items-center gap-1 text-[10px] font-bold tracking-wider text-primary">READ MORE <ArrowUpRight className="size-3" /></Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="bg-slate-50 py-12">
        <div className="mx-auto max-w-2xl space-y-10 px-4 sm:px-6">
          <div>
            <SectionHeading eyebrow="Contact us" title="Talk to our auction specialists" sub="Share your requirements and we’ll guide you through selling, buying, or logistics support." />
            <div className="mt-4"><ContactForm /></div>
          </div>
          {company && (company.locations.length > 0 || company.contacts.length > 0) && (
            <div>
              <SectionHeading eyebrow="Our team & offices" title={company.name ? `Reach ${company.name}` : "Reach us directly"} sub="Speak to a contact or visit one of our offices." />
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {company.contacts.map((c, i) => (
                  <div key={`c${i}`} className="rounded-xl border border-zinc-200 bg-white p-4 text-sm">
                    <p className="font-bold">{c.name}</p>
                    {c.email && <p className="mt-1 text-zinc-600"><a href={`mailto:${c.email}`} className="hover:underline">{c.email}</a></p>}
                    {contactPhone(c) && <p className="text-zinc-600">{contactPhone(c)}</p>}
                  </div>
                ))}
                {company.locations.map((l, i) => (
                  <div key={`l${i}`} className="rounded-xl border border-zinc-200 bg-white p-4 text-sm">
                    <p className="font-bold">{l.name}</p>
                    {l.address && <p className="mt-1 text-zinc-600">{l.address}</p>}
                    {l.phone && <p className="text-zinc-600">{l.phone}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}
          <div>
            <SectionHeading eyebrow="Subscribe" title="Stay ahead of upcoming auctions" sub="Get drop notices, pickup reminders, and new inventory highlights from the BidMyAsset team." />
            <div className="mt-4"><SubscribeForm /></div>
          </div>
        </div>
      </section>
    </>
  );
}
