import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Check, Sparkles } from "lucide-react";
import { Icon } from "@/components/Icon";
import { buyerPoints, countries, numbers, processSteps, whyCards } from "@/lib/content";

export const metadata: Metadata = { title: "About" };

const cta = {
  primary: "inline-flex items-center gap-2 rounded bg-white px-4 py-2.5 text-xs font-semibold text-primary hover:bg-blue-50",
  outline: "inline-flex items-center rounded border border-white/50 px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/10",
  ghost: "inline-flex items-center px-3 py-2.5 text-xs font-semibold text-white hover:underline",
};

function CtaRow() {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Link href="/register" className={cta.primary}>Register as a buyer <ArrowRight className="size-3.5" /></Link>
      <Link href="/auctions" className={cta.outline}>View upcoming auctions</Link>
      <Link href="/#contact" className={cta.ghost}>Contact our experts</Link>
    </div>
  );
}

export default function AboutPage() {
  return (
    <>
      <section className="hero-blue text-white">
        <div className="mx-auto grid max-w-5xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.25fr_1fr] lg:py-20">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-[9px] font-bold uppercase tracking-wider text-white/90">
              <Sparkles className="size-3" /> Southeast Asia’s leading industrial asset disposal firm
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.1] sm:text-5xl">
              Empowering your growth with premium <span className="text-sky-200">industrial assets</span>
            </h1>
            <p className="mt-6 max-w-xl text-sm leading-relaxed text-blue-50">
              Every machine has a second life. Every business deserves the chance to scale sustainably. BidMyAsset bridges global manufacturers and ambitious buyers — a transparent, secure marketplace for high-quality, pre-owned machinery.
            </p>
            <div className="mt-7"><CtaRow /></div>
          </div>

          <aside className="relative self-center rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur">
            <span className="absolute -top-2.5 left-4 rounded-full bg-primary px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wider">By the numbers</span>
            <dl className="mt-1 grid grid-cols-2 gap-x-6 gap-y-5">
              {numbers.map((n) => (
                <div key={n.label}>
                  <dt className="text-[9px] font-semibold uppercase tracking-wider text-blue-100/80">{n.label}</dt>
                  <dd className="mt-1 text-2xl font-extrabold">{n.value}</dd>
                </div>
              ))}
            </dl>
            <ul className="mt-5 flex flex-wrap gap-1.5">
              {countries.map((c) => (
                <li key={c} className="rounded-full border border-white/25 bg-white/10 px-2.5 py-1 text-[9px] font-semibold">{c}</li>
              ))}
            </ul>
          </aside>
        </div>
      </section>

      <section className="bg-white py-14">
        <div className="mx-auto grid max-w-5xl gap-8 px-4 sm:px-6 md:grid-cols-[1fr_1.4fr]">
          <div>
            <p className="eyebrow">For buyers</p>
            <h2 className="mt-2 text-2xl font-extrabold leading-tight sm:text-[28px]">We take the guesswork out of the secondary market.</h2>
          </div>
          <div>
            <p className="text-sm leading-relaxed text-zinc-600">
              Whether you’re an SME upgrading your production line without heavy capital outlay, or a global firm sourcing specific industrial components — our platform centralises high-value assets and gives you direct access to equipment that is often meticulously maintained and ready for a new phase of production.
            </p>
            <ul className="mt-5 grid gap-2.5 text-xs sm:grid-cols-2">
              {buyerPoints.map((p) => (
                <li key={p} className="flex items-center gap-2 text-zinc-700">
                  <span className="inline-flex size-4 items-center justify-center rounded-full bg-soft text-primary"><Check className="size-2.5" /></span>{p}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-zinc-50 py-14">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center">
            <p className="eyebrow">Why BidMyAsset</p>
            <h2 className="mt-2 text-3xl font-extrabold">Built for serious buyers, end to end.</h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-zinc-500">Six reasons procurement teams across Asia and Europe consolidate their secondary-market sourcing on BidMyAsset.</p>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {whyCards.map((c, i) => (
              <article key={c.title} className="flex flex-col rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
                <span className="inline-flex size-9 items-center justify-center rounded-lg bg-primary text-white"><Icon name={c.icon} className="size-4" /></span>
                <h3 className="mt-4 text-sm font-bold">{c.title}</h3>
                <p className="mt-2 flex-1 text-xs leading-relaxed text-zinc-500">{c.text}</p>
                <p className="mt-4 text-[10px] text-zinc-400">{String(i + 1).padStart(2, "0")}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-14">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center">
            <p className="eyebrow">Our proven process</p>
            <h2 className="mt-2 text-3xl font-extrabold">Four steps from discovery to delivery.</h2>
          </div>
          <ol className="mt-10 grid gap-8 md:grid-cols-4">
            {processSteps.map((s, i) => (
              <li key={s.title} className="relative">
                {i < 3 && <span aria-hidden className="absolute left-[72px] right-[-16px] top-8 hidden h-px bg-indigo-100 md:block" />}
                <div className="relative inline-flex size-16 items-center justify-center rounded-2xl border border-zinc-200 bg-white text-primary shadow-sm">
                  <Icon name={s.icon} className="size-6" />
                  <span className="absolute -right-2 -top-2 inline-flex size-5 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">{String(i + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="mt-4 text-base font-bold">{s.title}</h3>
                <p className="mt-1.5 text-xs leading-relaxed text-zinc-500">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="cta-blue py-16 text-center text-white">
        <div className="mx-auto max-w-3xl px-4">
          <h2 className="text-3xl font-extrabold sm:text-4xl">Ready to upgrade your production?</h2>
          <p className="mx-auto mt-4 max-w-xl text-sm text-blue-100">Join our network of qualified global bidders and gain access to the machinery you need at competitive market prices.</p>
          <div className="mt-7 flex justify-center"><CtaRow /></div>
        </div>
      </section>
    </>
  );
}
