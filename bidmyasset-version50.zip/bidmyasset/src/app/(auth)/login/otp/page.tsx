import type { Metadata } from "next";
import { EmailFlowForm } from "@/components/EmailFlowForm";

export const metadata: Metadata = { title: "Login with OTP" };

export default function LoginOtpPage() {
  return (
    <EmailFlowForm
      askCode
      title="Login with OTP"
      intro="Enter your email address and we'll send you a one-time password to login."
      button="Get Login OTP"
      sentMessage="If this email is registered, we’ve sent a one-time password to it. It expires in 10 minutes."
    />
  );
}
