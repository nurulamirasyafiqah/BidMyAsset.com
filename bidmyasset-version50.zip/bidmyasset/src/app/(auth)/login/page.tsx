import type { Metadata } from "next";
import { GoBack } from "@/components/AuthShell";
import { LoginForm } from "@/components/LoginForm";

export const metadata: Metadata = { title: "Login" };

export default function LoginPage() {
  return (
    <div className="flex flex-col items-center">
      <LoginForm />
      <GoBack />
    </div>
  );
}
