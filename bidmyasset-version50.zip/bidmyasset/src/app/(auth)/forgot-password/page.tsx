import type { Metadata } from "next";
import { EmailFlowForm } from "@/components/EmailFlowForm";

export const metadata: Metadata = { title: "Forgot Password" };

export default function ForgotPasswordPage() {
  return (
    <EmailFlowForm
      title="Forgot Password"
      intro="Enter your email address and we'll send you a secure link to reset your password."
      button="Send reset link"
      sentMessage="If this email is registered, we’ve sent a secure link to reset your password."
    />
  );
}
