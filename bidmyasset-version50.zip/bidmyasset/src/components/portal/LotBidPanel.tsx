"use client";

import { useState } from "react";
import type { Tier } from "@/lib/bidding";
import { MemberBid, RegisterModal, useMaxBids, useRegistration } from "./registration";

export function LotBidPanel(p: { lotId: string; currentBid?: number; slug: string; auctionTitle: string; startingBid: number; increment: number; tiers?: Tier[]; currency: string; status: "LIVE" | "UPCOMING" | "CLOSED" }) {
  const [reg, register] = useRegistration(p.slug);
  const [modal, setModal] = useState(false);
  const [maxBids, setMax] = useMaxBids();

  if (p.status === "CLOSED") return <p className="mt-3 rounded-md bg-zinc-100 py-2 text-center text-xs font-medium text-zinc-500">Bidding is closed</p>;
  return (
    <div className="mt-3">
      <MemberBid size="md" lotId={p.lotId} currentBid={p.currentBid} startingBid={p.startingBid} increment={p.increment} tiers={p.tiers} currency={p.currency} status={reg} canBid={p.status === "LIVE"}
        maxBid={maxBids[p.lotId]} onSetMax={(v) => setMax(p.lotId, v)} onRegister={() => setModal(true)} />
      {modal && <RegisterModal auctionTitle={p.auctionTitle} onClose={() => setModal(false)} onSubmit={async (answers) => { await register(answers); setModal(false); }} />}
    </div>
  );
}
