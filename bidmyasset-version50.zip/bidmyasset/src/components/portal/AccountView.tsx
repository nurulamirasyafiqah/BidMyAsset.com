"use client";

import { useEffect, useState, type FormEvent } from "react";
import { X } from "lucide-react";
import { api } from "@/lib/client-api";
import type { PortalData, UserProfile } from "@/lib/portal";
import { formatPhone } from "@/lib/phone";
import { CountrySelect, StateSelect, useDials, useGeoNames } from "@/components/GeoNames";
import { DataPrivacy } from "@/components/portal/DataPrivacy";
import { NotificationSettings, PreferencesSettings } from "@/components/settings/SettingsPanels";

type Key = keyof UserProfile;
const GROUP_1: [Key, string][] = [["firstName", "First name"], ["lastName", "Last name"], ["company", "Company"], ["designation", "Designation"], ["website", "Website"], ["signatureName", "Signature name"]];
const GROUP_2: [Key, string][] = [["address1", "Address line 1"], ["address2", "Address line 2"], ["city", "City"], ["state", "State / Province"], ["postalCode", "Postal code"], ["country", "Country"]];

const initials = (n: string) => n.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
const input = "mt-1 h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";
const outlineBtn = "rounded-md border border-primary/50 bg-white px-4 py-1.5 text-xs font-semibold text-primary hover:bg-primary/5";

export function AccountView({ user, data }: { user: UserProfile; data: PortalData }) {
  const [saved, setSaved] = useState(user);
  const [draft, setDraft] = useState(user);
  const [editing, setEditing] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const full = `${saved.firstName} ${saved.lastName}`.trim();
  const geo = useGeoNames(saved.country, saved.state);
  const dials = useDials();
  const shown = (k: Key) => (k === "country" ? geo.country : k === "state" ? geo.state : "") || saved[k];

  const [err, setErr] = useState("");
  async function save(e: FormEvent) {
    e.preventDefault();
    setErr("");
    try {
      const { id: _id, name: _name, email: _email, ...fields } = draft;
      await api(`api/collections/users/records/${user.id}`, { method: "PATCH", body: fields });
      setSaved(draft);
      setEditing(false);
    } catch (x) {
      setErr((x as Error).message);
    }
  }

  const grid = (rows: [Key, string][]) => (
    <dl className="grid gap-x-10 gap-y-5 sm:grid-cols-2">
      {rows.map(([k, label]) => (
        <div key={k}>
          <dt className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">{label}</dt>
          {editing
            ? <dd>{k === "country" ? <CountrySelect label={label} value={draft.country} onChange={(v) => setDraft({ ...draft, country: v, state: "" })} className={input} />
              : k === "state" ? <StateSelect label={label} country={draft.country} value={draft.state} onChange={(v) => setDraft({ ...draft, state: v })} className={input} />
              : <input aria-label={label} value={draft[k]} onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} className={input} />}</dd>
            : <dd className={`mt-1 text-sm ${saved[k] ? "text-ink" : "text-zinc-400"}`}>{shown(k) || "Not provided"}</dd>}
        </div>
      ))}
    </dl>
  );

  const row = (label: string, value: React.ReactNode) => (
    <div className="flex items-center justify-between gap-3 rounded-lg bg-white px-4 py-3 text-sm shadow-sm">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-[396px_1fr]">
        <section className="rounded-2xl border border-zinc-200 bg-gradient-to-br from-white to-zinc-100 p-5 shadow-sm">
          <div className="flex flex-col items-center pt-2">
            <span className="grid size-16 place-items-center rounded-full bg-blue-100 text-base font-semibold text-primary">{initials(full)}</span>
            <h2 className="mt-3 text-lg font-bold">{full}</h2>
            <span className="mt-2 rounded bg-blue-100 px-2.5 py-0.5 text-[10px] font-bold tracking-wider text-primary">BIDDER</span>
          </div>
          <div className="mt-5 space-y-3">
            {row("Full name", full)}
            {row("Primary email", <a href={`mailto:${saved.email}`} className="text-primary">{saved.email}</a>)}
            {row("Phone", formatPhone(saved.phone, user.phoneCountry || saved.country, dials))}
          </div>
        </section>

        <form onSubmit={save} className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        {err && <p role="alert" className="mb-3 text-xs font-medium text-red-600">{err}</p>}
          <div className="mb-5 flex items-start justify-between gap-3">
            <h2 className="text-base font-bold">Profile Details</h2>
            {editing ? (
              <div className="flex gap-2">
                <button type="button" onClick={() => { setDraft(saved); setEditing(false); }} data-btn="outline" className={outlineBtn}>Cancel</button>
                <button data-btn="primary" className="rounded-md bg-primary px-4 py-1.5 text-xs font-semibold text-white hover:bg-primary-700">Save</button>
              </div>
            ) : (
              <button type="button" onClick={() => { setDraft(saved); setEditing(true); }} data-btn="outline" className={outlineBtn}>Edit Profile</button>
            )}
          </div>
          {grid(GROUP_1)}
          <hr className="my-6 border-zinc-200" />
          {grid(GROUP_2)}
          <hr className="mt-6 border-zinc-200" />
        </form>
      </div>

      <section className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
        <div>
          <h2 className="text-base font-bold">Security</h2>
          <p className="mt-0.5 text-sm text-zinc-500">Change your password to keep your account secure.</p>
          <p className="mt-5 text-sm text-zinc-500">Use a strong, unique password that includes uppercase and lowercase letters, numbers, and special characters.</p>
        </div>
        <button type="button" onClick={() => setPwOpen(true)} data-btn="outline" className={outlineBtn}>Change Password</button>
      </section>

      <NotificationSettings scope="portal" />
      <PreferencesSettings scope="portal" />
      <DataPrivacy user={saved} data={data} />

      {pwOpen && <PasswordModal userId={user.id} onClose={() => setPwOpen(false)} />}
    </div>
  );
}

function PasswordModal({ onClose, userId }: { onClose: () => void; userId: string }) {
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [onClose]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const strong = next.length >= 8 && /[a-z]/.test(next) && /[A-Z]/.test(next) && /\d/.test(next) && /[^A-Za-z0-9]/.test(next);
    if (!strong) return setMsg({ ok: false, text: "Use at least 8 characters with uppercase, lowercase, a number and a special character." });
    if (next !== again) return setMsg({ ok: false, text: "The new passwords don’t match." });
    try {
      await api(`api/collections/users/records/${userId}`, { method: "PATCH", body: { oldPassword: cur, password: next, passwordConfirm: again } });
      setMsg({ ok: true, text: "Password updated. Signing you out…" });
      // PocketBase invalidates old tokens on password change → sign in again.
      setTimeout(async () => { await fetch("/api/logout", { method: "POST" }); window.location.href = "/login"; }, 1200);
    } catch (x) {
      setMsg({ ok: false, text: (x as Error).message });
    }
  }

  const f = (label: string, v: string, set: (s: string) => void, auto: string) => (
    <label className="block text-sm font-medium">{label}
      <input type="password" required autoComplete={auto} value={v} onChange={(e) => set(e.target.value)} className={input} />
    </label>
  );

  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form role="dialog" aria-modal="true" aria-labelledby="pw-title" data-dialog onSubmit={submit} className="relative w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-2xl">
        <button type="button" aria-label="Close" onClick={onClose} className="absolute right-4 top-4 text-zinc-400 hover:text-zinc-700"><X className="size-5" /></button>
        <h2 id="pw-title" data-dialog-title className="text-lg font-bold">Change Password</h2>
        {f("Current password", cur, setCur, "current-password")}
        {f("New password", next, setNext, "new-password")}
        {f("Confirm new password", again, setAgain, "new-password")}
        {msg && <p role="status" className={`rounded p-2 text-xs ${msg.ok ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-600"}`}>{msg.text}</p>}
        <div data-dialog-footer className="flex justify-end gap-3">
          <button type="button" onClick={onClose} data-btn="outline" className={outlineBtn}>Close</button>
          <button data-btn="primary" className="rounded-md bg-primary px-4 py-1.5 text-xs font-semibold text-white hover:bg-primary-700">Update password</button>
        </div>
      </form>
    </div>
  );
}
