"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CalendarDays, ChevronLeft, ChevronRight, Clock, RefreshCw } from "lucide-react";
import type { Auction, LocationLot } from "@/lib/data";
import { dayKey, formatKeyLong, formatStamp } from "@/lib/format";

const COMPANY_TZ = "Asia/Kuala_Lumpur";
const WEEK = 7 * 86400000;
const pad = (n: number) => String(n).padStart(2, "0");

type St = "LIVE" | "UPCOMING" | "CLOSED";
/** One row on the calendar: a timed auction, or a lot that has a physical location. */
type Entry = { key: string; title: string; sub?: string; city: string; region: string; startsAt: string; endsAt: string; timezone: string; href: string; cta: string; chip: string };
const statusOf = (a: Pick<Entry, "startsAt" | "endsAt">, now: number): St =>
  now >= +new Date(a.endsAt) ? "CLOSED" : now < +new Date(a.startsAt) ? "UPCOMING" : "LIVE";
const fromAuction = (a: Auction): Entry => ({ key: a.slug, title: a.title, city: a.city, region: a.region, startsAt: a.startsAt, endsAt: a.endsAt, timezone: a.timezone, href: `/timed/${a.slug}`, cta: "Go to Auction", chip: `${a.lotCount} lots` });
const fromLot = (l: LocationLot): Entry => ({ key: l.id, title: l.title, sub: `Lot ${l.lotNumber} · ${l.auctionTitle}`, city: l.city, region: l.region, startsAt: l.startsAt, endsAt: l.endsAt, timezone: l.timezone, href: `/timed/${l.auctionSlug}/lot/${l.lotNumber}`, cta: "View lot", chip: "Location lot" });

function Stat({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
      <p className="text-[11px] uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-2 text-2xl font-bold text-brand">{value}</p>
      {sub && <p className="mt-1 text-[11px] text-slate-500">{sub}</p>}
    </div>
  );
}

export function CalendarView({ auctions, locationLots = [], serverNow }: { auctions: Auction[]; locationLots?: LocationLot[]; serverNow: number }) {
  const router = useRouter();
  const todayKey = dayKey(serverNow, COMPANY_TZ);
  const [sel, setSel] = useState(todayKey);
  const [view, setView] = useState(() => { const [y, m] = todayKey.split("-").map(Number); return { y, m: m - 1 }; });
  const [mode, setMode] = useState<"timed" | "location">("timed");
  const [q, setQ] = useState("");

  const timed = mode === "timed";
  const source = useMemo<(Entry & { text: string })[]>(() => timed
    ? auctions.map((a) => ({ ...fromAuction(a), text: `${a.title} ${a.city} ${a.region} ${a.category} ${a.subcategory}` }))
    : locationLots.map((l) => ({ ...fromLot(l), text: `${l.title} ${l.auctionTitle} ${l.lotNumber} ${l.city} ${l.region}` })), [timed, auctions, locationLots]);
  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return source
      .filter((a) => !t || a.text.toLowerCase().includes(t))
      .sort((a, b) => +new Date(a.startsAt) - +new Date(b.startsAt));
  }, [source, q]);

  const entries = list.filter((a) => dayKey(a.startsAt, a.timezone) <= sel && sel <= dayKey(a.endsAt, a.timezone));
  const live = entries.filter((a) => statusOf(a, serverNow) === "LIVE").length;
  const upcoming = entries.filter((a) => statusOf(a, serverNow) === "UPCOMING").length;

  const monthKey = `${view.y}-${pad(view.m + 1)}`;
  const inMonth = list.filter((a) => dayKey(a.startsAt, a.timezone).startsWith(monthKey));
  const closingSoon = inMonth.filter((a) => +new Date(a.endsAt) > serverNow && +new Date(a.endsAt) - serverNow <= WEEK).length;

  const next = list.find((a) => +new Date(a.startsAt) > serverNow);
  const nextWeek = list.filter((a) => +new Date(a.startsAt) > serverNow && +new Date(a.startsAt) - serverNow <= WEEK).length;

  const first = new Date(Date.UTC(view.y, view.m, 1)).getUTCDay();
  const days = new Date(Date.UTC(view.y, view.m + 1, 0)).getUTCDate();
  const shift = (d: number) => setView(({ y, m }) => { const n = new Date(Date.UTC(y, m + d, 1)); return { y: n.getUTCFullYear(), m: n.getUTCMonth() }; });
  const rangeBadge = sel === todayKey ? "Live in range" : sel > todayKey ? "Scheduled" : "In range";

  return (
    <>
      <div className="border-b border-zinc-200 px-6 py-8 lg:px-8">
        <div className="mx-auto flex max-w-[1240px] flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Auction Calendar</h1>
            <p className="mt-2 max-w-xl text-sm text-slate-600">Discover upcoming activity across timed auctions and location-based lots. Select a date to view the full schedule and jump straight into the catalog.</p>
            <p className="mt-2 text-xs text-slate-500">{source.length} {timed ? "auctions" : "lots with a physical location"} scheduled across upcoming months.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex rounded-full border border-zinc-200 bg-white p-1 shadow-sm" role="tablist">
              {([["timed", "Timed Auctions"], ["location", "Location Lots"]] as const).map(([id, label]) => (
                <button key={id} role="tab" aria-selected={mode === id} onClick={() => setMode(id)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition ${mode === id ? "bg-primary text-white" : "text-ink hover:bg-zinc-50"}`}>{label}</button>
              ))}
            </div>
            <button onClick={() => router.refresh()} className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-white px-4 py-2 text-sm font-semibold text-primary hover:bg-primary/5"><RefreshCw className="size-4" />Refresh</button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1180px] space-y-6 px-4 py-8 sm:px-6">
        {(
          <>
            <div className="rounded-2xl bg-zinc-50 p-4">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Stat label={timed ? "Auctions scheduled" : "Scheduled"} value={inMonth.length} sub={timed ? `${pad(view.m + 1)}/${view.y}` : undefined} />
                <Stat label="Upcoming" value={inMonth.filter((a) => statusOf(a, serverNow) === "UPCOMING").length} />
                <Stat label="Live" value={inMonth.filter((a) => statusOf(a, serverNow) === "LIVE").length} />
                <Stat label="Closing soon" value={closingSoon} />
              </div>
            </div>

            <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-100 px-6 py-5">
                <h2 className="flex items-center gap-3 text-lg font-bold"><span className="grid size-9 place-items-center rounded-full bg-blue-50 text-primary"><CalendarDays className="size-4" /></span>Browse by Date</h2>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by auction, lot, city, or keyword" aria-label="Search auctions"
                  className="h-10 w-full rounded-md border border-zinc-300 px-3 text-sm placeholder:text-zinc-400 focus:border-primary focus:outline-none sm:w-96" />
              </div>

              <div className="grid gap-5 p-5 lg:grid-cols-[300px_1fr]">
                <div className="self-start rounded-2xl border border-blue-100 bg-gradient-to-br from-blue-50/60 to-white p-5">
                  <div className="flex items-center justify-between text-sm font-semibold">
                    <button aria-label="Previous month" onClick={() => shift(-1)} className="rounded p-1 hover:bg-white"><ChevronLeft className="size-4" /></button>
                    {new Date(Date.UTC(view.y, view.m, 1)).toLocaleString("en-US", { month: "long", year: "numeric", timeZone: "UTC" })}
                    <button aria-label="Next month" onClick={() => shift(1)} className="rounded p-1 hover:bg-white"><ChevronRight className="size-4" /></button>
                  </div>
                  <div className="mt-4 grid grid-cols-7 gap-y-1 text-center text-xs">
                    {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => <span key={d} className="pb-2 text-slate-400">{d}</span>)}
                    {Array.from({ length: first }).map((_, i) => <span key={`b${i}`} />)}
                    {Array.from({ length: days }, (_, i) => i + 1).map((n) => {
                      const key = `${monthKey}-${pad(n)}`;
                      return (
                        <button key={n} onClick={() => setSel(key)} aria-pressed={key === sel}
                          className={`mx-auto grid size-9 place-items-center rounded-md text-sm ${key === sel ? "bg-primary font-semibold text-white" : key === todayKey ? "font-bold text-primary" : "hover:bg-white"}`}>{n}</button>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-2xl border border-zinc-200 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold">{formatKeyLong(sel)}</p>
                      <p className="text-xs text-slate-500">{entries.length === 0 ? `No ${timed ? "auctions" : "lots"} in this range` : `${entries.length} ${timed ? "auctions" : "lots"} in range • ${live} live • ${upcoming} upcoming`}</p>
                    </div>
                    {entries.length > 0 && <span className="rounded-full bg-blue-100 px-3 py-1 text-[11px] font-semibold text-primary">{rangeBadge}</span>}
                  </div>

                  <div className="mt-4 max-h-[420px] space-y-3 overflow-y-auto pr-1">
                    {entries.length === 0 && (
                      <div className="flex flex-col items-center rounded-xl border border-dashed border-primary/40 bg-blue-50/60 px-6 py-14 text-center">
                        <CalendarDays className="size-7 text-primary" />
                        <p className="mt-3 text-sm font-bold">No activity in this range</p>
                        <p className="mt-0.5 text-xs text-slate-500">Try different dates or adjust your search.</p>
                      </div>
                    )}
                    {entries.map((a) => {
                      const st = statusOf(a, serverNow);
                      return (
                        <article key={a.key} className="flex flex-wrap items-stretch justify-between gap-4 rounded-2xl border border-zinc-200 p-5">
                          <div className="flex gap-4">
                            <span className="w-1 shrink-0 rounded-full bg-primary" />
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="rounded-full bg-primary px-3 py-0.5 text-[11px] font-semibold text-white">{st === "LIVE" ? "Live" : "Upcoming"}</span>
                                <span className="rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] text-slate-600">{a.chip}</span>
                              </div>
                              <h3 className="mt-2 text-base font-bold">{a.title}</h3>
                              {a.sub && <p className="text-xs text-slate-500">{a.sub}</p>}
                              {(a.city || a.region) && <p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-primary">{[a.city, a.region].filter(Boolean).join(", ")}</p>}
                              <Link href={a.href} className="mt-5 inline-block rounded-full bg-primary px-5 py-2 text-sm font-semibold text-white hover:bg-primary-700">{a.cta}</Link>
                            </div>
                          </div>
                          <p className="flex items-start gap-3 text-sm text-slate-500">
                            <span className="grid size-9 shrink-0 place-items-center rounded-full bg-blue-50 text-primary"><Clock className="size-4" /></span>
                            <span className="pt-1.5">{timed ? formatStamp(a.startsAt, a.timezone) : `Closes ${formatStamp(a.endsAt, a.timezone)}`}</span>
                          </p>
                        </article>
                      );
                    })}
                  </div>
                </div>
              </div>
            </section>

            <div className="rounded-2xl bg-zinc-50 p-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
                  <p className="text-[11px] uppercase tracking-wide text-slate-500">Next live event</p>
                  {next ? (
                    <>
                      <p className="mt-2 text-sm font-bold">{next.title}</p>
                      <p className="mt-1 text-xs text-slate-500">{formatStamp(next.startsAt, next.timezone).replace(/^\w+, /, "")}</p>
                      <Link href={next.href} className="mt-3 inline-block rounded-full border border-primary/50 px-4 py-1.5 text-xs font-semibold text-primary hover:bg-primary/5">View details</Link>
                    </>
                  ) : <p className="mt-2 text-sm text-slate-500">No upcoming live activity detected.</p>}
                </div>
                <Stat label="Next 7 days" value={nextWeek} sub={`Scheduled ${timed ? "auctions" : "lots"} in the next week.`} />
                <Stat label="Active catalogs" value={list.length} sub={`Unique ${timed ? "timed" : "location"} auctions matching your filters.`} />
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
