"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CreditCard, RefreshCw, Search } from "lucide-react";
import { Pill, Table } from "@/components/portal/ui";
import { formatMoney } from "@/lib/format";
import { T } from "@/components/T";
import { useT } from "@/lib/useT";
import type { Invoice } from "@/lib/portal";

export function InvoicesView({ invoices }: { invoices: Invoice[] }) {
  const router = useRouter();
  const t = useT();
  const [q, setQ] = useState("");
  const [payingId, setPayingId] = useState("");
  const [payErr, setPayErr] = useState("");
  const needle = q.trim().toLowerCase();
  // Toyyibpay: the backend creates the bill and returns the payment page; the invoice turns "Paid" once Toyyibpay confirms it.
  const pay = async (i: Invoice) => {
    if (!i.recordId) return;
    setPayingId(i.recordId); setPayErr("");
    try {
      const res = await fetch(`/api/pb/api/bma/invoices/${i.recordId}/pay`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}", cache: "no-store" });
      const j = (await res.json().catch(() => ({}))) as { url?: string; message?: string };
      if (!res.ok || !j.url) throw new Error(j.message || "Could not start the payment.");
      window.location.href = j.url;
    } catch (e) { setPayErr(e instanceof Error ? e.message : "Could not start the payment."); setPayingId(""); }
  };
  const shown = needle
    ? invoices.filter((i) => `${i.auctionTitle} ${i.lotTitle}`.toLowerCase().includes(needle))
    : invoices;

  return (
    <section className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold"><T>My Invoices</T></h1>
          <p className="mt-0.5 text-sm text-zinc-500"><T>View invoice details for your awarded lots.</T></p>
        </div>
        <div className="flex w-full items-center gap-3 sm:w-auto">
          <label className="relative block flex-1 sm:w-[400px] sm:flex-none">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("Search by auction name or lot sequence / lot name")}
              aria-label="Search invoices"
              className="h-10 w-full rounded-md border border-zinc-300 bg-white pl-10 pr-3 text-sm placeholder:text-zinc-400 focus:border-primary focus:outline-none"
            />
          </label>
          <button
            data-btn="outline"
            onClick={() => router.refresh()}
            className="inline-flex h-10 shrink-0 items-center gap-2 rounded-md border border-primary/40 bg-white px-5 text-sm font-semibold text-primary hover:bg-primary/5"
          >
            <RefreshCw className="size-4" />{t("Refresh")}
          </button>
        </div>
      </div>

      {payErr && <p role="alert" className="mt-4 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{payErr}</p>}
      <div className="mt-6">
        {shown.length === 0 ? (
          <div className="grid h-[100px] place-items-center rounded-lg border border-zinc-200 bg-zinc-100 px-4 text-center text-sm text-zinc-500">
            {t("No invoices found.")}
          </div>
        ) : (
          <Table
            head={[t("Invoice"), t("Auction / Lot"), t("Amount"), t("Status"), t("Issued"), ""]}
            rows={shown.map((i) => [
              <b key="i">{i.id}</b>,
              `${i.auctionTitle} · ${i.lotTitle}`,
              <span key="a">{formatMoney(i.amount, i.currency)}
                {i.hammer ? <span className="block text-[10px] text-zinc-500">hammer {formatMoney(i.hammer, i.currency)}{i.commission ? ` + commission ${formatMoney(i.commission, i.currency)}` : ""}{i.internetFee ? ` + internet fee ${formatMoney(i.internetFee, i.currency)}` : ""}{i.tax ? ` + tax ${formatMoney(i.tax, i.currency)}` : ""}</span>
                  : (i.commission || i.internetFee || i.tax) ? <span className="block text-[10px] text-zinc-500">incl. fees {formatMoney((i.commission ?? 0) + (i.internetFee ?? 0) + (i.tax ?? 0), i.currency)}</span> : null}</span>,
              <Pill key="s" tone={i.status === "PAID" ? "green" : "amber"}>{i.status === "PAID" ? t("Paid") : t("Unpaid")}</Pill>,
              new Date(i.issuedAt).toLocaleDateString("en-GB"),
              i.status === "UNPAID" && i.recordId
                ? <button key="p" type="button" disabled={payingId === i.recordId} onClick={() => pay(i)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-primary px-3 text-xs font-semibold text-white disabled:opacity-60"><CreditCard className="size-3.5" />{payingId === i.recordId ? t("Opening…") : t("Pay now")}</button>
                : null,
            ])}
          />
        )}
      </div>
    </section>
  );
}
