"use client";

import { createContext, useContext, type ReactNode } from "react";

export type SessionUser = { name: string; email: string; state: string; company: string };
const Ctx = createContext<SessionUser>({ name: "", email: "", state: "", company: "" });

export const UserProvider = ({ user, children }: { user: SessionUser; children: ReactNode }) => <Ctx.Provider value={user}>{children}</Ctx.Provider>;
export const useUser = () => useContext(Ctx);
