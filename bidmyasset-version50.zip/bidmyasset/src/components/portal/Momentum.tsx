export function Momentum({ data }: { data: { day: number; count: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const W = 560, H = 160, pad = 8, bw = (W - pad * 2) / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H + 18}`} className="h-52 w-full" role="img" aria-label="Bids per day, last 14 days">
      {[0, 0.5, 1].map((t) => <line key={t} x1={pad} x2={W - pad} y1={H - t * (H - 10)} y2={H - t * (H - 10)} stroke="#e4e4e7" strokeDasharray="3 4" />)}
      {data.map((d, i) => {
        const h = (d.count / max) * (H - 14);
        return (
          <g key={i}>
            <rect x={pad + i * bw + 4} y={H - h} width={bw - 8} height={Math.max(h, 2)} rx={3} fill={d.count ? "#0037e1" : "#e4e4e7"}>
              <title>{d.count} bid{d.count === 1 ? "" : "s"}</title>
            </rect>
            {(i === 0 || i === data.length - 1 || i === 6) && (
              <text x={pad + i * bw + bw / 2} y={H + 14} textAnchor="middle" fontSize="10" fill="#71717a">{i === data.length - 1 ? "Today" : `${data.length - 1 - i}d ago`}</text>
            )}
          </g>
        );
      })}
    </svg>
  );
}
