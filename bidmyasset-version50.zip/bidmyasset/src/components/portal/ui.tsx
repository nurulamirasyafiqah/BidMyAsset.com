import Link from "next/link";
import type { ReactNode } from "react";
import { Info, type LucideIcon } from "lucide-react";
import type { BidState } from "@/lib/portal";

export function PageTitle({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        {sub && <p className="mt-0.5 text-sm text-zinc-500">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Panel({ title, sub, action, children, className = "" }: { title?: string; sub?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm ${className}`}>
      {(title || action) && (
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-lg font-bold">{title}</h2>}
            {sub && <p className="mt-0.5 text-xs text-zinc-500">{sub}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function EmptyState({ icon: I, title, text, href, cta }: { icon: LucideIcon; title: string; text: string; href?: string; cta?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 px-6 py-10 text-center">
      <span className="grid size-11 place-items-center rounded-full bg-white shadow-sm"><I className="size-5 text-zinc-600" /></span>
      <p className="mt-3 text-sm font-semibold text-zinc-800">{title}</p>
      <p className="mt-1 max-w-xs text-xs text-zinc-500">{text}</p>
      {href && cta && <Link href={href} className="mt-4 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:bg-primary-700">{cta}</Link>}
    </div>
  );
}

export function StatCard({ label, value, hint, icon: I }: { label: string; value: number | string; hint: string; icon: LucideIcon }) {
  return (
    <div className="rounded-2xl bg-zinc-50 p-3">
      <div className="flex items-center justify-between rounded-xl border border-zinc-200 bg-white p-5 shadow-sm">
        <div>
          <p className="flex items-center gap-1.5 text-sm text-zinc-600">{label}<span title={hint}><Info className="size-3.5 text-zinc-400" /></span></p>
          <p className="mt-2 text-2xl font-bold">{value}</p>
        </div>
        <span className="grid size-11 place-items-center rounded-full bg-blue-50"><I className="size-5 text-primary" /></span>
      </div>
    </div>
  );
}

const chip: Record<BidState, string> = {
  LEADING: "bg-sky-50 text-sky-700 border-sky-200",
  OUTBID: "bg-rose-50 text-rose-600 border-rose-200",
  TRACKED: "bg-zinc-100 text-zinc-600 border-zinc-200",
};
export const stateLabel: Record<BidState, string> = { LEADING: "Leading", OUTBID: "Outbid", TRACKED: "Tracked" };

export function StateChip({ state }: { state: BidState }) {
  return <span className={`inline-block rounded-full border px-2 py-0.5 text-[11px] font-semibold ${chip[state]}`}>{stateLabel[state]}</span>;
}

export function Pill({ tone, children }: { tone: "green" | "amber" | "red" | "zinc"; children: ReactNode }) {
  const t = { green: "bg-emerald-50 text-emerald-700", amber: "bg-amber-50 text-amber-700", red: "bg-rose-50 text-rose-600", zinc: "bg-zinc-100 text-zinc-600" }[tone];
  return <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${t}`}>{children}</span>;
}

export function Table({ head, rows }: { head: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-zinc-200">
      <table className="w-full min-w-[560px] text-left text-xs">
        <thead className="bg-zinc-50 text-[11px] uppercase tracking-wide text-zinc-500">
          <tr>{head.map((h) => <th key={h} className="px-4 py-2.5 font-semibold">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-zinc-100">
          {rows.map((r, i) => <tr key={i} className="hover:bg-zinc-50">{r.map((c, j) => <td key={j} className="px-4 py-3">{c}</td>)}</tr>)}
        </tbody>
      </table>
    </div>
  );
}
