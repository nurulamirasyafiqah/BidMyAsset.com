"use client";

import { useState } from "react";
import Link from "next/link";
import { RectangleVertical, Search } from "lucide-react";
import { formatMoney } from "@/lib/format";
import type { PortalData } from "@/lib/portal";

export function FavouritesView({ items }: { items: PortalData["favourites"] }) {
  const [q, setQ] = useState("");
  const t = q.trim().toLowerCase();
  const shown = items.filter((f) => !t || `${f.lotTitle} ${f.auctionTitle} ${f.lotNumber}`.toLowerCase().includes(t));

  return (
    <>
      <div className="border-b border-zinc-200 px-6 pb-5 pt-12 lg:px-8">
        <div className="mx-auto max-w-[1240px]">
          <h1 className="text-3xl font-bold">My Favourite Lots</h1>
          <p className="mt-1 text-sm text-slate-600">Lots you’ve saved to keep track of upcoming bidding opportunities.</p>
        </div>
      </div>

      <div className="mx-auto max-w-[1240px] px-4 py-6 sm:px-6 lg:px-8">
        <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
          <div className="border-b border-zinc-100 p-5">
            <label className="flex h-9 max-w-md items-center gap-2 rounded-md border border-zinc-300 px-3 focus-within:border-primary">
              <Search className="size-4 text-zinc-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search lots or auctions..." aria-label="Search favourites" className="w-full bg-transparent text-sm outline-none placeholder:text-zinc-400" />
            </label>
          </div>
          <div className="p-5">
            {shown.length === 0 ? (
              <div className="flex flex-col items-center rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-6 py-14 text-center">
                <span className="grid size-12 place-items-center rounded-full bg-zinc-100"><RectangleVertical className="size-5 text-zinc-500" /></span>
                <p className="mt-3 text-sm font-bold">{items.length === 0 ? "No favourite lots yet" : "No matching lots"}</p>
                <p className="mt-1 text-xs text-zinc-500">{items.length === 0 ? "You have not added any favourite lots yet." : "Try a different search."}</p>
              </div>
            ) : (
              <ul className="divide-y divide-zinc-100">
                {shown.map((f) => (
                  <li key={f.lotNumber} className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
                    <div>
                      <Link href={`/timed/${f.auctionSlug}/lot/${f.lotNumber}`} className="font-semibold hover:text-primary">Lot {f.lotNumber} · {f.lotTitle}</Link>
                      <p className="text-xs text-zinc-500">{f.auctionTitle}</p>
                    </div>
                    <span className="text-xs text-zinc-500">Starting bid {formatMoney(f.startingBid, f.currency)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
