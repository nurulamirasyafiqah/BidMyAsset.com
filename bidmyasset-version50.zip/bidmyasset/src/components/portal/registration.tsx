"use client";

import { LegalLink } from "@/components/LegalPopup";
import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { CircleDot, X } from "lucide-react";
import { BidStepper } from "@/components/BidStepper";
import { formatMoney } from "@/lib/format";
import { incrementAt, type Tier } from "@/lib/bidding";
import { api } from "@/lib/client-api";
import { useLotEvents } from "@/lib/liveLots";
import { useUser } from "./UserContext";

export type RegStatus = "NONE" | "PENDING" | "APPROVED";

/** Registration status for this auction, read from / written to the backend. Staff approve in the PocketBase dashboard. */
export function useRegistration(slug: string) {
  const [status, setStatus] = useState<RegStatus>("NONE");
  useEffect(() => {
    let live = true;
    api<{ items: { status: RegStatus }[] }>(`api/collections/registrations/records?filter=${encodeURIComponent(`auction.slug="${slug}"`)}&perPage=1`)
      .then((r) => { if (live && r.items[0]) setStatus(r.items[0].status === "APPROVED" ? "APPROVED" : "PENDING"); })
      .catch(() => {});
    return () => { live = false; };
  }, [slug]);
  const register = async (answers?: Answers) => {
    const r = await api<{ status: string }>("api/bma/registrations", { body: { auction: slug, answers: answers ?? {} } });
    setStatus(r.status === "APPROVED" ? "APPROVED" : "PENDING");
  };
  return [status, register] as const;
}

/** Company → Questionnaire: the active template's questions, asked when a bidder registers. */
type Question = { id: string; text: string; type: "short" | "long" | "yesno" | "single" | "multi"; required: boolean; options: string[] };
export type Answers = Record<string, string | string[]>;

function useQuestionnaire() {
  const [qs, setQs] = useState<Question[] | null>(null);
  useEffect(() => {
    let live = true;
    api<{ questions?: Question[] }>("api/bma/questionnaire")
      .then((r) => { if (live) setQs(r.questions ?? []); })
      .catch(() => { if (live) setQs([]); }); // can't load: the server still enforces required questions and says which one is missing
    return () => { live = false; };
  }, []);
  return qs;
}

const field = "h-10 w-full rounded-md border border-zinc-200 bg-white px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

export function RegisterModal({ auctionTitle, onClose, onSubmit }: { auctionTitle: string; onClose: () => void; onSubmit: (answers: Answers) => Promise<void> }) {
  const user = useUser();
  const [accepted, setAccepted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const questions = useQuestionnaire();
  const [answers, setAnswers] = useState<Answers>({});
  const setA = (id: string, v: string | string[]) => setAnswers((p) => ({ ...p, [id]: v }));

  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [onClose]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!accepted || busy || questions === null) return;
    const missing = questions.find((q) => q.required && (Array.isArray(answers[q.id]) ? (answers[q.id] as string[]).length === 0 : !String(answers[q.id] ?? "").trim()));
    if (missing) { setErr(`Please answer: ${missing.text}`); return; }
    setBusy(true); setErr("");
    try { await onSubmit(answers); } catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  }

  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form role="dialog" aria-modal="true" aria-labelledby="reg-title" data-dialog onSubmit={submit} className="relative w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl">
        <button type="button" aria-label="Close" onClick={onClose} className="absolute right-4 top-4 text-zinc-400 hover:text-zinc-700"><X className="size-5" /></button>
        <h2 id="reg-title" data-dialog-title className="text-lg font-bold">Register to Bid</h2>
        <p className="mt-1 text-sm text-zinc-500">Complete the information below to request approval for <b className="text-ink">{auctionTitle}</b>.</p>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <label className="text-sm font-medium">Name<input value={user.name} disabled className={`${field} mt-1.5 bg-zinc-50 text-zinc-400`} /></label>
          <label className="text-sm font-medium">Email<input value={user.email} disabled className={`${field} mt-1.5 bg-zinc-50 text-zinc-400`} /></label>
          <label className="text-sm font-medium">Company<input name="company" defaultValue={user.company} className={`${field} mt-1.5`} /></label>
          <label className="text-sm font-medium">State / Province<input name="state" defaultValue={user.state} className={`${field} mt-1.5`} /></label>
        </div>

        {questions === null && <p className="mt-4 rounded-lg bg-zinc-50 p-4 text-sm text-zinc-500">Loading…</p>}
        {questions !== null && questions.length === 0 && <p className="mt-4 rounded-lg bg-zinc-50 p-4 text-sm text-zinc-500">No additional information is required for this auction. Submit your request to notify the auction team.</p>}
        {questions !== null && questions.length > 0 && (
          <div className="mt-4 max-h-64 space-y-4 overflow-y-auto pr-1">
            {questions.map((q) => (
              <fieldset key={q.id} className="text-sm">
                <legend className="font-medium">{q.text}{q.required && <span className="text-red-600"> *</span>}</legend>
                {q.type === "short" && <input className={`${field} mt-1.5`} value={String(answers[q.id] ?? "")} maxLength={2000} onChange={(e) => setA(q.id, e.target.value)} />}
                {q.type === "long" && <textarea rows={3} className="mt-1.5 w-full rounded-md border border-zinc-200 px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20" value={String(answers[q.id] ?? "")} maxLength={2000} onChange={(e) => setA(q.id, e.target.value)} />}
                {(q.type === "yesno" || q.type === "single") && (
                  <div className="mt-1.5 space-y-1.5">
                    {(q.type === "yesno" ? ["Yes", "No"] : q.options).map((o) => (
                      <label key={o} className="flex cursor-pointer items-center gap-2 text-zinc-700"><input type="radio" name={`q-${q.id}`} className="accent-[#0037e1]" checked={answers[q.id] === o} onChange={() => setA(q.id, o)} />{o}</label>
                    ))}
                  </div>
                )}
                {q.type === "multi" && (
                  <div className="mt-1.5 space-y-1.5">
                    {q.options.map((o) => {
                      const cur = (answers[q.id] as string[] | undefined) ?? [];
                      return <label key={o} className="flex cursor-pointer items-center gap-2 text-zinc-700"><input type="checkbox" className="accent-[#0037e1]" checked={cur.includes(o)} onChange={(e) => setA(q.id, e.target.checked ? [...cur, o] : cur.filter((x) => x !== o))} />{o}</label>;
                    })}
                  </div>
                )}
              </fieldset>
            ))}
          </div>
        )}

        <label className="mt-4 flex cursor-pointer items-start gap-2.5 text-sm text-zinc-600">
          <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-0.5 size-4 accent-[#0037e1]" />
          <span>I accept the <LegalLink kind="terms" className="underline">Terms &amp; Conditions</LegalLink> and <LegalLink kind="privacy" className="underline">Privacy Policy</LegalLink> required to bid in <b className="text-ink">{auctionTitle}</b>.</span>
        </label>

        {err && <p role="alert" className="mt-3 text-sm font-medium text-red-600">{err}</p>}
        <div data-dialog-footer className="mt-5 flex justify-end gap-3">
          <button type="button" data-btn="outline" onClick={onClose} className="rounded-md border border-primary/40 px-5 py-2 text-sm font-semibold text-primary hover:bg-primary/5">Cancel</button>
          <button data-btn="primary" disabled={!accepted || busy || questions === null} className="rounded-md bg-primary px-5 py-2 text-sm font-semibold text-white hover:bg-primary-700 disabled:cursor-not-allowed disabled:bg-primary/40">{busy ? "Submitting…" : "Submit registration"}</button>
        </div>
      </form>
    </div>
  );
}

/** The signed-in bidder's own maximum (proxy / absentee) bids, by lot id, kept on the server (max_bids). */
export function useMaxBids(enabled = true) {
  const [maxBids, setMaxBids] = useState<Record<string, number>>({});
  useEffect(() => {
    if (!enabled) return;
    let live = true;
    api<{ items: { lot: string; amount: number }[] }>("api/bma/max-bids")
      .then((r) => { if (live) setMaxBids(Object.fromEntries(r.items.map((i) => [i.lot, i.amount]))); })
      .catch(() => {});
    return () => { live = false; };
  }, [enabled]);
  const setMax = (lotId: string, v: number) => setMaxBids((m) => ({ ...m, [lotId]: v }));
  return [maxBids, setMax] as const;
}

type MemberBidProps = {
  lotId: string; currentBid?: number;
  startingBid: number; increment: number; tiers?: Tier[]; currency: string;
  status: RegStatus; canBid?: boolean;
  maxBid?: number; onSetMax: (v: number) => void;
  onRegister: () => void;
  size?: "sm" | "md";
};

/** The bidder-facing block under a lot: your position, max bid, and Register / Place Bid. */
export function MemberBid({ lotId, currentBid, startingBid, increment, tiers, currency, status, canBid = true, maxBid, onSetMax, onRegister, size = "sm" }: MemberBidProps) {
  const router = useRouter();
  const [note, setNote] = useState("");
  const [current, setCurrent] = useState(currentBid);
  useLotEvents((e) => { if (e.bidCount > 0) setCurrent(e.currentBid); }, [lotId], canBid); // someone else bid
  const nextMin = current === undefined ? startingBid : current + incrementAt(increment, tiers, current);

  type BidReply = { extended?: boolean; state?: "LEADING" | "OUTBID" | "SCHEDULED"; currentBid?: number };
  const soft = (r: BidReply) => (r.extended ? ". Soft close: this lot’s closing time was extended." : "");

  async function place(amount: number) {
    try {
      const r = await api<BidReply>("api/bma/bids", { body: { lot: lotId, amount } });
      setCurrent(r.currentBid ?? amount);
      setNote(r.state === "OUTBID"
        ? `Your bid of ${formatMoney(amount, currency)} was placed, but another bidder’s maximum bid is higher. The current bid is ${formatMoney(r.currentBid ?? amount, currency)}.`
        : `You are the highest bidder at ${formatMoney(amount, currency)}${soft(r)}`);
      if (r.extended || r.state === "OUTBID") router.refresh(); // pick up the new closing time / price
    } catch (x) {
      setNote((x as Error).message);
    }
  }
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const h = size === "sm" ? "h-8" : "h-9";

  function setMaxClick() {
    if (status === "NONE") return onRegister();
    if (status === "APPROVED") { setDraft(String(maxBid ?? nextMin)); setEditing(true); }
  }
  async function saveMax(e: FormEvent) {
    e.preventDefault();
    const v = Number(draft);
    if (!(v > 0)) return;
    try {
      const r = await api<BidReply & { maxBid: number }>("api/bma/max-bids", { method: "PUT", body: { lot: lotId, amount: v } });
      onSetMax(r.maxBid);
      setEditing(false);
      if (r.currentBid !== undefined && (r.currentBid > 0)) setCurrent(r.currentBid);
      setNote(r.state === "SCHEDULED"
        ? `Absentee bid saved: up to ${formatMoney(r.maxBid, currency)}. It becomes active when bidding opens.`
        : r.state === "LEADING"
          ? `You are the highest bidder at ${formatMoney(r.currentBid ?? v, currency)}, with a maximum of ${formatMoney(r.maxBid, currency)}${soft(r)}`
          : `Maximum saved, but another bidder’s maximum is higher. The current bid is ${formatMoney(r.currentBid ?? v, currency)}.`);
      if (r.extended || r.state === "OUTBID") router.refresh();
    } catch (x) {
      setNote((x as Error).message);
    }
  }

  return (
    <div className="space-y-2.5">
      <p className="flex items-center gap-2 rounded-md border border-zinc-200 bg-zinc-50 px-3 py-2 text-[11px] text-zinc-500">
        <CircleDot className="size-3 shrink-0" />{note || "No Bids Placed by You"}
      </p>

      <div className="flex items-end justify-between">
        <div>
          <p className="text-[9px] font-semibold uppercase tracking-wider text-zinc-400">{current === undefined ? "Starting bid" : "Current bid"}</p>
          <p className="text-lg font-bold">{formatMoney(current ?? startingBid, currency)}</p>
        </div>
        <div className="text-right">
          <p className="text-[9px] font-semibold uppercase tracking-wider text-zinc-400">My max bid</p>
          {maxBid && <p className="text-xs font-bold">{formatMoney(maxBid, currency)}</p>}
          <button type="button" onClick={setMaxClick} disabled={status === "PENDING"} className="text-[11px] font-medium text-primary underline disabled:text-zinc-300 disabled:no-underline">
            {maxBid ? "Edit Max Bid" : "+ Set Max Bid"}
          </button>
        </div>
      </div>

      {editing && (
        <form onSubmit={saveMax} className="flex gap-2">
          <input type="number" min={nextMin} step="any" value={draft} onChange={(e) => setDraft(e.target.value)} aria-label="Max bid" className="h-8 min-w-0 flex-1 rounded-md border border-zinc-300 px-2 text-xs" />
          <button className="rounded-md bg-primary px-3 text-xs font-semibold text-white">Save</button>
          <button type="button" onClick={() => setEditing(false)} className="rounded-md border border-zinc-300 px-3 text-xs">Cancel</button>
        </form>
      )}

      {status === "NONE" && (
        <button type="button" data-btn="outline" onClick={onRegister} className={`${h} w-full rounded-md border border-primary/50 bg-white text-xs font-semibold text-primary hover:bg-primary/5`}>Register to Bid</button>
      )}
      {status === "PENDING" && (
        <>
          <button type="button" disabled className={`${h} w-full cursor-not-allowed rounded-md bg-zinc-100 text-xs font-semibold text-zinc-500`}>Registration pending approval</button>
        </>
      )}
      {status === "APPROVED" && (canBid
        ? <BidStepper key={nextMin} startingBid={nextMin} increment={increment} tiers={tiers} currency={currency} next="" size={size} onPlace={place} />
        : <p className="rounded-md bg-zinc-100 py-2 text-center text-xs font-medium text-zinc-500">Approved · bidding opens when the auction starts</p>)}
    </div>
  );
}
