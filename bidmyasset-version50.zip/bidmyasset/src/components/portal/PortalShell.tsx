"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Bell, CalendarDays, ChevronDown, CircleDollarSign, Clock, FileText, Gavel, Heart,
  Home, LogOut, Menu, RefreshCw, Settings, X, type LucideIcon,
} from "lucide-react";
import { Footer } from "@/components/Footer";
import { useConfirm } from "@/components/admin/ui";
import { Logo } from "@/components/Logo";
import { NAV } from "@/lib/portalNav";
import { useRefresh } from "@/lib/useRefresh";
import type { Notice } from "@/lib/portal";
import { T } from "@/components/T";
import { useT } from "@/lib/useT";

const ICONS: Record<string, LucideIcon> = {
  home: Home, clock: Clock, heart: Heart, gavel: Gavel, file: FileText, dollar: CircleDollarSign, calendar: CalendarDays,
};

const initials = (n: string) => n.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

function useOutside(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && close();
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open, close]);
  return ref;
}

function Sidebar({ expanded, unread, onNavigate }: { expanded: boolean; unread: number; onNavigate?: () => void }) {
  const path = usePathname();
  const t = useT();
  const item = (href: string, label: string, I: LucideIcon, badge?: number) => {
    const active = path === href || (href !== "/dashboard" && path.startsWith(href + "/"));
    return (
      <Link key={href} href={href} title={t(label)} onClick={onNavigate}
        className={`relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-white/90 transition ${active ? "bg-primary text-white" : "hover:bg-white/10"} ${expanded ? "" : "justify-center"}`}>
        <I className="size-[18px] shrink-0" />
        {expanded && <span className="whitespace-nowrap">{t(label)}</span>}
        {badge !== undefined && (expanded
          ? <span className="ml-auto rounded-full bg-white px-1.5 text-[11px] font-bold text-brand">{badge}</span>
          : <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-sky-400 text-[9px] font-bold text-white">{badge}</span>)}
      </Link>
    );
  };
  return (
    <nav className="flex h-full flex-col bg-[#032250] p-2.5">
      <div className="space-y-1">
        {NAV.map((n) => (
          <div key={n.href}>
            {"divider" in n && n.divider && <div className="my-1 border-t border-white/15" />}
            {item(n.href, n.label, ICONS[n.icon])}
            {"divider" in n && n.divider && <div className="my-1 border-t border-white/15" />}
          </div>
        ))}
      </div>
      <div className="mt-auto space-y-1">
        {item("/notifications", "Notifications", Bell, unread)}
        {item("/settings", "Settings", Settings)}
      </div>
    </nav>
  );
}

export function PortalShell({ children, notices: initial, user: account, isAdmin = false }: { children: ReactNode; notices: Notice[]; user: { name: string; email: string }; isAdmin?: boolean }) {
  const router = useRouter();
  const { confirm, dialog } = useConfirm();
  const path = usePathname();
  const t = useT();
  const flush = path.startsWith("/timed"); // hero banners run edge to edge + footer bar
  const bare = path.startsWith("/auction-calendar") || path.startsWith("/favourites"); // own full-width header band, no footer
  const [drawer, setDrawer] = useState(false);
  const [rail, setRail] = useState(false);
  const [bell, setBell] = useState(false);
  const [menu, setMenu] = useState(false);
  const [notices, setNotices] = useState(initial);
  useEffect(() => { setNotices(initial); }, [initial]); // pick up fresh server data after Refresh
  const { refresh, busy } = useRefresh();
  const unread = notices.filter((n) => !n.read).length;
  const bellRef = useOutside(bell, () => setBell(false));
  const menuRef = useOutside(menu, () => setMenu(false));
  const markAll = () => {
    setNotices((l) => l.map((n) => ({ ...n, read: true })));
    notices.filter((n) => !n.read).forEach((n) => fetch(`/api/pb/api/collections/notifications/records/${n.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ read: true }) }).catch(() => {}));
  };
  const logout = async () => { setMenu(false); if (!(await confirm({ title: "Sign out?", body: "You will need to sign in again to place bids or view your account.", confirmLabel: "Sign out" }))) return; await fetch("/api/logout", { method: "POST" }); router.push("/login"); router.refresh(); };

  const links: [string, string][] = [
    ["/profile", "My Profile"], ["/favourites", "My Favourite Lots"], ["/my-bids", "My Bids"],
    ["/my-registrations", "My Registrations"], ["/dashboard", "My Dashboard"], ["/auction-calendar", "Auction Calendar"],
  ];

  return (
    <div className="flex min-h-screen flex-col bg-zinc-100">
      {/* top bar */}
      <header className="fixed inset-x-0 top-0 z-40 flex h-14 lg:left-16 items-center justify-between border-b border-zinc-200 bg-white px-3 sm:px-5">
        <div className="flex items-center gap-3 sm:gap-5 lg:pl-3">
          <button aria-label={t("Open menu")} onClick={() => setDrawer(true)} className="rounded p-1.5 hover:bg-zinc-100 lg:hidden"><Menu className="size-5" /></button>
          <Logo className="h-6" />
          <nav className="hidden items-center gap-4 text-xs font-semibold text-zinc-800 sm:flex">
            <Link href="/about" className="hover:text-primary"><T>About</T></Link>
            <Link href="/leadership" className="hover:text-primary"><T>Leadership</T></Link>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {/* notifications */}
          <div ref={bellRef} className="relative">
            <button aria-label={t("Notifications")} onClick={() => { setBell((v) => !v); setMenu(false); }} className="relative rounded-full p-2 hover:bg-zinc-100">
              <Bell className="size-[18px]" />
              {unread > 0 && <span className="absolute right-1 top-1 size-2 rounded-full bg-rose-500" />}
            </button>
            {bell && (
              <div className="absolute right-0 mt-2 w-80 max-w-[calc(100vw-1.5rem)] overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-lg">
                <div className="flex items-center justify-between border-b border-zinc-100 px-4 py-3">
                  <div>
                    <p className="text-sm font-bold"><T>Notifications</T></p>
                    <p className="text-[11px] text-zinc-500">{unread ? `${unread} unread` : "All caught up"}</p>
                  </div>
                  <div className="flex items-center gap-3 text-zinc-500">
                    <button aria-label={t("Refresh")} disabled={busy} onClick={refresh}><RefreshCw className={`size-3.5 ${busy ? "animate-spin" : ""}`} /></button>
                    <button onClick={markAll} disabled={!unread} className="text-xs disabled:text-zinc-400"><T>Mark all read</T></button>
                  </div>
                </div>
                {notices.length === 0 ? (
                  <p className="px-4 py-8 text-center text-sm text-zinc-500"><T>No notifications yet.</T></p>
                ) : (
                  <ul className="max-h-72 divide-y divide-zinc-100 overflow-y-auto">
                    {notices.map((n) => (
                      <li key={n.id} className={`px-4 py-3 text-xs ${n.read ? "" : "bg-blue-50/50"}`}>
                        <p className="font-semibold">{n.title}</p>
                        <p className="mt-0.5 text-zinc-500">{n.body}</p>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="flex gap-2 border-t border-zinc-100 p-3">
                  <button onClick={markAll} className="flex-1 rounded-md border border-primary/30 py-2 text-xs font-semibold text-primary/70 hover:bg-primary/5"><T>Mark all read</T></button>
                  <Link href="/notifications" onClick={() => setBell(false)} className="flex-1 rounded-md bg-primary py-2 text-center text-xs font-semibold text-white hover:bg-primary-700"><T>View all</T></Link>
                </div>
              </div>
            )}
          </div>

          {/* user menu */}
          <div ref={menuRef} className="relative">
            <button onClick={() => { setMenu((v) => !v); setBell(false); }} className="flex items-center gap-2 rounded-full border border-zinc-200 py-1 pl-1 pr-2.5 hover:bg-zinc-50">
              <span className="grid size-8 place-items-center rounded-full bg-zinc-100 text-xs font-semibold">{initials(account.name)}</span>
              <span className="hidden text-left leading-tight sm:block">
                <span className="block text-xs font-semibold">{account.name}</span>
                <span className="block text-[11px] text-zinc-500">{account.email}</span>
              </span>
              <ChevronDown className="size-4 text-zinc-500" />
            </button>
            {menu && (
              <div className="absolute right-0 mt-2 w-60 overflow-hidden rounded-xl border border-zinc-200 bg-white text-sm shadow-lg">
                <div className="border-b border-zinc-100 px-4 py-3">
                  <p className="text-xs font-bold"><T>Signed in</T></p>
                  <p className="mt-1 text-xs font-medium">{account.name}</p>
                  <p className="text-[11px] text-zinc-500">{account.email}</p>
                </div>
                <ul className="py-1">
                  {(isAdmin ? [...links, ["/admin/dashboard", "Admin Console"] as [string, string]] : links).map(([h, l]) => (
                    <li key={h}><Link href={h} onClick={() => setMenu(false)} className="block px-4 py-2 text-[13px] hover:bg-zinc-50">{l}</Link></li>
                  ))}
                </ul>
                <div className="border-t border-zinc-100 py-1">
                  <button onClick={logout} className="flex w-full items-center gap-2 px-4 py-2 text-[13px] font-medium text-rose-600 hover:bg-rose-50"><LogOut className="size-4" /><T>Logout</T></button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* desktop rail: full height, expands over the content on hover / tap / keyboard focus */}
      <aside
        onMouseEnter={() => setRail(true)}
        onMouseLeave={() => setRail(false)}
        onFocus={() => setRail(true)}
        onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setRail(false); }}
        className={`fixed inset-y-0 left-0 z-50 hidden overflow-hidden bg-[#032250] pt-14 transition-[width,box-shadow] duration-200 lg:block ${rail ? "w-60 shadow-2xl" : "w-16"}`}
      >
        <Sidebar expanded={rail} unread={unread} onNavigate={() => setRail(false)} />
      </aside>

      {/* mobile drawer */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawer(false)} />
          <div className="absolute inset-y-0 left-0 w-60">
            <button aria-label={t("Close menu")} onClick={() => setDrawer(false)} className="absolute right-2 top-3 z-10 rounded p-1 text-white/80"><X className="size-5" /></button>
            <div className="h-full pt-12 bg-[#032250]"><Sidebar expanded unread={unread} onNavigate={() => setDrawer(false)} /></div>
          </div>
        </div>
      )}

      {bare ? (
        <main className="flex-1 pt-14 lg:pl-16">{children}</main>
      ) : flush ? (
        <>
          <main className="flex-1 pt-14 lg:pl-16">{children}</main>
          <div className="sticky bottom-0 z-30 lg:pl-16"><Footer /></div>
        </>
      ) : (
        <main className="flex-1 px-4 pb-10 pt-20 sm:px-6 lg:pl-28 lg:pr-8">
          <div className="mx-auto max-w-[1240px]">{children}</div>
        </main>
      )}
      {dialog}
    </div>
  );
}
