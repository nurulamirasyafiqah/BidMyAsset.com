"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Download, Trash2, X } from "lucide-react";
import { api } from "@/lib/client-api";
import type { PortalData, UserProfile } from "@/lib/portal";

const outlineBtn = "inline-flex items-center gap-2 rounded-md border border-primary/50 bg-white px-4 py-1.5 text-xs font-semibold text-primary hover:bg-primary/5";
const input = "mt-1 h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

// The export is built in the browser from the signed-in user's own data. TODO (server): POST /api/me/export (async job, emailed link),
// POST /api/me/delete-request (re-verify password, create a request for Super Admin — blueprint: NO HARD DELETE of
// transactional records; bids / invoices are retained or anonymised per legal + data-retention rules).

export function DataPrivacy({ user, data }: { user: UserProfile; data: PortalData }) {
  const [open, setOpen] = useState(false);
  const [requested, setRequested] = useState(false);

  async function exportData() {
    const payload = await api("api/bma/me/export").catch(() => ({ exportedAt: new Date().toISOString(), profile: user, ...data }));
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "bidmyasset-my-data.json" });
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  const unpaid = data.invoices.filter((i) => i.status === "UNPAID").length;
  const leading = data.bids.filter((b) => b.state === "LEADING").length;
  const blockers = [unpaid && `${unpaid} unpaid invoice${unpaid > 1 ? "s" : ""}`, leading && `${leading} bid${leading > 1 ? "s" : ""} currently leading`].filter(Boolean) as string[];

  return (
    <section className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      <h2 className="text-base font-bold">Data &amp; privacy</h2>
      <p className="mt-0.5 text-sm text-zinc-500">Download a copy of your data or ask us to close your account.</p>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-100 pt-5">
        <div className="max-w-xl">
          <p className="text-sm font-medium">Export my data</p>
          <p className="text-xs text-zinc-500">Profile, bids, favourites, registrations, invoices and notifications as a JSON file.</p>
        </div>
        <button type="button" onClick={exportData} data-btn="outline" className={outlineBtn}><Download className="size-3.5" />Download</button>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-100 pt-5">
        <div className="max-w-xl">
          <p className="text-sm font-medium text-rose-600">Delete my account</p>
          <p className="text-xs text-zinc-500">
            Your profile is removed and your sign-in disabled. Bid and invoice records are kept in anonymised form where the law requires.
          </p>
          {requested && <p role="status" className="mt-2 rounded bg-amber-50 p-2 text-xs text-amber-700">Deletion requested — our team will confirm by email (request recorded).</p>}
        </div>
        <button type="button" disabled={requested} onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-md border border-rose-300 bg-white px-4 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 disabled:opacity-50">
          <Trash2 className="size-3.5" />Delete account
        </button>
      </div>

      {open && <DeleteModal blockers={blockers} onClose={() => setOpen(false)} onDone={() => { setOpen(false); setRequested(true); }} />}
    </section>
  );
}

function DeleteModal({ blockers, onClose, onDone }: { blockers: string[]; onClose: () => void; onDone: () => void }) {
  const [pw, setPw] = useState("");
  const [word, setWord] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [onClose]);

  const blocked = blockers.length > 0;
  const ok = !blocked && pw !== "" && word === "DELETE";
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!ok) return;
    try { await api("api/bma/me/delete-request", { body: { password: pw } }); onDone(); } catch (x) { setErr((x as Error).message); }
  }

  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form role="dialog" aria-modal="true" aria-labelledby="del-title" data-dialog onSubmit={submit} className="relative w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-2xl">
        <button type="button" aria-label="Close" onClick={onClose} className="absolute right-4 top-4 text-zinc-400 hover:text-zinc-700"><X className="size-5" /></button>
        <h2 id="del-title" data-dialog-title className="text-lg font-bold">Delete your account?</h2>
        {blocked ? (
          <p role="alert" className="rounded bg-rose-50 p-3 text-xs text-rose-600">
            You can’t delete your account yet — you still have {blockers.join(" and ")}. Settle these first, then try again.
          </p>
        ) : (
          <>
            <p className="text-sm text-zinc-600">This can’t be undone. Download your data first if you need a copy.</p>
            <label className="block text-sm font-medium">Password
              <input type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} className={input} />
            </label>
            <label className="block text-sm font-medium">Type <b>DELETE</b> to confirm
              <input value={word} onChange={(e) => setWord(e.target.value)} className={input} autoComplete="off" />
            </label>
          </>
        )}
        {err && <p role="alert" className="rounded bg-rose-50 p-2 text-xs text-rose-600">{err}</p>}
        <div data-dialog-footer className="flex justify-end gap-3">
          <button type="button" onClick={onClose} data-btn="outline" className={outlineBtn}>Cancel</button>
          {!blocked && <button disabled={!ok} className="rounded-md bg-rose-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-rose-700 disabled:opacity-50">Delete account</button>}
        </div>
      </form>
    </div>
  );
}
