"use client";

import { useEffect, useState } from "react";
import { useRefresh } from "@/lib/useRefresh";
import Link from "next/link";
import { Bell, Check, RefreshCw, Settings } from "lucide-react";
import { useDisplayTimezone } from "@/lib/preferences";
import type { Notice } from "@/lib/portal";

export function NotificationsView({ initial }: { initial: Notice[] }) {
  const { refresh, busy } = useRefresh();
  const [items, setItems] = useState(initial);
  // pick up fresh server data after Refresh (useState(initial) alone would ignore it)
  useEffect(() => { setItems(initial); }, [initial]);
  const markAll = () => {
    items.filter((n) => !n.read).forEach((n) => fetch(`/api/pb/api/collections/notifications/records/${n.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ read: true }) }).catch(() => {}));
    setItems((l) => l.map((n) => ({ ...n, read: true })));
  };
  const tz = useDisplayTimezone("portal");
  const when = (iso: string) => new Date(iso).toLocaleString("en-US", { timeZone: tz, month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  const unread = items.filter((n) => !n.read).length;

  return (
    <section className="mx-auto mt-2 max-w-[820px] overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
      <header className="flex items-start justify-between gap-4 border-b border-zinc-200 p-5">
        <div className="flex gap-3">
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-primary"><Bell className="size-5" /></span>
          <div>
            <h1 className="text-xl font-bold">Notifications</h1>
            <p className="text-xs text-zinc-500">Stay on top of your bidding activity and updates.</p>
            <p className="mt-1 flex items-center gap-1.5 text-xs font-medium text-sky">
              {unread ? <>{unread} unread · <button onClick={markAll} className="underline">Mark all read</button></> : <><Check className="size-3.5" />All caught up</>}
            </p>
          </div>
        </div>
        <Link href="/settings" className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-xs font-semibold text-zinc-600 hover:bg-zinc-100"><Settings className="size-3.5" />Settings</Link>
        <button onClick={refresh} disabled={busy} className="inline-flex items-center gap-2 rounded-md border border-primary/40 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/5 disabled:opacity-60">
          <RefreshCw className={`size-3.5 ${busy ? "animate-spin" : ""}`} />Refresh
        </button>
      </header>

      {items.length === 0 ? (
        <div className="flex flex-col items-center px-6 py-16 text-center">
          <span className="grid size-14 place-items-center rounded-full bg-zinc-100"><Bell className="size-6 text-zinc-400" /></span>
          <p className="mt-4 text-base font-bold">No notifications yet</p>
          <p className="mt-1 text-xs text-zinc-500">You’ll see updates about your auction registrations, bids, and activity here.</p>
        </div>
      ) : (
        <ul className="divide-y divide-zinc-100">
          {items.map((n) => (
            <li key={n.id} className={`px-5 py-4 text-sm ${n.read ? "" : "bg-blue-50/50"}`}>
              <p className="font-semibold">{n.title}{!n.read && <span className="ml-2 inline-block size-2 rounded-full bg-primary" />}</p>
              <p className="mt-0.5 text-xs text-zinc-500">{n.body}</p>
              <p className="mt-1 text-[11px] text-zinc-400">{when(n.at)}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
