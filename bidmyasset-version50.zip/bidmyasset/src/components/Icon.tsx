import {
  ArrowUpRight, Award, Compass, Eye, Gavel, Globe, Leaf, Lock, Package,
  Scale, ShieldCheck, Tag, Truck, Wrench, type LucideIcon,
} from "lucide-react";

const map: Record<string, LucideIcon> = {
  arrow: ArrowUpRight,
  award: Award,
  compass: Compass,
  eye: Eye,
  gavel: Gavel,
  globe: Globe,
  leaf: Leaf,
  lock: Lock,
  package: Package,
  scale: Scale,
  shield: ShieldCheck,
  tag: Tag,
  truck: Truck,
  wrench: Wrench,
};

export function Icon({ name, className }: { name: string; className?: string }) {
  const C = map[name] ?? Package;
  return <C className={className} aria-hidden />;
}
