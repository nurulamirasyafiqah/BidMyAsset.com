"use client";

import { useEffect, useState } from "react";
import { formatRemaining } from "@/lib/format";

/**
 * Display-only countdown. Authority is the SERVER clock (blueprint §15):
 * `serverNow` is stamped by the server at render; we keep the offset between
 * it and the browser clock so a wrong user PC clock never changes the timer.
 */
export function Countdown({ target, serverNow }: { target: string; serverNow: number }) {
  const [now, setNow] = useState(serverNow);

  useEffect(() => {
    const offset = serverNow - Date.now();
    const tick = () => setNow(Date.now() + offset);
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [serverNow]);

  return <span suppressHydrationWarning>{formatRemaining(new Date(target).getTime() - now)}</span>;
}
