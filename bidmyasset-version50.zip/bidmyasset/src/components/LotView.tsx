import Link from "next/link";
import { notFound } from "next/navigation";
import { ImageOff, Star } from "lucide-react";
import { Gallery } from "@/components/Gallery";
import { BidStepper } from "@/components/BidStepper";
import { getBrand } from "@/lib/brand";
import { Countdown } from "@/components/Countdown";
import { PageHero } from "@/components/PageHero";
import { ShareMenu } from "@/components/ShareMenu";
import { UseMyLocation } from "@/components/UseMyLocation";
import { LotBidPanel } from "@/components/portal/LotBidPanel";
import { LiveRefresh } from "@/lib/liveLots";
import { BidActivity } from "@/components/BidActivity";
import { T } from "@/components/T";
import { getAuction, getLot, getLots } from "@/lib/api-data";
import { getStatus } from "@/lib/data";
import { formatDateTime, formatMoney } from "@/lib/format";

function Detail({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <dt className="text-[9px] font-semibold uppercase tracking-wider text-primary/70"><T>{label}</T></dt>
      <dd className="mt-0.5 text-xs text-zinc-700">{value}</dd>
    </div>
  );
}

/** Lot detail. `member` = logged-in bidder view under /timed (Register to Bid, max bid). */
export async function LotView({ slug, lot, member = false }: { slug: string; lot: string; member?: boolean }) {
  const base = member ? "/timed" : "/auctions";
  const a = await getAuction(slug);
  const l = a ? await getLot(slug, Number(lot)) : undefined;
  if (!a || !l) notFound();
  const brand = await getBrand(); // Auction House → Theming & Config → "Allow questions & rating"

  const serverNow = Date.now();
  const status = getStatus(a, serverNow);
  const isLive = status === "LIVE";
  const here = `${base}/${a.slug}/lot/${l.lotNumber}`;
  const overview = l.description ?? "Details will be available soon.";
  const total = (await getLots(slug)).length;

  return (
    <>
      <PageHero
        compact
        crumbs={[{ label: "Home", href: member ? "/dashboard" : "/" }, { label: "Timed", href: base }, { label: a.title, href: `${base}/${a.slug}` }, { label: l.title }]}
        title={l.title}
        kicker={`Lot ${l.lotNumber} of ${total}`}
      >
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-500">
            <span className={`rounded px-1.5 py-0.5 font-semibold ${isLive ? "bg-sky-100 text-sky" : "bg-white text-slate-600"}`}>
              {status === "LIVE" ? <T>Live</T> : status === "UPCOMING" ? <T>Upcoming</T> : <T>Closed</T>}
            </span>
            <Link href={`${base}/${a.slug}`} className="text-primary hover:underline">{a.title}</Link>
            <span>· Ends {formatDateTime(a.endsAt, a.timezone)}</span>
            <span>· {l.category} • {l.subcategory}</span>
          </p>
          <ShareMenu title={l.title} />
        </div>
        {l.description && <p className="mt-3 max-w-3xl text-xs leading-relaxed text-slate-500">{l.description}</p>}
      </PageHero>

      <div className="mx-auto grid max-w-5xl gap-5 px-4 py-6 sm:px-6 lg:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <Gallery images={l.images?.length ? l.images : a.images ?? []} alt={l.title} />

          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-bold"><T>Lot overview</T></h2>
            <p className="mt-2 text-xs leading-relaxed text-zinc-600">{overview}</p>
          </section>

          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-bold"><T>Lot details</T></h2>
            <dl className="mt-3 grid gap-x-8 gap-y-3 sm:grid-cols-2">
              <Detail label="Lot sequence" value={`#${l.lotNumber}`} />
              <Detail label="Lot number" value={l.lotNumber} />
              <Detail label="Auction name" value={a.title} />
              <Detail label="Category" value={l.category} />
              <Detail label="Subcategory" value={l.subcategory} />
              <Detail label="SKU" value={l.sku} />
              <Detail label="Quantity" value={l.quantity} />
              <Detail label="Time zone" value={a.timezone} />
              <Detail label="Currency" value={a.currency} />
              <Detail label="Starting bid" value={formatMoney(l.startingBid, a.currency)} />
            </dl>
          </section>

          {status !== "UPCOMING" && <BidActivity lotId={l.id} currency={a.currency} timezone={a.timezone} live={isLive} />}

          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-bold"><T>Location</T></h2>
            <p className="mt-1 text-[11px] text-primary"><T>Exact pickup details will be shared with registered bidders.</T></p>
            {a.coords && Math.abs(a.coords.lat) <= 90 && Math.abs(a.coords.lng) <= 180
              ? /* wide view, no pin: the exact spot stays hidden from the public */
                <iframe title={`Map of the ${a.city} area`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="mt-3 h-40 w-full rounded-md border border-zinc-200"
                  src={`https://www.openstreetmap.org/export/embed.html?bbox=${a.coords.lng - 0.12},${a.coords.lat - 0.08},${a.coords.lng + 0.12},${a.coords.lat + 0.08}&layer=mapnik`} />
              : <div className="mt-3 flex h-40 items-center justify-center rounded-md bg-zinc-200 text-zinc-400"><ImageOff className="size-6" /></div>}
            <p className="mt-2 text-xs font-medium text-zinc-700">{a.city}, {a.region}</p>
            <UseMyLocation target={a.coords} />
            {a.coords && (
              <a className="mt-2 inline-block text-[11px] text-primary hover:underline" target="_blank" rel="noopener noreferrer"
                href={`https://www.google.com/maps/search/?api=1&query=${a.coords.lat},${a.coords.lng}`}>
                <T>Open in Google Maps</T>
              </a>
            )}
          </section>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <section className="overflow-hidden rounded-xl border border-primary/20 bg-white shadow-lg shadow-primary/10">
            <div className="bg-indigo-50 px-4 py-2 text-[9px] font-semibold uppercase tracking-wider text-primary/70">
              {isLive ? <T>Ending in</T> : status === "UPCOMING" ? <T>Starting in</T> : <T>Closed</T>}{" "}
              {status !== "CLOSED" && (
                <span className="ml-1 text-[11px] font-bold normal-case tracking-normal text-primary">
                  <Countdown target={isLive ? a.endsAt : a.startsAt} serverNow={serverNow} />
                </span>
              )}
              <span className="ml-2 normal-case tracking-normal">{formatDateTime(a.endsAt, a.timezone)}</span>
            </div>
            <div className="p-4">
              <h2 className="text-sm font-bold"><T>Bidding summary</T></h2>
              <p className="mt-0.5 text-[10px] text-zinc-400"><T>Get approved to start bidding on this lot.</T></p>
              {member ? (
                <LotBidPanel lotId={l.id} currentBid={l.currentBid} slug={a.slug} auctionTitle={a.title} startingBid={l.startingBid} increment={l.increment} tiers={l.incrementMatrix} currency={a.currency} status={status} />
              ) : (
                <>
              <div className="mt-3 flex items-end justify-between">
                <div>
                  <p className="text-[9px] font-semibold uppercase tracking-wider text-zinc-400">Starting bid</p>
                  <p className="text-xl font-extrabold">{formatMoney(l.startingBid, a.currency)}</p>
                </div>
                <Link href={`/login?next=${encodeURIComponent(here)}`} className="text-[10px] text-primary underline"><T>+ Set Max Bid</T></Link>
              </div>
              <div className="mt-3">
                {isLive ? (
                  <BidStepper startingBid={l.startingBid} increment={l.increment} tiers={l.incrementMatrix} currency={a.currency} next={here} />
                ) : (
                  <p className="rounded-md bg-zinc-100 py-2 text-center text-xs font-medium text-zinc-500">
                    {status === "UPCOMING" ? <T>Bidding opens when the auction starts</T> : <T>Bidding is closed</T>}
                  </p>
                )}
              </div>
                </>
              )}
            </div>
          </section>

          {brand.ratings && <section className="rounded-xl border border-zinc-200 bg-white p-4">
            <h2 className="text-sm font-bold">Lot ratings</h2>
            <p className="mt-0.5 text-[10px] text-zinc-400">See what other bidders think about this lot.</p>
            <Link href={member ? "#" : `/login?next=${encodeURIComponent(here)}`} className="mt-2 inline-block rounded border border-primary/40 px-2.5 py-1 text-[10px] font-medium text-primary">Rate this lot</Link>
            <p className="mt-2 flex items-center gap-1 text-[10px] text-zinc-500">
              {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-3 fill-amber-300 text-amber-300" />)}
              <b>0.0</b> / 5 • 0 ratings
            </p>
            <p className="mt-1 text-[10px] text-zinc-400">No bidder ratings yet. Be the first to share your feedback.</p>
          </section>}

          <section className="rounded-xl border border-zinc-200 bg-white p-4 text-[11px] text-zinc-600">
            <h2 className="text-sm font-bold text-ink"><T>Need help?</T></h2>
            <p className="mt-1 text-[10px] text-zinc-400">Questions about this lot or bidding requirements? Contact our support team and we’ll be happy to assist.</p>
            <p className="mt-2">Email: <a className="text-primary" href="mailto:marketing@bidmyasset.com">marketing@bidmyasset.com</a></p>
            <p>Phone: <a className="text-primary" href="tel:6045024643">6045024643</a></p>
          </section>
        </aside>
      </div>
    </>
  );
}
