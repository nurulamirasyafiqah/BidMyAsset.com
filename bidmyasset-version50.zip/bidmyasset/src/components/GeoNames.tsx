"use client";

import { useEffect, useState } from "react";
import { getCountries, getStates, type Option } from "@/lib/geo";

/** Resolves stored codes (country "MY", state "07") to display names ("Malaysia", "Selangor"). Empty until loaded / if unknown. */
export function useGeoNames(country: string, state: string) {
  const [names, setNames] = useState({ country: "", state: "" });
  useEffect(() => {
    let live = true;
    (async () => {
      const c = country ? ((await getCountries()).find((x) => x.value === country)?.label ?? "") : "";
      const s = country && state ? ((await getStates(country)).find((x) => x.value === state)?.label ?? "") : "";
      if (live) setNames({ country: c, state: s });
    })().catch(() => {});
    return () => { live = false; };
  }, [country, state]);
  return names;
}

/** Country dropdown; stores the ISO code, shows the full name. */
export function CountrySelect({ value, onChange, className, label }: { value: string; onChange: (iso: string) => void; className?: string; label: string }) {
  const [list, setList] = useState<Option[]>([]);
  useEffect(() => { getCountries().then(setList).catch(() => {}); }, []);
  return (
    <select aria-label={label} value={value} onChange={(e) => onChange(e.target.value)} className={className}>
      <option value="">Select country</option>
      {list.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
    </select>
  );
}

/** State/province dropdown for the chosen country; falls back to a text box when the country has no states in the dataset. */
export function StateSelect({ country, value, onChange, className, label }: { country: string; value: string; onChange: (v: string) => void; className?: string; label: string }) {
  const [list, setList] = useState<Option[] | null>(null);
  useEffect(() => {
    let live = true;
    setList(null);
    if (!country) { setList([]); return; }
    getStates(country).then((s) => live && setList(s)).catch(() => live && setList([]));
    return () => { live = false; };
  }, [country]);
  if (list !== null && list.length === 0) return <input aria-label={label} value={value} onChange={(e) => onChange(e.target.value)} className={className} />;
  return (
    <select aria-label={label} value={value} disabled={list === null} onChange={(e) => onChange(e.target.value)} className={className}>
      <option value="">{list === null ? "Loading…" : "Select state / province"}</option>
      {(list ?? []).map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
    </select>
  );
}

/** ISO country → dial code ("MY" → "+60"), loaded lazily. */
export function useDials() {
  const [dials, setDials] = useState<Record<string, string>>({});
  useEffect(() => { getCountries().then((c) => setDials(Object.fromEntries(c.map((x) => [x.value, x.dial])))).catch(() => {}); }, []);
  return dials;
}
