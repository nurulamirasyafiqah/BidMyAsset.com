"use client";

import { useState } from "react";
import { haversineKm } from "@/lib/format";

/** Blueprint §23: "Approximately N km from your location" / "Distance unavailable". */
export function UseMyLocation({ target }: { target?: { lat: number; lng: number } }) {
  const [text, setText] = useState("Distance unavailable");
  const [busy, setBusy] = useState(false);

  if (!target) return null;

  function locate() {
    if (!navigator.geolocation) return;
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const km = haversineKm({ lat: p.coords.latitude, lng: p.coords.longitude }, target!);
        setText(`Approximately ${Math.round(km).toLocaleString("en-US")} km from your location`);
        setBusy(false);
      },
      () => {
        setText("Distance unavailable");
        setBusy(false);
      },
    );
  }

  return (
    <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-zinc-500">
      <span>{text}</span>
      <button type="button" onClick={locate} disabled={busy} className="font-medium text-primary underline disabled:opacity-50">
        {busy ? "Locating…" : "Use My Location"}
      </button>
    </p>
  );
}
