"use client";
import { createContext, useContext, type ReactNode } from "react";
import { DEFAULT_BRAND, type Brand } from "@/lib/brandShared";

const Ctx = createContext<Brand>(DEFAULT_BRAND);
export const BrandProvider = ({ brand, children }: { brand: Brand; children: ReactNode }) => <Ctx.Provider value={brand}>{children}</Ctx.Provider>;
export const useBrand = () => useContext(Ctx);
