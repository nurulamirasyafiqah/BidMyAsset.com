import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { LegalLink } from "@/components/LegalPopup";
import type { ReactNode } from "react";
import { Logo } from "./Logo";

function DotArrow() {
  // diamond dots forming an upward arrow, fading toward the top
  const rows = 12;
  const dots: { x: number; y: number; o: number }[] = [];
  for (let r = 0; r < rows; r++) {
    const count = r + 1;
    for (let c = 0; c < count; c++) {
      dots.push({ x: 90 + (c - (count - 1) / 2) * 12, y: 10 + r * 11, o: 0.15 + (r / rows) * 0.6 });
    }
  }
  return (
    <svg viewBox="0 0 180 150" className="absolute bottom-6 right-6 h-36 w-44" aria-hidden>
      {dots.map((d, i) => (
        <rect key={i} x={d.x - 2} y={d.y - 2} width="4" height="4" transform={`rotate(45 ${d.x} ${d.y})`} fill="#fff" opacity={d.o} />
      ))}
    </svg>
  );
}

export function AuthShell({ children, footerLinks = true }: { children: ReactNode; footerLinks?: boolean }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_minmax(0,0.4fr)]">
      <div className="relative flex flex-col px-6 py-8 sm:px-9">
        <Logo className="h-6" />
        <div className="flex flex-1 items-center justify-center py-10">{children}</div>
        {footerLinks && (
          <div className="flex gap-4 text-[11px] text-zinc-700">
            <LegalLink kind="privacy" className="inline-flex items-center gap-1 underline" />
            <LegalLink kind="terms" className="inline-flex items-center gap-1 underline">Terms &amp; Conditions <ExternalLink className="size-3" /></LegalLink>
          </div>
        )}
      </div>
      <aside className="relative m-6 hidden overflow-hidden rounded-2xl text-white lg:block" style={{ background: "linear-gradient(160deg,#0b3a8f 0%,#1d5fc4 55%,#0f93ff 100%)" }}>
        <div className="absolute inset-0 flex flex-col justify-center px-14">
          <span className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-[9px] font-bold uppercase tracking-[0.18em] text-white/80">
            <span className="size-1.5 rounded-full bg-white/60" /> Trusted industrial auction platform
          </span>
          <h2 className="text-4xl font-extrabold leading-tight">Invest In Your Ideal Asset.</h2>
        </div>
        <DotArrow />
      </aside>
    </div>
  );
}

export function GoBack({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="mt-6 inline-flex items-center gap-2 text-xs text-zinc-800 hover:text-primary">
      ← Go back
    </Link>
  );
}
