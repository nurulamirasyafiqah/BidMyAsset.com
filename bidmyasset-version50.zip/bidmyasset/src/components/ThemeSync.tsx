"use client";

import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";

/** Fired by the admin screens right after they save an Auction House setting, so this tab updates at once. */
export const HOUSE_UPDATED_EVENT = "bma:house-updated";
export const notifyHouseUpdated = () => { try { window.dispatchEvent(new Event(HOUSE_UPDATED_EVENT)); } catch { /* ignore */ } };

const POLL_MS = 30_000;

/**
 * Keeps an open page in step with Auction House → Theming & Config (colours, buttons, dialogs, ratings, categories, logo…).
 * The root layout only renders once per full page load, so without this a tab never sees a change made in the admin.
 * It asks /api/brand/version (cheap) every 30 s, when the tab regains focus, and right after an admin save;
 * if the house record changed it calls router.refresh(), which re-renders the layout with the new theme (no full reload, no lost state).
 */
export function ThemeSync({ version }: { version: string }) {
  const router = useRouter();
  const current = useRef(version);
  useEffect(() => { current.current = version; }, [version]);

  useEffect(() => {
    let stopped = false;
    let busy = false;
    const check = async () => {
      if (busy || document.visibilityState === "hidden") return;
      busy = true;
      try {
        const res = await fetch(`/api/brand/version?v=${encodeURIComponent(current.current)}`, { cache: "no-store" });
        const j = (await res.json()) as { version?: string | null };
        if (!stopped && j.version && j.version !== current.current) router.refresh();
      } catch { /* offline or backend down: try again next time */ } finally { busy = false; }
    };
    const id = window.setInterval(check, POLL_MS);
    const onVisible = () => { if (document.visibilityState === "visible") void check(); };
    window.addEventListener("focus", onVisible);
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener(HOUSE_UPDATED_EVENT, check);
    return () => {
      stopped = true;
      window.clearInterval(id);
      window.removeEventListener("focus", onVisible);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener(HOUSE_UPDATED_EVENT, check);
    };
  }, [router]);

  return null;
}
