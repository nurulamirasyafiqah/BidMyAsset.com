"use client";
import { useEffect, useState } from "react";
import { useBrand } from "@/components/BrandProvider";

/** Home hero: uploaded banner images (cross-fade every 6 s) behind the headline; plain blue hero when none are uploaded. */
export function BannerHero({ children }: { children: React.ReactNode }) {
  const { banners } = useBrand();
  const [i, setI] = useState(0);
  useEffect(() => {
    if (banners.length < 2) return;
    const t = setInterval(() => setI((n) => (n + 1) % banners.length), 6000);
    return () => clearInterval(t);
  }, [banners.length]);
  return (
    <section className="hero-blue relative overflow-hidden">
      {banners.map((b, n) => /* eslint-disable-next-line @next/next/no-img-element */ <img key={b} src={b} alt="" aria-hidden className={`absolute inset-0 size-full object-cover transition-opacity duration-700 ${n === i ? "opacity-100" : "opacity-0"}`} />)}
      {banners.length > 0 && <div className="absolute inset-0 bg-slate-900/45" />}
      <div className="relative">{children}</div>
    </section>
  );
}
