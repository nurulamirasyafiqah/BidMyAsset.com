"use client";
import Image from "next/image";
import Link from "next/link";
import { useBrand } from "@/components/BrandProvider";

export function Logo({ className = "h-6" }: { className?: string }) {
  const b = useBrand();
  return (
    <Link href="/" aria-label={`${b.name} home`} className="inline-flex">
      {b.logo
        ? /* uploaded in Admin → Auction House (PocketBase); may be SVG, so a plain <img> */ <img src={b.logo} alt={b.name} className={`${className} w-auto`} />
        : <Image src="/logo.png" alt={b.name} width={738} height={180} priority className={`${className} w-auto`} />}
    </Link>
  );
}
