"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Heart, LayoutGrid, List, Search, Star } from "lucide-react";
import type { Auction, Lot } from "@/lib/data";
import { formatDateTime, formatMoney } from "@/lib/format";
import { BidStepper } from "./BidStepper";
import { Countdown } from "./Countdown";
import { PlaceholderImage } from "./PlaceholderImage";
import { LiveRefresh } from "@/lib/liveLots";
import { MemberBid, RegisterModal, useMaxBids, useRegistration } from "./portal/registration";
import { useBrand } from "./BrandProvider";
import { api } from "@/lib/client-api";

type Sort = "ending" | "recent" | "low" | "high" | "bids";
const SORTS: { id: Sort; label: string }[] = [
  { id: "ending", label: "Ending Soon" },
  { id: "recent", label: "Recently Added" },
  { id: "low", label: "Lowest Price" },
  { id: "high", label: "Highest Price" },
  { id: "bids", label: "Most Bids" },
];
const PAGE = 12;

type Props = {
  auction: Pick<Auction, "slug" | "currency" | "endsAt" | "timezone" | "tone" | "images">;
  lots: Lot[];
  serverNow: number;
  /** Logged-in bidder view: Register to Bid, Set Max Bid, links under `base`. */
  member?: boolean;
  base?: string;
  auctionTitle?: string;
};

export function LotBrowser({ auction, lots, serverNow, member = false, base = "/auctions", auctionTitle = "" }: Props) {
  const { categories } = useBrand(); // Auction House → Categories (null = not configured: offer every category)
  const [reg, register] = useRegistration(auction.slug);
  const router = useRouter();
  const pathname = usePathname();
  // lot id -> favourites record id, loaded from the backend for signed-in bidders
  const [favs, setFavs] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!member) return;
    let live = true;
    api<{ items: { id: string; lot: string }[] }>(`api/collections/favourites/records?filter=${encodeURIComponent(`lot.auction.slug="${auction.slug}"`)}&perPage=500&fields=id,lot`)
      .then((r) => { if (live) setFavs(Object.fromEntries(r.items.map((f) => [f.lot, f.id]))); })
      .catch(() => {});
    return () => { live = false; };
  }, [member, auction.slug]);
  const toggleFav = useCallback(async (lotId: string) => {
    if (!member) { router.push(`/login?next=${encodeURIComponent(pathname)}`); return; }
    const existing = favs[lotId];
    if (existing === "pending") return; // the add request is still in flight
    if (existing) {
      setFavs((f) => { const n = { ...f }; delete n[lotId]; return n; }); // optimistic
      try { await api(`api/collections/favourites/records/${existing}`, { method: "DELETE" }); }
      catch { setFavs((f) => ({ ...f, [lotId]: existing })); }
    } else {
      setFavs((f) => ({ ...f, [lotId]: "pending" }));
      try { const r = await api<{ id: string }>("api/bma/favourites", { body: { lot: lotId } }); setFavs((f) => ({ ...f, [lotId]: r.id })); }
      catch { setFavs((f) => { const n = { ...f }; delete n[lotId]; return n; }); }
    }
  }, [member, favs, router, pathname]);
  const [modal, setModal] = useState(false);
  const [maxBids, setMax] = useMaxBids(member);
  const [onlyMax, setOnlyMax] = useState(false);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<Sort>("ending");
  const [subs, setSubs] = useState<Set<string>>(new Set());
  const [openOnly, setOpenOnly] = useState(true);
  const [showFilters, setShowFilters] = useState(true);
  const [grid, setGrid] = useState(true);
  const [visible, setVisible] = useState(PAGE);

  const prices = lots.map((l) => l.startingBid);
  const lo = Math.min(...prices);
  const hi = Math.max(...prices) + 1; // matches design: "RM 30,000 – RM 30,001"
  const [min, setMin] = useState(lo);
  const [max, setMax] = useState(hi);

  const groups = useMemo(() => {
    const m = new Map<string, Map<string, number>>();
    for (const l of lots) {
      if (!m.has(l.category)) m.set(l.category, new Map());
      const g = m.get(l.category)!;
      g.set(l.subcategory, (g.get(l.subcategory) ?? 0) + 1);
    }
    // Only the subcategories the auction house enabled. A category the saved selection doesn't mention is shown in full.
    return [...m.entries()].map(([cat, subMap]) => {
      const allowed = categories?.[cat];
      return {
        cat,
        subs: [...subMap.entries()].filter(([s]) => !allowed || allowed.includes(s)).sort((a, b) => a[0].localeCompare(b[0])),
      };
    }).filter((g) => g.subs.length > 0);
  }, [lots, categories]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const f = lots.filter(
      (l) =>
        (!q || `${l.title} ${l.description ?? ""} ${l.sku}`.toLowerCase().includes(q)) &&
        (subs.size === 0 || subs.has(l.subcategory)) &&
        l.startingBid >= min &&
        l.startingBid <= max &&
        (!member || !onlyMax || l.id in maxBids),
    );
    const by: Record<Sort, (a: Lot, b: Lot) => number> = {
      ending: (a, b) => a.lotNumber - b.lotNumber, // same close time → lot order
      recent: (a, b) => b.addedOrder - a.addedOrder,
      low: (a, b) => a.startingBid - b.startingBid,
      high: (a, b) => b.startingBid - a.startingBid,
      bids: (a, b) => b.bidCount - a.bidCount,
    };
    return [...f].sort(by[sort]);
  }, [lots, query, subs, min, max, sort, member, onlyMax, maxBids]);

  const toggle = (s: string) => {
    setSubs((prev) => {
      const n = new Set(prev);
      if (n.has(s)) n.delete(s); else n.add(s);
      return n;
    });
    setVisible(PAGE);
  };

  const shown = results.slice(0, visible);

  return (
    <>
    <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6 lg:flex-row">
      {showFilters && (
        <aside className="w-full shrink-0 space-y-5 text-xs lg:w-52">
          <div>
            <label htmlFor="lot-search" className="mb-1.5 block font-semibold">Search</label>
            <div className="flex items-center gap-2 rounded-md border border-zinc-200 bg-white px-2.5 py-2">
              <Search className="size-3.5 text-zinc-400" />
              <input
                id="lot-search"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setVisible(PAGE); }}
                placeholder="Search lots by Name & Descript"
                className="w-full bg-transparent text-xs outline-none placeholder:text-zinc-400"
              />
            </div>
          </div>

          <fieldset className="border-t border-zinc-200 pt-4">
            <legend className="mb-2 font-semibold">Sort By</legend>
            <div className="space-y-1.5">
              {SORTS.map((s) => (
                <label key={s.id} className="flex cursor-pointer items-center gap-2 text-zinc-600">
                  <input type="radio" name="sort" checked={sort === s.id} onChange={() => setSort(s.id)} className="accent-primary" />
                  {s.label}
                </label>
              ))}
            </div>
          </fieldset>

          <div className="border-t border-zinc-200 pt-4">
            <p className="mb-2 font-semibold">Category</p>
            {groups.map((g) => (
              <div key={g.cat} className="mb-3">
                <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-zinc-400">{g.cat}</p>
                <div className="space-y-1.5">
                  {g.subs.map(([s, n]) => (
                    <label key={s} className="flex cursor-pointer items-center justify-between text-zinc-600">
                      <span className="flex items-center gap-2">
                        <input type="checkbox" checked={subs.has(s)} onChange={() => toggle(s)} className="accent-primary" />
                        {s}
                      </span>
                      <span className="rounded-full bg-sky-100 px-1.5 text-[10px] font-semibold text-sky-700">{n}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-zinc-200 pt-4">
            <p className="mb-2 font-medium">
              Price Range ({formatMoney(min, auction.currency)} - {formatMoney(max, auction.currency)})
            </p>
            <div className="dual-range">
              <div className="absolute inset-x-0 top-1/2 h-1 -translate-y-1/2 rounded bg-primary" />
              <input type="range" aria-label="Minimum price" min={lo} max={hi} value={min} onChange={(e) => setMin(Math.min(Number(e.target.value), max))} />
              <input type="range" aria-label="Maximum price" min={lo} max={hi} value={max} onChange={(e) => setMax(Math.max(Number(e.target.value), min))} />
            </div>
          </div>

          <label className="flex cursor-pointer items-center justify-between border-t border-zinc-200 pt-4 font-medium">
            Open lots only
            <button
              type="button"
              role="switch"
              aria-checked={openOnly}
              onClick={() => setOpenOnly((v) => !v)}
              className={`relative h-5 w-9 rounded-full transition ${openOnly ? "bg-primary" : "bg-zinc-300"}`}
            >
              <span className={`absolute top-0.5 size-4 rounded-full bg-white transition-all ${openOnly ? "left-[18px]" : "left-0.5"}`} />
            </button>
          </label>
          {member && (
            <div className="border-t border-zinc-200 pt-4">
              <label className="flex cursor-pointer items-center justify-between gap-2 rounded-md border border-zinc-200 bg-white px-2.5 py-2 text-zinc-600">
                Show lots where I have a max bid
                <input type="checkbox" checked={onlyMax} onChange={(e) => setOnlyMax(e.target.checked)} className="accent-primary" />
              </label>
              {Object.keys(maxBids).length === 0 && <p className="mt-1.5 text-[10px] text-zinc-400">No active max bids yet.</p>}
            </div>
          )}
        </aside>
      )}

      <section className="min-w-0 flex-1">
        <div className="mb-3 flex items-center justify-between text-xs">
          <p className="text-zinc-600">{Math.min(shown.length, results.length)} of {results.length} results</p>
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setShowFilters((v) => !v)} className="font-medium text-sky">
              {showFilters ? "Collapse Filters" : "Show Filters"}
            </button>
            <div className="flex overflow-hidden rounded-md border border-zinc-200">
              <button type="button" aria-label="Grid view" onClick={() => setGrid(true)} className={`p-1.5 ${grid ? "bg-brand text-white" : "bg-white text-zinc-500"}`}><LayoutGrid className="size-3.5" /></button>
              <button type="button" aria-label="List view" onClick={() => setGrid(false)} className={`p-1.5 ${!grid ? "bg-brand text-white" : "bg-white text-zinc-500"}`}><List className="size-3.5" /></button>
            </div>
          </div>
        </div>

        {results.length === 0 ? (
          <p className="rounded-xl border border-dashed border-zinc-300 bg-white p-10 text-center text-sm text-zinc-500">No lots match your filters.</p>
        ) : (
          <div className={grid ? "grid gap-4 sm:grid-cols-2 xl:grid-cols-3" : "space-y-4"}>
            <LiveRefresh lotIds={shown.map((l) => l.id)} />
            {shown.map((l) => (
              <LotCard key={l.id} lot={l} auction={auction} serverNow={serverNow} row={!grid} base={base}
                memberBid={member ? (
                  <MemberBid lotId={l.id} currentBid={l.currentBid} startingBid={l.startingBid} increment={l.increment} tiers={l.incrementMatrix} currency={auction.currency} status={reg}
                    maxBid={maxBids[l.id]} onSetMax={(v) => setMax(l.id, v)}
                    onRegister={() => setModal(true)} />
                ) : null} fav={!!favs[l.id]} onFav={() => void toggleFav(l.id)} />
            ))}
          </div>
        )}

        {visible < results.length && (
          <div className="mt-6 text-center">
            <button type="button" data-btn="outline" onClick={() => setVisible((v) => v + PAGE)} className="rounded-full border border-primary px-5 py-1.5 text-xs font-medium text-primary hover:bg-primary/5">
              Load more lots
            </button>
          </div>
        )}
      </section>
    </div>
    {modal && <RegisterModal auctionTitle={auctionTitle} onClose={() => setModal(false)} onSubmit={async (answers) => { await register(answers); setModal(false); }} />}
    </>
  );
}

function LotCard({ lot, auction, serverNow, row, base, memberBid, fav, onFav }: { lot: Lot; auction: Props["auction"]; serverNow: number; row: boolean; base: string; memberBid: React.ReactNode; fav: boolean; onFav: () => void }) {
  const { ratings } = useBrand(); // Auction House → "Allow questions & rating"
  const href = `${base}/${auction.slug}/lot/${lot.lotNumber}`;

  return (
    <article className={`rounded-2xl border border-zinc-200 bg-white p-2 shadow-sm ${row ? "flex gap-4" : ""}`}>
      <div className={`relative overflow-hidden rounded-xl ${row ? "w-60 shrink-0" : "aspect-[4/3]"}`}>
        {(lot.images?.[0] ?? auction.images?.[0])
          ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={(lot.images?.[0] ?? auction.images?.[0])!} alt={lot.title} loading="lazy" className="size-full min-h-32 object-cover" />
          : <PlaceholderImage tone={auction.tone} className="size-full min-h-32 !from-zinc-300 !via-zinc-400 !to-zinc-500" />}
        <span className="absolute left-2 top-2 rounded-full bg-sky-500 px-2 py-0.5 text-[10px] font-bold text-white">● LIVE</span>
        <button
          type="button"
          onClick={onFav}
          aria-label={fav ? "Remove from watchlist" : "Add to watchlist"}
          className="absolute right-2 top-2 inline-flex size-7 items-center justify-center rounded-full bg-white"
        >
          <Heart className={`size-3.5 ${fav ? "fill-red-500 text-red-500" : "text-zinc-700"}`} />
        </button>
        <div className="absolute inset-x-2 bottom-2 rounded-md bg-slate-600/60 px-2 py-1.5 text-center text-[10px] font-semibold text-white backdrop-blur-sm">
          <span className="text-white/60">ENDING IN</span> <Countdown target={auction.endsAt} serverNow={serverNow} />
          <span className="mx-1 text-white/50">·</span>
          {formatDateTime(auction.endsAt, auction.timezone)}
        </div>
      </div>

      <div className={`px-2 pb-2 ${row ? "flex-1 pt-2" : "pt-3"}`}>
        <div className="flex items-center justify-between text-[11px]">
          <Link href={href} className="font-bold text-primary">LOT {lot.lotNumber}</Link>
          {ratings && <span className="flex items-center gap-1 text-zinc-400">
            {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-2.5" />)}
            No ratings yet
          </span>}
        </div>
        <Link href={href} className="mt-1.5 block text-sm font-semibold text-ink hover:text-primary">{lot.title}</Link>
        <p className="mt-1 text-[11px] text-zinc-500">{lot.description ? lot.description.slice(0, 80) + "…" : "Details will be available soon."}</p>
        {memberBid ? <div className="mt-3">{memberBid}</div> : (
          <>
            <p className="mt-3 text-[9px] font-semibold uppercase tracking-wider text-zinc-400">Starting bid</p>
            <p className="text-lg font-bold">{formatMoney(lot.startingBid, auction.currency)}</p>
            <div className="mt-3">
              <BidStepper startingBid={lot.startingBid} increment={lot.increment} tiers={lot.incrementMatrix} currency={auction.currency} next={href} size="sm" />
            </div>
          </>
        )}
      </div>
    </article>
  );
}
