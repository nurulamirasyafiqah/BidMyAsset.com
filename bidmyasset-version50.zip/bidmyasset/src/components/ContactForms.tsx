"use client";

import { useState, type FormEvent } from "react";

type State = "idle" | "sending" | "sent" | "error";

const field =
  "w-full rounded-md border border-zinc-200 bg-white px-3 py-2 text-xs text-ink placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

function useSubmit(endpoint: string) {
  const [state, setState] = useState<State>("idle");
  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setState("sending");
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.fromEntries(new FormData(form))),
      });
      if (!res.ok) throw new Error();
      form.reset();
      setState("sent");
    } catch {
      setState("error");
    }
  }
  return { state, onSubmit };
}

function Note({ state, idle }: { state: State; idle: string }) {
  if (state === "sent") return <p className="text-[11px] font-medium text-emerald-600">Thank you — we’ve received your submission.</p>;
  if (state === "error") return <p className="text-[11px] font-medium text-red-600">Something went wrong. Please try again.</p>;
  return <p className="text-[11px] text-zinc-500">{idle}</p>;
}

export function ContactForm() {
  const { state, onSubmit } = useSubmit("/api/contact");
  return (
    <form onSubmit={onSubmit} className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
      <div className="grid gap-3 sm:grid-cols-2">
        <input name="firstName" required placeholder="First name" className={field} />
        <input name="lastName" required placeholder="Last name" className={field} />
        <input name="email" type="email" required placeholder="Email address" className={field} />
        <input name="phone" type="tel" placeholder="Phone (optional)" className={field} />
      </div>
      <input name="subject" placeholder="Subject (optional)" className={field} />
      <textarea name="message" required rows={3} placeholder="Tell us what you need help with" className={`${field} resize-y`} />
      <div className="flex items-center justify-between gap-3">
        <Note state={state} idle="We respond within 1 business day." />
        <button data-btn="primary" disabled={state === "sending"} className="rounded-md bg-primary px-4 py-2 text-xs font-semibold text-white hover:bg-primary-700 disabled:opacity-60">
          {state === "sending" ? "Sending…" : "Send message"}
        </button>
      </div>
    </form>
  );
}

export function SubscribeForm() {
  const { state, onSubmit } = useSubmit("/api/subscribe");
  return (
    <form onSubmit={onSubmit} className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
      <div className="grid gap-3 sm:grid-cols-2">
        <input name="firstName" required placeholder="First name" className={field} />
        <input name="lastName" required placeholder="Last name" className={field} />
      </div>
      <input name="email" type="email" required placeholder="you@example.com" className={field} />
      <button data-btn="primary" disabled={state === "sending"} className="w-full rounded-md bg-primary py-2 text-xs font-semibold text-white hover:bg-primary-700 disabled:opacity-60">
        {state === "sending" ? "Subscribing…" : "Subscribe"}
      </button>
      <Note state={state} idle="We only send essential updates. Unsubscribe anytime." />
    </form>
  );
}
