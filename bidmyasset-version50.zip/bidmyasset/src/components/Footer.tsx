"use client";

import { ExternalLink, Mail, Phone } from "lucide-react";
import { LegalLink } from "@/components/LegalPopup";
import { useBrand } from "@/components/BrandProvider";
import { T } from "@/components/T";

export function Footer() {
  const CONTACT = useBrand(); // from the PocketBase `house` record via BrandProvider (works in server and client layouts)
  return (
    <footer className="sticky bottom-0 z-30 border-t border-zinc-200 bg-zinc-50 text-[11px] text-zinc-600">
      <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-2 sm:px-5">
        <div className="flex items-center gap-5">
          <a href={`tel:${CONTACT.phone}`} className="inline-flex items-center gap-1.5 hover:text-primary">
            <Phone className="size-3" /> {CONTACT.phone}
          </a>
          <a href={`mailto:${CONTACT.email}`} className="inline-flex items-center gap-1.5 hover:text-primary">
            <Mail className="size-3" /> {CONTACT.email}
          </a>
        </div>
        <div className="flex items-center gap-4">
          <LegalLink kind="privacy" className="inline-flex items-center gap-1 hover:text-primary" />
          <LegalLink kind="terms" className="inline-flex items-center gap-1 hover:text-primary"><T>Terms & Conditions</T> <ExternalLink className="size-3" /></LegalLink>
          <span>© {new Date().getFullYear()} {CONTACT.name}. <T>All rights reserved.</T></span>
        </div>
      </div>
    </footer>
  );
}
