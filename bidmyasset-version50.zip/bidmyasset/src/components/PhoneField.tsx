"use client";

import { useEffect, useState } from "react";
import { getCountries, type CountryOption } from "@/lib/geo";

const input =
  "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

/** Dial-code select + number. Submits `<name>Country` (ISO) and `<name>` (number). */
export function PhoneField({
  name, placeholder, required, defaultIso = "MY", defaultValue = "",
}: { name: string; placeholder: string; required?: boolean; defaultIso?: string; defaultValue?: string }) {
  const [countries, setCountries] = useState<CountryOption[]>([]);
  const [iso, setIso] = useState(defaultIso);

  useEffect(() => {
    getCountries().then(setCountries).catch(() => {});
  }, []);

  const options = countries.length ? countries : [{ value: iso, label: iso, dial: "" }];

  return (
    <div className="flex gap-2">
      <select
        name={`${name}Country`}
        value={iso}
        onChange={(e) => setIso(e.target.value)}
        aria-label="Country code"
        className="h-9 w-28 shrink-0 rounded-md border border-zinc-300 bg-white px-1.5 text-xs"
      >
        {options.map((c) => (
          <option key={c.value} value={c.value}>{c.dial ? `${c.value} ${c.dial}` : c.value}</option>
        ))}
      </select>
      <input name={name} type="tel" required={required} defaultValue={defaultValue} placeholder={placeholder} className={input} />
    </div>
  );
}
