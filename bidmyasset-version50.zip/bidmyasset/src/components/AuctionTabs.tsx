import Link from "next/link";

export function AuctionTabs({ active, base = "/auctions" }: { active: "live" | "archive"; base?: string }) {
  const tab = "rounded-md px-4 py-2 text-xs font-semibold transition";
  const on = "bg-sky text-white shadow";
  const off = "bg-white text-slate-700 hover:bg-slate-50";
  return (
    <div className="mt-4 flex gap-2" role="tablist">
      <Link role="tab" aria-selected={active === "live"} href={base} className={`${tab} ${active === "live" ? on : off}`}>Live &amp; Upcoming</Link>
      <Link role="tab" aria-selected={active === "archive"} href={`${base}/archive`} className={`${tab} ${active === "archive" ? on : off}`}>Archive</Link>
    </div>
  );
}
