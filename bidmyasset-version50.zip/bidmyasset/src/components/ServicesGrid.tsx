"use client";

import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { services } from "@/lib/content";
import { Icon } from "./Icon";

export function ServicesGrid() {
  const [active, setActive] = useState(0);
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {services.map((s, i) => {
        const on = i === active;
        return (
          <button
            key={s.title}
            type="button"
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            className={`relative flex min-h-[120px] flex-col rounded-xl p-4 text-left shadow-sm transition ${on ? "bg-primary text-white" : "bg-white text-ink"}`}
          >
            <span className={`text-[10px] ${on ? "text-white/70" : "text-zinc-400"}`}>[{String(i + 1).padStart(2, "0")}]</span>
            {!on && (
              <span className="mt-1 inline-flex size-7 items-center justify-center rounded-lg bg-soft text-primary">
                <Icon name={s.icon} className="size-3.5" />
              </span>
            )}
            <span className={`text-sm font-bold ${on ? "mt-3" : "mt-2"}`}>{s.title}</span>
            <span className={`mt-1 text-[11px] leading-relaxed ${on ? "text-white/80" : "text-zinc-500"}`}>{s.text}</span>
            {on && (
              <span className="absolute bottom-3 right-3 inline-flex size-7 items-center justify-center rounded-full bg-white text-primary">
                <ArrowUpRight className="size-3.5" />
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
