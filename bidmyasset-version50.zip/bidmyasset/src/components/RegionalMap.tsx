"use client";

import { useEffect, useRef, useState } from "react";
import "leaflet/dist/leaflet.css";
import { regionPoints } from "@/lib/content";

/** Leadership → "Operating Across Asia": an interactive OpenStreetMap with one pin per region (no API key needed). */
export function RegionalMap() {
  const box = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let map: import("leaflet").Map | undefined;
    let cancelled = false;
    (async () => {
      try {
        const L = (await import("leaflet")).default;
        if (cancelled || !box.current) return;
        map = L.map(box.current, { scrollWheelZoom: false, attributionControl: true, zoomControl: true });
        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 12, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);
        const pin = L.divIcon({
          className: "", iconSize: [18, 18], iconAnchor: [9, 9],
          html: '<span style="display:block;width:18px;height:18px;border-radius:9999px;background:#1D4ED8;border:3px solid #fff;box-shadow:0 2px 8px rgba(15,23,42,.45)"></span>',
        });
        const pts = regionPoints.map((r) => {
          const m = L.marker([r.lat, r.lng], { icon: pin, title: r.name, keyboard: true }).addTo(map!);
          const tip = document.createElement("div");
          const b = document.createElement("b"); b.textContent = r.name;
          tip.append(b, document.createElement("br"), document.createTextNode(r.city));
          m.bindTooltip(tip, { direction: "top", offset: [0, -8] });
          return L.latLng(r.lat, r.lng);
        });
        map.fitBounds(L.latLngBounds(pts), { padding: [28, 28], maxZoom: 6 });
      } catch { if (!cancelled) setFailed(true); }
    })();
    return () => { cancelled = true; map?.remove(); };
  }, []);

  if (failed) return <div className="mt-[52px] grid aspect-[16/9] place-items-center rounded-xl border border-zinc-200 bg-zinc-50 text-xs text-zinc-500">The map could not be loaded.</div>;
  return <div ref={box} role="img" aria-label={`Map of our regions: ${regionPoints.map((r) => r.name).join(", ")}`} className="z-0 mt-[52px] aspect-[16/9] w-full overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100" />;
}
