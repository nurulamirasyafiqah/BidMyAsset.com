import type { AuctionStatus } from "@/lib/data";

const dot: Record<AuctionStatus, string> = {
  LIVE: "bg-sky-300",
  UPCOMING: "bg-amber-400",
  CLOSED: "bg-red-500",
};

export function StatusBadge({ status }: { status: AuctionStatus }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-white">
      <span className={`size-1.5 rounded-full ${dot[status]}`} />
      {status}
    </span>
  );
}
