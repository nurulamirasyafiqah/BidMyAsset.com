"use client";

import { useState } from "react";
import Link from "next/link";
import { Minus, Plus } from "lucide-react";
import { formatMoney } from "@/lib/format";
import { incrementAt, type Tier } from "@/lib/bidding";
import { FeeEstimate } from "@/components/FeeEstimate";

/**
 * UI only. Real bids go through the server pipeline (auth → qualification →
 * time check → increment check …). Until buyer accounts exist, Place Bid sends
 * visitors to Login and remembers where they came from.
 */
export function BidStepper({
  startingBid, increment, tiers, currency, next, size = "md", onPlace,
}: { startingBid: number; increment: number; tiers?: Tier[]; currency: string; next: string; size?: "sm" | "md"; onPlace?: (amount: number) => void }) {
  const [value, setValue] = useState(startingBid);
  const dec = () => setValue((v) => Math.max(startingBid, v - incrementAt(increment, tiers, v - 0.01)));
  const inc = () => setValue((v) => v + incrementAt(increment, tiers, v));
  const h = size === "sm" ? "h-8" : "h-9";

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <button type="button" onClick={dec} aria-label="Decrease bid" className={`${h} w-9 shrink-0 rounded-md border border-primary/30 text-primary hover:bg-primary/5`}>
          <Minus className="mx-auto size-3.5" />
        </button>
        <div className={`flex ${h} flex-1 items-center justify-center gap-1.5 rounded-md border border-zinc-200 bg-white px-2 text-xs font-medium`}>
          {formatMoney(value, currency)}
          <span className="rounded bg-zinc-100 px-1 text-[9px] text-zinc-400">+{formatMoney(incrementAt(increment, tiers, value), currency).replace(" ", "")}</span>
        </div>
        <button type="button" onClick={inc} aria-label="Increase bid" className={`${h} w-9 shrink-0 rounded-md border border-primary/30 text-primary hover:bg-primary/5`}>
          <Plus className="mx-auto size-3.5" />
        </button>
      </div>
      {onPlace ? (
        <button type="button" data-btn="primary" onClick={() => onPlace(value)} className={`flex ${h} w-full items-center justify-center rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700`}>Place Bid</button>
      ) : (
        <Link
          href={`/login?next=${encodeURIComponent(next)}`}
          data-btn="primary"
          className={`flex ${h} w-full items-center justify-center rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700`}
        >
          Place Bid
        </Link>
      )}
      <FeeEstimate amount={value} currency={currency} />
    </div>
  );
}
