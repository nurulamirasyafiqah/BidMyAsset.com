"use client";

import { useCallback, useEffect, useState } from "react";
import { Trophy } from "lucide-react";
import { formatMoney } from "@/lib/format";
import { useT } from "@/lib/useT";
import { useLotEvents } from "@/lib/liveLots";

type Activity = {
  ranking: { rank: number; bidder: string; amount: number; mine: boolean }[];
  history: { bidder: string; amount: number; at: string; mine: boolean }[];
  rankingShown: boolean; historyShown: boolean; historyNote: string; totalBids: number;
};

/**
 * Bidder ranking + bid history of one lot. What is shown follows Auction Builder → Auction Info (ranking: top 10 / top 3 / all / hidden;
 * history: always / after close / never) and is decided by the server (GET /api/bma/lots/{id}/bids), so a hidden list is never sent to the browser.
 */
export function BidActivity({ lotId, currency, timezone, live }: { lotId: string; currency: string; timezone: string; live: boolean }) {
  const t = useT();
  const [d, setD] = useState<Activity | null>(null);
  const [failed, setFailed] = useState(false);
  const load = useCallback(async () => {
    try {
      const r = await fetch(`/api/pb/api/bma/lots/${lotId}/bids`, { cache: "no-store" });
      if (!r.ok) throw new Error();
      setD((await r.json()) as Activity); setFailed(false);
    } catch { setFailed(true); }
  }, [lotId]);
  useEffect(() => {
    load();
    if (!live) return;
    const t = setInterval(load, 60000); // safety net only: updates normally arrive instantly through the live stream
    return () => clearInterval(t);
  }, [load, live]);
  useLotEvents(() => { void load(); }, [lotId], live); // a bid placed by anyone shows up straight away

  if (failed && !d) return null;
  if (!d) return null;
  const nothing = !d.rankingShown && !d.historyShown && !d.historyNote;
  if (nothing) return null;
  const when = (iso: string) => new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short", timeZone: timezone }).format(new Date(iso));

  return (
    <section className="rounded-xl border border-zinc-200 bg-white p-5" aria-label="Bidder ranking and bid history">
      {d.rankingShown && (
        <div>
          <h2 className="flex items-center gap-1.5 text-sm font-bold"><Trophy className="size-4 text-amber-500" />{t("Bidder ranking")}</h2>
          {d.ranking.length === 0 ? <p className="mt-2 text-xs text-zinc-500">{t("No bids yet.")}</p> : (
            <ol className="mt-2 divide-y divide-zinc-100 text-xs">
              {d.ranking.map((r) => (
                <li key={r.rank} className={`flex items-center justify-between py-1.5 ${r.mine ? "font-semibold text-primary" : ""}`}>
                  <span><span className="mr-2 inline-block w-5 text-zinc-400">{r.rank}.</span>{r.bidder}</span>
                  <span>{formatMoney(r.amount, currency)}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      )}
      {(d.historyShown || d.historyNote) && (
        <div className={d.rankingShown ? "mt-5 border-t border-zinc-100 pt-4" : ""}>
          <h2 className="text-sm font-bold">{t("Bid history")}{d.historyShown ? ` (${d.history.length})` : ""}</h2>
          {!d.historyShown ? <p className="mt-2 text-xs text-zinc-500">{t(d.historyNote)}</p>
            : d.history.length === 0 ? <p className="mt-2 text-xs text-zinc-500">{t("No bids yet.")}</p> : (
              <div className="mt-2 max-h-64 overflow-y-auto">
                <table className="w-full text-xs">
                  <thead><tr className="text-left text-[10px] uppercase tracking-wider text-zinc-400"><th className="py-1 font-semibold">{t("Bidder")}</th><th className="py-1 font-semibold">{t("Amount")}</th><th className="py-1 text-right font-semibold">{t("Time")}</th></tr></thead>
                  <tbody className="divide-y divide-zinc-100">
                    {d.history.map((h, i) => (
                      <tr key={i} className={h.mine ? "font-semibold text-primary" : ""}>
                        <td className="py-1.5">{h.bidder}</td><td className="py-1.5">{formatMoney(h.amount, currency)}</td><td className="py-1.5 text-right text-zinc-500">{when(h.at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
        </div>
      )}
    </section>
  );
}
