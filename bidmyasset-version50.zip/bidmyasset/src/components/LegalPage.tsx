import Link from "next/link";
import { getLegalText } from "@/lib/brand";

export const LEGAL_PATHS = { privacy: "/privacy", terms: "/terms" } as const;
const TITLE = { privacy: "Privacy Policy", terms: "Terms & Conditions" } as const;

/**
 * Public page for the policy the admin saved in Auction House → Legal Policies.
 * `html` was cleaned by the backend on save (backend/html_sanitize.go), so it is safe to render as-is.
 */
export async function LegalPage({ kind }: { kind: "privacy" | "terms" }) {
  const doc = await getLegalText(kind);
  const other = kind === "privacy" ? "terms" : "privacy";
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-10 sm:px-6">
        <h1 className="text-2xl font-bold text-ink">{TITLE[kind]}</h1>
        {doc ? (
          <>
            <p className="mt-1 text-xs text-zinc-500">{doc.name}</p>
            <article className="legal-doc mt-6 text-sm leading-relaxed text-zinc-700 [&_a]:text-primary [&_a]:underline [&_blockquote]:border-l-4 [&_blockquote]:border-zinc-200 [&_blockquote]:pl-4 [&_h1]:mt-6 [&_h1]:text-xl [&_h1]:font-bold [&_h2]:mt-6 [&_h2]:text-lg [&_h2]:font-bold [&_h3]:mt-5 [&_h3]:font-bold [&_ol]:ml-5 [&_ol]:list-decimal [&_p]:mt-3 [&_table]:mt-3 [&_td]:border [&_td]:p-2 [&_th]:border [&_th]:p-2 [&_ul]:ml-5 [&_ul]:list-disc"
              dangerouslySetInnerHTML={{ __html: doc.html }} />
          </>
        ) : (
          <p className="mt-6 rounded-xl border border-dashed border-zinc-300 bg-white p-10 text-center text-sm text-zinc-500">
            This {TITLE[kind].toLowerCase()} has not been published yet. Please check back soon.
          </p>
        )}
        <p className="mt-10 border-t border-zinc-200 pt-4 text-xs text-zinc-500">
          Also read our <Link href={LEGAL_PATHS[other]} className="font-semibold text-primary hover:underline">{TITLE[other]}</Link> · <Link href="/" className="hover:underline">Back to home</Link>
        </p>
    </div>
  );
}
