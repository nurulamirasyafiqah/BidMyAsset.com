import { notFound } from "next/navigation";
import { Package } from "lucide-react";
import { LotBrowser } from "@/components/LotBrowser";
import { PageHero } from "@/components/PageHero";
import { getAuction, getLots } from "@/lib/api-data";
import { getStatus } from "@/lib/data";

/** Auction page: hero + lot browser, or the "Lots coming soon" state. `member` = logged-in bidder view under /timed. */
export async function AuctionView({ slug, member = false }: { slug: string; member?: boolean }) {
  const a = await getAuction(slug);
  if (!a) notFound();

  const base = member ? "/timed" : "/auctions";
  const serverNow = Date.now();
  const status = getStatus(a, serverNow);
  const lots = status === "CLOSED" ? [] : await getLots(a.slug);

  return (
    <>
      <PageHero
        compact
        crumbs={[{ label: "Home", href: member ? "/dashboard" : "/" }, { label: "Timed", href: base }, { label: a.title }]}
        title={a.title}
        kicker={`Sequence #${a.sequence}${a.city || a.region ? ` · ${[a.city, a.region].filter(Boolean).join(", ")}` : ""}`}
      />
      {lots.length > 0 ? (
        <LotBrowser
          auction={{ slug: a.slug, currency: a.currency, endsAt: a.endsAt, timezone: a.timezone, tone: a.tone, images: a.images }}
          lots={lots}
          serverNow={serverNow}
          member={member}
          base={base}
          auctionTitle={a.title}
        />
      ) : (
        <div className="mx-auto max-w-xl px-4 py-8">
          <div className="rounded-2xl border border-dashed border-sky/50 bg-gradient-to-b from-sky-50 to-white p-8 text-center">
            <p className="text-[9px] font-bold uppercase tracking-[0.25em] text-sky">Auction update</p>
            <span className="mx-auto mt-3 inline-flex size-9 items-center justify-center rounded-full bg-white text-sky shadow"><Package className="size-4" /></span>
            <h2 className="mt-3 text-lg font-bold">Lots coming soon</h2>
            <p className="mt-1 text-xs text-zinc-500">We’re getting this timed auction ready with new inventory. Sit tight while we prep the lots.</p>
            <p className="mx-auto mt-3 w-fit rounded-full border border-sky/30 bg-sky-50 px-3 py-1 text-[9px] font-bold uppercase tracking-wider text-sky">Follow the schedule so you’re first when bidding opens.</p>
          </div>
        </div>
      )}
    </>
  );
}
