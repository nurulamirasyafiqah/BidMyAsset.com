"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PasswordInput } from "./PasswordInput";
import { api, landingFor } from "@/lib/client-api";

const input = "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

export function LoginForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = e.currentTarget.elements;
    setBusy(true); setError("");
    try {
      const res = await api("api/collections/users/auth-with-password", {
        body: { identity: (f.namedItem("email") as HTMLInputElement).value, password: (f.namedItem("password") as HTMLInputElement).value },
      });
      router.push(landingFor(new URLSearchParams(window.location.search).get("next"), res));
      router.refresh();
    } catch (err) {
      // A disabled account is only reported after the right password, so this doesn't reveal which emails exist.
      const m = err instanceof Error ? err.message : "";
      setError(m.startsWith("This account has been disabled") ? m : "Incorrect email or password."); // same message for unknown email and wrong password
      setBusy(false);
    }
  }

  return (
    <div className="w-full max-w-[336px]">
      <h1 className="text-2xl font-bold">Welcome</h1>
      <p className="mt-0.5 text-xs text-zinc-500">Log in to your <b className="text-zinc-700">BidMyAsset</b> account.</p>

      <form onSubmit={onSubmit} className="mt-4 space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
        <div>
          <label htmlFor="email" className="mb-1 block text-[11px] font-medium">Email</label>
          <input id="email" type="email" required placeholder="you@example.com" className={input} />
        </div>
        <div>
          <label htmlFor="password" className="mb-1 block text-[11px] font-medium">Password</label>
          <PasswordInput id="password" required />
        </div>
        <Link href="/forgot-password" className="block text-[11px] underline">Forgot your password?</Link>
        {error && <p role="alert" className="text-[11px] font-medium text-red-600">{error}</p>}
        <button disabled={busy} data-btn="primary" className="h-8 w-full rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700 disabled:opacity-60">{busy ? "Signing in…" : "Login"}</button>
        <p className="text-center text-[9px] font-semibold tracking-widest text-zinc-400">OR</p>
        <Link href="/login/otp" className="block text-center text-[11px] text-primary underline">Login with OTP</Link>
      </form>

      <p className="mt-5 text-center text-[11px] text-zinc-600">
        Don’t have an account? <Link href="/register" className="underline">Register</Link>
      </p>
    </div>
  );
}
