"use client";

import { useEffect, useState, type ReactNode } from "react";
import { ExternalLink } from "lucide-react";
import { Btn, Modal } from "@/components/admin/ui";
import { fetchHouse } from "@/lib/houseClient";
import type { LegalPolicy } from "@/lib/auctionHouse";

const TITLE = { privacy: "Privacy Policy", terms: "Terms & Conditions" } as const;
const PATH = { privacy: "/privacy", terms: "/terms" } as const;
type Kind = keyof typeof TITLE;

/** Shows the policy saved in Auction House → Legal Policies (newest one that has that text) in a pop-up. */
type Doc = { name: string; html: string };
type Loader = (kind: Kind) => Promise<Doc | null>;

/** Admin: reads the settings API (always current). */
const loadAdmin: Loader = async (kind) => {
  const { legal } = await fetchHouse();
  const hit = [...legal].reverse().find((p: LegalPolicy) => p[kind].trim());
  return hit ? { name: hit.name, html: hit[kind] } : null;
};
/** Public: reads the published policy through /api/legal (no sign-in needed). */
const loadPublic: Loader = async (kind) => {
  const res = await fetch(`/api/legal?kind=${kind}`);
  if (!res.ok) throw new Error("failed");
  const j = (await res.json()) as Doc;
  return j.html.trim() ? j : null;
};

function LegalPopup({ kind, onClose, load }: { kind: Kind; onClose: () => void; load: Loader }) {
  const [state, setState] = useState<"loading" | "error" | "ready">("loading");
  const [doc, setDoc] = useState<Doc | null>(null);
  useEffect(() => {
    let live = true;
    load(kind)
      .then((d) => { if (!live) return; setDoc(d); setState("ready"); })
      .catch(() => live && setState("error"));
    return () => { live = false; };
  }, [kind, load]);
  return (
    <Modal wide title={TITLE[kind]} sub={doc?.name} onClose={onClose}
      footer={<><a href={PATH[kind]} target="_blank" rel="noopener" className="mr-auto inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">Open full page <ExternalLink className="size-3" /></a><Btn variant="outline" onClick={onClose}>Close</Btn></>}>
      {state === "loading" && <p role="status" className="py-8 text-center text-xs text-zinc-500">Loading…</p>}
      {state === "error" && <p role="alert" className="py-8 text-center text-xs text-rose-600">Couldn’t load the {TITLE[kind].toLowerCase()}. Please try again.</p>}
      {state === "ready" && !doc && <p className="rounded-lg border border-dashed border-zinc-300 py-8 text-center text-xs text-zinc-500">This {TITLE[kind].toLowerCase()} has not been published yet. Add it in Auction House → Legal Policies.</p>}
      {state === "ready" && doc && (
        // the backend sanitizes this HTML on save (backend/html_sanitize.go)
        <article className="max-h-[60vh] overflow-y-auto pr-1 text-sm leading-relaxed text-zinc-700 [&_a]:text-primary [&_a]:underline [&_h1]:mt-4 [&_h1]:text-lg [&_h1]:font-bold [&_h2]:mt-4 [&_h2]:font-bold [&_h3]:mt-3 [&_h3]:font-bold [&_ol]:ml-5 [&_ol]:list-decimal [&_p]:mt-2 [&_ul]:ml-5 [&_ul]:list-disc"
          dangerouslySetInnerHTML={{ __html: doc.html }} />
      )}
    </Modal>
  );
}

/** The "Privacy Policy" and "Terms & Conditions" links for the admin footer; each opens the pop-up. */
export function LegalLinks() {
  const [open, setOpen] = useState<Kind | null>(null);
  const cls = "inline-flex items-center gap-1 hover:text-primary";
  return (
    <>
      <button type="button" onClick={() => setOpen("privacy")} className={cls}>Privacy Policy <ExternalLink className="size-3" /></button>
      <button type="button" onClick={() => setOpen("terms")} className={cls}>Terms &amp; Conditions <ExternalLink className="size-3" /></button>
      {open && <LegalPopup kind={open} load={loadAdmin} onClose={() => setOpen(null)} />}
    </>
  );
}

/** A link on a public page ("Privacy Policy", "Terms & Conditions") that opens the policy in a pop-up. */
export function LegalLink({ kind, className, children }: { kind: Kind; className?: string; children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={className}>{children ?? <>{TITLE[kind]} <ExternalLink className="size-3" /></>}</button>
      {open && <LegalPopup kind={kind} load={loadPublic} onClose={() => setOpen(false)} />}
    </>
  );
}
