export function SectionHeading({
  eyebrow, title, sub, align = "left", light = false,
}: { eyebrow: string; title: string; sub?: string; align?: "left" | "center"; light?: boolean }) {
  return (
    <div className={align === "center" ? "text-center" : ""}>
      <p className={`eyebrow ${light ? "!text-sky-200" : ""}`}>{eyebrow}</p>
      <h2 className={`mt-1.5 text-2xl font-bold sm:text-[28px] ${light ? "text-white" : "text-ink"}`}>{title}</h2>
      {sub && <p className={`mt-1.5 text-sm ${light ? "text-blue-100" : "text-zinc-500"} ${align === "center" ? "mx-auto max-w-xl" : "max-w-xl"}`}>{sub}</p>}
    </div>
  );
}
