"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/client-api";
import { formatMoney } from "@/lib/format";

type Quote = { hammer: number; commission: number; internetFee: number; tax?: number; fees: number; total: number };
const cache = new Map<number, Quote>();

/**
 * "+ buyer's fees … · est. total …" under a bid. The numbers come from the server (GET /api/bma/fee-quote),
 * i.e. the same Company commission + tax and Auction House internet buying fee that end up on the invoice.
 * Renders nothing when no fee is configured (or the quote can't be loaded).
 */
export function FeeEstimate({ amount, currency }: { amount: number; currency: string }) {
  const [quote, setQuote] = useState<Quote | null>(cache.get(amount) ?? null);

  useEffect(() => {
    if (!(amount > 0)) { setQuote(null); return; }
    const hit = cache.get(amount);
    if (hit) { setQuote(hit); return; }
    let live = true;
    const t = setTimeout(() => {
      api<Quote>(`api/bma/fee-quote?amount=${encodeURIComponent(String(amount))}`)
        .then((q) => { cache.set(amount, q); if (live) setQuote(q); })
        .catch(() => { if (live) setQuote(null); });
    }, 250); // the stepper can be clicked quickly
    return () => { live = false; clearTimeout(t); };
  }, [amount]);

  if (!quote || quote.fees <= 0) return null;
  const parts = [quote.commission > 0 && `commission ${formatMoney(quote.commission, currency)}`, quote.internetFee > 0 && `internet fee ${formatMoney(quote.internetFee, currency)}`, (quote.tax ?? 0) > 0 && `tax ${formatMoney(quote.tax ?? 0, currency)}`].filter(Boolean).join(" + ");
  return (
    <p className="text-[10px] leading-snug text-zinc-500" title={parts}>
      + buyer’s fees {formatMoney(quote.fees, currency)} · <b className="font-semibold text-zinc-700">est. total {formatMoney(quote.total, currency)}</b>
    </p>
  );
}
