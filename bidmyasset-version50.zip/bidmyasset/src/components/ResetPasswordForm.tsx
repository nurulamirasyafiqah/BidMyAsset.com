"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { api } from "@/lib/client-api";
import { PasswordInput } from "./PasswordInput";

/** Target of the reset link in the email: /reset-password?token=… */
export function ResetPasswordForm() {
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const password = String(f.get("password"));
    if (password.length < 8) return setMsg({ ok: false, text: "Password must be at least 8 characters." });
    if (password !== f.get("confirm")) return setMsg({ ok: false, text: "Passwords do not match." });
    const token = new URLSearchParams(window.location.search).get("token") ?? "";
    try {
      await api("api/collections/users/confirm-password-reset", { body: { token, password, passwordConfirm: password } });
      setMsg({ ok: true, text: "Password updated. You can now log in." });
    } catch {
      setMsg({ ok: false, text: "This reset link is invalid or has expired." });
    }
  }

  return (
    <div className="w-full max-w-[336px]">
      <h1 className="text-2xl font-bold">Reset password</h1>
      <form onSubmit={onSubmit} className="mt-4 space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
        <label className="block text-[11px] font-medium">New password<PasswordInput name="password" required autoComplete="new-password" /></label>
        <label className="block text-[11px] font-medium">Confirm password<PasswordInput name="confirm" required autoComplete="new-password" /></label>
        {msg && <p role="status" className={`text-[11px] font-medium ${msg.ok ? "text-emerald-700" : "text-red-600"}`}>{msg.text}</p>}
        <button data-btn="primary" className="h-8 w-full rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700">Update password</button>
      </form>
      <p className="mt-5 text-center text-[11px]"><Link href="/login" className="underline">Back to Login</Link></p>
    </div>
  );
}
