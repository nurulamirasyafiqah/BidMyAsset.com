"use client";

import { LegalLink } from "@/components/LegalPopup";
import { useRef, useState, type FormEvent, type ReactNode } from "react";
import Link from "next/link";
import { ArrowLeft, Check } from "lucide-react";
import { GeoFields } from "./GeoFields";
import { PasswordInput } from "./PasswordInput";
import { PhoneField } from "./PhoneField";
import { api } from "@/lib/client-api";

const input =
  "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";
const steps = ["Basic Info", "Address", "Other details"];

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-[11px] font-medium">{label}</label>
      {children}
    </div>
  );
}

type Data = Record<string, string>;

export function RegisterForm() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<Data>({});
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const read = (form: HTMLFormElement): Data =>
    Object.fromEntries([...new FormData(form).entries()].filter(([, v]) => typeof v === "string")) as Data;

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const merged = { ...data, ...read(e.currentTarget) };

    if (step === 0) {
      if (merged.password !== merged.confirm) return setError("Passwords do not match.");
      if (merged.password.length < 8) return setError("Password must be at least 8 characters.");
    }
    setData(merged);
    if (step < 2) setStep(step + 1);
    else {
      setBusy(true);
      try {
        await api("api/collections/users/records", {
          body: {
            email: merged.email, password: merged.password, passwordConfirm: merged.confirm,
            name: `${merged.firstName} ${merged.lastName}`.trim(),
            firstName: merged.firstName, lastName: merged.lastName, phone: merged.phone, phoneCountry: merged.phoneCountry,
            address1: merged.address1, address2: merged.address2, country: merged.country, state: merged.state,
            city: merged.city, postalCode: merged.postcode, company: merged.company, designation: merged.designation,
            website: merged.website, accountType: merged.company ? "COMPANY" : "INDIVIDUAL",
          },
        });
        await api("api/collections/users/auth-with-password", { body: { identity: merged.email, password: merged.password } });
        setDone(true);
      } catch (x) {
        setError((x as Error).message);
      } finally {
        setBusy(false);
      }
    }
  }

  function back() {
    if (formRef.current) setData((d) => ({ ...d, ...read(formRef.current!) })); // keep what was typed
    setError("");
    setStep((s) => Math.max(0, s - 1));
  }

  if (done) {
    return (
      <div className="w-full max-w-sm text-center">
        <span className="mx-auto inline-flex size-10 items-center justify-center rounded-full bg-emerald-100 text-emerald-600"><Check className="size-5" /></span>
        <h1 className="mt-3 text-xl font-bold">Registration received</h1>
        <p className="mt-1 text-xs text-zinc-500">Your account is ready. You can now browse timed auctions and register to bid.</p>
        <Link href="/dashboard" className="mt-5 inline-block text-xs text-primary underline">Go to my dashboard</Link>
      </div>
    );
  }

  return (
    <div className="w-full max-w-[360px]">
      <h1 className="text-2xl font-bold">Bidder Registration</h1>
      <p className="mt-0.5 text-xs text-zinc-500">Complete your Bidder Registration in 3 Simple Steps</p>

      <ol className="mt-5 flex items-center justify-between px-1">
        {steps.map((s, i) => (
          <li key={s} className="flex items-center gap-2 text-[11px]">
            <span className={`inline-flex size-6 items-center justify-center rounded-full text-[10px] font-semibold ${i <= step ? "bg-primary text-white" : "bg-zinc-100 text-zinc-500"}`}>
              {i < step ? <Check className="size-3" /> : i + 1}
            </span>
            <span className={i === step ? "font-medium" : "text-zinc-600"}>{s}</span>
          </li>
        ))}
      </ol>

      <form key={step} ref={formRef} onSubmit={submit} className="mt-4 space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
        {step === 0 && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Field label="First name"><input name="firstName" required defaultValue={data.firstName} className={input} /></Field>
              <Field label="Last name"><input name="lastName" required defaultValue={data.lastName} className={input} /></Field>
            </div>
            <Field label="Email address"><input name="email" type="email" required defaultValue={data.email} className={input} /></Field>
            <Field label="Phone number">
              <PhoneField name="phone" required placeholder="Enter phone number" defaultIso={data.phoneCountry} defaultValue={data.phone} />
            </Field>
            <Field label="Password"><PasswordInput name="password" required defaultValue={data.password} /></Field>
            <Field label="Confirm password"><PasswordInput name="confirm" required defaultValue={data.confirm} /></Field>
          </>
        )}

        {step === 1 && (
          <>
            <Field label="Address line 1"><input name="address1" required defaultValue={data.address1} className={input} /></Field>
            <Field label="Address line 2 (optional)"><input name="address2" defaultValue={data.address2} className={input} /></Field>
            <GeoFields defaults={{ country: data.country, state: data.state, city: data.city }} />
            <Field label="Zip/Postal code"><input name="postcode" required defaultValue={data.postcode} className={input} /></Field>
          </>
        )}

        {step === 2 && (
          <>
            <Field label="Company name (optional)"><input name="company" defaultValue={data.company} className={input} /></Field>
            <Field label="Designation (optional)"><input name="designation" defaultValue={data.designation} className={input} /></Field>
            <Field label="Company website (optional)">
              <input name="website" type="url" placeholder="https://example.com" defaultValue={data.website} className={input} />
            </Field>
            <Field label="Fax number (optional)">
              <PhoneField name="fax" placeholder="Enter fax number" defaultIso={data.faxCountry} defaultValue={data.fax} />
            </Field>
            <label className="flex items-start gap-2 rounded-md border border-zinc-200 p-3 text-[11px] leading-snug text-zinc-600">
              <input type="checkbox" required className="mt-0.5 accent-primary" />
              <span>
                By clicking <b className="text-zinc-900">REGISTER</b> you have agreed to{" "}
                <LegalLink kind="terms" className="underline">Terms and Conditions</LegalLink> and <LegalLink kind="privacy" className="underline">Privacy Statement</LegalLink>.
              </span>
            </label>
          </>
        )}

        {error && <p role="alert" className="text-[11px] font-medium text-red-600">{error}</p>}

        {step === 0 ? (
          <button data-btn="primary" className="h-9 w-full rounded-md bg-primary/90 text-xs font-semibold text-white hover:bg-primary">Continue</button>
        ) : (
          <div className="grid grid-cols-[1fr_2fr] gap-3">
            <button type="button" data-btn="outline" onClick={back} className="h-9 rounded-md border border-primary/40 bg-white text-xs font-medium text-primary hover:bg-primary/5">Back</button>
            <button data-btn="primary" className="h-9 rounded-md bg-primary/90 text-xs font-semibold text-white hover:bg-primary">{step < 2 ? "Continue" : busy ? "Registering…" : "Register"}</button>
          </div>
        )}
      </form>

      <div className="mt-5 space-y-3 text-center text-[11px]">
        <Link href="/" className="inline-flex items-center gap-2 hover:text-primary"><ArrowLeft className="size-3" /> Go back</Link>
        <p className="text-zinc-600">Already have an account? <Link href="/login" className="text-primary underline">Login</Link></p>
      </div>
    </div>
  );
}
