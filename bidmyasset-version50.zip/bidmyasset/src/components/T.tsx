"use client";

import { useT } from "@/lib/useT";

/** `<T>My Bids</T>` — works inside server components too; shows the text in the visitor's chosen language. */
export function T({ children }: { children: string }) {
  const t = useT();
  return <>{t(children)}</>;
}
