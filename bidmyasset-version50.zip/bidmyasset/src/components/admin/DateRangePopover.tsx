"use client";

import { useEffect, useRef, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import { Btn } from "@/components/admin/ui";

export type DateRange = { start: string; end: string }; // "YYYY-MM-DD" (local dates)

const pad = (n: number) => String(n).padStart(2, "0");
export const toISO = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const fromISO = (s: string) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
export const fmtDate = (s: string) => fromISO(s).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
export const fmtRange = (r: DateRange) => (r.start === r.end ? fmtDate(r.start) : `${fmtDate(r.start)} – ${fmtDate(r.end)}`);
/** The period of equal length immediately before the given range. */
export function previousRange(r: DateRange): DateRange {
  const s = fromISO(r.start), e = fromISO(r.end);
  const days = Math.round((e.getTime() - s.getTime()) / 86400000) + 1;
  const pe = new Date(s); pe.setDate(pe.getDate() - 1);
  const ps = new Date(pe); ps.setDate(ps.getDate() - (days - 1));
  return { start: toISO(ps), end: toISO(pe) };
}

const WEEKDAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

function DatePicker({ value, onChange, min, max, label }: { value: string; onChange: (v: string) => void; min?: string; max?: string; label: string }) {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState(() => { const d = value ? fromISO(value) : min ? fromISO(min) : new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);

  const toggle = () => {
    if (!open) { const d = value ? fromISO(value) : min ? fromISO(min) : new Date(); setView(new Date(d.getFullYear(), d.getMonth(), 1)); }
    setOpen((o) => !o);
  };
  const first = view.getDay();
  const dim = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: dim }, (_, i) => i + 1)];
  const today = toISO(new Date());

  return (
    <div ref={ref} className="relative">
      <button type="button" aria-label={label} aria-haspopup="dialog" aria-expanded={open} onClick={toggle}
        className={`flex h-8 w-full items-center gap-2 rounded-md border bg-white px-2.5 text-left text-xs ${open ? "border-primary" : "border-zinc-300"} hover:border-primary/60`}>
        <CalendarDays className="size-3.5 shrink-0 text-zinc-500" />
        <span className={value ? "text-zinc-900" : "text-zinc-500"}>{value ? fmtDate(value) : "Pick a date"}</span>
      </button>
      {open && (
        <div role="dialog" aria-label={`${label} calendar`} className="absolute left-0 top-full z-[70] mt-1 w-[232px] rounded-lg border border-zinc-200 bg-white p-2.5 shadow-lg">
          <div className="mb-2 flex items-center justify-between">
            <button type="button" aria-label="Previous month" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1))} className="rounded p-1 hover:bg-zinc-100"><ChevronLeft className="size-4" /></button>
            <span className="text-xs font-semibold">{view.toLocaleDateString("en-GB", { month: "long", year: "numeric" })}</span>
            <button type="button" aria-label="Next month" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1))} className="rounded p-1 hover:bg-zinc-100"><ChevronRight className="size-4" /></button>
          </div>
          <div className="grid grid-cols-7 text-center text-[10px] text-zinc-500">{WEEKDAYS.map((w) => <span key={w} className="py-1">{w}</span>)}</div>
          <div className="grid grid-cols-7 gap-y-0.5 text-center text-xs">
            {cells.map((d, i) => {
              if (d === null) return <span key={i} />;
              const iso = toISO(new Date(view.getFullYear(), view.getMonth(), d));
              const off = (!!min && iso < min) || (!!max && iso > max);
              const sel = iso === value;
              return (
                <button key={i} type="button" disabled={off} onClick={() => { onChange(iso); setOpen(false); }}
                  className={`mx-auto grid size-7 place-items-center rounded-full ${sel ? "bg-primary font-semibold text-white" : off ? "cursor-not-allowed text-zinc-300" : "hover:bg-zinc-100"} ${iso === today && !sel ? "ring-1 ring-primary/40" : ""}`}>{d}</button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export function DateRangePopover({ applied, onApply, onReset, onClose }: { applied: DateRange | null; onApply: (r: DateRange) => void; onReset: () => void; onClose: () => void }) {
  const [start, setStart] = useState(applied?.start ?? "");
  const [end, setEnd] = useState(applied?.end ?? "");
  const ref = useRef<HTMLDivElement>(null);
  const today = toISO(new Date());

  useEffect(() => {
    // Ignore clicks on the wrapper (incl. the toggle button) so the toggle can close it itself.
    const down = (e: MouseEvent) => { const host = ref.current?.parentElement; if (host && !host.contains(e.target as Node)) onClose(); };
    const key = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("mousedown", down);
    document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", down); document.removeEventListener("keydown", key); };
  }, [onClose]);

  const pickStart = (v: string) => { setStart(v); if (end && end < v) setEnd(""); };
  const ready = !!start && !!end && start <= end;

  return (
    <div ref={ref} role="dialog" aria-label="Custom range" className="absolute left-0 top-full z-[65] mt-2 w-[240px] rounded-lg border border-zinc-200 bg-white p-3.5 shadow-lg">
      <h3 className="text-sm font-bold">Custom Range</h3>
      <p className="mt-0.5 text-[11px] text-zinc-500">Select a start and end date for the dashboard.</p>
      <div className="mt-3 space-y-2.5">
        <div className="grid grid-cols-[62px_1fr] items-center gap-2 text-[11px] font-medium text-zinc-700"><span>Start date</span><DatePicker label="Start date" value={start} onChange={pickStart} max={today} /></div>
        <div className="grid grid-cols-[62px_1fr] items-center gap-2 text-[11px] font-medium text-zinc-700"><span>End date</span><DatePicker label="End date" value={end} onChange={setEnd} min={start || undefined} max={today} /></div>
      </div>
      <div className="mt-3.5 flex items-center justify-between">
        <Btn variant="outline" className="h-7 px-3 text-[11px]" onClick={() => { setStart(""); setEnd(""); onReset(); }}>Reset</Btn>
        <Btn variant="solid" className="h-7 px-3 text-[11px]" disabled={!ready} onClick={() => onApply({ start, end })}>Apply Range</Btn>
      </div>
    </div>
  );
}
