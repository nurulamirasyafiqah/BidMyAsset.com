"use client";

import { useEffect, useState } from "react";
import { COMPANY_ERROR_EVENT, usePersisted } from "@/lib/companyClient";
import { ChevronDown, Pencil, Plus } from "lucide-react";
import { Btn, Card, Field, inputCls, Modal, PageHead } from "@/components/admin/ui";
import { AuctioneersPanel } from "@/components/admin/PeopleViews";
import { BankSection, CommissionSection, Consignors, Contacts, Locations, LotBidDetails, Policies, Questionnaire, Taxes } from "@/components/admin/CompanySections";

type Company = { name: string; email: string; phone: string; line1: string; line2: string; city: string; state: string; postal: string; country: string };
const BLANK: Company = { name: "", email: "", phone: "", line1: "", line2: "", city: "", state: "", postal: "", country: "" };

const TREE = [
  { id: "overview", label: "Overview" },
  { id: "users", label: "Users", kids: [["auctioneers", "Auctioneers"], ["consignors", "Consignors"]] },
  { id: "financial", label: "Financial", kids: [["bank", "Bank"], ["taxes", "Taxes"], ["commission", "Auctioneer Commission"]] },
  { id: "settings", label: "Settings", kids: [["contacts", "Contacts"], ["lotbid", "Lot Bid Details"], ["locations", "Locations"], ["policies", "Policies"], ["questionnaire", "Questionnaire"]] },
] as const;

const SECTION_LABELS: Record<string, string> = {};
for (const t of TREE) if ("kids" in t) for (const [id, label] of t.kids) SECTION_LABELS[id] = label;

function CompanyForm({ initial, title, cta, onSave, onClose }: { initial: Company; title: string; cta: string; onSave: (c: Company) => void; onClose: () => void }) {
  const [c, setC] = useState(initial);
  const set = (k: keyof Company) => (e: React.ChangeEvent<HTMLInputElement>) => setC({ ...c, [k]: e.target.value });
  return (
    <Modal wide title={title} onClose={onClose}
      footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="solid" disabled={!c.name.trim()} onClick={() => onSave(c)}>{cta}</Btn></>}>
      <div className="space-y-3">
        <Field label="Company Name"><input className={inputCls} value={c.name} onChange={set("name")} placeholder="Company Name" /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Email"><input type="email" className={inputCls} value={c.email} onChange={set("email")} placeholder="name@company.com" /></Field>
          <Field label="Phone"><input className={inputCls} value={c.phone} onChange={set("phone")} placeholder="Enter phone number" /></Field>
        </div>
        <Field label="Address Line 1"><input className={inputCls} value={c.line1} onChange={set("line1")} placeholder="Street address" /></Field>
        <Field label="Address Line 2"><input className={inputCls} value={c.line2} onChange={set("line2")} placeholder="Suite, unit, etc." /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="City"><input className={inputCls} value={c.city} onChange={set("city")} placeholder="City" /></Field>
          <Field label="State"><input className={inputCls} value={c.state} onChange={set("state")} placeholder="State" /></Field>
          <Field label="Postal Code"><input className={inputCls} value={c.postal} onChange={set("postal")} placeholder="Zip / Postal code" /></Field>
          <Field label="Country"><input className={inputCls} value={c.country} onChange={set("country")} placeholder="Country" /></Field>
        </div>
      </div>
    </Modal>
  );
}

export function CompanyView() {
  const [company, setCompany, loading] = usePersisted<Company | null>("company", null);
  const [saveErr, setSaveErr] = useState("");
  useEffect(() => {
    const h = (e: Event) => setSaveErr(String((e as CustomEvent).detail ?? ""));
    window.addEventListener(COMPANY_ERROR_EVENT, h);
    return () => window.removeEventListener(COMPANY_ERROR_EVENT, h);
  }, []);
  const [modal, setModal] = useState<"create" | "edit" | null>(null);
  const [section, setSection] = useState("overview");
  const [open, setOpen] = useState<Record<string, boolean>>({ users: true });

  return (
    <>
      <PageHead title="Company" sub="Manage company information, users, financial details, and policies."
        actions={!loading && !company ? <Btn variant="solid" onClick={() => setModal("create")}><Plus className="size-4" />Add Company</Btn> : undefined} />

      {saveErr && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{saveErr}</p>}
      {loading ? <p className="py-10 text-center text-xs text-zinc-500">Loading…</p> : !company ? (
        <Card className="mx-auto mt-6 max-w-md border-blue-100 p-8 text-center">
          <span className="mx-auto grid size-9 place-items-center rounded-full bg-blue-50 text-primary"><Plus className="size-4" /></span>
          <h2 className="mt-3 text-lg font-bold">Set up a company profile</h2>
          <p className="mt-1 text-xs text-zinc-500">Add your organization’s details to manage contacts, users, and financial information for auctions.</p>
          <Btn variant="solid" className="mt-4" onClick={() => setModal("create")}>Create company</Btn>
        </Card>
      ) : (
        <Card className="p-5">
          <h2 className="text-base font-bold">{company.name}</h2><p className="text-xs text-zinc-500">{company.email}</p>
          <div className="mt-4 grid gap-4 md:grid-cols-[200px_1fr]">
            <nav className="rounded-lg border border-zinc-200 p-2 text-xs" aria-label="Company sections">
              {TREE.map((t) => "kids" in t ? (
                <div key={t.id}>
                  <button onClick={() => setOpen({ ...open, [t.id]: !open[t.id] })} aria-expanded={!!open[t.id]} className="flex w-full items-center justify-between rounded px-3 py-2 text-left font-semibold hover:bg-zinc-50">{t.label}<ChevronDown className={`size-3.5 transition ${open[t.id] ? "" : "-rotate-90"}`} /></button>
                  {open[t.id] && t.kids.map(([id, label]) => (
                    <button key={id} onClick={() => setSection(id)} className={`block w-full rounded px-5 py-1.5 text-left ${section === id ? "bg-sky-50 font-semibold text-primary" : "text-zinc-600 hover:bg-zinc-50"}`}>{label}</button>
                  ))}
                </div>
              ) : (
                <button key={t.id} onClick={() => setSection(t.id)} className={`block w-full rounded border px-3 py-2 text-left font-semibold ${section === t.id ? "border-primary text-primary" : "border-transparent hover:bg-zinc-50"}`}>{t.label}</button>
              ))}
            </nav>
            <div>
              {section === "overview" ? (
                <div className="rounded-lg border border-zinc-200 p-4">
                  <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Company Overview</h3><p className="text-xs text-zinc-500">Summary of the selected company’s profile and contact information.</p></div>
                    <button aria-label="Edit company" onClick={() => setModal("edit")} className="rounded border border-zinc-200 p-1.5 text-primary hover:bg-zinc-50"><Pencil className="size-3.5" /></button></div>
                  <dl className="mt-4 grid gap-x-6 gap-y-4 text-xs sm:grid-cols-3">
                    {([["Company Name", company.name], ["Email", company.email], ["Phone", company.phone], ["Address Line 1", company.line1], ["Address Line 2", company.line2], ["City", company.city], ["State", company.state], ["Postal Code", company.postal], ["Country", company.country]] as const).map(([k, v]) => (
                      <div key={k}><dt className="text-zinc-500">{k}</dt><dd className="mt-0.5 font-semibold">{v || "—"}</dd></div>
                    ))}
                  </dl>
                  <div className="mt-4 border-t border-zinc-100 pt-3 text-xs"><p className="text-zinc-500">Full Address</p><p className="mt-0.5 font-semibold">{[company.line1, company.line2, company.city, company.postal, company.country].filter(Boolean).join(", ")}</p></div>
                </div>
              ) : section === "auctioneers" ? <AuctioneersPanel />
                : section === "consignors" ? <Consignors />
                : section === "bank" ? <BankSection />
                : section === "taxes" ? <Taxes />
                : section === "commission" ? <CommissionSection />
                : section === "contacts" ? <Contacts />
                : section === "lotbid" ? <LotBidDetails />
                : section === "locations" ? <Locations />
                : section === "policies" ? <Policies />
                : section === "questionnaire" ? <Questionnaire /> : (
                <div className="grid place-items-center rounded-lg border border-dashed border-zinc-300 py-16 text-center text-xs text-zinc-500">
                  {SECTION_LABELS[section] ?? section} — coming soon.
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      {modal === "create" && <CompanyForm initial={BLANK} title="Create company" cta="Create company" onClose={() => setModal(null)} onSave={(c) => { setCompany(c); setModal(null); }} />}
      {modal === "edit" && company && <CompanyForm initial={company} title="Edit company" cta="Save changes" onClose={() => setModal(null)} onSave={(c) => { setCompany(c); setModal(null); }} />}
    </>
  );
}
