"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { BarChart3, CalendarDays, CheckCircle2, Clock, ExternalLink, LayoutDashboard, ListOrdered, MoreHorizontal, PlayCircle, SlidersHorizontal, TrendingUp, Users, Video, ArrowDownWideNarrow, Timer, Filter } from "lucide-react";
import { Btn, Card, Drawer, PageHead, RefreshBtn, SearchBox } from "@/components/admin/ui";
import { PlaceholderImage } from "@/components/PlaceholderImage";
import { studioAuctions, type StudioAuction } from "@/lib/admin";
import { StudioGate } from "@/lib/studioApi";

/* ---------- date helpers (Studio stores dd/mm/yyyy; Intelligence shows mm/dd/yyyy + UTC+8) ---------- */

const pad = (n: number) => String(n).padStart(2, "0");
const parseDMY = (s: string, time = "12:00") => {
  const [d, t] = s.split(" ");
  const [dd, mm, yy] = d.split("/").map(Number);
  const [h, m] = (t ? t : time).split(":").map(Number);
  return new Date(yy, mm - 1, dd, h, m);
};
const fmtD = (d: Date) => `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${d.getFullYear()}`;
const fmtT = (d: Date) => `${pad(d.getHours() % 12 || 12)}:${pad(d.getMinutes())} ${d.getHours() < 12 ? "am" : "pm"} UTC+8`;

function times(a: StudioAuction) {
  const start = parseDMY(a.starts);
  const end = parseDMY(a.ends);
  return { start, end };
}

const intelligenceAuctions = () => studioAuctions.filter((a) => a.status === "RUNNING" || a.status === "CLOSED");

/* ---------- list ---------- */

const SORTS = [
  ["wrap", "Wrap-ups first", "Sort by ending soonest", ArrowDownWideNarrow],
  ["seq", "Sequence order", "Ascending sequence number", ListOrdered],
] as const;
type SortKey = (typeof SORTS)[number][0];

const MENU = [
  ["reports", "Open reports", ExternalLink], ["kpi-analytics", "KPI analytics", TrendingUp], ["unified-analytics", "Unified analytics", BarChart3],
  ["analytics-dashboard", "Analytics dashboard", LayoutDashboard], ["bidder-analysis", "Bidder analysis", Users], ["recordings", "Recordings", Video],
] as const;

function RowMenu({ a }: { a: StudioAuction }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const down = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    const key = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", down); document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", down); document.removeEventListener("keydown", key); };
  }, [open]);
  const mode = a.status === "CLOSED" ? "?mode=closed" : "";
  return (
    <div ref={ref} className="relative">
      <button aria-label={`Actions for ${a.title}`} aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((v) => !v)} className="grid size-7 place-items-center rounded border border-zinc-200 bg-white hover:bg-zinc-50"><MoreHorizontal className="size-4" /></button>
      {open && (
        <ul role="menu" className="absolute right-0 z-30 mt-1 w-48 rounded-lg border border-zinc-200 bg-white py-1 text-xs shadow-lg">
          {MENU.map(([v, l, Icon]) => (
            <li key={v} role="none"><Link role="menuitem" href={`/admin/auction-intelligence/${a.id}/${v}${mode}`} onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2 hover:bg-zinc-50"><Icon className="size-3.5 text-zinc-500" />{l}</Link></li>
          ))}
        </ul>
      )}
    </div>
  );
}

const COLS = "md:grid-cols-[minmax(0,2.6fr)_minmax(0,0.8fr)_minmax(0,1fr)_minmax(0,1.1fr)_minmax(0,1.1fr)_minmax(0,0.7fr)_52px]";

function IntelligenceViewInner({ initialMode = "RUNNING" }: { initialMode?: "RUNNING" | "CLOSED" }) {
  const [mode, setMode] = useState<"RUNNING" | "CLOSED">(initialMode);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState<SortKey>("wrap");
  const [types, setTypes] = useState<string[]>([]);
  const all = intelligenceAuctions();
  const count = (m: string) => all.filter((a) => a.status === m).length;
  const rows = useMemo(() => all
    .filter((a) => a.status === mode)
    .filter((a) => !types.length || types.includes(a.type))
    .filter((a) => `${a.title} ${a.company} ${a.id}`.toLowerCase().includes(q.toLowerCase()))
    // Order follows the reference design: "Wrap-ups first" lists by end date/time, latest end at the top.
    .sort((a, b) => sort === "seq" ? Number(a.id) - Number(b.id) : +times(b).end - +times(a).end),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  [mode, q, sort, types]);

  const chip = "inline-flex items-center gap-1.5 rounded-full bg-sky-50 px-2.5 py-1 text-xs font-medium text-primary";
  return (
    <>
      <PageHead title="Auction Intelligence" sub="Analyze lifecycle trends and performance across all auctions."
        chips={<><span className={chip}><span className="size-1.5 rounded-full bg-primary" />{all.length} auctions tracked</span><span className={chip}><span className="size-1.5 rounded-full bg-primary" />Viewing: {mode === "RUNNING" ? "Running" : "Closed"}</span></>}
        actions={<RefreshBtn />} />

      <div className="rounded-2xl bg-zinc-100 p-3">
        <div className="grid gap-3 sm:grid-cols-2">
          {([["RUNNING", "Running Auctions", "Monitor live events and bidding activity.", PlayCircle], ["CLOSED", "Closed Auctions", "Review wrap-ups and final summaries.", CheckCircle2]] as const).map(([m, t, s, Icon]) => {
            const on = mode === m;
            return (
              <button key={m} onClick={() => setMode(m)} aria-pressed={on} className={`relative rounded-xl border p-4 text-left transition ${on ? "border-sky-300 bg-sky-50 ring-1 ring-sky-200" : "border-zinc-200 bg-white hover:bg-zinc-50"}`}>
                <span aria-hidden className={`absolute right-3 top-3 grid size-3 place-items-center rounded-full border ${on ? "border-ink" : "border-zinc-300"}`}>{on && <span className="size-1.5 rounded-full bg-ink" />}</span>
                <span className={`grid size-8 place-items-center rounded-md ${on ? "bg-sky-100 text-sky-600" : "bg-zinc-100 text-zinc-500"}`}><Icon className="size-4" /></span>
                <p className="mt-3 text-2xl font-bold leading-none">{count(m)}</p>
                <p className="mt-1.5 text-sm font-semibold">{t}</p><p className="text-[11px] text-zinc-500">{s}</p>
              </button>
            );
          })}
        </div>
      </div>

      <Card className="mt-5">
        <div className="flex items-center justify-between gap-3 p-4">
          <SearchBox value={q} onChange={setQ} placeholder="Search auctions or companies..." className="w-96 max-w-full" />
          <Btn variant="ghost" className="h-8 text-xs" onClick={() => setOpen(true)}><SlidersHorizontal className="size-3.5" />Filter &amp; sort</Btn>
        </div>
        <div className={`hidden gap-3 border-b border-zinc-100 px-4 py-2.5 text-[10px] font-bold uppercase tracking-wide text-zinc-600 md:grid ${COLS}`}>
          <span>Auction</span><span>Lots</span><span>Image</span>
          <span className="flex items-center gap-1.5">Starts<CalendarDays className="size-3 text-zinc-400" /></span>
          <span className="flex items-center gap-1.5">Ends<Clock className="size-3 text-zinc-400" /></span>
          <span>Type</span><span className="text-right">Actions</span>
        </div>
        <ul className="space-y-2 p-3">
          {rows.length === 0 && <li className="py-10 text-center text-xs text-zinc-500">No auctions match.</li>}
          {rows.map((a, i) => {
            const t = times(a);
            return (
              <li key={a.id} className={`grid items-center gap-3 rounded-lg border border-zinc-200 bg-white px-3 py-3 shadow-sm ${COLS}`}>
                <div className="min-w-0">
                  <p className="flex items-start gap-2 text-[13px] font-semibold leading-snug"><span className="mt-0.5 shrink-0 rounded-full bg-ink px-2 py-0.5 text-[9px] font-bold text-white">#{a.id}</span>{a.title}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-zinc-600">{a.company}<span className={`rounded px-1.5 py-px text-[9px] font-semibold ${a.status === "RUNNING" ? "bg-sky-100 text-sky-700" : "bg-zinc-100 text-zinc-600"}`}>{a.status === "RUNNING" ? "Live" : "Closed"}</span></p>
                </div>
                <div><span className="rounded bg-zinc-100 px-1.5 py-0.5 text-[10px] font-semibold">{a.lots} total</span><p className="mt-1 text-[10px] text-zinc-500">{a.active} active</p></div>
                <div className="h-9 w-16 overflow-hidden rounded">{a.images?.[0] ? <img src={a.images[0].url} alt="" className="h-full w-full object-cover" /> : <PlaceholderImage tone={i + Number(a.id) || 1} className="h-full w-full [&_svg]:size-5" />}</div>
                <div><p className="text-[11px] font-semibold">{fmtD(t.start)}</p><p className="text-[10px] text-zinc-500">{fmtT(t.start)}</p></div>
                <div><p className="text-[11px] font-semibold">{fmtD(t.end)}</p><p className="text-[10px] text-zinc-500">{fmtT(t.end)}</p></div>
                <div><span className="inline-block rounded-full bg-sky-100 px-2.5 py-0.5 text-[10px] font-semibold text-sky-800">{a.type}</span></div>
                <div className="flex md:justify-end"><RowMenu a={a} /></div>
              </li>
            );
          })}
        </ul>
      </Card>

      {open && (
        <Drawer title="Filters & sort" sub="Tune the auction intelligence view without leaving the page." onClose={() => setOpen(false)}
          footer={<><Btn variant="outline" className="flex-1" onClick={() => { setSort("wrap"); setTypes([]); }}>Reset</Btn><Btn variant="solid" className="flex-1" onClick={() => setOpen(false)}>Done</Btn></>}>
          <section>
            <div className="mb-3 flex items-start gap-2"><ListOrdered className="mt-0.5 size-3.5 text-zinc-500" /><div><h3 className="text-xs font-bold">Sort focus</h3><p className="text-[10px] text-zinc-500">Choose what should surface first.</p></div></div>
            <div role="radiogroup" aria-label="Sort focus" className="space-y-2">
              {SORTS.map(([v, t, s, Icon]) => (
                <button key={v} role="radio" aria-checked={sort === v} onClick={() => setSort(v)} className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left ${sort === v ? "border-zinc-300 bg-zinc-100" : "border-zinc-200 hover:bg-zinc-50"}`}>
                  <Icon className="size-3.5 shrink-0 text-zinc-500" /><span><span className="block text-xs font-semibold">{t}</span><span className="block text-[10px] text-zinc-500">{s}</span></span>
                </button>
              ))}
            </div>
          </section>
          <section>
            <div className="mb-3 flex items-start gap-2"><Filter className="mt-0.5 size-3.5 text-zinc-500" /><div><h3 className="text-xs font-bold">Auction format</h3><p className="text-[10px] text-zinc-500">Select the auction types to display.</p></div></div>
            <button aria-pressed={types.includes("Timed")} onClick={() => setTypes((t) => (t.includes("Timed") ? [] : ["Timed"]))}
              className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-xs font-medium ${types.includes("Timed") ? "border-primary bg-primary text-white" : "border-zinc-300 bg-white hover:bg-zinc-50"}`}><Timer className="size-3.5" />Timed</button>
          </section>
        </Drawer>
      )}
    </>
  );
}

export const IntelligenceView = (p: { initialMode?: "RUNNING" | "CLOSED" }) => <StudioGate><IntelligenceViewInner {...p} /></StudioGate>;
