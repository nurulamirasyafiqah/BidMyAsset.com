"use client";

import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { Badge, Btn, DataTable, SearchBox, inputCls } from "@/components/admin/ui";
import { loadBids, loadQuestions, reviewQuestion, studio, type BidRow, type QuestionRow, type QuestionStatus } from "@/lib/studioApi";
import type { StudioAuction } from "@/lib/admin";

const when = (iso: string, tz = "Asia/Kuala_Lumpur") =>
  new Date(iso).toLocaleString("en-GB", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).replace(",", "");
const money = (n: number, cur = "MYR") => { try { return new Intl.NumberFormat("en-US", { style: "currency", currency: cur }).format(n); } catch { return `${cur} ${n.toLocaleString()}`; } };

/** Loads a list once per auction; `reload` refetches. Nothing is loaded while the backend is unreachable. */
function useList<T>(fetcher: (id: string) => Promise<T[]>, id: string) {
  const [rows, setRows] = useState<T[] | null>(null);
  const [err, setErr] = useState("");
  const reload = useCallback(() => {
    setErr(""); setRows(null);
    fetcher(id).then(setRows).catch((e) => { setErr(e instanceof Error ? e.message : "Could not load"); setRows([]); });
  }, [fetcher, id]);
  useEffect(() => { if (studio.live) reload(); else setRows([]); }, [reload]);
  return { rows, setRows, err, reload };
}

const Note = ({ children, tone = "zinc" }: { children: ReactNode; tone?: "zinc" | "red" }) =>
  <p role={tone === "red" ? "alert" : "status"} className={`mx-5 my-4 rounded-md px-3 py-2 text-xs ${tone === "red" ? "bg-rose-50 text-rose-700" : "bg-zinc-50 text-zinc-600"}`}>{children}</p>;

const STATE_TONE: Record<string, "blue" | "zinc" | "orange" | "red"> = { LEADING: "blue", OUTBID: "zinc", WON: "blue", LOST: "zinc", REJECTED: "red" };

export function BidHistoryTab({ auction: a }: { auction: StudioAuction }) {
  const { rows, err, reload } = useList<BidRow>(loadBids, a.id);
  const [lot, setLot] = useState("");
  const [q, setQ] = useState("");
  const lots = useMemo(() => [...new Map((rows ?? []).map((b) => [b.lot, b])).values()].sort((x, y) => x.lotNo - y.lotNo), [rows]);
  const shown = (rows ?? []).filter((b) => (!lot || b.lot === lot) && `${b.bidder} ${b.email}`.toLowerCase().includes(q.toLowerCase()));
  const tz = a.tz ?? "Asia/Kuala_Lumpur";

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-4">
        <h2 className="text-sm font-bold">Bid History{rows ? ` (${shown.length}${shown.length !== rows.length ? ` of ${rows.length}` : ""})` : ""}</h2>
        <div className="flex items-center gap-2">
          <select aria-label="Filter by lot" value={lot} onChange={(e) => setLot(e.target.value)} className={`${inputCls} h-8 w-44 text-xs`}>
            <option value="">All lots</option>
            {lots.map((b) => <option key={b.lot} value={b.lot}>Lot {b.lotNo} · {b.lotTitle}</option>)}
          </select>
          <SearchBox value={q} onChange={setQ} placeholder="Search bidders..." className="w-44" />
          <Btn variant="outline" className="h-8 text-xs" onClick={reload}>Refresh</Btn>
        </div>
      </div>
      {!studio.live && <Note>Bid history is only available when Auction Studio is connected to the backend.</Note>}
      {err && <Note tone="red">{err}</Note>}
      {rows === null ? <Note>Loading bids…</Note> : (
        <div className="mt-3"><DataTable head={["Time", "Lot", "Bidder", "Amount", "Status"]} empty={rows.length ? "No bids match the current filter." : "No bids have been placed in this auction yet."}
          rows={shown.map((b) => [
            <span key="t" className="whitespace-nowrap">{when(b.at, tz)}</span>,
            <div key="l"><p className="text-[13px] font-semibold">{b.lotTitle}</p><p className="text-zinc-500">Lot {b.lotNo}</p></div>,
            <div key="b"><p className="text-[13px] font-semibold">{b.bidder}</p><p className="text-zinc-500">{b.email}</p></div>,
            <b key="a">{money(b.amount, a.currency)}</b>,
            <Badge key="s" tone={STATE_TONE[b.state] ?? "zinc"}>{b.state ? b.state[0] + b.state.slice(1).toLowerCase() : "—"}</Badge>,
          ])} /></div>
      )}
      {a.hideBidders && rows && rows.length > 0 && <p className="px-5 pb-3 text-[11px] text-zinc-500">This auction hides bidder details from other bidders; staff always see them here.</p>}
    </>
  );
}

const STATUS_TONE: Record<QuestionStatus, "orange" | "blue" | "zinc"> = { PENDING: "orange", PUBLISHED: "blue", HIDDEN: "zinc" };
const STATUS_LABEL: Record<QuestionStatus, string> = { PENDING: "Needs review", PUBLISHED: "Published", HIDDEN: "Hidden" };

function QuestionCard({ item, tz, onSaved }: { item: QuestionRow; tz: string; onSaved: (q: QuestionRow) => void }) {
  const [answer, setAnswer] = useState(item.answer);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const act = async (status: QuestionStatus) => {
    setBusy(true); setErr("");
    try { await reviewQuestion(item.id, answer.trim(), status); onSaved({ ...item, answer: answer.trim(), status }); }
    catch (e) { setErr(e instanceof Error ? e.message : "Could not save"); }
    setBusy(false);
  };
  const dirty = answer.trim() !== item.answer;
  return (
    <li className="rounded-lg border border-zinc-200 p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <p className="text-[11px] text-zinc-500">Lot {item.lotNo} · {item.lotTitle} · {item.asker}{item.email ? ` (${item.email})` : ""} · {when(item.at, tz)}</p>
        <Badge tone={STATUS_TONE[item.status]}>{STATUS_LABEL[item.status]}</Badge>
      </div>
      <p className="mt-2 whitespace-pre-wrap text-[13px] font-semibold">{item.question}</p>
      <label className="mt-3 block text-[11px] font-semibold text-zinc-600">Answer
        <textarea value={answer} onChange={(e) => setAnswer(e.target.value)} rows={3} maxLength={4000} placeholder="Write the answer bidders will see…" className={`${inputCls} mt-1 w-full py-2 text-xs font-normal`} />
      </label>
      {err && <p role="alert" className="mt-2 text-xs text-rose-600">{err}</p>}
      <div className="mt-3 flex flex-wrap gap-2">
        <Btn className="h-8 text-xs" disabled={busy || !answer.trim() || (item.status === "PUBLISHED" && !dirty)} onClick={() => act("PUBLISHED")}>{item.status === "PUBLISHED" ? "Update published answer" : "Publish answer"}</Btn>
        {item.status !== "HIDDEN" && <Btn variant="outline" className="h-8 text-xs" disabled={busy} onClick={() => act("HIDDEN")}>Hide</Btn>}
        {item.status !== "PENDING" && <Btn variant="outline" className="h-8 text-xs" disabled={busy} onClick={() => act("PENDING")}>Move back to review</Btn>}
        {item.status === "PENDING" && dirty && <Btn variant="outline" className="h-8 text-xs" disabled={busy} onClick={() => act("PENDING")}>Save draft</Btn>}
      </div>
    </li>
  );
}

export function QuestionsTab({ auction: a }: { auction: StudioAuction }) {
  const { rows, setRows, err, reload } = useList<QuestionRow>(loadQuestions, a.id);
  const [flt, setFlt] = useState<"ALL" | QuestionStatus>("ALL");
  const count = (s: "ALL" | QuestionStatus) => (rows ?? []).filter((x) => s === "ALL" || x.status === s).length;
  const shown = (rows ?? []).filter((x) => flt === "ALL" || x.status === flt);

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-4">
        <h2 className="text-sm font-bold">Questions &amp; Review</h2>
        <div className="flex items-center gap-2">
          <div className="flex overflow-hidden rounded-md border border-zinc-200 text-[11px] font-semibold">
            {([["ALL", "All"], ["PENDING", "Needs review"], ["PUBLISHED", "Published"], ["HIDDEN", "Hidden"]] as const).map(([k, label]) =>
              <button key={k} onClick={() => setFlt(k)} aria-pressed={flt === k} className={`px-2.5 py-1 ${flt === k ? "bg-zinc-100" : "bg-white text-zinc-500 hover:bg-zinc-50"}`}>{label} <span className="text-zinc-400">{count(k)}</span></button>)}
          </div>
          <Btn variant="outline" className="h-8 text-xs" onClick={reload}>Refresh</Btn>
        </div>
      </div>
      {!studio.live && <Note>Questions are only available when Auction Studio is connected to the backend.</Note>}
      {err && <Note tone="red">{err}</Note>}
      {rows === null ? <Note>Loading questions…</Note> : shown.length === 0 ? (
        <Note>{rows.length ? "No questions match this filter." : "No questions have been asked about this auction's lots yet."}</Note>
      ) : (
        <ul className="space-y-3 p-5">
          {shown.map((x) => <QuestionCard key={x.id} item={x} tz={a.tz ?? "Asia/Kuala_Lumpur"} onSaved={(n) => setRows((l) => (l ?? []).map((y) => (y.id === n.id ? n : y)))} />)}
        </ul>
      )}
    </>
  );
}
