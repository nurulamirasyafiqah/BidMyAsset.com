"use client";

import { trackAdmin } from "@/lib/trackAdmin";
import { withMinSpin } from "@/lib/minSpin";
import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { ArrowDownWideNarrow, ArrowUpNarrowWide, Bell, CalendarDays, CheckCheck, Clock, FilterX, Inbox, Info, Monitor, RefreshCw, SlidersHorizontal, Sparkles, User } from "lucide-react";
import Link from "next/link";
import { Btn, Card, DataTable, Drawer, PageHead, RefreshBtn, SearchBox } from "@/components/admin/ui";
import { useAdminNotices } from "@/components/admin/AdminShell";
import { ACTION_TYPES, type ActivityEntry } from "@/lib/userActivity";

const TIMELINES = [["today", "Today", "Activities from today only", 0], ["7", "Last 7 days", "Activities from the past week", 7], ["15", "Last 15 days", "Activities from the past 2 weeks", 15], ["30", "Last 30 days", "Activities from the past month", 30]] as const;
const SORTS = [["recent", "Most recent", "Latest activity first", Clock], ["oldest", "Oldest first", "Start from earliest events", ArrowUpNarrowWide], ["highest", "Highest bid value", "Surface largest bid entries", ArrowDownWideNarrow], ["lowest", "Lowest bid value", "Focus on smaller bid interactions", ArrowUpNarrowWide]] as const;
type TlKey = (typeof TIMELINES)[number][0];
type SortKey = (typeof SORTS)[number][0];
type Filters = { tl: TlKey; sort: SortKey; actions: string[]; devices: string[] };
const DEFAULTS: Filters = { tl: "7", sort: "recent", actions: [], devices: [] };

const p2 = (n: number) => String(n).padStart(2, "0");
const h12 = (d: Date) => d.getHours() % 12 || 12;
const fmtDate = (iso: string) => { const d = new Date(iso); return `${p2(d.getMonth() + 1)}/${p2(d.getDate())}/${d.getFullYear()} ${p2(h12(d))}:${p2(d.getMinutes())} ${d.getHours() < 12 ? "am" : "pm"}`; };
const fmtRefreshed = (d: Date) => `${["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][d.getMonth()]} ${d.getDate()}, ${h12(d)}:${p2(d.getMinutes())} ${d.getHours() < 12 ? "AM" : "PM"}`;
const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? "" : "s"} ago`;
function relative(iso: string) {
  const m = Math.floor((Date.now() - +new Date(iso)) / 60000);
  if (m < 1) return "Just now";
  if (m < 60) return plural(m, "minute");
  const h = Math.floor(m / 60);
  return h < 24 ? plural(h, "hour") : plural(Math.floor(h / 24), "day");
}
const inTimeline = (e: ActivityEntry, days: number) => (days === 0 ? new Date(e.at).toDateString() === new Date().toDateString() : +new Date(e.at) >= Date.now() - days * 86400000);
const money = (n: number, cur: string) => `${cur ? cur + " " : ""}${n.toLocaleString("en-US")}`;
const POSITIVE = new Set(["Logged In", "Account Created", "Register Auction", "Add Watchlist", "Place Bid", "Update Profile", "Change Password", "Export Data", "Admin Action"]);

function Section({ icon: Icon, title, sub, children }: { icon: typeof Clock; title: string; sub: string; children: ReactNode }) {
  return (
    <section>
      <div className="mb-3 flex items-start gap-2"><Icon className="mt-0.5 size-3.5 text-zinc-500" /><div><h3 className="text-xs font-bold">{title}</h3><p className="text-[10px] text-zinc-500">{sub}</p></div></div>
      {children}
    </section>
  );
}
function OptionRow({ icon: Icon, title, sub, on, onClick }: { icon: typeof Clock; title: string; sub: string; on: boolean; onClick: () => void }) {
  return (
    <button role="radio" aria-checked={on} onClick={onClick} className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition ${on ? "border-zinc-300 bg-zinc-100 shadow-sm" : "border-zinc-200 bg-white hover:bg-zinc-50"}`}>
      <Icon className="size-3.5 shrink-0 text-zinc-500" /><span><span className="block text-xs font-semibold">{title}</span><span className="block text-[10px] text-zinc-500">{sub}</span></span>
    </button>
  );
}
function CountChip({ label, count, on, onClick, icon: Icon }: { label: string; count: number; on: boolean; onClick: () => void; icon?: typeof Clock }) {
  return (
    <button aria-pressed={on} onClick={onClick} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${on ? "border-primary bg-primary text-white" : "border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-50"}`}>
      {Icon && <Icon className="size-3" />}{label}<span className={`text-[10px] ${on ? "text-white/80" : "text-zinc-500"}`}>{count}</span>
    </button>
  );
}

export function ActivityView() {
  const [entries, setEntries] = useState<ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(null);
  const load = useCallback(async () => {
    setLoading(true); setErr("");
    try {
      const res = await withMinSpin(() => fetch("/api/admin/user-activity", { cache: "no-store" }));
      const j = (await res.json()) as { items?: ActivityEntry[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setEntries(j.items ?? []); setRefreshedAt(new Date());
    } catch (e) { setErr(e instanceof Error ? e.message : "Failed to load"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState<Filters>(DEFAULTS);
  const [draft, setDraft] = useState<Filters>(DEFAULTS);
  const tlOf = (k: TlKey) => TIMELINES.find(([v]) => v === k)!;
  const active = 1 + (f.sort !== "recent" ? 1 : 0) + (f.actions.length ? 1 : 0) + (f.devices.length ? 1 : 0);

  // Timeline is the "server" query; everything after it is a client-side filter.
  const base = useMemo(() => entries.filter((e) => inTimeline(e, tlOf(f.tl)[3])), [entries, f.tl]); // eslint-disable-line react-hooks/exhaustive-deps
  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const amt = (e: ActivityEntry) => e.amount ?? 0;
    return base
      .filter((e) => !f.actions.length || f.actions.includes(e.action))
      .filter((e) => !f.devices.length || f.devices.includes(e.device))
      .filter((e) => !needle || `${e.user} ${e.email} ${e.action} ${e.category} ${e.details} ${e.ip}`.toLowerCase().includes(needle))
      .sort((a, b) => f.sort === "oldest" ? +new Date(a.at) - +new Date(b.at)
        : f.sort === "highest" ? amt(b) - amt(a) || +new Date(b.at) - +new Date(a.at)
        : f.sort === "lowest" ? amt(a) - amt(b) || +new Date(b.at) - +new Date(a.at)
        : +new Date(b.at) - +new Date(a.at));
  }, [base, f, q]);

  const stat = (list: ActivityEntry[]) => ({
    lots: new Set(list.filter((e) => e.lotId).map((e) => e.lotId)).size,
    users: new Set(list.map((e) => e.email)).size,
    auctions: new Set(list.filter((e) => e.auctionId).map((e) => e.auctionId)).size,
    volume: list.reduce((s, e) => s + (e.amount ?? 0), 0),
  });
  const now = stat(rows), all = stat(base);
  const countBy = (key: "action" | "device") => base.reduce<Record<string, number>>((m, e) => (e[key] ? ((m[e[key]] = (m[e[key]] ?? 0) + 1), m) : m), {});
  const volLabel = (list: ActivityEntry[]) => {
    const bids = list.filter((e) => e.amount !== null);
    const cur = new Set(bids.map((e) => e.currency));
    return cur.size > 1 ? "Mixed" : money(bids.reduce((sum, e) => sum + (e.amount ?? 0), 0), [...cur][0] ?? "");
  };
  const actionCounts = countBy("action"), deviceCounts = countBy("device");
  const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  const draftActive = 1 + (draft.sort !== "recent" ? 1 : 0) + (draft.actions.length ? 1 : 0) + (draft.devices.length ? 1 : 0);

  const activeChips = [tlOf(f.tl)[1], ...(f.sort !== "recent" ? [SORTS.find(([v]) => v === f.sort)![1]] : []), ...f.actions, ...f.devices];
  return (
    <>
      <PageHead title="User Activity Analytics" sub="Track all platform activity in real-time. Monitor user interactions, bidding patterns, and engagement metrics across the entire system."
        chips={<><span className="inline-flex items-center gap-1.5 rounded-full bg-sky-50 px-3 py-1.5 text-xs font-medium text-primary"><span className="size-1.5 rounded-full bg-primary" />Showing {rows.length} of {base.length} entries</span><span className="text-[10px]">Last refreshed {refreshedAt ? fmtRefreshed(refreshedAt) : "—"}</span></>}
        actions={<Btn disabled={loading} onClick={() => void load()}><RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />Refresh</Btn>} />

      <div className="rounded-2xl bg-zinc-100 p-3">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {([["Lots touched", now.lots, `of ${all.lots}`], ["Unique users", now.users, `of ${all.users}`], ["Auctions touched", now.auctions, `of ${all.auctions}`], ["Bid volume", volLabel(rows), `of ${volLabel(base)}`]] as const).map(([l, v, s]) => (
            <Card key={l} className="rounded-2xl p-5"><p className="text-xs text-zinc-700">{l}</p><p className="mt-2 text-[28px] font-semibold leading-none">{v}</p><p className="mt-2 text-[10px] text-rose-800">{s}</p></Card>
          ))}
        </div>
      </div>

      <Card className="mt-5 rounded-2xl">
        <div className="px-5 pt-5"><h2 className="text-sm font-bold">Recent activity</h2></div>
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-4">
          <SearchBox value={q} onChange={setQ} placeholder="Search users, actions, or IP addresses..." className="w-96 max-w-full" />
          <div className="flex items-center gap-2">
            <Btn variant="ghost" className="h-9 text-xs" onClick={() => { setDraft(f); setOpen(true); }}><SlidersHorizontal className="size-3.5" />Filter &amp; sort<span className="grid min-w-4 place-items-center rounded bg-zinc-200 px-1 text-[10px]">{active}</span></Btn>
            <button onClick={() => { setF(DEFAULTS); setQ(""); }} className="inline-flex h-9 items-center gap-1.5 rounded-md px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50"><FilterX className="size-3.5" />Reset</button>
          </div>
        </div>
        <div className="mx-5 mt-3 flex flex-wrap items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-4 py-3 text-xs">
          <span className="font-medium">Active:</span>{activeChips.map((c) => <span key={c} className="rounded border border-zinc-200 bg-zinc-100 px-2 py-0.5 text-[11px]">{c}</span>)}
        </div>
        <div className="mt-5 overflow-x-auto border-t border-zinc-100">
          <table className="w-full min-w-[900px] text-left text-xs">
            <thead className="bg-zinc-50 text-[10px] font-bold uppercase tracking-wide text-zinc-700">
              <tr>{["User", "Action", "Category", "Details", "Device", "Amount", "Date"].map((h) => <th key={h} className="px-5 py-3.5">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-12 text-center text-zinc-500">{err ? <span role="alert" className="text-rose-600">{err}</span> : loading ? "Loading…" : "No activity matches these filters."}</td></tr>}
              {rows.map((e) => (
                <tr key={e.id} className="hover:bg-zinc-50">
                  <td className="px-5 py-3"><div className="flex items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-full border border-zinc-200 bg-zinc-50 text-zinc-500"><User className="size-4" /></span><div><p className="text-[13px] font-semibold leading-tight">{e.user}</p><p className="text-[10px] text-zinc-500">{e.email}</p></div></div></td>
                  <td className="px-2 py-3"><span className={`inline-block whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[10px] font-medium ${POSITIVE.has(e.action) ? "border-sky-300 bg-sky-50 text-sky-700" : "border-zinc-300 bg-white text-zinc-700"}`}>{e.action}</span></td>
                  <td className="px-2 py-3"><span className="inline-block whitespace-nowrap rounded-full bg-zinc-100 px-2.5 py-0.5 text-[10px] font-medium text-zinc-700">{e.category}</span></td>
                  <td className="px-2 py-3 text-[12px] text-zinc-700">{e.details}</td>
                  <td className="px-2 py-3">{e.device ? <span className="inline-flex items-center gap-1.5 rounded-full border border-zinc-200 bg-zinc-100 px-2.5 py-0.5 text-[10px] font-medium text-zinc-700"><Monitor className="size-3" />{e.device}</span> : "—"}</td>
                  <td className="px-2 py-3 pl-5 text-zinc-700">{e.amount === null ? "—" : money(e.amount, e.currency)}</td>
                  <td className="whitespace-nowrap px-5 py-3"><p className="text-[12px] font-medium">{fmtDate(e.at)}</p><p className="text-[10px] text-zinc-500">{relative(e.at)}</p></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {open && (
        <Drawer title="Filters & sort" sub="Tune the activity feed without leaving the analytics workspace." onClose={() => setOpen(false)}
          footer={<div className="w-full space-y-3">
            <div className="flex gap-2"><Btn variant="outline" className="flex-1" onClick={() => setOpen(false)}>Cancel</Btn><Btn variant="solid" className="flex-1" onClick={() => { setF(draft); setOpen(false); }}>Apply</Btn></div>
            <button onClick={() => setDraft(DEFAULTS)} className="mx-auto flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-ink"><FilterX className="size-3.5" />Clear all filters</button>
          </div>}>
          <div className="flex items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2 text-[11px]"><Sparkles className="size-3.5 text-zinc-500" /><span className="font-medium">{draftActive} active</span><span className="text-zinc-400">•</span><span className="text-zinc-600">{tlOf(draft.tl)[1]}</span></div>
          <Section icon={CalendarDays} title="Timeline" sub="Changing timeline fetches new data from the server.">
            <div role="radiogroup" aria-label="Timeline" className="space-y-2">{TIMELINES.map(([v, t, s]) => <OptionRow key={v} icon={CalendarDays} title={t} sub={s} on={draft.tl === v} onClick={() => setDraft({ ...draft, tl: v })} />)}</div>
            <p className="mt-2 flex items-start gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2 text-[10px] text-zinc-600"><Info className="mt-px size-3 shrink-0 text-zinc-400" />Client-side filters update immediately. Timeline changes require a refresh from the API.</p>
          </Section>
          <Section icon={Clock} title="Sort focus" sub="Choose what should surface first.">
            <div role="radiogroup" aria-label="Sort focus" className="space-y-2">{SORTS.map(([v, t, s, Icon]) => <OptionRow key={v} icon={Icon} title={t} sub={s} on={draft.sort === v} onClick={() => setDraft({ ...draft, sort: v })} />)}</div>
          </Section>
          <Section icon={Sparkles} title="Action types" sub="Select the events to highlight.">
            <div className="flex flex-wrap gap-2">
              {[...ACTION_TYPES].filter((a) => actionCounts[a]).sort((a, b) => actionCounts[b] - actionCounts[a]).map((a) => <CountChip key={a} label={a} count={actionCounts[a]} on={draft.actions.includes(a)} onClick={() => setDraft({ ...draft, actions: toggle(draft.actions, a) })} />)}
            </div>
          </Section>
          <Section icon={Monitor} title="Device focus" sub="Zero in on a specific client type.">
            <div className="flex flex-wrap gap-2">
              {Object.entries(deviceCounts).map(([d, n]) => <CountChip key={d} icon={Monitor} label={d} count={n} on={draft.devices.includes(d)} onClick={() => setDraft({ ...draft, devices: toggle(draft.devices, d) })} />)}
            </div>
          </Section>
        </Drawer>
      )}
    </>
  );
}

export function AdminNotificationsView() {
  const { notices, unread, markAll, markOne } = useAdminNotices();
  const groups = useMemo(() => {
    const today = new Date().toDateString();
    const m = new Map<string, typeof notices>();
    for (const n of notices) {
      const d = new Date(n.at);
      const key = d.toDateString() === today ? "TODAY" : d.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });
      m.set(key, [...(m.get(key) ?? []), n]);
    }
    return [...m.entries()];
  }, [notices]);
  return (
    <Card className="mx-auto max-w-3xl">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-zinc-100 p-5">
        <div className="flex items-start gap-3">
          <span className="grid size-10 place-items-center rounded-lg bg-blue-50 text-primary"><Bell className="size-5" /></span>
          <div><h1 className="text-lg font-bold">Notifications</h1><p className="text-xs text-zinc-500">Stay on top of auction activity across your organization.</p>
            <p className="mt-1 text-xs font-semibold text-primary">{unread ? `${unread} unread notifications` : "All caught up"}</p></div>
        </div>
        <div className="flex gap-2"><Link href="/admin/settings" className="inline-flex h-8 items-center rounded-md border border-zinc-200 px-3 text-xs font-semibold text-zinc-700 hover:bg-zinc-50">Settings</Link><Btn className="h-8 text-xs" onClick={markAll} disabled={!unread}><CheckCheck className="size-3.5" />Mark all read</Btn><RefreshBtn small /></div>
      </div>
      {notices.length === 0 ? (
        <div className="grid place-items-center py-16 text-center"><span className="grid size-9 place-items-center rounded-full bg-zinc-100"><Bell className="size-4 text-zinc-500" /></span><p className="mt-3 text-sm font-bold">No notifications yet</p><p className="text-xs text-zinc-500">You’ll see updates about auction registrations, questions, and document changes here.</p></div>
      ) : (
        <div className="space-y-4 p-5">
          {groups.map(([day, list]) => (
            <section key={day}>
              <p className="mb-3 flex items-center gap-3 text-[10px] font-semibold tracking-widest text-zinc-500"><span className="h-px flex-1 bg-zinc-200" />{day}<span className="h-px flex-1 bg-zinc-200" /></p>
              <ul className="space-y-3">
                {list.map((n) => (
                  <li key={n.id} className={`flex gap-3 rounded-lg border border-zinc-200 bg-white p-3.5 ${n.read ? "border-l-zinc-200" : "border-l-4 border-l-amber-400"}`}>
                    <span className="grid size-8 shrink-0 place-items-center rounded-full bg-blue-50 text-primary"><Bell className="size-4" /></span>
                    <div className="min-w-0 flex-1 text-xs">
                      <div className="flex items-start justify-between gap-3"><p className="text-[13px] font-bold">{n.title}</p><span className="shrink-0 font-semibold text-primary">{new Date(n.at).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }).toLowerCase()}</span></div>
                      <p className="mt-0.5 text-zinc-600">{n.body}</p>
                      <Link href={n.link ?? "/admin/bidders"} onClick={() => markOne(n.id)} className="mt-1.5 inline-block font-semibold text-primary">View details →</Link>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </Card>
  );
}

type CrmType = "contact" | "subscription" | "career";
type CrmEntry = { type: CrmType; id: string; name: string; email: string; phone: string; subject: string; message: string; document: string; created: string };
const CRM_FILTERS = [["all", "All Types"], ["contact", "Contact Us"], ["subscription", "Subscription"], ["career", "Career"]] as const;
const CRM_LABEL: Record<CrmType, string> = { contact: "Contact Us", subscription: "Subscription", career: "Career" };
const na = (v?: string) => (v && v.trim() ? v : "N/A");

export function CrmHubView() {
  const [filter, setFilter] = useState<(typeof CRM_FILTERS)[number][0]>("all");
  const [items, setItems] = useState<CrmEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const res = await withMinSpin(() => fetch("/api/admin/crm", { cache: "no-store" }));
      const j = (await res.json()) as { items?: CrmEntry[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setItems(j.items ?? []);
    } catch (e) { setError(e instanceof Error ? e.message : "Failed to load"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const rows = useMemo(() => items.filter((e) => filter === "all" || e.type === filter), [items, filter]);
  const title = filter === "all" ? "CRM Hub" : `CRM Hub (${CRM_FILTERS.find((f) => f[0] === filter)![1].toUpperCase()})`;
  return (
    <>
      <PageHead title={title} sub="View contact, subscription, and career submissions in one place."
        actions={<>
          <select aria-label="Filter by type" value={filter} onChange={(e) => { setFilter(e.target.value as typeof filter); trackAdmin(`Filtered CRM Hub: ${CRM_FILTERS.find((f) => f[0] === e.target.value)?.[1]}`); }} className="h-9 rounded-md border border-zinc-300 bg-white px-3 text-sm focus:border-primary focus:outline-none">
            {CRM_FILTERS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          <Btn onClick={() => { trackAdmin("Refreshed CRM Hub"); void load(); }} disabled={loading}><RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />Refresh</Btn>
        </>} />
      <Card className="p-4">
        <h2 className="mb-3 text-sm font-bold">Entries ({rows.length})</h2>
        {error ? <p className="rounded-lg border border-rose-200 bg-rose-50 py-8 text-center text-xs text-rose-600">{error}</p>
          : rows.length === 0 ? <div className="grid place-items-center rounded-lg border border-zinc-200 py-10 text-center"><Inbox className="size-5 text-zinc-400" /><p className="mt-2 text-xs font-bold">{loading ? "Loading…" : "No entries found"}</p>{!loading && <p className="mt-1 text-xs text-zinc-500">There are no CRM Hub entries yet.</p>}</div>
          : <DataTable head={["Type", "ID", "Name", "Email", "Phone", "Subject", "Message", "Document"]} rows={rows.map((e) => [
              CRM_LABEL[e.type], <span key="id" title={e.id}>{e.id}</span>, na(e.name),
              <a key="m" href={`mailto:${e.email}`} className="text-primary hover:underline">{e.email}</a>,
              na(e.phone), <span key="s" className="block max-w-[180px]">{na(e.subject)}</span>,
              <span key="g" title={e.message} className="block max-w-[260px] truncate">{na(e.message)}</span>,
              e.document ? <a key="d" href={`/api/pb/${e.document.replace(/^\//, "")}`} target="_blank" rel="noreferrer" className="text-primary hover:underline">View</a> : "N/A",
            ])} />}
      </Card>
    </>
  );
}

export { ProfileView } from "@/components/admin/ProfileView";
