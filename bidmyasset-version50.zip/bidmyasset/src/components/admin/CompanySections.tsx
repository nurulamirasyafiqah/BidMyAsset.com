"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowUp, FileText, MapPin, MoreVertical, Pencil, Plus, SlidersHorizontal, Trash2 } from "lucide-react";
import { FEE_DEFS, feeValueError, type Fee, type FeeKind } from "@/lib/auctionHouse";
import { fetchHouse, postHouse } from "@/lib/houseClient";
import { parseFee } from "@/lib/auctionHouse";
import { loadCompany, saveCompany, usePersisted } from "@/lib/companyClient";
import { Avatar, Badge, Btn, Card, DataTable, Field, inputCls, Modal, RefreshBtn, SearchBox, Toggle, useConfirm } from "@/components/admin/ui";

/* ---------- shared helpers ---------- */

export function SectionHead({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="mb-3 rounded-lg border border-zinc-200 bg-zinc-50 px-4 py-2.5">
      <p className="text-sm font-bold">{title}</p>
      <p className="text-xs text-zinc-500">{sub}</p>
    </div>
  );
}

function CardHead({ title, sub, actions }: { title: string; sub: string; actions?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div><h3 className="text-base font-bold">{title}</h3><p className="text-xs text-zinc-500">{sub}</p></div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

const IconBtn = ({ label, onClick, danger, children }: { label: string; onClick: () => void; danger?: boolean; children: React.ReactNode }) => (
  <button aria-label={label} onClick={onClick}
    className={`inline-flex items-center gap-1.5 rounded px-1.5 py-1 text-xs font-semibold hover:bg-zinc-50 ${danger ? "text-rose-600" : "text-primary"}`}>{children}</button>
);

/** The saved company name (empty until a company profile exists). */
function useCompanyName() {
  const [co] = usePersisted<{ name?: string } | null>("company", null);
  return co?.name?.trim() || "Your company";
}

const uid = () => Math.random().toString(36).slice(2, 9);
const num = (v: string) => (v.trim() === "" ? NaN : Number(v));
const validPct = (v: string) => { const n = num(v); return !Number.isNaN(n) && n >= 0 && n <= 100; };

/* ---------- Consignors ---------- */

type Consignor = { id: string; first: string; last: string; email: string; commission: string; registered: string; status: "Onboarded" | "Invited"; disabled?: boolean; invitedAt?: string };
const today = () => { const d = new Date(); return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}/${d.getFullYear()}`; };

export function Consignors() {
  const { confirm, dialog } = useConfirm();
  const [rows, setRows] = usePersisted<Consignor[]>("consignors", []);
  const [q, setQ] = useState("");
  const [add, setAdd] = useState(false);
  const [menu, setMenu] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "Onboarded" | "Invited">("all");
  const [sort, setSort] = useState<"name" | "newest">("name");
  const [showFilters, setShowFilters] = useState(false);
  const [f, setF] = useState({ first: "", last: "", email: "", commission: "" });
  const [editId, setEditId] = useState<string | null>(null); // null = adding a new consignor
  const [err, setErr] = useState("");
  const [focus, setFocus] = useState<"first" | "commission">("first");
  const [toast, setToast] = useState<{ ok: boolean; text: string } | null>(null);
  const flash = (ok: boolean, text: string) => { setToast({ ok, text }); setTimeout(() => setToast(null), 4000); };

  const visible = useMemo(() => {
    const s = q.toLowerCase();
    const r = rows.filter((c) => (filter === "all" || c.status === filter) && (!s || `${c.first} ${c.last} ${c.email}`.toLowerCase().includes(s)));
    return sort === "name" ? [...r].sort((a, b) => a.first.localeCompare(b.first)) : [...r].reverse();
  }, [rows, q, filter, sort]);

  const invite = () => {
    if (!f.first.trim() || !f.last.trim()) return setErr("First and last name are required.");
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setErr("Enter a valid email address.");
    if (f.commission.trim() !== "" && !validPct(f.commission)) return setErr("Commission must be a number between 0 and 100.");
    if (rows.some((c) => c.id !== editId && c.email.toLowerCase() === f.email.trim().toLowerCase())) return setErr("A consignor with this email already exists.");
    const commission = f.commission.trim();
    if (editId) setRows((l) => l.map((c) => (c.id === editId ? { ...c, first: f.first.trim(), last: f.last.trim(), commission } : c)));
    else setRows([...rows, { id: uid(), first: f.first.trim(), last: f.last.trim(), email: f.email.trim(), commission, registered: today(), status: "Invited" }]);
    closeAdd();
  };
  const closeAdd = () => { setAdd(false); setEditId(null); setFocus("first"); setF({ first: "", last: "", email: "", commission: "" }); setErr(""); };
  const openEdit = (c: Consignor, field: "first" | "commission" = "first") => { setFocus(field); setEditId(c.id); setF({ first: c.first, last: c.last, email: c.email, commission: c.commission }); setErr(""); setAdd(true); };
  /** No email is sent: copy the sign-up link for the admin to share, and remember when it was issued. */
  const resend = async (c: Consignor) => {
    const link = `${window.location.origin}${c.status === "Invited" ? "/register" : "/login"}`;
    try { await navigator.clipboard.writeText(link); }
    catch { return flash(false, `Couldn't copy automatically. Share this link: ${link}`); }
    setRows((l) => l.map((r) => (r.id === c.id ? { ...r, invitedAt: today() } : r)));
    flash(true, `${c.status === "Invited" ? "Registration" : "Login"} link copied. Send it to ${c.email}.`);
  };

  return (
    <>
      <SectionHead title="Consignors" sub="Maintain consignor contacts and account access." />
      <Card className="p-4">
        <CardHead title="Consignors" sub="Manage consignor onboarding, activation, and permissions."
          actions={<>
            <RefreshBtn small />
            <Btn variant="solid" className="h-8 text-xs" onClick={() => setAdd(true)}><Plus className="size-3.5" />Add Consignor</Btn>
          </>} />
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {([["Total", rows.length, "All consignors under this company"], ["Onboarded", rows.filter((c) => c.status === "Onboarded").length, "Active consignors in the platform"],
            ["Invited", rows.filter((c) => c.status === "Invited").length, "Awaiting onboarding completion"], ["Active", rows.filter((c) => c.status === "Onboarded" && !c.disabled).length, "Enabled accounts"]] as const).map(([l, n, s]) => (
            <div key={l} className="rounded-lg bg-zinc-50 p-3"><p className="text-[10px] font-bold uppercase text-zinc-500">{l}</p><p className="text-xl font-semibold">{n}</p><p className="text-[10px] text-zinc-500">{s}</p></div>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <SearchBox value={q} onChange={setQ} placeholder="Search consignors..." className="w-72" />
          <Btn variant="outline" className="h-8 text-xs" onClick={() => setShowFilters(!showFilters)}><SlidersHorizontal className="size-3.5" />Filters &amp; sort</Btn>
        </div>
        {showFilters && (
          <div className="mt-2 flex flex-wrap items-center gap-4 rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-xs">
            <label className="flex items-center gap-2 font-semibold">Status
              <select className="h-8 rounded-md border border-zinc-300 bg-white px-2 font-normal" value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)}>
                <option value="all">All</option><option value="Onboarded">Onboarded</option><option value="Invited">Invited</option></select></label>
            <label className="flex items-center gap-2 font-semibold">Sort by
              <select className="h-8 rounded-md border border-zinc-300 bg-white px-2 font-normal" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}>
                <option value="name">Name (A–Z)</option><option value="newest">Newest first</option></select></label>
          </div>
        )}
        {toast && <p role="status" className={`mt-3 rounded-md px-3 py-2 text-xs ${toast.ok ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{toast.text}</p>}
        <p className="my-2 text-[11px] text-zinc-500">Showing {visible.length} consignor{visible.length === 1 ? "" : "s"}</p>
        <DataTable head={["Name", "Email", "Commission", "Registered", "Status", "Actions"]} empty="No consignors match your search."
          rows={visible.map((c) => [
            <span key="n" className="flex items-center gap-2 font-semibold"><Avatar name={`${c.first} ${c.last}`} size="size-7" />{c.first} {c.last}</span>,
            c.email,
            c.commission ? `${c.commission}%` : <span key="cm" className="text-[11px] text-zinc-400">No rate configured</span>,
            c.registered,
            <span key="s" className="flex flex-col items-start gap-0.5"><Badge tone={c.status === "Onboarded" ? "blue" : "amber"}>{c.status}</Badge>{c.status === "Invited" && c.invitedAt && <span className="text-[10px] text-zinc-400">Link shared {c.invitedAt}</span>}</span>,
            <span key="a" className="relative flex items-center gap-2">
              <Toggle on={!c.disabled} onChange={async (v) => { if (!v && !(await confirm({ title: "Disable this consignor?", body: `${c.first} ${c.last} will be signed out and won’t be able to log in or use the site until re-enabled.`, confirmLabel: "Disable" }))) return; setRows((l) => l.map((r) => (r.id === c.id ? { ...r, disabled: !v } : r))); }} label={`Enable ${c.first} ${c.last}`} />
              <button aria-label="More actions" onClick={() => setMenu(menu === c.id ? null : c.id)} className="rounded p-1 text-zinc-500 hover:bg-zinc-100"><MoreVertical className="size-4" /></button>
              {menu === c.id && (
                <div className="absolute right-0 top-7 z-10 w-48 rounded-md border border-zinc-200 bg-white py-1 text-xs shadow-lg">
                  <button className="block w-full px-3 py-1.5 text-left hover:bg-zinc-50" onClick={() => { setMenu(null); openEdit(c, "commission"); }}>{c.commission ? "Edit commission rate" : "Add commission rate"}</button>
                  {!c.disabled && <button className="block w-full px-3 py-1.5 text-left hover:bg-zinc-50" onClick={() => { setMenu(null); void resend(c); }}>Resend invitation</button>}
                  <button className="block w-full px-3 py-1.5 text-left hover:bg-zinc-50" onClick={() => { setMenu(null); openEdit(c); }}>Edit</button>
                  <button className="block w-full px-3 py-1.5 text-left text-rose-600 hover:bg-zinc-50" onClick={async () => { setMenu(null); if (await confirm({ title: "Remove this consignor?", body: `${c.first} ${c.last} (${c.email}) will be removed from this company. This can't be undone.`, confirmLabel: "Remove" })) setRows((l) => l.filter((r) => r.id !== c.id)); }}>Remove</button>
                </div>
              )}
            </span>,
          ])} />
      </Card>
      {add && (
        <Modal title={editId ? "Edit consignor" : "Add consignor"} sub={editId ? "Update this consignor’s name and commission rate." : "Add a consignor to this company. They show as Invited until they register on the website with this email. Use Resend invitation in Actions to copy the sign-up link and send it to them."} onClose={closeAdd}
          footer={<><Btn variant="outline" onClick={closeAdd}>Cancel</Btn><Btn variant="solid" onClick={invite}>{editId ? "Save" : "Add consignor"}</Btn></>}>
          <div className="space-y-3">
            <Field label="First name"><input autoFocus={focus === "first"} className={inputCls} value={f.first} onChange={(e) => setF({ ...f, first: e.target.value })} /></Field>
            <Field label="Last name"><input className={inputCls} value={f.last} onChange={(e) => setF({ ...f, last: e.target.value })} /></Field>
            <Field label="Email"><input type="email" className={`${inputCls} ${editId ? "bg-zinc-100 text-zinc-500" : ""}`} disabled={!!editId} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
            <Field label="Commission rate (%)"><input inputMode="decimal" autoFocus={focus === "commission"} className={inputCls} placeholder="Optional, e.g. 10" value={f.commission} onChange={(e) => setF({ ...f, commission: e.target.value })} /></Field>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}
      {dialog}
    </>
  );
}

/* ---------- Bank ---------- */

type Bank = { id: string; name: string; last4: string; isDefault: boolean };

export function BankSection() {
  const { confirm, dialog } = useConfirm();
  const [banks, setBanks] = usePersisted<Bank[]>("banks", []);
  const [edit, setEdit] = useState<Bank | "new" | null>(null);
  const [name, setName] = useState("");
  const [acct, setAcct] = useState("");
  const [def, setDef] = useState(false);
  const [err, setErr] = useState("");

  const open = (b: Bank | "new") => {
    setEdit(b); setErr(""); setAcct("");
    setName(b === "new" ? "" : b.name);
    setDef(b === "new" ? banks.length === 0 : b.isDefault);
  };
  const save = () => {
    if (!name.trim()) return setErr("Bank name is required.");
    const isNew = edit === "new";
    if (isNew && !/^\d{4,20}$/.test(acct)) return setErr("Enter the account number (numbers only, 4–20 digits).");
    if (!isNew && acct && !/^\d{4,20}$/.test(acct)) return setErr("Account number must be numbers only (4–20 digits).");
    const id = isNew ? uid() : (edit as Bank).id;
    const prev = isNew ? undefined : (edit as Bank);
    const last4 = acct ? acct.slice(-4) : prev?.last4 ?? "";   // only last 4 digits are ever kept
    const makeDefault = def || banks.length === 0 || !!prev?.isDefault; // the default account stays default until another one is chosen
    const next: Bank = { id, name: name.trim(), last4, isDefault: !!makeDefault };
    let list = isNew ? [...banks, next] : banks.map((b) => (b.id === id ? next : b));
    if (next.isDefault) list = list.map((b) => ({ ...b, isDefault: b.id === id }));
    setBanks(list); setEdit(null);
  };
  const remove = (id: string) => {
    let list = banks.filter((b) => b.id !== id);
    if (list.length && !list.some((b) => b.isDefault)) list = list.map((b, i) => ({ ...b, isDefault: i === 0 }));
    setBanks(list);
  };

  return (
    <>
      <SectionHead title="Bank" sub="Configure primary and settlement banking details." />
      <Card className="p-4">
        <CardHead title="Bank accounts" sub={`${banks.length} account${banks.length === 1 ? "" : "s"}`}
          actions={<Btn variant="solid" className="h-8 text-xs" onClick={() => open("new")}>Add account</Btn>} />
        <div className="mt-3">
          <DataTable head={["Bank name", "Account", "Status", "Actions"]} empty="No bank accounts yet."
            rows={banks.map((b) => [
              <span key="n" className="font-semibold">{b.name}</span>,
              <span key="a" className="font-mono">{b.last4 ? `•••••${b.last4}` : "••••••••"}</span>,
              b.isDefault ? <Badge key="s">Default</Badge> : "",
              <span key="x" className="flex items-center justify-end gap-3">
                <IconBtn label={`Edit ${b.name}`} onClick={() => open(b)}><Pencil className="size-3.5" />Edit</IconBtn>
                <IconBtn label={`Delete ${b.name}`} danger onClick={async () => { if (await confirm({ title: "Delete this bank account?", body: `${b.name} will be removed from this company. This can't be undone.`, confirmLabel: "Delete" })) remove(b.id); }}><Trash2 className="size-3.5" /></IconBtn>
                {!b.isDefault && <button className="text-xs font-semibold text-primary hover:underline" onClick={() => setBanks(banks.map((x) => ({ ...x, isDefault: x.id === b.id })))}>Make default</button>}
              </span>,
            ])} />
        </div>
      </Card>
      {edit && (
        <Modal title={edit === "new" ? "Add bank account" : "Edit bank account"} sub="Provide the settlement bank account details for this company." onClose={() => setEdit(null)}
          footer={<><Btn variant="outline" onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="solid" onClick={save}>Save</Btn></>}>
          <div className="space-y-3">
            <Field label="Bank name"><input autoFocus className={inputCls} placeholder="Bank of Example" value={name} onChange={(e) => setName(e.target.value)} /></Field>
            <div>
              <Field label="Account number">
                <input inputMode="numeric" className={inputCls} value={acct} onChange={(e) => setAcct(e.target.value.replace(/\D/g, ""))}
                  placeholder={edit !== "new" ? (edit.last4 ? `•••••${edit.last4} (leave blank to keep)` : "Leave blank to keep current") : "0123456789"} />
              </Field>
              <p className="mt-1 text-[11px] text-zinc-500">Numbers only. We store only the last 4 digits for display.</p>
            </div>
            <label className="flex items-start justify-between gap-3 rounded-md border border-zinc-200 px-3 py-2 text-xs">
              <span><span className="block font-semibold">Set as default payout account</span><span className="text-[11px] text-zinc-500">Company payouts will be sent to the default bank account.</span></span>
              <input type="checkbox" className="mt-1 size-4 accent-[var(--color-primary)]" checked={def} onChange={(e) => setDef(e.target.checked)} />
            </label>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}
      {dialog}
    </>
  );
}

/* ---------- Taxes ---------- */

export function Taxes() {
  const [rates, setRates] = usePersisted<{ federal: string; state: string }>("taxes", { federal: "", state: "" });
  const [edit, setEdit] = useState<"federal" | "state" | null>(null);
  const [val, setVal] = useState("");
  const [err, setErr] = useState("");
  const open = (k: "federal" | "state") => { setEdit(k); setVal(rates[k]); setErr(""); };
  const save = () => {
    if (val.trim() !== "" && !validPct(val)) return setErr("Enter a number between 0 and 100.");
    setRates({ ...rates, [edit!]: val.trim() }); setEdit(null);
  };
  const none = !rates.federal && !rates.state;
  const box = (k: "federal" | "state", title: string, desc: string) => (
    <div className="flex items-start justify-between rounded-lg border border-zinc-200 bg-zinc-50 p-3">
      <div>
        <p className="text-[10px] font-bold uppercase text-zinc-500">{title}</p>
        <p className="my-1 text-lg font-semibold">{rates[k] ? `${rates[k]}%` : "—"}</p>
        <p className="text-[11px] text-zinc-500">{desc}</p>
      </div>
      <Btn className="h-7 text-xs" onClick={() => open(k)}>Set rate</Btn>
    </div>
  );
  return (
    <>
      <SectionHead title="Taxes" sub="Review and update tax remittance preferences." />
      <Card className="p-4">
        <CardHead title="Tax configuration" sub="Tax percentages added to new invoices." />
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {box("federal", "Federal tax", "Federal tax percentage applied to transactions.")}
          {box("state", "State tax", "State tax percentage applied based on local regulations.")}
        </div>
        {none && <p className="mt-3 text-xs text-zinc-600">No tax defaults are configured yet. Add a rate to ensure invoices include the correct tax percentages.</p>}
        <p className="mt-3 text-[11px] text-zinc-500">Federal and state tax are added together and charged on every new invoice, on the hammer price plus the commission and internet buying fee. Existing invoices are not changed.</p>
      </Card>
      {edit && (
        <Modal title={`Edit ${edit} tax`} sub={`Enter the tax percentage as a numeric value. For example, enter "8.25" for 8.25%.`} onClose={() => setEdit(null)}
          footer={<><Btn variant="outline" onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="solid" onClick={save}>Save</Btn></>}>
          <Field label="Tax percentage (%)"><input autoFocus inputMode="decimal" className={inputCls} placeholder="8.25" value={val} onChange={(e) => setVal(e.target.value)} /></Field>
          <p className="mt-1 text-[11px] text-zinc-500">Leave blank and save to clear this tax rate.</p>
          {err && <p role="alert" className="mt-2 text-xs font-semibold text-rose-600">{err}</p>}
        </Modal>
      )}
    </>
  );
}

/* ---------- Auctioneer Commission ---------- */
// Same fee structures, fields and validation as Auction House → Fees & Commissions (src/lib/auctionHouse.ts).

const COMMISSION_LABELS: Partial<Record<FeeKind, string>> = {
  tier_pct: "Tiered percentage rate", tier_pct_cap: "Tiered percentage with cap", tier_flat: "Tiered flat percentage rate",
};
const feeLabel = (k: FeeKind) => COMMISSION_LABELS[k] ?? FEE_DEFS.find((d) => d.kind === k)!.label;

function CommissionSummary({ fee }: { fee: Fee }) {
  const def = FEE_DEFS.find((d) => d.kind === fee.kind)!;
  const rec = fee as unknown as Record<string, number>;
  return (
    <div>
      <p className="text-[11px] text-zinc-500">Auctioneer commission</p>
      <p className="mb-3 text-sm font-semibold">{feeLabel(fee.kind)}</p>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {def.fields.map((f) => (
          <div key={f.key}><p className="text-[11px] text-zinc-500">{f.label}</p><p className="text-sm font-semibold">{rec[f.key].toLocaleString("en-US", { maximumFractionDigits: 4 })}</p></div>
        ))}
      </div>
    </div>
  );
}

function CommissionModal({ fee, onSave, onClear, onClose }: { fee: Fee | null; onSave: (f: Fee) => void; onClear: () => void; onClose: () => void }) {
  const [kind, setKind] = useState<FeeKind>(fee?.kind ?? "flat_pct");
  // values kept per structure so switching options doesn't wipe what was typed
  const [vals, setVals] = useState<Record<string, string>>(() => {
    const f = fee as Record<string, unknown> | null;
    return f ? Object.fromEntries(Object.entries(f).filter(([k]) => k !== "kind").map(([k, v]) => [`${f.kind}.${k}`, String(v)])) : {};
  });
  const def = FEE_DEFS.find((d) => d.kind === kind)!;
  const get = (k: FeeKind, key: string) => vals[`${k}.${key}`] ?? "";
  const invalid = def.fields.some((f) => feeValueError(f, get(kind, f.key)));
  const save = () => onSave({ kind, ...Object.fromEntries(def.fields.map((f) => [f.key, Number(get(kind, f.key))])) } as Fee);
  return (
    <Modal wide title="Edit auctioneer commission" sub="Configure the commission structure applied to auctions created by this company." onClose={onClose}
      footer={<>
        <Btn variant="outline" onClick={onClose}>Cancel</Btn>
        <button className="px-2 text-xs font-semibold text-zinc-700 hover:underline" onClick={onClear}>Clear commission</button>
        <Btn variant="solid" disabled={invalid} onClick={save}>Save commission</Btn></>}>
      <p className="text-[11px] text-zinc-500">Choose one template below and provide the required values. It is added to every new invoice, next to the internet buying fee.</p>
      <p className="mt-1 text-[11px] text-zinc-500">Note: the currency is applied when the auction is created.</p>
      <div className="mt-3 space-y-2" role="radiogroup" aria-label="Commission structure">
        {FEE_DEFS.map((d) => (
          <div key={d.kind}>
            <label className="flex cursor-pointer items-center gap-2 text-xs">
              <input type="radio" name="commission" checked={kind === d.kind} onChange={() => setKind(d.kind)} className="accent-[var(--color-primary)]" />{feeLabel(d.kind)}
            </label>
            {kind === d.kind && (
              <div className={`mt-2 grid gap-3 pl-6 ${d.fields.length >= 3 ? "sm:grid-cols-3" : "sm:grid-cols-2"}`}>
                {d.fields.map((f) => {
                  const v = get(d.kind, f.key);
                  const err = v === "" ? "" : feeValueError(f, v);
                  return (
                    <div key={f.key}>
                      <Field label={f.label}>
                        <input type="number" min={0} max={f.pct ? 100 : undefined} step="any" inputMode="decimal" className={inputCls} value={v} aria-invalid={!!err}
                          onChange={(e) => setVals({ ...vals, [`${d.kind}.${f.key}`]: e.target.value })} />
                      </Field>
                      {err && <p role="alert" className="mt-1 text-[11px] text-rose-600">{err}</p>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </Modal>
  );
}

export function CommissionSection() {
  // Company section `commission` (PocketBase company record). Separate from the internet buying fee (Auction House → `house.fee`).
  const [fee, setFee] = useState<Fee | null>(null);
  const [edit, setEdit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  useEffect(() => { loadCompany().then((d) => setFee(parseFee(d.commission))).catch((e) => setErr(e instanceof Error ? e.message : "Failed to load commission")).finally(() => setLoading(false)); }, []);
  const persistFee = async (next: Fee | null) => {
    setErr("");
    try { const d = await saveCompany({ commission: next }); setFee(parseFee(d.commission)); setEdit(false); }
    catch (e) { setEdit(false); setErr(e instanceof Error ? e.message : "Failed to save"); }
  };
  return (
    <>
      <SectionHead title="Auctioneer Commission" sub="Control default auctioneer commission structures." />
      <Card className="p-4">
        <CardHead title="Auctioneer commission" sub="Commission defaults applied to auctions created by this company."
          actions={<Btn variant="solid" className="h-8 text-xs" onClick={() => setEdit(true)}>{fee ? "Edit commission" : "Add commission"}</Btn>} />
        <div className="mt-4 rounded-lg border border-sky-200 bg-sky-50 p-3">
          {loading ? <p className="text-xs text-zinc-600">Loading…</p> : fee ? <CommissionSummary fee={fee} /> : <p className="text-xs text-zinc-600">No commission configuration found.</p>}
        </div>
        {err && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{err}</p>}
        <p className="mt-3 text-[11px] text-zinc-500">Charged to the buyer on new invoices, in addition to the internet buying fee set in Auction House → Fees &amp; Commissions.</p>
      </Card>
      {edit && <CommissionModal fee={fee} onClose={() => setEdit(false)} onSave={(f) => void persistFee(f)} onClear={() => void persistFee(null)} />}
    </>
  );
}

/* ---------- Contacts ---------- */

const DIAL = [["MY", "+60"], ["TH", "+66"], ["SG", "+65"], ["ID", "+62"], ["BN", "+673"], ["US", "+1"], ["GB", "+44"], ["AU", "+61"]] as const;
const flag = (iso: string) => String.fromCodePoint(...[...iso].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));

function PhoneInput({ iso, number, onIso, onNumber }: { iso: string; number: string; onIso: (v: string) => void; onNumber: (v: string) => void }) {
  return (
    <div className="flex gap-2">
      <select aria-label="Country code" value={iso} onChange={(e) => onIso(e.target.value)} className="h-9 w-28 shrink-0 rounded-md border border-zinc-300 bg-white px-1.5 text-xs">
        {DIAL.map(([c, d]) => <option key={c} value={c}>{flag(c)} {d}</option>)}
      </select>
      <input type="tel" className={inputCls} placeholder="12-345 6789" value={number} onChange={(e) => onNumber(e.target.value.replace(/[^\d\s-]/g, ""))} />
    </div>
  );
}
const fullPhone = (iso: string, n: string) => (n.trim() ? `${DIAL.find((d) => d[0] === iso)![1]}${n.replace(/^0/, "").replace(/[\s-]/g, "")}` : "");

type Contact = { id: string; name: string; email: string; iso: string; phone: string };

export function Contacts() {
  const { confirm, dialog } = useConfirm();
  const [list, setList] = usePersisted<Contact[]>("contacts", []);
  const [edit, setEdit] = useState<Contact | "new" | null>(null);
  const [f, setF] = useState<Contact>({ id: "", name: "", email: "", iso: "MY", phone: "" });
  const [err, setErr] = useState("");

  const open = (c: Contact | "new") => { setEdit(c); setErr(""); setF(c === "new" ? { id: uid(), name: "", email: "", iso: "MY", phone: "" } : c); };
  const save = () => {
    if (!f.name.trim()) return setErr("Name is required.");
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return setErr("Enter a valid email address.");
    setList(edit === "new" ? [...list, f] : list.map((c) => (c.id === f.id ? f : c)));
    setEdit(null);
  };

  return (
    <>
      <SectionHead title="Contacts" sub="Keep company-wide contact details organized." />
      <Card className="p-4">
        <CardHead title="Company contacts" sub={`${list.length} contact${list.length === 1 ? "" : "s"} listed for this company.`}
          actions={<Btn variant="solid" className="h-8 text-xs" onClick={() => open("new")}>Add contact</Btn>} />
        {list.length === 0 ? <p className="py-8 text-center text-xs text-zinc-500">No contacts yet.</p> : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((c) => (
              <div key={c.id} className="rounded-lg border border-zinc-200 shadow-sm">
                <div className="flex gap-3 p-3">
                  <Avatar name={c.name} />
                  <div className="min-w-0 text-xs"><p className="font-bold">{c.name}</p><p className="text-zinc-500">{c.email || "—"}</p><p className="text-zinc-500">{fullPhone(c.iso, c.phone) || "—"}</p></div>
                </div>
                <div className="flex justify-between border-t border-zinc-100 px-3 py-1.5">
                  <IconBtn label={`Edit ${c.name}`} onClick={() => open(c)}><Pencil className="size-3.5" />Edit</IconBtn>
                  <IconBtn label={`Delete ${c.name}`} danger onClick={async () => { if (await confirm({ title: "Delete this contact?", body: `${c.name} will be removed from the company contacts.`, confirmLabel: "Delete" })) setList((l) => l.filter((x) => x.id !== c.id)); }}><Trash2 className="size-3.5" /></IconBtn>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
      {edit && (
        <Modal title={edit === "new" ? "Add contact" : "Edit contact"} sub="Contacts are shown in the “Our team & offices” section of the public website’s contact area." onClose={() => setEdit(null)}
          footer={<><Btn variant="outline" onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="solid" onClick={save}>Save contact</Btn></>}>
          <div className="space-y-3">
            <Field label="Name"><input autoFocus className={inputCls} placeholder="Jane Doe" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="Email"><input type="email" className={inputCls} placeholder="jane@example.com" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
            <Field label="Phone"><PhoneInput iso={f.iso} number={f.phone} onIso={(iso) => setF({ ...f, iso })} onNumber={(phone) => setF({ ...f, phone })} /></Field>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}
      {dialog}
    </>
  );
}

/* ---------- Lot Bid Details ---------- */

type Row = { from: string; increment: string };
const Select = ({ value, onChange, options, label }: { value: string; onChange: (v: string) => void; options: readonly (readonly [string, string])[]; label: string }) => (
  <select aria-label={label} value={value} onChange={(e) => onChange(e.target.value)} className="h-9 w-full rounded-md border border-zinc-300 bg-white px-2 text-sm focus:border-primary focus:outline-none">
    {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
  </select>
);

export function LotBidDetails() {
  const [v, setV] = useState({ start: "10000", reserve: "", estStart: "", estEnd: "", strategy: "single", method: "absolute", inc: "500" });
  const [matrix, setMatrix] = useState<Row[]>([{ from: "0", increment: "500" }]);
  const [saved, setSaved] = useState({ ...v });
  const [err, setErr] = useState("");
  const [ok, setOk] = useState(false);
  useEffect(() => {
    loadCompany().then((d) => {
      const b = d.bidSettings as { v?: typeof v; matrix?: Row[] } | null;
      if (b?.v) { setV({ ...v, ...b.v }); setSaved({ ...v, ...b.v }); }
      if (b?.matrix?.length) setMatrix(b.matrix);
    }).catch((e) => setErr(e instanceof Error ? e.message : "Failed to load bid settings"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => { setV({ ...v, [k]: e.target.value.replace(/[^\d.]/g, "") }); setOk(false); };
  const pct = v.method === "percent";
  const fmtNum = (s: string) => (s ? Number(s).toLocaleString("en-US") : "");

  const save = () => {
    if (!(num(v.start) >= 0)) return setErr("Starting bid is required.");
    if (v.reserve && num(v.reserve) < num(v.start)) return setErr("Reserve price cannot be lower than the starting bid.");
    if (v.estStart && v.estEnd && num(v.estEnd) < num(v.estStart)) return setErr("Estimated end must be greater than or equal to estimated start.");
    if (v.strategy === "single" && !(num(v.inc) > 0)) return setErr("Increment value must be greater than 0.");
    if (v.strategy === "matrix" && (!matrix.length || matrix.some((r) => !(num(r.from) >= 0) || !(num(r.increment) > 0)))) return setErr("Each matrix row needs a starting amount and an increment greater than 0.");
    setErr("");
    saveCompany({ bidSettings: { v, matrix } }).then(() => { setSaved({ ...v }); setOk(true); }).catch((e) => setErr(e instanceof Error ? e.message : "Failed to save"));
  };
  const chip = saved.strategy === "single" ? `Single increment • ${fmtNum(saved.inc)}${saved.method === "percent" ? "%" : ""}` : `Increment matrix • ${matrix.length} row${matrix.length === 1 ? "" : "s"}`;

  return (
    <>
      <SectionHead title="Lot Bid Details" sub="Configure default lot-level bidding settings." />
      <Card className="p-0">
        <div className="border-b border-zinc-200 px-5 py-3"><h3 className="text-base font-bold">Default Lot Bid Settings</h3><p className="text-xs text-zinc-500">Configure default bidding settings that will be applied to new auctions.</p></div>
        <div className="space-y-6 px-5 py-4">
          <div>
            <h4 className="text-sm font-bold">Bid configuration</h4><p className="mb-3 text-[11px] text-zinc-500">Define default starting bid, reserve price, and estimated sale range.</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Starting bid"><input inputMode="decimal" className={inputCls} value={v.start} onChange={set("start")} /></Field>
              <Field label="Reserve price"><input inputMode="decimal" className={inputCls} placeholder="Optional" value={v.reserve} onChange={set("reserve")} /></Field>
              <Field label="Estimated start"><input inputMode="decimal" className={inputCls} placeholder="Optional" value={v.estStart} onChange={set("estStart")} /></Field>
              <Field label="Estimated end"><input inputMode="decimal" className={inputCls} placeholder="Optional" value={v.estEnd} onChange={set("estEnd")} /></Field>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold">Bid increments</h4><p className="mb-3 text-[11px] text-zinc-500">Configure how bids advance during auctions by default.</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Increment strategy"><Select label="Increment strategy" value={v.strategy} onChange={(s) => { setV({ ...v, strategy: s }); setOk(false); }} options={[["single", "Single increment"], ["matrix", "Increment matrix"]]} /></Field>
              <Field label="Calculation method"><Select label="Calculation method" value={v.method} onChange={(s) => { setV({ ...v, method: s }); setOk(false); }} options={[["absolute", "Absolute value"], ["percent", "Percentage of starting bid"]]} /></Field>
              {v.strategy === "single" && <Field label={pct ? "Increment value (%)" : "Increment value"}><input inputMode="decimal" className={inputCls} value={v.inc} onChange={set("inc")} /></Field>}
            </div>
            {v.strategy === "matrix" && (
              <div className="mt-3 space-y-2">
                {matrix.map((r, i) => (
                  <div key={i} className="grid grid-cols-[1fr_1fr_auto] items-end gap-2">
                    <Field label="Bids from"><input inputMode="decimal" className={inputCls} value={r.from} onChange={(e) => { setMatrix(matrix.map((x, j) => (j === i ? { ...x, from: e.target.value.replace(/[^\d.]/g, "") } : x))); setOk(false); }} /></Field>
                    <Field label={pct ? "Increment (%)" : "Increment"}><input inputMode="decimal" className={inputCls} value={r.increment} onChange={(e) => { setMatrix(matrix.map((x, j) => (j === i ? { ...x, increment: e.target.value.replace(/[^\d.]/g, "") } : x))); setOk(false); }} /></Field>
                    <button aria-label="Remove row" className="mb-1.5 rounded p-1 text-rose-600 hover:bg-rose-50" onClick={() => setMatrix(matrix.filter((_, j) => j !== i))}><Trash2 className="size-4" /></button>
                  </div>
                ))}
                <Btn className="h-8 text-xs" onClick={() => setMatrix([...matrix, { from: "", increment: "" }])}><Plus className="size-3.5" />Add row</Btn>
              </div>
            )}
          </div>
          {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          {ok && <p role="status" className="text-xs font-semibold text-emerald-700">Bid settings saved.</p>}
        </div>
        <div className="flex items-center justify-between border-t border-zinc-200 px-5 py-3">
          <span className="rounded border border-zinc-200 px-2 py-0.5 text-[10px] text-zinc-600">{chip}</span>
          <Btn variant="solid" onClick={save}>Save bid settings</Btn>
        </div>
      </Card>
    </>
  );
}

/* ---------- Locations ---------- */

type Loc = { id: string; name: string; formatted: string; line1: string; line2: string; city: string; state: string; postal: string; country: string; phone: string };
const BLANK_LOC = (): Loc => ({ id: uid(), name: "", formatted: "", line1: "", line2: "", city: "", state: "", postal: "", country: "", phone: "" });
const locAddress = (l: Loc) => l.formatted.trim() || [l.line1, l.line2, l.city, l.state, `${l.postal} ${l.country}`.trim()].filter(Boolean).join(", ");

export function Locations() {
  const { confirm, dialog } = useConfirm();
  const [list, setList] = usePersisted<Loc[]>("locations", []);
  const [edit, setEdit] = useState<Loc | "new" | null>(null);
  const [f, setF] = useState<Loc>(BLANK_LOC());
  const [err, setErr] = useState("");
  const open = (l: Loc | "new") => { setEdit(l); setErr(""); setF(l === "new" ? BLANK_LOC() : l); };
  const save = () => {
    if (!f.name.trim()) return setErr("Location name is required.");
    if (!f.formatted.trim() && !f.line1.trim()) return setErr("Enter an address (paste a full address or fill in Address line 1).");
    setList(edit === "new" ? [...list, f] : list.map((l) => (l.id === f.id ? f : l)));
    setEdit(null);
  };
  const t = (k: keyof Loc) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <>
      <SectionHead title="Locations" sub="Track lot locations and pickup destinations." />
      <Card className="p-4">
        <CardHead title="Locations" sub="Physical addresses used for invoices, pickups, and logistics." actions={<Btn variant="solid" className="h-8 text-xs" onClick={() => open("new")}>Add location</Btn>} />
        <div className="mt-4 space-y-3">
          {list.length === 0 && <p className="py-8 text-center text-xs text-zinc-500">No locations yet.</p>}
          {list.map((l) => (
            <div key={l.id} className="rounded-lg border border-zinc-200 shadow-sm">
              <div className="flex gap-3 p-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-sky-50 text-primary"><MapPin className="size-4" /></span>
                <div className="text-xs"><p className="font-bold">{l.name}</p><p className="text-zinc-600">{locAddress(l)}</p>{l.phone && <p className="mt-1 text-[11px] text-zinc-500">Phone: {l.phone}</p>}</div>
              </div>
              <div className="flex justify-between border-t border-zinc-100 px-3 py-1.5">
                <IconBtn label={`Edit ${l.name}`} onClick={() => open(l)}><Pencil className="size-3.5" />Edit</IconBtn>
                <IconBtn label={`Delete ${l.name}`} danger onClick={async () => { if (await confirm({ title: "Delete this location?", body: `${l.name} will be removed. This can't be undone.`, confirmLabel: "Delete" })) setList((x) => x.filter((y) => y.id !== l.id)); }}><Trash2 className="size-3.5" /></IconBtn>
              </div>
            </div>
          ))}
        </div>
      </Card>
      {edit && (
        <Modal wide title={edit === "new" ? "Add location" : "Edit location"} sub="Offices and pickup sites. They are shown in the “Our team & offices” section of the public website." onClose={() => setEdit(null)}
          footer={<><Btn variant="outline" onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="solid" onClick={save}>Save location</Btn></>}>
          <div className="space-y-3">
            <Field label="Location name"><input autoFocus className={inputCls} placeholder="Headquarters, Warehouse, Pickup site..." value={f.name} onChange={t("name")} /></Field>
            <Field label="Search address / formatted address"><textarea rows={2} className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm placeholder:text-zinc-400 focus:border-primary focus:outline-none" placeholder="Paste a full address or use the fields below." value={f.formatted} onChange={(e) => setF({ ...f, formatted: e.target.value })} /></Field>
            <Field label="Address line 1"><input className={inputCls} placeholder="123 Example Street" value={f.line1} onChange={t("line1")} /></Field>
            <Field label="Address line 2"><input className={inputCls} placeholder="Suite, unit, or building (optional)" value={f.line2} onChange={t("line2")} /></Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="City"><input className={inputCls} value={f.city} onChange={t("city")} /></Field>
              <Field label="State / Province"><input className={inputCls} value={f.state} onChange={t("state")} /></Field>
              <Field label="Postal code"><input className={inputCls} value={f.postal} onChange={t("postal")} /></Field>
              <Field label="Country"><input className={inputCls} value={f.country} onChange={t("country")} /></Field>
            </div>
            <Field label="Phone"><input type="tel" className={inputCls} placeholder="Optional, e.g. +1 555 123 4567" value={f.phone} onChange={t("phone")} /></Field>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}
      {dialog}
    </>
  );
}

/* ---------- Policies ---------- */

type Policy = { id: string; name: string; privacy: string; terms: string };
const TA = "w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none";

export function LegalPoliciesCard({ embedded = false }: { embedded?: boolean }) {
  const { confirm, dialog } = useConfirm();
  const companyName = useCompanyName();
  const [list, setList] = useState<Policy[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadErr, setLoadErr] = useState("");
  const [saving, setSaving] = useState(false);
  // Same data as Admin → Auction House → Legal Policies (PocketBase `house.legal`), shown on the public /privacy and /terms pages
  const reload = async () => { try { setList((await fetchHouse()).legal); setLoadErr(""); } catch (e) { setLoadErr(e instanceof Error ? e.message : "Failed to load policies"); } finally { setLoading(false); } };
  useEffect(() => { void reload(); }, []);
  const persist = async (next: Policy[]) => {
    try { await postHouse({ legal: JSON.stringify(next) }); await reload(); return ""; }
    catch (e) { return e instanceof Error ? e.message : "Failed to save"; }
  };
  const [manage, setManage] = useState(false);
  const [view, setView] = useState<Policy | null>(null);
  const [edit, setEdit] = useState<Policy | "new" | null>(null);
  const [f, setF] = useState<Policy>({ id: "", name: "", privacy: "", terms: "" });
  const [err, setErr] = useState("");
  const openEdit = (p: Policy | "new") => { setEdit(p); setErr(""); setF(p === "new" ? { id: uid(), name: "", privacy: "", terms: "" } : p); };
  const save = async () => {
    if (!f.name.trim()) return setErr("Policy name is required.");
    if (!f.privacy.trim() && !f.terms.trim()) return setErr("Add a privacy policy, terms of use, or both.");
    setSaving(true); setErr("");
    const m = await persist(edit === "new" ? [...list, f] : list.map((p) => (p.id === f.id ? f : p)));
    setSaving(false);
    if (m) setErr(m); else setEdit(null);
  };
  const snippet = (s: string) => (s.length > 150 ? `${s.slice(0, 150).trim()}…` : s);

  const manageBtn = <Btn variant="solid" className="h-8 text-xs" onClick={() => setManage(true)}>Manage policies</Btn>;
  return (
    <>
      <Shell embedded={embedded}>
        {embedded
          ? <div className="mb-3 flex items-start justify-between gap-3"><p className="text-[11px] text-zinc-500">Shown on the public Privacy Policy and Terms pages. Same policies as Company → Policies.</p>{manageBtn}</div>
          : <CardHead title="Legal policies" sub="Terms of use, privacy policy, and other legal templates shared with bidders." actions={manageBtn} />}
        <div className={embedded ? "space-y-2" : "mt-4 space-y-2"}>
          {loadErr && <p role="alert" className="rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
          {loading && <p className="py-6 text-center text-xs text-zinc-500">Loading…</p>}
          {!loading && list.length === 0 && !loadErr && <p className="py-6 text-center text-xs text-zinc-500">No policies have been published yet.</p>}
          {list.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5">
              <span className="flex items-center gap-3 text-xs font-semibold"><span className="grid size-8 place-items-center rounded-full bg-zinc-200 text-zinc-600"><FileText className="size-4" /></span>{p.name}</span>
              <button className="text-xs text-zinc-500 hover:text-primary hover:underline" onClick={() => setView(p)}>View</button>
            </div>
          ))}
        </div>
      </Shell>

      {manage && (
        <Modal wide title="Manage policies" onClose={() => setManage(false)} footer={<Btn variant="outline" onClick={() => setManage(false)}>Close</Btn>}>
          <div className="flex items-start justify-between gap-3">
            <div><p className="text-xs font-semibold">{companyName}</p><p className="text-[11px] text-zinc-500">Maintain bidder-facing privacy policies and terms of use documents.</p></div>
            <Btn variant="solid" className="h-8 text-xs" onClick={() => openEdit("new")}><Plus className="size-3.5" />Add policy</Btn>
          </div>
          <div className="mt-3 space-y-2">
            {list.length === 0 && <p className="rounded-lg border border-zinc-200 py-6 text-center text-xs text-zinc-500">No policies have been added yet.</p>}
            {list.map((p) => (
              <div key={p.id} className="flex items-start justify-between gap-3 rounded-lg border border-zinc-200 p-3">
                <div className="flex gap-3">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-zinc-100 text-zinc-600"><FileText className="size-4" /></span>
                  <div><p className="text-xs font-bold">{p.name}</p><p className="mt-0.5 text-[11px] text-zinc-500">{snippet(p.terms || p.privacy) || "No content yet."}</p></div>
                </div>
                <div className="flex shrink-0 gap-1.5">
                  <button aria-label={`Edit ${p.name}`} onClick={() => openEdit(p)} className="grid size-7 place-items-center rounded-full border border-zinc-200 text-primary hover:bg-zinc-50"><Pencil className="size-3.5" /></button>
                  <button aria-label={`Delete ${p.name}`} onClick={async () => { if (await confirm({ title: "Delete this policy?", body: `${p.name} will be removed. This can't be undone.`, confirmLabel: "Delete", noLog: true })) { const m = await persist(list.filter((x) => x.id !== p.id)); if (m) setLoadErr(m); } }} className="grid size-7 place-items-center rounded-full border border-rose-200 text-rose-600 hover:bg-rose-50"><Trash2 className="size-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {edit && (
        <Modal wide title={edit === "new" ? "Add policy" : "Edit policy"} onClose={() => setEdit(null)}
          footer={<><Btn variant="outline" onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="solid" disabled={saving} onClick={() => void save()}>{saving ? "Saving…" : edit === "new" ? "Add policy" : "Save changes"}</Btn></>}>
          <div className="max-h-[65vh] space-y-3 overflow-y-auto pr-1">
            <Field label="Name"><input autoFocus className={inputCls} placeholder="Policy name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="Privacy policy (HTML/plain text)"><textarea rows={10} className={TA} value={f.privacy} onChange={(e) => setF({ ...f, privacy: e.target.value })} /></Field>
            <Field label="Terms of use (HTML/plain text)"><textarea rows={10} className={TA} value={f.terms} onChange={(e) => setF({ ...f, terms: e.target.value })} /></Field>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}

      {view && (
        <Modal wide title={view.name} onClose={() => setView(null)} footer={<Btn variant="outline" onClick={() => setView(null)}>Close</Btn>}>
          <div className="max-h-[65vh] space-y-4 overflow-y-auto text-xs">
            <div><h4 className="mb-1 font-bold">Privacy policy</h4><p className="whitespace-pre-wrap text-zinc-700">{view.privacy || "—"}</p></div>
            <div><h4 className="mb-1 font-bold">Terms of use</h4><p className="whitespace-pre-wrap text-zinc-700">{view.terms || "—"}</p></div>
          </div>
        </Modal>
      )}
      {dialog}
    </>
  );
}

/* ---------- Questionnaire ---------- */

const QTYPES = [["short", "Short text"], ["long", "Long text"], ["yesno", "Yes / No"], ["single", "Single choice"], ["multi", "Multiple choice"]] as const;
type QType = (typeof QTYPES)[number][0];
type Question = { id: string; text: string; type: QType; required: boolean; options: string[] };
type Template = { id: string; name: string; active: boolean; questions: Question[] };
const hasOptions = (t: QType) => t === "single" || t === "multi";
const typeLabel = (t: QType) => QTYPES.find((x) => x[0] === t)![1];

function QuestionBuilder({ tpl, onSave, onClose }: { tpl: Template; onSave: (q: Question[]) => void; onClose: () => void }) {
  const [qs, setQs] = useState<Question[]>(tpl.questions.map((q) => ({ ...q, options: [...q.options] })));
  const [err, setErr] = useState("");
  const upd = (id: string, patch: Partial<Question>) => setQs(qs.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  const move = (i: number, d: -1 | 1) => { const j = i + d; if (j < 0 || j >= qs.length) return; const n = [...qs]; [n[i], n[j]] = [n[j], n[i]]; setQs(n); };
  const save = () => {
    for (const [i, q] of qs.entries()) {
      if (!q.text.trim()) return setErr(`Question ${i + 1} needs text.`);
      if (hasOptions(q.type) && q.options.filter((o) => o.trim()).length < 2) return setErr(`Question ${i + 1} needs at least two options.`);
    }
    onSave(qs.map((q) => ({ ...q, text: q.text.trim(), options: hasOptions(q.type) ? q.options.map((o) => o.trim()).filter(Boolean) : [] })));
  };
  return (
    <Modal wide title={`Questions — ${tpl.name}`} sub="Build the onboarding questions shown to consignors." onClose={onClose}
      footer={<><Btn variant="outline" onClick={onClose}>Cancel</Btn><Btn variant="solid" onClick={save}>Save questions</Btn></>}>
      <div className="max-h-[65vh] space-y-3 overflow-y-auto pr-1">
        {qs.length === 0 && <p className="rounded-lg border border-dashed border-zinc-300 py-6 text-center text-xs text-zinc-500">No questions yet. Add your first question.</p>}
        {qs.map((q, i) => (
          <div key={q.id} className="rounded-lg border border-zinc-200 p-3">
            <div className="flex items-start gap-2">
              <span className="mt-1.5 text-xs font-bold text-zinc-500">{i + 1}.</span>
              <div className="min-w-0 flex-1 space-y-2">
                <input aria-label={`Question ${i + 1}`} className={inputCls} placeholder="Question text" value={q.text} onChange={(e) => upd(q.id, { text: e.target.value })} />
                <div className="flex flex-wrap items-center gap-3">
                  <select aria-label="Question type" className="h-8 rounded-md border border-zinc-300 bg-white px-2 text-xs" value={q.type}
                    onChange={(e) => { const t = e.target.value as QType; upd(q.id, { type: t, options: hasOptions(t) && q.options.length === 0 ? ["", ""] : q.options }); }}>
                    {QTYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </select>
                  <label className="flex items-center gap-1.5 text-xs"><input type="checkbox" className="accent-[var(--color-primary)]" checked={q.required} onChange={(e) => upd(q.id, { required: e.target.checked })} />Required</label>
                </div>
                {hasOptions(q.type) && (
                  <div className="space-y-1.5">
                    {q.options.map((o, k) => (
                      <div key={k} className="flex items-center gap-2">
                        <input aria-label={`Option ${k + 1}`} className={inputCls} placeholder={`Option ${k + 1}`} value={o} onChange={(e) => upd(q.id, { options: q.options.map((x, m) => (m === k ? e.target.value : x)) })} />
                        <button aria-label="Remove option" className="rounded p-1 text-rose-600 hover:bg-rose-50" onClick={() => upd(q.id, { options: q.options.filter((_, m) => m !== k) })}><Trash2 className="size-3.5" /></button>
                      </div>
                    ))}
                    <button className="text-xs font-semibold text-primary hover:underline" onClick={() => upd(q.id, { options: [...q.options, ""] })}>+ Add option</button>
                  </div>
                )}
              </div>
              <div className="flex shrink-0 flex-col gap-1">
                <button aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)} className="rounded p-1 text-zinc-500 hover:bg-zinc-100 disabled:opacity-30"><ArrowUp className="size-3.5" /></button>
                <button aria-label="Move down" disabled={i === qs.length - 1} onClick={() => move(i, 1)} className="rounded p-1 text-zinc-500 hover:bg-zinc-100 disabled:opacity-30"><ArrowDown className="size-3.5" /></button>
                <button aria-label="Delete question" onClick={() => setQs(qs.filter((x) => x.id !== q.id))} className="rounded p-1 text-rose-600 hover:bg-rose-50"><Trash2 className="size-3.5" /></button>
              </div>
            </div>
          </div>
        ))}
        <Btn className="h-8 text-xs" onClick={() => setQs([...qs, { id: uid(), text: "", type: "short", required: false, options: [] }])}><Plus className="size-3.5" />Add question</Btn>
        {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
      </div>
    </Modal>
  );
}

export function Questionnaire() {
  const { confirm, dialog } = useConfirm();
  const companyName = useCompanyName();
  const [list, setList] = usePersisted<Template[]>("questionnaires", []);
  const [manage, setManage] = useState(false);
  const [add, setAdd] = useState(false);
  const [build, setBuild] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [active, setActive] = useState(false);
  const [err, setErr] = useState("");
  const close = () => { setAdd(false); setName(""); setActive(false); setErr(""); };
  const save = () => {
    if (!name.trim()) return setErr("Template name is required.");
    if (list.some((t) => t.name.toLowerCase() === name.trim().toLowerCase())) return setErr("A template with this name already exists.");
    const id = uid();
    setList([...(active ? list.map((t) => ({ ...t, active: false })) : list), { id, name: name.trim(), active, questions: [] }]);
    close();
    setBuild(id);   // go straight to building questions
  };
  const count = (t: Template) => `${t.questions.length} question${t.questions.length === 1 ? "" : "s"}`;
  const building = list.find((t) => t.id === build);

  return (
    <>
      <SectionHead title="Questionnaire" sub="Build onboarding questionnaires for consignors." />
      <Card className="p-0">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-zinc-200 px-4 py-3">
          <div><h3 className="text-base font-bold">Questionnaire templates</h3><p className="text-xs text-zinc-500">Questionnaire templates for this company. The active template is asked on the “Register to Bid” form, and the answers are stored with each registration.</p></div>
          <Btn variant="solid" className="h-8 text-xs" onClick={() => setManage(true)}>Manage templates</Btn>
        </div>
        <div className="px-4 py-4 text-xs">
          {list.length === 0 ? <p className="text-zinc-500">No questionnaire templates have been associated with this company.</p> : (
            <ul className="space-y-2">{list.map((t) => (
              <li key={t.id} className="rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2">
                <div className="flex items-center justify-between"><span className="font-semibold">{t.name}</span><span className="flex items-center gap-2 text-zinc-500">{count(t)}{t.active && <Badge tone="green">Active</Badge>}</span></div>
                {t.questions.length > 0 && <ol className="mt-1.5 list-decimal space-y-0.5 pl-5 text-zinc-600">{t.questions.map((q) => <li key={q.id}>{q.text}{q.required && <span className="text-rose-600"> *</span>} <span className="text-[10px] text-zinc-400">({typeLabel(q.type)})</span></li>)}</ol>}
              </li>
            ))}</ul>
          )}
        </div>
      </Card>

      {manage && (
        <Modal wide title="Manage questionnaire templates" onClose={() => setManage(false)} footer={<Btn variant="outline" onClick={() => setManage(false)}>Close</Btn>}>
          <div className="flex items-start justify-between gap-3">
            <div><p className="text-xs font-semibold">{companyName}</p><p className="text-[11px] text-zinc-500">Create bidder questionnaires. Only the active one is shown when a bidder registers.</p></div>
            <Btn variant="solid" className="h-8 text-xs" onClick={() => setAdd(true)}><Plus className="size-3.5" />Add template</Btn>
          </div>
          <div className="mt-3">
            {list.length === 0 ? <p className="rounded-lg border border-zinc-200 py-8 text-center text-xs text-zinc-500">No questionnaire templates have been added yet.</p> : (
              <div className="space-y-2">{list.map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 rounded-lg border border-zinc-200 p-3 text-xs">
                  <span><span className="flex items-center gap-2 font-semibold">{t.name}{t.active && <Badge tone="green">Active</Badge>}</span><span className="text-[11px] text-zinc-500">{count(t)}</span></span>
                  <span className="flex items-center gap-2">
                    <button className="font-semibold text-primary hover:underline" onClick={() => setBuild(t.id)}>Edit questions</button>
                    {!t.active && <button className="font-semibold text-primary hover:underline" onClick={() => setList(list.map((x) => ({ ...x, active: x.id === t.id })))}>Set active</button>}
                    <button aria-label={`Delete ${t.name}`} onClick={async () => { if (await confirm({ title: "Delete this questionnaire template?", body: `${t.name} and its questions will be removed. This can't be undone.`, confirmLabel: "Delete" })) setList((l) => l.filter((x) => x.id !== t.id)); }} className="grid size-7 place-items-center rounded-full border border-rose-200 text-rose-600 hover:bg-rose-50"><Trash2 className="size-3.5" /></button>
                  </span>
                </div>
              ))}</div>
            )}
          </div>
        </Modal>
      )}

      {add && (
        <Modal title="Add template" onClose={close} footer={<><Btn variant="outline" onClick={close}>Cancel</Btn><Btn variant="solid" onClick={save}>Add template</Btn></>}>
          <div className="space-y-3">
            <Field label="Template name"><input autoFocus className={inputCls} placeholder="Template name" value={name} onChange={(e) => setName(e.target.value)} /></Field>
            <label className="flex items-center gap-2 text-xs"><input type="checkbox" className="size-4 accent-[var(--color-primary)]" checked={active} onChange={(e) => setActive(e.target.checked)} />Set as active</label>
            {err && <p role="alert" className="text-xs font-semibold text-rose-600">{err}</p>}
          </div>
        </Modal>
      )}

      {building && <QuestionBuilder tpl={building} onClose={() => setBuild(null)} onSave={(q) => { setList(list.map((t) => (t.id === building.id ? { ...t, questions: q } : t))); setBuild(null); }} />}
      {dialog}
    </>
  );
}

/** Card on the Company page, plain block when embedded in Auction House. */
function Shell({ embedded, children }: { embedded: boolean; children: React.ReactNode }) {
  return embedded ? <div>{children}</div> : <Card className="p-4">{children}</Card>;
}

/** Admin → Company → Policies. The list, add, edit, view and delete UI is shared with Auction House → Legal Policies. */
export function Policies() {
  return (
    <>
      <SectionHead title="Policies" sub="Publish bidding and purchase policies for buyers. Saved policies appear on the public Privacy Policy and Terms pages." />
      <LegalPoliciesCard />
    </>
  );
}
