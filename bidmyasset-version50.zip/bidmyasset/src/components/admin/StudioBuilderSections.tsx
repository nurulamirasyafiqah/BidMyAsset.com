"use client";

import { useEffect, useState, type ReactNode } from "react";
import { ArrowDown, ArrowUp, CreditCard, ExternalLink, MapPin, Plus, Shield, Trash2, Upload } from "lucide-react";
import { Btn, Field, inputCls, Toggle, useConfirm } from "@/components/admin/ui";
import { builderFiles, imageProblem, notifyCatalog, saveBuilder, studio, updateAuction, zonedIso } from "@/lib/studioApi";
import type { Img, StudioAuction, StudioLot } from "@/lib/admin";
import { ImageManager } from "@/components/admin/ImageManager";
import { fetchHouse } from "@/lib/houseClient";
import { loadCompany } from "@/lib/companyClient";
import type { LegalPolicy as LegalDoc } from "@/lib/auctionHouse";

type P = { a: StudioAuction; saved: (msg: string) => void; lots: StudioLot[] };
const area = "w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none";

function Group({ title, sub, children }: { title: string; sub?: string; children: ReactNode }) {
  return <div className="mt-5 first:mt-0"><h3 className="text-sm font-bold">{title}</h3>{sub && <p className="mb-2 text-[11px] text-zinc-500">{sub}</p>}{children}</div>;
}
function Footer({ note, label, onSave, disabled, busy, err }: { note: ReactNode; label: string; onSave: () => void; disabled?: boolean; busy?: boolean; err?: string }) {
  return <div className="mt-6 border-t border-zinc-100 pt-4">{err && <p role="alert" className="mb-2 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-700">{err}</p>}
    <div className="flex items-center justify-between"><span className="rounded border border-zinc-200 px-2 py-0.5 text-[10px] text-zinc-600">{note}</span><Btn variant="solid" className="h-8 text-xs" disabled={disabled || busy} onClick={onSave}>{busy ? "Saving…" : label}</Btn></div></div>;
}
/** Runs a save, shows the error under the button when it fails and the toast when it works. */
function useSave(saved: (m: string) => void) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const run = async <T,>(job: () => Promise<T>, msg: string | ((r: T) => string)): Promise<T | undefined> => {
    setBusy(true); setErr("");
    try { const r = await job(); saved(typeof msg === "function" ? msg(r) : msg); return r; }
    catch (e) { setErr(e instanceof Error ? e.message : "Could not save"); }
    finally { setBusy(false); }
  };
  return { busy, err, run };
}
const asList = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);
const asObj = (v: unknown): Record<string, unknown> => (v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {});
const rid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
const shortName = (n: string) => n.replace(/_[a-z0-9]{10}(\.[^.]+)?$/i, "$1");
function Row({ title, sub, on, onChange }: { title: string; sub: string; on: boolean; onChange: (v: boolean) => void }) {
  return <div className="flex items-center justify-between rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5"><div><p className="text-xs font-semibold">{title}</p><p className="text-[11px] text-zinc-500">{sub}</p></div><Toggle on={on} onChange={onChange} label={title} /></div>;
}
const Sel = ({ v, set, opts }: { v: string; set: (s: string) => void; opts: readonly string[] }) => <select className={inputCls} value={v} onChange={(e) => set(e.target.value)}>{opts.map((o) => <option key={o}>{o}</option>)}</select>;
const iso = (d: string) => (d.includes("/") ? d.slice(0, 10).split("/").reverse().join("-") : "");
const hhmm = (d: string) => (d.includes(" ") ? d.split(" ")[1].slice(0, 5) : "");


const ZONES = ["Asia/Kuala_Lumpur", "Asia/Singapore", "Asia/Bangkok", "Asia/Jakarta", "Asia/Manila", "Asia/Hong_Kong", "Asia/Kolkata", "Australia/Sydney", "UTC"];
export function AuctionInfo({ a, saved }: P) {
  const x = asObj(a.builder?.info);
  const s = (k: string, d: string) => (typeof x[k] === "string" ? (x[k] as string) : d);
  const b = (k: string, d: boolean) => (typeof x[k] === "boolean" ? (x[k] as boolean) : d);
  const [f, setF] = useState({ title: a.title, tz: a.tz ?? "Asia/Kuala_Lumpur", type: a.auctionType ?? "Subject to Confirmation", sd: iso(a.starts), st: hhmm(a.starts) || "16:00", ed: iso(a.ends), et: hhmm(a.ends) || "17:00",
    stagger: !!a.stagger, gap: s("gap", "5"), unit: s("unit", "Minutes"), up: b("up", true), run: b("run", true), approval: a.approval === "auto" ? "Approve Automatically" : "Approve Manually", ranking: s("ranking", "Show top 10 bidders"),
    soft: s("soft", "0"), softUnit: s("softUnit", "Minutes"), history: s("history", "Always"), mask: !!a.hideBidders, desc: a.description ?? "" });
  const [cover, setCover] = useState(a.images ?? []);
  const { busy, err, run } = useSave(saved);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));
  const endsBeforeStart = !!f.sd && !!f.ed && !!f.st && !!f.et && zonedIso(f.ed, f.et, f.tz) <= zonedIso(f.sd, f.st, f.tz);
  const softN = f.soft.trim() === "" ? 0 : Number(f.soft);
  const softBad = !(softN >= 0) || softN * (f.softUnit === "Seconds" ? 1 : 60) > 86400; // 0 = off, at most 24 hours
  const bad = !f.title.trim() || !f.sd || !f.ed || !f.st || !f.et || endsBeforeStart || (f.stagger && !(Number(f.gap) > 0)) || softBad;
  const save = () => run(() => updateAuction(a, { ...f, extras: { gap: f.gap, unit: f.unit, up: f.up, run: f.run, ranking: f.ranking, soft: f.soft, softUnit: f.softUnit, history: f.history } }), "Auction details saved.");
  return (
    <>
      <Group title="Metadata" sub="Basics bidders see on the auction page.">
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Auction title"><input className={inputCls} value={f.title} onChange={(e) => set("title", e.target.value)} /></Field>
          <Field label="Company"><input disabled className={`${inputCls} bg-zinc-100 text-zinc-500`} value={a.company} readOnly /></Field>
          <Field label="Time zone"><Sel v={f.tz} set={(v) => set("tz", v)} opts={Array.from(new Set([f.tz, ...ZONES]))} /></Field>
          <Field label="Auction type"><Sel v={f.type} set={(v) => set("type", v)} opts={["Subject to Confirmation", "Reserve", "Absolute"]} /></Field></div>
      </Group>
      <Group title="Schedule" sub="Dates are interpreted in the selected time zone.">
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Start date"><input type="date" className={inputCls} value={f.sd} onChange={(e) => set("sd", e.target.value)} /></Field><Field label="Start time"><input type="time" className={inputCls} value={f.st} onChange={(e) => set("st", e.target.value)} /></Field>
          <Field label="End date"><input type="date" className={inputCls} min={f.sd || undefined} value={f.ed} onChange={(e) => set("ed", e.target.value)} /></Field><Field label="End time"><input type="time" className={inputCls} value={f.et} onChange={(e) => set("et", e.target.value)} /></Field></div>
        {endsBeforeStart && <p role="alert" className="mt-1 text-[11px] text-rose-600">The end must be after the start.</p>}
        <div className="mt-3 rounded-lg border border-zinc-200 p-3"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold">Lot staggering</p><p className="text-[11px] text-zinc-500">Automatically offset each lot’s closing time from the auction end.</p></div><Toggle on={f.stagger} onChange={(v) => set("stagger", v)} label="Lot staggering" /></div>
          {f.stagger && <><div className="mt-3 grid gap-3 sm:grid-cols-[1fr_140px]"><Field label="Gap between lots"><input type="number" min={1} className={inputCls} value={f.gap} onChange={(e) => set("gap", e.target.value)} /></Field><Field label="Unit"><Sel v={f.unit} set={(v) => set("unit", v)} opts={["Minutes", "Seconds", "Hours"]} /></Field></div>
            <p className="mt-1 text-[11px] text-zinc-500">Lots close one after another, a gap apart, ending with the auction (lots can only close at or before the auction end). Use Staggered closing in the Lot Builder to apply the gap to your lots; closing times can still be set per lot.</p></>}</div>
      </Group>
      <Group title="Editing rules" sub="Control who can adjust auction settings while the sale is scheduled or live.">
        <div className="space-y-2"><Row title="Allow edits while upcoming" sub="Keep editable as the auction approaches its start date." on={f.up} onChange={(v) => set("up", v)} /><Row title="Allow edits while running" sub="Permit changes to auction settings once bidding begins." on={f.run} onChange={(v) => set("run", v)} /></div>
      </Group>
      <Group title="Bidder approval" sub="Control who can access bidding once registration is submitted.">
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Approval mode"><Sel v={f.approval} set={(v) => set("approval", v)} opts={["Approve Manually", "Approve Automatically"]} /></Field>
          <Field label="Bidder ranking"><Sel v={f.ranking} set={(v) => set("ranking", v)} opts={["Show top 10 bidders", "Show top 3 bidders", "Show all bidders", "Hide ranking"]} /></Field>
          <Field label="Soft close"><div className="flex gap-2"><input type="number" min={0} className={inputCls} value={f.soft} onChange={(e) => set("soft", e.target.value)} /><Sel v={f.softUnit} set={(v) => set("softUnit", v)} opts={["Minutes", "Seconds"]} /></div></Field>
          <Field label="Show bidder history"><Sel v={f.history} set={(v) => set("history", v)} opts={["Always", "After close", "Never"]} /></Field></div>
        <p className="mt-1 text-[11px] text-zinc-500">Approval mode, bidder masking, soft close, bidder ranking and bid history take effect immediately. Soft close: a bid placed in the last N minutes (or seconds) of a lot moves that lot’s closing time to bid time + N (0 = off, max 24 hours). Ranking and history show on the lot page; bidders appear as “Bidder 1, 2…” (or first name + last initial when masking is off), and a bidder always sees “You” on their own rows.</p>
        <div className="mt-3"><Row title="Mask bidder details" sub="Hide bidder names from competing bidders." on={f.mask} onChange={(v) => set("mask", v)} /></div>
      </Group>
      <Group title="Description" sub="Shown on the public auction page."><textarea rows={3} className={area} value={f.desc} onChange={(e) => set("desc", e.target.value)} /></Group>
      <Group title="Cover images" sub="Shown on the auction card and page of the public website. Saved to the database as soon as you upload.">
        <ImageManager kind="auction" id={a.id} images={cover} max={10} onChange={(i) => { setCover(i); a.images = i; }} />
      </Group>
      <Footer note={bad ? "Needs attention" : "Ready to review"} label="Save auction details" disabled={bad} busy={busy} err={err} onSave={save} />
    </>
  );
}

const money = (n: number) => (Number.isFinite(n) ? String(n) : "");
export function LotBidDetails({ a, saved }: P) {
  const cb = studio.companyBid; // Admin → Company → Lot Bid Details
  const mine = asObj(a.builder?.bid);
  const hasTiers = !!cb?.tiers && cb.tiers.length > 0;
  const [f, setF] = useState({
    start: money(typeof mine.start === "number" ? mine.start : cb?.set ? cb.start : 0),
    strat: mine.strategy === "tiered" ? "Tiered increments" : "Single increment",
    inc: money(typeof mine.increment === "number" && mine.increment > 0 ? mine.increment : cb?.set && cb.increment > 0 ? cb.increment : 0),
    apply: false,
  });
  const { busy, err, run } = useSave(saved);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));
  const n = (s: string) => Number(s.replace(/,/g, ""));
  const tiered = f.strat === "Tiered increments";
  const bad = !(n(f.start) >= 0) || f.start.trim() === "" || (!tiered && !(n(f.inc) > 0));
  const save = () => run(() => saveBuilder(a, "bid", { start: n(f.start), increment: tiered ? 0 : n(f.inc), strategy: tiered ? "tiered" : "single", applyExisting: f.apply }),
    (r: { applied?: number; skipped?: number }) => r.applied !== undefined ? `Bid settings saved and applied to ${r.applied} lot${r.applied === 1 ? "" : "s"}${r.skipped ? ` (${r.skipped} skipped: reserve below the new starting bid)` : ""}.` : "Bid settings saved. New lots will start with these values.");
  return (
    <>
      <p className="mb-3 text-[11px] text-zinc-500">{mine.start !== undefined ? "Your saved settings for this auction." : cb?.set ? "Starting from the company settings (Admin → Company → Lot Bid Details)." : "No company bid settings are set yet; enter the values for this auction."}</p>
      <Group title="Bid configuration" sub="New lots in this auction start with these values. Reserve prices are set per lot in the Lot Builder.">
        <div className="max-w-xs"><Field label="Starting bid"><input inputMode="decimal" className={inputCls} value={f.start} onChange={(e) => set("start", e.target.value)} /></Field></div>
      </Group>
      <Group title="Bid increments" sub="How bids advance during the auction.">
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Increment strategy"><Sel v={f.strat} set={(v) => set("strat", v)} opts={hasTiers ? ["Single increment", "Tiered increments"] : ["Single increment"]} /></Field>
          {!tiered && <Field label="Increment value"><input inputMode="decimal" className={inputCls} value={f.inc} onChange={(e) => set("inc", e.target.value)} /></Field>}</div>
        {tiered ? <p className="mt-1 text-[11px] text-zinc-500">Uses the tiers from Company → Lot Bid Details.</p> : !hasTiers && <p className="mt-1 text-[11px] text-zinc-500">Tiered increments appear here once they are set in Company → Lot Bid Details.</p>}
      </Group>
      <Group title="Existing lots"><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={f.apply} onChange={(e) => set("apply", e.target.checked)} />Also apply to lots in this auction that have no bids yet ({a.lots})</label>
        <p className="mt-1 text-[11px] text-zinc-500">Lots that already have bids are never changed. Lots whose reserve is below the new starting bid are skipped.</p></Group>
      <Footer note={`${f.strat} • ${tiered ? "company tiers" : f.inc}`} label="Save bid settings" disabled={bad} busy={busy} err={err} onSave={save} />
    </>
  );
}

type Contact = { id: string; name: string; email: string; phone: string; title: string; notes: string; primary: boolean; avatar?: string };
export function Contacts({ a, saved }: P) {
  const { confirm, dialog } = useConfirm();
  const [list, setList] = useState<Contact[]>(() => asList<Contact>(a.builder?.contacts).map((c) => ({ ...c, id: String(c.id) })));
  const [files, setFiles] = useState<Img[]>(a.contactFiles ?? []);
  const [upErr, setUpErr] = useState("");
  const { busy, err, run } = useSave(saved);
  const upd = (id: string, p: Partial<Contact>) => setList((l) => l.map((c) => (c.id === id ? { ...c, ...p } : c)));
  const move = (i: number, d: number) => setList((l) => { const n = [...l], j = i + d; if (j < 0 || j >= n.length) return l; [n[i], n[j]] = [n[j], n[i]]; return n; });
  const setPrimary = (id: string) => setList((l) => l.map((c) => ({ ...c, primary: c.id === id })));
  const urlOf = (n?: string) => files.find((f) => f.name === n)?.url;
  const bad = list.some((c) => !c.name.trim() || !/^\S+@\S+\.\S+$/.test(c.email.trim()));
  const upload = async (c: Contact, f?: File) => {
    if (!f) return;
    const p = imageProblem(f); if (p) { setUpErr(p); return; }
    setUpErr("");
    try { const r = await builderFiles(a, "avatar", [f]); setFiles(r.files); if (r.added[0]) upd(c.id, { avatar: r.added[0] }); }
    catch (e) { setUpErr(e instanceof Error ? e.message : "Could not upload the photo"); }
  };
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Auction contacts</h3><p className="text-[11px] text-zinc-500">Manage who appears on the auction landing page.</p></div>
        <Btn variant="solid" className="h-8 text-xs" onClick={() => setList((l) => [...l, { id: rid(), name: "", email: "", phone: "", title: "", notes: "", primary: l.length === 0 }])}><Plus className="size-3.5" />Add contact</Btn></div>
      <div className="mt-3 max-w-xs"><Field label="Company"><select className={inputCls} defaultValue={a.company}><option>{a.company}</option></select></Field></div>
      {list.some((c) => c.primary) && <span className="mt-2 inline-block rounded bg-zinc-100 px-2 py-0.5 text-[10px] text-zinc-600">Primary contact set</span>}
      {upErr && <p role="alert" className="mt-2 text-xs text-rose-600">{upErr}</p>}
      <div className="mt-3 space-y-3">
        {list.length === 0 && <p className="rounded-lg border border-zinc-200 bg-zinc-50 py-8 text-center text-xs text-zinc-500">No contacts yet.</p>}
        {list.map((c, i) => (
          <div key={c.id} className="rounded-xl border border-zinc-200 p-4">
            <div className="flex items-center gap-3"><div className="flex flex-col"><button aria-label="Move up" onClick={() => move(i, -1)} className="text-zinc-400 hover:text-ink"><ArrowUp className="size-3" /></button><button aria-label="Move down" onClick={() => move(i, 1)} className="text-zinc-400 hover:text-ink"><ArrowDown className="size-3" /></button></div>
              {urlOf(c.avatar) /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={urlOf(c.avatar)} alt="" className="size-8 rounded-full object-cover" /> : <span className="grid size-8 place-items-center rounded-full bg-zinc-100 text-xs font-semibold">{(c.name[0] ?? "?").toUpperCase()}</span>}<div className="min-w-0 flex-1"><p className="text-xs font-semibold">{c.name || "New contact"}</p><p className="text-[11px] text-zinc-500">{c.email}</p></div>
              {c.primary && <span className="rounded bg-primary px-2 py-0.5 text-[10px] font-semibold text-white">Primary</span>}
              <button aria-label="Delete contact" onClick={async () => { if (await confirm({ title: "Delete this contact?", body: `${c.name || "This contact"} will be removed from the auction when you save.`, confirmLabel: "Delete" })) setList((l) => l.filter((x) => x.id !== c.id)); }} className="text-rose-500 hover:text-rose-700"><Trash2 className="size-4" /></button></div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2"><Field label="Name"><input className={inputCls} value={c.name} onChange={(e) => upd(c.id, { name: e.target.value })} /></Field><Field label="Email"><input type="email" className={inputCls} value={c.email} onChange={(e) => upd(c.id, { email: e.target.value })} /></Field>
              <Field label="Phone"><input className={inputCls} value={c.phone} onChange={(e) => upd(c.id, { phone: e.target.value })} /></Field><Field label="Title"><input className={inputCls} placeholder="Auction Manager" value={c.title} onChange={(e) => upd(c.id, { title: e.target.value })} /></Field></div>
            <div className="mt-3"><Field label="Notes"><textarea rows={2} className={area} placeholder="Optional internal notes or contact responsibilities." value={c.notes} onChange={(e) => upd(c.id, { notes: e.target.value })} /></Field></div>
            <div className="mt-3 flex items-center justify-between"><span className="flex items-center gap-2"><label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-primary/40 px-3 text-xs font-semibold text-primary hover:bg-primary/5"><Upload className="size-3.5" />{c.avatar ? "Replace photo" : "Upload photo"}<input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(e) => { upload(c, e.target.files?.[0]); e.target.value = ""; }} /></label>
              {c.avatar && <button className="text-[11px] text-rose-600 hover:underline" onClick={() => upd(c.id, { avatar: "" })}>Remove photo</button>}</span>
              <span className="flex items-center gap-2 text-[11px]">Primary contact<Toggle on={c.primary} onChange={(v) => v ? setPrimary(c.id) : upd(c.id, { primary: false })} label="Primary contact" /></span></div>
          </div>
        ))}
      </div>
      <Footer note={`${list.length} contact${list.length === 1 ? "" : "s"}`} label="Save contacts" disabled={bad} busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "contacts", list.map((c) => ({ ...c, name: c.name.trim(), email: c.email.trim() }))), "Contacts saved.")} />
      {dialog}
    </>
  );
}

/** HTML (already cleaned by the backend) to a short plain-text excerpt for the preview. */
const excerpt = (html: string, n = 320) => {
  const t = (new DOMParser().parseFromString(html, "text/html").body.textContent ?? "").replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n).trimEnd()}…` : t;
};

/** Which policy from Auction House → Legal Policies (also Company → Policies) this auction uses. Saved in auctions.builder.legal. */
export function LegalPolicy({ a, saved }: P) {
  const stored = asObj(a.builder?.legal);
  const savedId = typeof stored.policyId === "string" ? stored.policyId : "";
  const savedName = typeof stored.name === "string" ? stored.name : "";
  const [id, setId] = useState(savedId);
  const [list, setList] = useState<LegalDoc[] | null>(null);
  const [loadErr, setLoadErr] = useState("");
  const { busy, err, run } = useSave(saved);
  useEffect(() => {
    let live = true;
    fetchHouse().then((h) => { if (live) setList(h.legal); }).catch((e) => { if (live) setLoadErr(e instanceof Error ? e.message : "Could not load the legal policies."); });
    return () => { live = false; };
  }, []);
  const cur = list?.find((p) => p.id === id);
  const gone = !!id && list !== null && !cur; // the saved policy was deleted in Auction House afterwards
  return (
    <>
      <Group title="Legal policy" sub="Select the legal policy associated with this auction. Policies are managed in Auction House → Legal Policies.">
        <div className="max-w-xs">
          <select className={inputCls} value={id} disabled={list === null && !loadErr} onChange={(e) => setId(e.target.value)}>
            <option value="">{list === null && !loadErr ? "Loading…" : "Select a policy"}</option>
            {gone && <option value={id}>{savedName || "Saved policy"} (no longer available)</option>}
            {(list ?? []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        {loadErr && <p role="alert" className="mt-2 text-[11px] text-rose-600">{loadErr}</p>}
        {list !== null && list.length === 0 && <p className="mt-2 text-[11px] text-zinc-500">No legal policies yet. Add one in Auction House → Legal Policies first.</p>}
      </Group>
      <div className="mt-4 rounded-lg border border-zinc-200 p-4"><span className="rounded bg-zinc-100 px-2 py-0.5 text-[11px] font-semibold">{cur ? cur.name : gone ? `${savedName || "Saved policy"} (no longer available)` : "No policy selected"}</span>
        <div className="mt-3 rounded-lg border border-zinc-200 p-4">
          {cur ? (
            <div className="space-y-3 text-xs text-zinc-700">
              <div><p className="text-[10px] font-bold uppercase text-zinc-500">Privacy policy</p><p className="mt-1">{excerpt(cur.privacy) || "—"}</p></div>
              <div><p className="text-[10px] font-bold uppercase text-zinc-500">Terms of use</p><p className="mt-1">{excerpt(cur.terms) || "—"}</p></div>
            </div>
          ) : (
            <div className="grid place-items-center py-6 text-center"><Shield className="size-8 text-sky-500" /><p className="mt-2 text-sm font-semibold">{gone ? "This policy was removed" : "No policy selected"}</p><p className="text-xs text-zinc-500">{gone ? "Choose another policy, or clear the selection." : "Choose a privacy policy and terms of use to review the content here."}</p></div>
          )}
        </div>
      </div>
      <Footer note={cur ? "Policy selected" : "No policy selected"} label="Save legal policy" busy={busy} err={err} disabled={list === null || id === savedId}
        onSave={() => run(() => saveBuilder(a, "legal", { policyId: id }), id ? "Legal policy saved." : "Legal policy cleared.")} />
    </>
  );
}


type Loc = { id: string; label: string; l1: string; l2: string; city: string; state: string; country: string; zip: string; phone: string; lat: string; lng: string };
const MAPS_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY;
/** Live map from the coordinates: Google Maps when NEXT_PUBLIC_GOOGLE_MAPS_KEY is set, otherwise OpenStreetMap (no key needed). */
function MapPreview({ lat, lng }: { lat: string; lng: string }) {
  const la = Number(lat), ln = Number(lng);
  if (lat.trim() === "" || lng.trim() === "" || isNaN(la) || isNaN(ln) || Math.abs(la) > 90 || Math.abs(ln) > 180)
    return <div className="mt-3 grid h-40 place-items-center rounded-lg bg-sky-50 text-center text-xs text-zinc-500"><div><MapPin className="mx-auto mb-1 size-6 text-rose-500" />Enter a latitude and longitude to preview the map.</div></div>;
  const src = MAPS_KEY ? `https://www.google.com/maps/embed/v1/place?key=${encodeURIComponent(MAPS_KEY)}&q=${la},${ln}&zoom=15`
    : `https://www.openstreetmap.org/export/embed.html?bbox=${ln - 0.01},${la - 0.006},${ln + 0.01},${la + 0.006}&layer=mapnik&marker=${la},${ln}`;
  return <div className="mt-3"><iframe title={`Map at ${la}, ${ln}`} src={src} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-40 w-full rounded-lg border border-zinc-200" />
    <a href={`https://www.google.com/maps?q=${la},${ln}`} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1 text-[11px] text-primary hover:underline">Open in Google Maps<ExternalLink className="size-3" /></a></div>;
}
export function Address({ a, saved }: P) {
  const { confirm, dialog } = useConfirm();
  const [list, setList] = useState<Loc[]>(() => asList<Loc>(a.builder?.address).map((l) => ({ ...l, id: String(l.id) })));
  const { busy, err, run } = useSave(saved);
  const upd = (id: string, p: Partial<Loc>) => setList((l) => l.map((c) => (c.id === id ? { ...c, ...p } : c)));
  const badCoord = (v: string, lim: number) => v.trim() !== "" && (isNaN(Number(v)) || Math.abs(Number(v)) > lim);
  const bad = list.some((l) => !l.label.trim() || !l.l1.trim() || badCoord(l.lat, 90) || badCoord(l.lng, 180));
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Auction locations</h3><p className="text-[11px] text-zinc-500">Define viewing or inspection addresses for bidders.</p></div>
        <Btn variant="solid" className="h-8 text-xs" onClick={() => setList((l) => [...l, { id: rid(), label: "", l1: "", l2: "", city: "", state: "", country: "Malaysia", zip: "", phone: "", lat: "", lng: "" }])}><Plus className="size-3.5" />Add location</Btn></div>
      <div className="mt-3 space-y-3">{list.length === 0 && <p className="rounded-lg border border-zinc-200 bg-zinc-50 py-8 text-center text-xs text-zinc-500">No locations yet.</p>}{list.map((c) => (
        <div key={c.id} className="rounded-xl border border-zinc-200 p-4">
          <div className="flex items-center justify-between"><p className="text-xs font-semibold">{c.label || "New location"}</p><button aria-label="Delete location" onClick={async () => { if (await confirm({ title: "Delete this location?", body: `${c.label || "This location"} will be removed from the auction when you save.`, confirmLabel: "Delete" })) setList((l) => l.filter((x) => x.id !== c.id)); }} className="text-rose-500 hover:text-rose-700"><Trash2 className="size-4" /></button></div>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field label="Label"><input className={inputCls} value={c.label} onChange={(e) => upd(c.id, { label: e.target.value })} /></Field><Field label="Address line 1"><input className={inputCls} value={c.l1} onChange={(e) => upd(c.id, { l1: e.target.value })} /></Field>
            <Field label="Address line 2"><input className={inputCls} placeholder="Suite, unit" value={c.l2} onChange={(e) => upd(c.id, { l2: e.target.value })} /></Field><Field label="City"><input className={inputCls} value={c.city} onChange={(e) => upd(c.id, { city: e.target.value })} /></Field>
            <Field label="State / Province"><input className={inputCls} value={c.state} onChange={(e) => upd(c.id, { state: e.target.value })} /></Field><Field label="Country"><Sel v={c.country} set={(v) => upd(c.id, { country: v })} opts={Array.from(new Set([c.country, "Malaysia", "Singapore", "Thailand", "Indonesia"].filter(Boolean)))} /></Field>
            <Field label="Postal code"><input className={inputCls} value={c.zip} onChange={(e) => upd(c.id, { zip: e.target.value })} /></Field><Field label="Contact number"><input className={inputCls} value={c.phone} onChange={(e) => upd(c.id, { phone: e.target.value })} /></Field>
            <Field label="Latitude"><input className={inputCls} value={c.lat} onChange={(e) => upd(c.id, { lat: e.target.value })} /></Field><Field label="Longitude"><input className={inputCls} value={c.lng} onChange={(e) => upd(c.id, { lng: e.target.value })} /></Field>
          </div>
          {(badCoord(c.lat, 90) || badCoord(c.lng, 180)) && <p role="alert" className="mt-1 text-[11px] text-rose-600">Latitude must be within ±90 and longitude within ±180.</p>}
          <MapPreview lat={c.lat} lng={c.lng} />
        </div>))}</div>
      <Footer note={`${list.length} location${list.length === 1 ? "" : "s"}`} label="Save address" disabled={bad} busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "address", list), "Address saved.")} />
      {dialog}
    </>
  );
}

export function Documents({ a }: P) {
  const { confirm, dialog } = useConfirm();
  const [docs, setDocs] = useState<Img[]>(a.documents ?? []);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const apply = async (add: File[], remove: string[] = []) => {
    setBusy(true); setErr("");
    try { setDocs((await builderFiles(a, "document", add, remove)).files); }
    catch (e) { setErr(e instanceof Error ? e.message : "Could not update the documents"); }
    setBusy(false);
  };
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Supporting documents</h3><p className="text-[11px] text-zinc-500">Upload brochures, terms, or shipping instructions for bidders. PDF, Word, Excel, PNG or JPG, up to 25 MB each. Saved as soon as you upload.</p></div>
        <label className={`inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md bg-primary px-3 text-xs font-semibold text-white hover:bg-primary-700 ${busy ? "pointer-events-none opacity-60" : ""}`}><Upload className="size-3.5" />{busy ? "Working…" : "Upload"}<input type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg" className="sr-only" onChange={(e) => { const fs = Array.from(e.target.files ?? []); e.target.value = ""; if (fs.length) apply(fs); }} /></label></div>
      {err && <p role="alert" className="mt-2 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-700">{err}</p>}
      <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50">{docs.length === 0 ? <p className="py-10 text-center text-xs text-zinc-500">No documents yet. Upload PDFs, terms, or other reference files for bidders.</p> :
        <ul className="divide-y divide-zinc-200">{docs.map((d) => <li key={d.name} className="flex items-center justify-between px-3 py-2 text-xs"><a href={d.url} target="_blank" rel="noreferrer" className="text-primary hover:underline">{shortName(d.name)}</a><button aria-label={`Remove ${shortName(d.name)}`} disabled={busy} onClick={async () => { if (await confirm({ title: "Remove this document?", body: `${shortName(d.name)} will be deleted from the auction.`, confirmLabel: "Remove" })) apply([], [d.name]); }} className="text-rose-500"><Trash2 className="size-4" /></button></li>)}</ul>}</div>
      <p className="mt-4 text-[11px] text-zinc-500">{docs.length} document{docs.length === 1 ? "" : "s"}</p>
      {dialog}
    </>
  );
}

type BankRow = { id: string; name: string; last4: string; isDefault?: boolean };
const maskBank = (last4: string) => (last4 ? `•••• ${last4}` : "••••");

/** Which payout bank from Company → Bank this auction settles to. Saved in auctions.builder.bank (name + last 4 digits only). */
export function FinancialSupplier({ a, saved }: P) {
  const stored = asObj(a.builder?.bank);
  const savedId = typeof stored.bankId === "string" ? stored.bankId : "";
  const savedName = typeof stored.name === "string" ? stored.name : "";
  const savedLast4 = typeof stored.last4 === "string" ? stored.last4 : "";
  const [id, setId] = useState(savedId);
  const [banks, setBanks] = useState<BankRow[] | null>(null);
  const [loadErr, setLoadErr] = useState("");
  const { busy, err, run } = useSave(saved);
  useEffect(() => {
    let live = true;
    loadCompany()
      .then((d) => { if (live) setBanks(asList<BankRow>(d.banks).filter((b) => b && typeof b.id === "string" && typeof b.name === "string")); })
      .catch((e) => { if (live) setLoadErr(e instanceof Error ? e.message : "Could not load the banks."); });
    return () => { live = false; };
  }, []);
  const cur = banks?.find((b) => b.id === id);
  const gone = !!id && banks !== null && !cur; // the saved bank was removed in Company → Bank afterwards
  return (
    <>
      <Group title="Bank details" sub="Choose the payout bank used for settlement and accounting exports. Banks are managed in Company → Bank.">
        <div className="max-w-xs">
          <select className={inputCls} value={id} disabled={banks === null && !loadErr} onChange={(e) => setId(e.target.value)}>
            <option value="">{banks === null && !loadErr ? "Loading…" : "Select a bank"}</option>
            {gone && <option value={id}>{savedName || "Saved bank"} {maskBank(savedLast4)} (no longer available)</option>}
            {(banks ?? []).map((b) => <option key={b.id} value={b.id}>{b.name} {maskBank(b.last4)}{b.isDefault ? " · default" : ""}</option>)}
          </select>
        </div>
        {loadErr && <p role="alert" className="mt-2 text-[11px] text-rose-600">{loadErr}</p>}
        {banks !== null && banks.length === 0 && <p className="mt-2 text-[11px] text-zinc-500">No banks yet. Add one in Company → Bank first.</p>}
        <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-xs">
          <p className="text-[10px] font-bold uppercase text-zinc-500">Bank</p><p className="font-semibold">{cur ? cur.name : gone ? `${savedName || "Saved bank"} (no longer available)` : "—"}</p>
          <p className="mt-2 text-[10px] font-bold uppercase text-zinc-500">Account number</p><p className="font-semibold">{cur ? maskBank(cur.last4) : gone ? maskBank(savedLast4) : "—"}</p>
        </div>
      </Group>
      <Footer note={cur ? `Selected: ${cur.name}` : "No bank selected"} label="Save bank details" busy={busy} err={err} disabled={banks === null || id === savedId}
        onSave={() => run(() => saveBuilder(a, "bank", { bankId: id }), id ? "Bank details saved." : "Bank selection cleared.")} />
    </>
  );
}


type Q = { id: string; text: string; help: string; req: boolean };
const PRESETS: Record<string, string[]> = { "Use Basic contact info": ["Company name", "Tax ID"], "Use Asset inspection": ["Preferred inspection date", "Number of attendees"] };
export function BidderRegistration({ a, saved }: P) {
  const mk = (t: string): Q => ({ id: `q_${rid()}`, text: t, help: "", req: false });
  const [qs, setQs] = useState<Q[]>(() => asList<Partial<Q>>(a.builder?.registration).map((q): Q => ({ text: "", help: "", req: false, ...q, id: String(q.id) })));
  const { busy, err, run } = useSave(saved);
  const upd = (id: string, p: Partial<Q>) => setQs((l) => l.map((c) => (c.id === id ? { ...c, ...p } : c)));
  const move = (i: number, d: number) => setQs((l) => { const n = [...l], j = i + d; if (j < 0 || j >= n.length) return l; [n[i], n[j]] = [n[j], n[i]]; return n; });
  return (
    <>
      <Group title="Bidder registration questions" sub="Collect additional information from bidders as part of the registration flow. When this list has questions, it replaces the company-wide questionnaire for this auction.">
        <div className="flex flex-wrap items-center gap-2"><Btn variant="outline" className="h-8 text-xs" onClick={() => setQs((l) => [...l, mk("")])}><Plus className="size-3.5" />Add question</Btn>
          {Object.keys(PRESETS).map((k) => <button key={k} onClick={() => setQs(PRESETS[k].map(mk))} className="px-2 text-xs font-semibold text-primary hover:underline">{k}</button>)}</div>
      </Group>
      <div className="mt-3 space-y-3">{qs.length === 0 && <p className="rounded-lg border border-zinc-200 bg-zinc-50 py-8 text-center text-xs text-zinc-500">No auction-specific questions. Bidders answer the company questionnaire (if any).</p>}{qs.map((q, i) => (
        <div key={q.id} className="rounded-xl border border-zinc-200 p-3">
          <div className="mb-2 flex items-center gap-2"><button aria-label="Move up" onClick={() => move(i, -1)} className="text-zinc-400 hover:text-ink"><ArrowUp className="size-3.5" /></button><button aria-label="Move down" onClick={() => move(i, 1)} className="text-zinc-400 hover:text-ink"><ArrowDown className="size-3.5" /></button><span className="rounded bg-zinc-100 px-2 py-0.5 text-[10px] font-semibold">Question {i + 1}</span><button aria-label="Delete question" onClick={() => setQs((l) => l.filter((x) => x.id !== q.id))} className="ml-auto text-rose-500"><Trash2 className="size-4" /></button></div>
          <input aria-label={`Question ${i + 1}`} className={inputCls} placeholder="Question text" maxLength={300} value={q.text} onChange={(e) => upd(q.id, { text: e.target.value })} />
          <textarea rows={2} className={`${area} mt-2`} placeholder="Optional helper text" value={q.help} onChange={(e) => upd(q.id, { help: e.target.value })} />
          <label className="mt-2 flex items-center gap-2 text-[11px] text-zinc-600"><Toggle on={q.req} onChange={(v) => upd(q.id, { req: v })} label="Required question" />Required question</label>
        </div>))}</div>
      <Footer note={`${qs.length} question${qs.length === 1 ? "" : "s"}`} label="Save questions" disabled={qs.some((q) => !q.text.trim())} busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "registration", qs.map((q) => ({ ...q, text: q.text.trim() }))), "Registration questions saved.")} />
    </>
  );
}

export function CommissionTax({ a, saved }: P) {
  const mine = asObj(a.builder?.commission);
  const [f, setF] = useState({ fed: String(mine.fed ?? ""), st: String(mine.st ?? ""), notes: String(mine.notes ?? "") });
  const { busy, err, run } = useSave(saved);
  const bad = [f.fed, f.st].some((v) => v.trim() !== "" && (isNaN(Number(v)) || Number(v) < 0 || Number(v) > 100));
  return (
    <>
      <div><h3 className="text-sm font-bold">Commission &amp; tax</h3><p className="text-[11px] text-zinc-500">Tax percentages and internal commission notes for this auction.</p></div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2"><Field label="Federal tax (%)"><input className={inputCls} placeholder="Ex: 5" value={f.fed} onChange={(e) => setF({ ...f, fed: e.target.value })} /></Field><Field label="State tax (%)"><input className={inputCls} placeholder="Ex: 2.5" value={f.st} onChange={(e) => setF({ ...f, st: e.target.value })} /></Field></div>
      {bad && <p role="alert" className="mt-1 text-[11px] text-rose-600">Tax must be a number between 0 and 100.</p>}
      <div className="mt-3"><Field label="Internal notes"><textarea rows={3} className={area} placeholder="Add context for finance or comments from the original auction." value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field></div>
      <div className="mt-4"><div className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Buyer fee tiers</div>
        <div className="mt-2 rounded-lg border border-zinc-200 bg-zinc-50 py-8 text-center text-[11px] text-zinc-500">Buyer fees are managed in Admin → Auction House → Fees &amp; Commissions. Importing them into an auction isn’t connected yet.</div></div>
      <Footer note="Tax rates and notes" label="Save commission & tax" disabled={bad} busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "commission", { fed: f.fed.trim(), st: f.st.trim(), notes: f.notes }), "Commission & tax saved.")} />
    </>
  );
}

export function PaymentConfig({ a, saved }: P) {
  const [on, setOn] = useState(!!asObj(a.builder?.payment).enabled);
  const { busy, err, run } = useSave(saved);
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Payment Configuration</h3><p className="text-[11px] text-zinc-500">Enable payment processing for this auction.</p></div><span className="flex items-center gap-1 text-[11px] text-zinc-500"><CreditCard className="size-3.5" />Payment Settings</span></div>
      <div className="mt-3"><Row title="Enable Payment" sub="Allow payment processing for this auction" on={on} onChange={setOn} /></div>
      <Footer note={on ? "Payment enabled" : "Payment disabled"} label="Save Payment Configuration" busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "payment", { enabled: on }), "Payment configuration saved.")} />
    </>
  );
}

/** Derived from the lots themselves: every active lot's consignor (set in the Lot Builder). */
export function Consignors({ lots }: P) {
  const groups = new Map<string, number[]>();
  let none = 0;
  for (const l of lots) {
    if (l.status !== "Active") continue;
    const c = l.consignor.trim();
    if (!c) { none++; continue; }
    groups.set(c, [...(groups.get(c) ?? []), l.no]);
  }
  const rows = [...groups.entries()].sort((x, y) => x[0].localeCompare(y[0]));
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Active consignors</h3><p className="text-[11px] text-zinc-500">Consignors with at least one active lot in this auction.</p></div><span className="rounded border border-zinc-200 px-2 py-0.5 text-[10px] text-zinc-600">{rows.length} consignor{rows.length === 1 ? "" : "s"}</span></div>
      {rows.length === 0 ? <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50 py-10 text-center text-xs text-zinc-500">No consignors have active lots yet.<span className="block text-[10px]">Set a consignor on each lot in the Lot Builder.</span></div> :
        <ul className="mt-3 divide-y divide-zinc-200 rounded-lg border border-zinc-200">{rows.map(([n, nos]) => <li key={n} className="flex items-center justify-between px-3 py-2 text-xs"><span className="font-semibold">{n}</span><span className="text-zinc-500">{nos.length} lot{nos.length === 1 ? "" : "s"} · {nos.sort((x, y) => x - y).map((x) => `#${x}`).join(", ")}</span></li>)}</ul>}
      {none > 0 && <p className="mt-2 text-[11px] text-zinc-500">{none} active lot{none === 1 ? " has" : "s have"} no consignor.</p>}
    </>
  );
}

export function CatalogEmails({ a, saved }: P) {
  const { confirm, dialog } = useConfirm();
  const cat = asObj(a.builder?.catalog);
  const stored = asList<string>(cat.emails);
  const [list, setList] = useState<string[]>(stored);
  const [v, setV] = useState("");
  const [sendBusy, setSendBusy] = useState(false);
  const [sendErr, setSendErr] = useState("");
  const { busy, err, run } = useSave(saved);
  const valid = /^\S+@\S+\.\S+$/.test(v.trim());
  const dupe = list.includes(v.trim().toLowerCase());
  const dirty = list.length !== stored.length || list.some((e, i) => e !== stored[i]);
  const add = () => { if (valid && !dupe) { setList((l) => [...l, v.trim().toLowerCase()]); setV(""); } };
  const importList = async (f?: File) => { if (!f) return; const found = (await f.text()).split(/[\s,;]+/).map((s) => s.trim().toLowerCase()).filter((s) => /^\S+@\S+\.\S+$/.test(s)); setList((l) => Array.from(new Set([...l, ...found]))); };
  const sentAt = typeof cat.sentAt === "string" ? cat.sentAt : "";
  const send = async () => {
    if (!(await confirm({ title: "Email the catalog to these recipients?", body: `${stored.length} recipient${stored.length === 1 ? "" : "s"} will each get an email about “${a.title}”.`, confirmLabel: "Send emails", tone: "primary" }))) return;
    setSendBusy(true); setSendErr("");
    try { const r = await notifyCatalog(a); saved(`Sent to ${r.sent} recipient${r.sent === 1 ? "" : "s"}${r.failed ? ` (${r.failed} failed)` : ""}.`); }
    catch (e) { setSendErr(e instanceof Error ? e.message : "Could not send the emails"); }
    setSendBusy(false);
  };
  return (
    <>
      <div className="flex items-start justify-between"><div><h3 className="text-sm font-bold">Catalog notification emails</h3><p className="text-[11px] text-zinc-500">Keep preferred suppliers informed when the catalog is published.</p></div>
        <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-zinc-300 px-3 text-xs font-semibold hover:bg-zinc-50"><Upload className="size-3.5" />Import list<input type="file" accept=".csv,.txt" className="sr-only" onChange={(e) => { importList(e.target.files?.[0]); e.target.value = ""; }} /></label></div>
      <div className="mt-3 flex max-w-sm gap-2"><input type="email" aria-label="Supplier email" className={inputCls} placeholder="supplier@example.com" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} /><Btn variant="solid" className="h-9 text-xs" disabled={!valid || dupe} onClick={add}>Add email</Btn></div>
      {dupe && <p role="alert" className="mt-1 text-[11px] text-rose-600">This email is already on the list.</p>}
      <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50">{list.length === 0 ? <p className="py-10 text-center text-xs text-zinc-500">No notification emails yet.</p> :
        <ul className="divide-y divide-zinc-200">{list.map((e) => <li key={e} className="flex items-center justify-between px-3 py-2 text-xs">{e}<button aria-label={`Remove ${e}`} onClick={() => setList((l) => l.filter((x) => x !== e))} className="text-rose-500"><Trash2 className="size-4" /></button></li>)}</ul>}</div>
      <div className="mt-4 rounded-lg border border-zinc-200 p-3">
        <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-semibold">Send the catalog email</p><p className="text-[11px] text-zinc-500">{!a.published ? "Publish the auction first." : dirty ? "Save the recipients first." : stored.length === 0 ? "Add and save recipients first." : sentAt ? `Last sent ${new Date(sentAt).toLocaleString("en-GB", { timeZone: a.tz ?? "Asia/Kuala_Lumpur", dateStyle: "medium", timeStyle: "short" })} to ${String(cat.sentCount ?? "?")} recipients.` : "Not sent yet. Emails go out only when you press Send."}</p></div>
          <Btn variant="outline" className="h-8 text-xs" disabled={!a.published || dirty || stored.length === 0 || sendBusy} onClick={send}>{sendBusy ? "Sending…" : "Send now"}</Btn></div>
        {sendErr && <p role="alert" className="mt-2 text-xs text-rose-600">{sendErr}</p>}</div>
      <Footer note={`${list.length} recipient${list.length === 1 ? "" : "s"}`} label="Save recipients" busy={busy} err={err} onSave={() => run(() => saveBuilder(a, "catalog", { emails: list }), "Recipients saved.")} />
      {dialog}
    </>
  );
}

export const SECTION_VIEWS: Record<string, (p: P) => ReactNode> = {
  "Auction Info": AuctionInfo, "Lot Bid Details": LotBidDetails, Contacts, "Legal Policy": LegalPolicy, Address, Documents,
  "Financial Supplier": FinancialSupplier, "Bidder Registration": BidderRegistration, "Commission & Tax": CommissionTax,
  "Payment Configuration": PaymentConfig, Consignors, "Catalog Notification": CatalogEmails,
};
