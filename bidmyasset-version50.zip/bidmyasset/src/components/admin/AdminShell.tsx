"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, type MouseEvent as ReactMouseEvent, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Activity, BarChart3, Bell, Briefcase, Building2, ChevronDown, Contact, ExternalLink, FileText, Gavel, Home, Inbox,
  Layers, LogOut, Mail, Menu, Phone, RefreshCw, Settings, User, UserCheck, Users, X, type LucideIcon,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { LegalLinks } from "@/components/LegalPopup";
import { CONTACT } from "@/lib/content";
import { ADMIN_NAV, type AdminNotice } from "@/lib/admin";
import { Avatar, useConfirm } from "@/components/admin/ui";
import { trackAdmin } from "@/lib/trackAdmin";
import { useRefresh } from "@/lib/useRefresh";

const ICONS: Record<string, LucideIcon> = {
  home: Home, building: Building2, briefcase: Briefcase, layers: Layers, users: Users, userCheck: UserCheck,
  gavel: Gavel, contact: Contact, file: FileText, chart: BarChart3, activity: Activity, inbox: Inbox,
};

type Ctx = { notices: AdminNotice[]; unread: number; markAll: () => void; markOne: (id: string) => void };
const NoticeCtx = createContext<Ctx>({ notices: [], unread: 0, markAll: () => {}, markOne: () => {} });
export const useAdminNotices = () => useContext(NoticeCtx);

function useOutside(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && close();
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open, close]);
  return ref;
}

const shortTime = (iso: string) => new Date(iso).toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "numeric", minute: "2-digit" });

function Sidebar({ unread, expanded = true, onNavigate, onItemClick }: {
  unread: number; expanded?: boolean; onNavigate?: () => void; onItemClick?: (e: ReactMouseEvent<HTMLAnchorElement>) => void;
}) {
  const path = usePathname();
  const item = (href: string, label: string, I: LucideIcon, badge?: number) => {
    const active = path === href || path.startsWith(href + "/");
    return (
      <Link key={href} href={href} title={label} aria-label={label}
        onClick={(e) => { onItemClick?.(e); if (!e.defaultPrevented) onNavigate?.(); }}
        aria-current={active ? "page" : undefined}
        className={`relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium text-white/90 transition ${active ? "bg-primary text-white" : "hover:bg-white/10"} ${expanded ? "" : "justify-center"}`}>
        <I className="size-[18px] shrink-0" />
        {expanded && <span className="whitespace-nowrap">{label}</span>}
        {badge !== undefined && (expanded
          ? <span className="ml-auto rounded-full bg-white px-1.5 text-[10px] font-bold text-brand">{badge}</span>
          : badge > 0 && <span className="absolute -right-0.5 -top-0.5 grid min-w-4 place-items-center rounded-full bg-sky-400 px-1 text-[9px] font-bold leading-4 text-white">{badge}</span>)}
      </Link>
    );
  };
  return (
    <nav className="flex h-full flex-col bg-[#032250] p-2.5 pt-14">
      <div className="space-y-1">
        {ADMIN_NAV.map((n) => (
          <div key={n.href}>
            {item(n.href, n.label, ICONS[n.icon])}
            {"divider" in n && n.divider && <div className="my-2 border-t border-white/15" />}
          </div>
        ))}
      </div>
      <div className="mt-auto space-y-1 pb-8">
        {item("/admin/notifications", "Notifications", Bell, unread)}
        {item("/admin/settings", "Settings", Settings)}
      </div>
    </nav>
  );
}

/** "/admin/auction-studio/1025" → "Auction Studio › 1025" */
function pageLabel(path: string) {
  const nav = ADMIN_NAV.find((n) => path === n.href || path.startsWith(n.href + "/"));
  const rest = nav ? path.slice(nav.href.length).split("/").filter(Boolean) : path.replace(/^\/admin\/?/, "").split("/").filter(Boolean);
  return [nav?.label ?? "Admin", ...rest].join(" › ");
}

export function AdminShell({ children, notices: initial, user: adminUser }: { children: ReactNode; notices: AdminNotice[]; user: { name: string; email: string } }) {
  const router = useRouter();
  const pathname = usePathname();
  const lastTracked = useRef("");
  useEffect(() => { if (lastTracked.current !== pathname) { lastTracked.current = pathname; trackAdmin(`Viewed ${pageLabel(pathname)}`); } }, [pathname]);
  const { confirm, dialog } = useConfirm();
  const [drawer, setDrawer] = useState(false);
  const [rail, setRail] = useState(false); // desktop rail: closed by default, opens on hover / focus / touch
  const railRef = useRef<HTMLElement>(null);
  const tap = useRef({ touch: false, wasOpen: false }); // state of the rail at the moment of the last pointer-down
  const [bell, setBell] = useState(false);
  const [menu, setMenu] = useState(false);
  // Notices and which ones this admin has read both come from the database, so read state follows the admin across browsers.
  const [notices, setNotices] = useState(initial);
  useEffect(() => { setNotices(initial); }, [initial]);
  const remember = (ids: string[]) => {
    if (!ids.length) return;
    fetch("/api/admin/notices/read", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) }).catch(() => { /* offline: it shows as unread again after the next refresh */ });
  };
  const { refresh, busy } = useRefresh();
  const unread = notices.filter((n) => !n.read).length;
  const bellRef = useOutside(bell, () => setBell(false));
  const menuRef = useOutside(menu, () => setMenu(false));
  const markAll = () => { remember(notices.filter((n) => !n.read).map((n) => n.id)); setNotices((l) => l.map((n) => ({ ...n, read: true }))); };
  const markOne = (id: string) => { remember([id]); setNotices((l) => l.map((n) => (n.id === id ? { ...n, read: true } : n))); };
  const preview = notices.filter((n) => !n.read).slice(0, 3);

  // touch: tap anywhere outside the open rail to close it
  useEffect(() => {
    if (!rail) return;
    const h = (e: PointerEvent) => railRef.current && !railRef.current.contains(e.target as Node) && setRail(false);
    document.addEventListener("pointerdown", h);
    return () => document.removeEventListener("pointerdown", h);
  }, [rail]);

  // touch: first tap on a collapsed rail only opens it (so you can see the labels); second tap navigates
  const onRailItem = (e: ReactMouseEvent<HTMLAnchorElement>) => {
    if (tap.current.touch && !tap.current.wasOpen) { e.preventDefault(); setRail(true); }
  };

  return (
    <NoticeCtx.Provider value={{ notices, unread, markAll, markOne }}>
      <div className="min-h-screen bg-zinc-100">
        <header className="fixed inset-x-0 top-0 z-40 flex h-11 items-center justify-between border-b border-zinc-200 bg-white px-3 sm:px-5 lg:left-16">
          <div className="flex items-center gap-3 lg:pl-2">
            <button aria-label="Open menu" onClick={() => setDrawer(true)} className="rounded p-1.5 hover:bg-zinc-100 lg:hidden"><Menu className="size-5" /></button>
            <Logo className="h-6" />
          </div>
          <div className="flex items-center gap-2">
            <div ref={bellRef} className="relative">
              <button aria-label="Notifications" onClick={() => { setBell((v) => !v); setMenu(false); }} className="relative rounded-full p-2 hover:bg-zinc-100">
                <Bell className="size-[17px]" />
                {unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid min-w-4 place-items-center rounded-full bg-red-600 px-1 text-[9px] font-bold leading-4 text-white">{unread}</span>}
              </button>
              {bell && (
                <div className="absolute right-0 mt-2 w-[22rem] max-w-[calc(100vw-1.5rem)] overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-xl">
                  <div className="flex items-center justify-between border-b border-zinc-100 px-4 py-3">
                    <div>
                      <p className="text-sm font-bold">Notifications</p>
                      <p className="text-[11px] text-zinc-500">{unread ? `${unread} unread` : "All caught up"}</p>
                    </div>
                    <div className="flex items-center gap-3 text-zinc-600">
                      <button aria-label="Refresh" disabled={busy} onClick={refresh}><RefreshCw className={`size-3.5 ${busy ? "animate-spin" : ""}`} /></button>
                      <button onClick={markAll} disabled={!unread} className="text-xs font-semibold disabled:text-zinc-400">Mark all read</button>
                    </div>
                  </div>
                  {preview.length === 0 ? (
                    <p className="px-4 py-8 text-center text-sm text-zinc-500">No unread notifications.</p>
                  ) : (
                    <ul className="divide-y divide-zinc-100">
                      {preview.map((n) => (
                        <li key={n.id} className="flex gap-3 px-4 py-3">
                          <span className="grid size-8 shrink-0 place-items-center rounded-full bg-blue-50 text-primary"><Bell className="size-4" /></span>
                          <div className="min-w-0 text-xs">
                            <div className="flex items-start justify-between gap-2">
                              <p className="font-semibold">{n.title}</p>
                              <span className="shrink-0 text-[11px] font-semibold text-primary">{shortTime(n.at)}</span>
                            </div>
                            <p className="mt-0.5 line-clamp-2 text-zinc-500">{n.body}</p>
                            <Link href="/admin/notifications" onClick={() => { markOne(n.id); setBell(false); }} className="mt-1 inline-block font-semibold text-primary">View</Link>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                  {unread > preview.length && <p className="border-t border-zinc-100 py-2 text-center text-xs text-zinc-500">+{unread - preview.length} more notifications</p>}
                  <div className="flex gap-2 border-t border-zinc-100 p-3">
                    <button onClick={markAll} className="flex-1 rounded-md border border-primary/30 py-2 text-xs font-semibold text-primary hover:bg-primary/5">Mark all read</button>
                    <Link href="/admin/notifications" onClick={() => setBell(false)} className="flex-1 rounded-md bg-primary py-2 text-center text-xs font-semibold text-white hover:bg-primary-700">View all</Link>
                  </div>
                </div>
              )}
            </div>

            <div ref={menuRef} className="relative">
              <button onClick={() => { setMenu((v) => !v); setBell(false); }} aria-label="Account menu" className="flex items-center gap-1 rounded-full p-0.5 hover:bg-zinc-50">
                <Avatar name={adminUser.name} size="size-8" />
                <ChevronDown className="size-4 text-zinc-500" />
              </button>
              {menu && (
                <div className="absolute right-0 mt-2 w-64 overflow-hidden rounded-xl border border-zinc-200 bg-white text-sm shadow-xl">
                  <div className="flex items-center gap-3 border-b border-zinc-100 px-4 py-3">
                    <Avatar name={adminUser.name} size="size-10" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold">{adminUser.name} <span className="ml-1 rounded bg-primary/10 px-1.5 py-0.5 align-middle text-[9px] font-bold uppercase tracking-wide text-primary">Admin</span></p>
                      <p className="truncate text-xs text-zinc-500">{adminUser.email}</p>
                    </div>
                  </div>
                  <ul className="py-1">
                    <li><Link href="/admin/profile" onClick={() => setMenu(false)} className="flex items-center gap-3 px-4 py-2.5 text-[13px] hover:bg-zinc-50"><User className="size-4 text-zinc-500" />Profile Settings</Link></li>
                    <li><Link href="/admin/settings" onClick={() => setMenu(false)} className="flex items-center gap-3 px-4 py-2.5 text-[13px] hover:bg-zinc-50"><Settings className="size-4 text-zinc-500" />Account Settings</Link></li>
                  </ul>
                  <div className="border-t border-zinc-100 py-1">
                    <button onClick={async () => { setMenu(false); if (await confirm({ title: "Sign out?", body: "You will need to sign in again to access the admin console.", confirmLabel: "Sign out", noLog: true })) { await fetch("/api/logout", { method: "POST" }); router.push("/login"); router.refresh(); } }} className="flex w-full items-center gap-3 px-4 py-2.5 text-[13px] font-medium text-rose-600 hover:bg-rose-50"><LogOut className="size-4" />Sign Out</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        <aside
          ref={railRef}
          aria-label="Admin navigation"
          onPointerDown={(e) => { tap.current = { touch: e.pointerType === "touch", wasOpen: rail }; }}
          onPointerEnter={(e) => { if (e.pointerType === "mouse") setRail(true); }}
          onPointerLeave={(e) => { if (e.pointerType === "mouse") setRail(false); }}
          onFocus={() => { if (!tap.current.touch) setRail(true); }}
          onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setRail(false); }}
          className={`fixed inset-y-0 left-0 z-50 hidden overflow-hidden bg-[#032250] transition-[width,box-shadow] duration-200 lg:block ${rail ? "w-60 shadow-2xl" : "w-16"}`}
        >
          <Sidebar unread={unread} expanded={rail} onItemClick={onRailItem} onNavigate={() => setRail(false)} />
        </aside>

        {drawer && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/40" onClick={() => setDrawer(false)} />
            <div className="absolute inset-y-0 left-0 w-60">
              <button aria-label="Close menu" onClick={() => setDrawer(false)} className="absolute right-2 top-3 z-10 rounded p-1 text-white/80"><X className="size-5" /></button>
              <Sidebar unread={unread} onNavigate={() => setDrawer(false)} />
            </div>
          </div>
        )}

        <main className="px-4 pb-14 pt-[68px] sm:px-6 lg:pl-16">
          <div className="mx-auto max-w-[1060px] lg:px-6">{children}</div>
        </main>

        <footer className="fixed inset-x-0 bottom-0 z-30 border-t border-zinc-200 bg-zinc-50 text-[11px] text-zinc-600 lg:left-16">
          <div className="flex flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-1.5 sm:px-5">
            <div className="flex items-center gap-5">
              <a href={`tel:${CONTACT.phone}`} className="inline-flex items-center gap-1.5 hover:text-primary"><Phone className="size-3" />{CONTACT.phone}</a>
              <a href={`mailto:${CONTACT.email}`} className="inline-flex items-center gap-1.5 hover:text-primary"><Mail className="size-3" />{CONTACT.email}</a>
            </div>
            <div className="flex items-center gap-4">
              <LegalLinks />
              <span>© {new Date().getFullYear()} BidMyAsset. All rights reserved.</span>
            </div>
          </div>
        </footer>
      </div>
      {dialog}
    </NoticeCtx.Provider>
  );
}
