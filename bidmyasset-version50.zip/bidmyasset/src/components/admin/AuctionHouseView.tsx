"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Pencil, Search, X } from "lucide-react";
import { Badge, Btn, Card, Modal, PageHead, Tabs } from "@/components/admin/ui";
import { categoryLibrary } from "@/lib/admin";
import { notifyHouseUpdated } from "@/components/ThemeSync";
import { EmailTemplatesView } from "@/components/admin/EmailTemplatesView";
import { FeeModal, LegalModal, PaymentModal, ProfileModal, SmtpModal, ThemeModal } from "@/components/admin/AuctionHouseEditors";
import { FEE_DEFS, fromRecord, initialHouse, parseCategories, settingsFromDoc, type CategorySelection, type Fee, type House, type HouseRecord, type LegalPolicy, type SettingsDoc } from "@/lib/auctionHouse";

const TABS = [["overview", "Overview"], ["categories", "Categories"], ["email", "Email Config"]] as const;
type Tab = (typeof TABS)[number][0];

const KV = ({ k, children }: { k: string; children: ReactNode }) => (
  <div><p className="text-[11px] text-zinc-500">{k}</p><div className="mt-0.5 text-sm text-zinc-800">{children}</div></div>
);
const Section = ({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) => (
  <Card>
    <div className="flex items-center justify-between border-b border-zinc-100 px-5 py-3.5"><h2 className="text-sm font-bold">{title}</h2>{action}</div>
    <div className="p-5">{children}</div>
  </Card>
);
const EditLink = ({ onClick, label = "Edit" }: { onClick?: () => void; label?: string }) => (
  <button onClick={onClick} className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"><Pencil className="size-3.5" />{label}</button>
);

function FeeSummary({ fee }: { fee: Fee }) {
  const def = FEE_DEFS.find((d) => d.kind === fee.kind)!;
  const rec = fee as unknown as Record<string, number>;
  return (
    <div>
      <p className="text-[11px] text-zinc-500">Internet buying fee</p>
      <p className="mb-3 text-sm font-semibold">{def.label}</p>
      <div className="grid grid-cols-2 gap-4">
        {def.fields.map((f) => <KV key={f.key} k={f.label}>{rec[f.key].toLocaleString("en-US", { maximumFractionDigits: 4 })}</KV>)}
      </div>
    </div>
  );
}

function Overview() {
  const [h, setH] = useState<House>(initialHouse);
  const [dlg, setDlg] = useState<null | "profile" | "smtp" | "fee" | "theme" | "payment" | "legal">(null);
  const [editPolicy, setEditPolicy] = useState<LegalPolicy | null>(null);
  const [toast, setToast] = useState("");
  // profile, branding, fee, theme and legal policies come from PocketBase (/api/admin/house); SMTP and payment from /api/admin/house/integrations
  useEffect(() => {
    fetch("/api/admin/house", { cache: "no-store" }).then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j: HouseRecord) => setH((p) => ({ ...p, ...fromRecord(j) })))
      .catch(() => setToast("Could not load the saved auction house settings. The values shown are defaults; don’t save the profile until this loads."));
  }, []);
  useEffect(() => {
    fetch("/api/admin/house/integrations", { cache: "no-store" }).then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j: { smtp: House["smtp"]; payment: House["payment"] }) => setH((p) => ({ ...p, smtp: j.smtp, payment: j.payment })))
      .catch(() => setToast("Could not load the saved email and payment settings."));
  }, []);
  const saveProfile = (patch: Partial<House>) => { setH((p) => ({ ...p, ...patch })); setDlg(null); setToast("Saved to PocketBase."); notifyHouseUpdated(); };
  // SMTP + Toyyibpay: PUT /api/admin/house/integrations. Secrets are sent once and never come back (only passwordSet / secretSet).
  const saveIntegrations = async (body: Record<string, unknown>, msg: string) => {
    const res = await fetch("/api/admin/house/integrations", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    const j = (await res.json().catch(() => ({}))) as { message?: string; smtp?: House["smtp"]; payment?: House["payment"] };
    if (!res.ok) throw new Error(j.message || `Save failed (${res.status})`);
    setH((p) => ({ ...p, ...(j.smtp ? { smtp: j.smtp } : {}), ...(j.payment ? { payment: j.payment } : {}) }));
    setDlg(null); setToast(msg);
  };
  const saveSmtp = (p: Partial<House> & { smtpPassword?: string }) => saveIntegrations(
    { smtp: { host: p.smtp?.host ?? "", port: p.smtp?.port ?? "", username: p.smtp?.username ?? "", password: p.smtpPassword || undefined, from: p.smtp?.from ?? "", fromName: p.smtp?.fromName ?? "" } },
    "Email settings saved. OTP, password-reset and catalog emails now use this server.");
  const savePayment = (p: Partial<House> & { paymentSecret?: string }) => saveIntegrations(
    { payment: { secret: p.paymentSecret || undefined, categoryCode: p.payment?.categoryCode ?? "", sandbox: !!p.payment?.sandbox } },
    "Payment settings saved. Bidders can now pay unpaid invoices online.");
  // fee + theme: PUT /api/admin/house/settings (validated by the backend); throws so the dialog can show why it failed
  const saveSettings = async (patch: Pick<Partial<House>, "fee" | "theme" | "legal">) => {
    const body: Record<string, unknown> = {};
    if ("fee" in patch) body.fee = patch.fee ?? null;
    if ("theme" in patch) body.theme = patch.theme;
    if ("legal" in patch) body.legal = patch.legal;
    const res = await fetch("/api/admin/house/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    const j = (await res.json().catch(() => ({}))) as SettingsDoc & { message?: string };
    if (!res.ok) throw new Error(j.message || `Save failed (${res.status})`);
    setH((p) => ({ ...p, ...settingsFromDoc(j) }));
    setDlg(null);
    notifyHouseUpdated(); // this tab re-renders with the new theme right away; other open tabs catch up within 30 s
    const ex = j.example;
    setToast("fee" in patch
      ? patch.fee && ex ? `Fee saved. Example: a hammer price of ${ex.hammer.toLocaleString("en-US")} adds an internet buying fee of ${ex.internetFee.toLocaleString("en-US")}. It applies to new invoices and shows next to bids.` : "Fee removed."
      : "legal" in patch ? "Legal policies saved. The footer, login and registration links open them at /privacy and /terms."
      : "Theme saved. This page and the public website update right away; other open tabs within 30 seconds.");
  };
  const removePolicy = async (p: LegalPolicy) => {
    if (!window.confirm(`Remove “${p.name}”? Its privacy policy and terms will no longer be shown on the website.`)) return;
    try { await saveSettings({ legal: h.legal.filter((x) => x.id !== p.id) }); } catch (e) { setToast(e instanceof Error ? e.message : "Could not remove the policy."); }
  };
  const link = (v: string) => (v ? <a href={v} className="text-primary hover:underline">{v}</a> : "-");
  const dash = (v: string) => v || "-";
  const swatch = (c: string) => c ? <span className="inline-flex items-center gap-1.5"><span className="size-3 rounded-sm border border-zinc-300" style={{ background: c }} />{c}</span> : "-";
  return (
    <div className="space-y-5">
      {toast && <p role="status" className="rounded-md border border-emerald-100 bg-emerald-50 px-4 py-2 text-xs text-emerald-700">{toast}</p>}
      <Card>
        <div className="flex items-start justify-between px-5 pt-5">
          <div><p className="text-xs text-zinc-500">Auction house name</p><p className="text-lg font-bold">{h.name}</p></div>
          <EditLink onClick={() => setDlg("profile")} />
        </div>
        <div className="mt-4 flex items-center justify-between gap-4 border-t border-zinc-100 p-5">
          <div className="space-y-2">
            {/* description is admin-entered HTML: render only after server-side sanitizing */}
            <p className="text-sm">{h.description.replace(/<[^>]*>/g, "")}</p>
            <KV k="Corporate URL">{link(h.website)}</KV>
          </div>
          {h.bannerUrls?.[0] ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={h.bannerUrls[0]} alt="Banner" className="h-12 w-20 shrink-0 rounded object-cover" /> : <div className="grid h-12 w-20 shrink-0 place-items-center rounded bg-zinc-200 text-[10px] text-zinc-500">Banner</div>}
        </div>
      </Card>

      <div className="grid gap-5 md:grid-cols-2">
        <Section title="Contact & website">
          <div className="grid grid-cols-2 gap-4">
            <KV k="Domain">{h.domain}</KV><KV k="Website">{link(h.website)}</KV>
            <KV k="Support Email">{dash(h.supportEmail)}</KV><KV k="Support Phone">{dash(h.supportPhone)}</KV>
          </div>
        </Section>
        <Section title="Social profiles">
          <div className="grid grid-cols-2 gap-4"><KV k="Facebook">{dash(h.facebook)}</KV><KV k="Twitter">{dash(h.twitter)}</KV><KV k="LinkedIn">{dash(h.linkedin)}</KV><KV k="WhatsApp">{dash(h.whatsapp)}</KV></div>
        </Section>
        <Section title="Analytics & tracking"><KV k="Google Analytics ID">{dash(h.gaId)}</KV></Section>
        <Section title="Branding">
          <div className="flex gap-6">
            <KV k="Logo">{h.logoUrl ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={h.logoUrl} alt="Logo" className="mt-1 h-10 max-w-32 object-contain" /> : h.logoName ? <span className="mt-1 grid size-10 place-items-center rounded bg-brand text-[10px] font-bold text-white">BMA</span> : "-"}</KV>
            <KV k="Favicon">{h.faviconUrl ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={h.faviconUrl} alt="Favicon" className="mt-1 size-5 object-contain" /> : h.faviconName ? <span className="mt-1 grid size-5 place-items-center rounded bg-brand text-[8px] font-bold text-white">B</span> : "-"}</KV>
          </div>
        </Section>
        <Section title="Email Configuration" action={<EditLink onClick={() => setDlg("smtp")} />}>
          <div className="grid grid-cols-2 gap-4"><KV k="Host">{dash(h.smtp.host)}</KV><KV k="Port">{dash(h.smtp.port)}</KV><KV k="Username">{dash(h.smtp.username)}</KV><KV k="Password">{h.smtp.passwordSet ? "••••••••" : "-"}</KV><KV k="Sender address">{dash(h.smtp.from)}</KV><KV k="Sender name">{dash(h.smtp.fromName)}</KV></div>
        </Section>
        <Section title="Fees & Commissions" action={<Btn variant="solid" className="h-8 text-xs" onClick={() => setDlg("fee")}>{h.fee ? "Edit Commission" : "Add Commission"}</Btn>}>
          {h.fee ? <FeeSummary fee={h.fee} /> : <p className="text-xs text-zinc-500">No buyer fee configuration found.</p>}
        </Section>
        <Section title="Theming & Config" action={<EditLink onClick={() => setDlg("theme")} />}>
          <div className="grid grid-cols-2 gap-4"><KV k="Primary Color">{swatch(h.theme.primary)}</KV><KV k="Secondary Color">{swatch(h.theme.secondary)}</KV>
            <KV k="Rating & Questions"><span className="rounded bg-zinc-100 px-2 py-0.5 text-[11px] font-semibold text-zinc-600">{h.theme.ratings ? "Enabled" : "Disabled"}</span></KV></div>
        </Section>
        <Section title="Payment Credentials" action={<EditLink onClick={() => setDlg("payment")} />}>
          <KV k="Default gateway"><label className="flex items-center gap-2"><input type="radio" checked={h.payment.defaultGateway} readOnly />Toyyibpay</label></KV>
          <div className="mt-3 grid grid-cols-2 gap-4"><KV k="Secret Key">{h.payment.secretSet ? "••••••••" : "-"}</KV><KV k="Category Code">{dash(h.payment.categoryCode)}</KV><KV k="Mode">{h.payment.sandbox ? "Sandbox (testing)" : "Live"}</KV></div>
        </Section>
      </div>
      <Section title="Legal Policies" action={<EditLink label="Add" onClick={() => { setEditPolicy(null); setDlg("legal"); }} />}>
        {h.legal.length === 0
          ? <p className="rounded-lg border border-dashed border-zinc-300 py-8 text-center text-xs text-zinc-500">No legal policy configured yet. Add one to manage your privacy policy and terms of use from a single place.</p>
          : <ul className="divide-y divide-zinc-100">{h.legal.map((l) => (
              <li key={l.id} className="flex items-center justify-between gap-3 py-2 text-sm"><span className="font-semibold">{l.name}</span>
                <span className="flex items-center gap-2">
                  {l.privacy && <a href="/privacy" target="_blank" rel="noopener" title="Open the public Privacy Policy"><Badge tone="blue">Privacy</Badge></a>}
                  {l.terms && <a href="/terms" target="_blank" rel="noopener" title="Open the public Terms & Conditions"><Badge tone="zinc">Terms</Badge></a>}
                  <button type="button" onClick={() => { setEditPolicy(l); setDlg("legal"); }} className="text-xs font-semibold text-primary hover:underline">Edit</button>
                  <button type="button" onClick={() => removePolicy(l)} className="text-xs font-semibold text-rose-600 hover:underline">Remove</button>
                </span></li>))}
            </ul>}
        {h.legal.length > 1 && <p className="mt-3 text-[11px] text-zinc-500">When several policies are added, the website shows the newest one that has a privacy policy (or terms).</p>}
      </Section>

      {dlg === "profile" && <ProfileModal house={h} onClose={() => setDlg(null)} onSave={saveProfile} />}
      {dlg === "smtp" && <SmtpModal house={h} onClose={() => setDlg(null)} onSave={saveSmtp} />}
      {dlg === "fee" && <FeeModal house={h} onClose={() => setDlg(null)} onSave={saveSettings} />}
      {dlg === "theme" && <ThemeModal house={h} onClose={() => setDlg(null)} onSave={saveSettings} />}
      {dlg === "payment" && <PaymentModal house={h} onClose={() => setDlg(null)} onSave={savePayment} />}
      {dlg === "legal" && <LegalModal key={editPolicy?.id ?? "new"} initial={editPolicy ?? undefined} onClose={() => setDlg(null)}
        onSave={(p) => saveSettings({ legal: editPolicy ? h.legal.map((x) => (x.id === p.id ? p : x)) : [...h.legal, p] })} />}
    </div>
  );
}

function ReviewSelectedModal({ cats, sel, onClose, onSave }: { cats: string[]; sel: Record<string, Set<string>>; onClose: () => void; onSave: (next: Record<string, Set<string>>) => void }) {
  // Work on a draft so "Close" discards removals and "Save" commits them.
  const [draft, setDraft] = useState<Record<string, Set<string>>>(() => Object.fromEntries(cats.map((c) => [c, new Set(sel[c])])));
  const rows = cats.flatMap((c) => categoryLibrary[c].filter((s) => draft[c].has(s)).map((s) => ({ c, s })));
  const remove = (c: string, s: string) => setDraft((p) => { const n = new Set(p[c]); n.delete(s); return { ...p, [c]: n }; });
  const clearAll = () => setDraft(Object.fromEntries(cats.map((c) => [c, new Set<string>()])));
  return (
    <Modal wide title="Review Selected Categories" onClose={onClose}
      footer={<><Btn variant="outline" className="h-8 text-xs" onClick={onClose}>Close</Btn><Btn variant="solid" className="h-8 text-xs" onClick={() => onSave(draft)}>Save</Btn></>}>
      <div className="mb-3 flex items-center justify-between text-xs">
        <span className="font-medium text-zinc-700">Total Selected: {rows.length}</span>
        {rows.length > 0 && <button onClick={clearAll} className="font-medium text-primary hover:underline">Clear All</button>}
      </div>
      <div className="max-h-[55vh] overflow-y-auto rounded-lg border border-zinc-200">
        <table className="w-full text-left text-xs">
          <thead className="sticky top-0 bg-zinc-50 text-zinc-700"><tr><th className="px-3 py-2.5 font-semibold">Category</th><th className="px-3 py-2.5 font-semibold">Subcategory</th><th className="w-10" /></tr></thead>
          <tbody className="divide-y divide-zinc-100">
            {rows.length === 0 && <tr><td colSpan={3} className="py-8 text-center text-zinc-500">No categories selected.</td></tr>}
            {rows.map(({ c, s }) => (
              <tr key={c + "/" + s} className="hover:bg-zinc-50">
                <td className="px-3 py-2.5 text-zinc-600">{c}</td>
                <td className="px-3 py-2.5 font-semibold">{s}</td>
                <td className="px-3 py-2.5 text-right"><button aria-label={`Remove ${s}`} onClick={() => remove(c, s)} className="rounded p-0.5 text-red-500 hover:bg-red-50"><X className="size-4" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

/** Library selection → what is stored: every library category with its enabled subcategories (empty list = none). */
const toStored = (cats: string[], sel: Record<string, Set<string>>): CategorySelection =>
  Object.fromEntries(cats.map((c) => [c, categoryLibrary[c].filter((s) => sel[c].has(s))]));

function Categories() {
  const cats = Object.keys(categoryLibrary);
  const [active, setActive] = useState(cats[0]);
  const [q, setQ] = useState("");
  const [onlySelected, setOnlySelected] = useState(false);
  const [review, setReview] = useState(false);
  // Nothing saved yet (or a category the saved selection doesn't know) = everything offered, same as the public filter.
  const [sel, setSel] = useState<Record<string, Set<string>>>(() => Object.fromEntries(cats.map((c) => [c, new Set(categoryLibrary[c])])));
  const [savedSig, setSavedSig] = useState<string | null>(null); // null = still loading
  const [configured, setConfigured] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const sig = JSON.stringify(toStored(cats, sel));
  const dirty = savedSig !== null && sig !== savedSig;

  useEffect(() => {
    fetch("/api/admin/house/settings", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j: SettingsDoc) => {
        const saved = parseCategories(j.categories);
        const next = Object.fromEntries(cats.map((c) => [c, new Set(saved && c in saved ? categoryLibrary[c].filter((s) => saved[c].includes(s)) : categoryLibrary[c])]));
        setSel(next); setConfigured(!!saved); setSavedSig(JSON.stringify(toStored(cats, next)));
      })
      .catch(() => { setSavedSig(JSON.stringify(toStored(cats, sel))); setMsg({ ok: false, text: "Could not load the saved selection. Showing everything selected." }); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      const res = await fetch("/api/admin/house/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ categories: JSON.parse(sig) }), cache: "no-store" });
      const j = (await res.json().catch(() => ({}))) as SettingsDoc & { message?: string };
      if (!res.ok) throw new Error(j.message || `Save failed (${res.status})`);
      setSavedSig(sig); setConfigured(true); notifyHouseUpdated();
      setMsg({ ok: true, text: "Saved. The category filter on the public auction pages now follows this selection." });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Save failed" }); } finally { setBusy(false); }
  };
  // back to "not configured": the public filter shows every category again
  const reset = async () => {
    if (!window.confirm("Reset the category library? The public filter will show every category again.")) return;
    setBusy(true); setMsg(null);
    try {
      const res = await fetch("/api/admin/house/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ categories: null }), cache: "no-store" });
      const j = (await res.json().catch(() => ({}))) as SettingsDoc & { message?: string };
      if (!res.ok) throw new Error(j.message || `Reset failed (${res.status})`);
      const all = Object.fromEntries(cats.map((c) => [c, new Set(categoryLibrary[c])]));
      setSel(all); setSavedSig(JSON.stringify(toStored(cats, all))); setConfigured(false); notifyHouseUpdated();
      setMsg({ ok: true, text: "Reset. The public category filter shows every category again." });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Reset failed" }); } finally { setBusy(false); }
  };
  const total = cats.reduce((n, c) => n + sel[c].size, 0);
  const toggle = (c: string, s: string) => setSel((p) => { const n = new Set(p[c]); n.has(s) ? n.delete(s) : n.add(s); return { ...p, [c]: n }; });
  const setAll = (c: string, on: boolean) => setSel((p) => ({ ...p, [c]: on ? new Set(categoryLibrary[c]) : new Set() }));
  const shownCats = useMemo(() => cats.filter((c) => c.toLowerCase().includes(q.toLowerCase()) || categoryLibrary[c].some((s) => s.toLowerCase().includes(q.toLowerCase()))), [cats, q]);
  const subs = categoryLibrary[active].filter((s) => (!q || s.toLowerCase().includes(q.toLowerCase()) || active.toLowerCase().includes(q.toLowerCase())) && (!onlySelected || sel[active].has(s)));

  return (
    <Card>
      <div className="border-b border-zinc-100 px-5 py-4"><h2 className="text-base font-bold">Category Library</h2><p className="text-xs text-zinc-500">Curate categories and subcategories for your auction experience.</p></div>
      <div className="flex items-center justify-between border-b border-zinc-100 px-5 py-3">
        <Btn variant="ghost" className="h-8 text-xs" onClick={() => setOnlySelected((v) => !v)}>{onlySelected ? "Show All" : "Show Selected Only"}</Btn>
        <div className="flex items-center gap-2">
          {configured && <Btn variant="ghost" className="h-8 text-xs" disabled={busy} onClick={reset}>Reset to default</Btn>}
          <Btn variant="outline" className="h-8 text-xs" onClick={() => setReview(true)}>Review Selected ({total})</Btn>
          <Btn variant="solid" className="h-8 text-xs" disabled={!dirty || busy} onClick={save}>{busy ? "Saving…" : "Save changes"}</Btn>
        </div>
      </div>
      {(msg || dirty || !configured) && (
        <p role={msg && !msg.ok ? "alert" : "status"} className={`border-b border-zinc-100 px-5 py-2 text-xs ${msg ? (msg.ok ? "text-emerald-700" : "text-rose-600") : dirty ? "text-amber-700" : "text-zinc-500"}`}>
          {msg ? msg.text : dirty ? "You have unsaved changes." : "Not saved yet: the public filter currently shows every category. Choose what to offer, then save."}
        </p>
      )}
      <div className="grid md:grid-cols-[210px_1fr]">
        <div className="border-b border-zinc-100 p-3 md:border-b-0 md:border-r">
          <label className="relative mb-2 block"><Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-zinc-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search categories..." className="h-8 w-full rounded-md border border-zinc-300 pl-8 pr-2 text-xs focus:border-primary focus:outline-none" /></label>
          <ul>
            {shownCats.map((c) => (
              <li key={c}><button onClick={() => setActive(c)} className={`flex w-full items-center justify-between border-l-2 px-3 py-2 text-left text-xs ${active === c ? "border-primary bg-zinc-100 font-semibold" : "border-transparent hover:bg-zinc-50"}`}>
                <span className="truncate">{c}</span><span className="ml-2 rounded bg-zinc-100 px-1.5 text-[10px] text-zinc-600">{categoryLibrary[c].length}</span></button></li>
            ))}
          </ul>
        </div>
        <div className="p-4">
          <div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-bold">{active}</h3>
            <div className="flex gap-2"><Btn variant="outline" className="h-7 px-3 text-[11px]" onClick={() => setAll(active, true)}>Select All</Btn><Btn variant="outline" className="h-7 px-3 text-[11px]" onClick={() => setAll(active, false)}>Deselect All</Btn></div></div>
          <ul className="space-y-1.5">
            {subs.length === 0 && <li className="py-6 text-center text-xs text-zinc-500">No subcategories match.</li>}
            {subs.map((s) => (
              <li key={s}><label className="flex cursor-pointer items-center gap-3 rounded border border-zinc-200 px-3 py-2 text-xs hover:bg-zinc-50">
                <input type="checkbox" checked={sel[active].has(s)} onChange={() => toggle(active, s)} className="size-3.5 accent-primary" />{s}</label></li>
            ))}
          </ul>
        </div>
      </div>
      {review && <ReviewSelectedModal cats={cats} sel={sel} onClose={() => setReview(false)} onSave={(next) => { setSel(next); setReview(false); }} />}
    </Card>
  );
}

export function AuctionHouseView() {
  const [tab, setTab] = useState<Tab>("overview");
  return (
    <>
      <PageHead title="Auction House" sub="Manage your auction house identity and compliance settings" />
      <Tabs items={TABS} value={tab} onChange={setTab} />
      {tab === "overview" ? <Overview /> : tab === "categories" ? <Categories /> : <EmailTemplatesView />}
    </>
  );
}
