"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUp, EyeOff, Pencil, Plus, Trash2, Upload, X } from "lucide-react";
import { Avatar, Badge, Btn, Card, Field, Modal, PageHead, Tabs, Toggle, inputCls, useConfirm } from "@/components/admin/ui";

/** Admin → Team: the people on the public /leadership page (Leadership Team, Strategic Advisors, Management Team). */
type Group = "leadership" | "advisor" | "management";
type Member = { id: string; name: string; role: string; group: Group; photoName: string; photoUrl: string; linkedin: string; sort: number; visible: boolean; updated: string };

const GROUPS = [["leadership", "Leadership Team"], ["advisor", "Strategic Advisors"], ["management", "Management Team"]] as const;
const MAX = 2 * 1024 * 1024;
const photoSrc = (m: Pick<Member, "photoUrl" | "updated">) => (m.photoUrl ? `/api/pb${m.photoUrl}?v=${encodeURIComponent(m.updated)}` : "");

async function api<T>(init?: RequestInit): Promise<T> {
  const res = await fetch("/api/admin/team", { cache: "no-store", ...init });
  const j = (await res.json().catch(() => ({}))) as T & { message?: string };
  if (!res.ok) throw new Error(j.message || "Something went wrong. Please try again.");
  return j;
}

function MemberForm({ initial, group, onClose, onSaved }: { initial?: Member; group: Group; onClose: () => void; onSaved: (m: Member) => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [role, setRole] = useState(initial?.role ?? "");
  const [grp, setGrp] = useState<Group>(initial?.group ?? group);
  const [linkedin, setLinkedin] = useState(initial?.linkedin ?? "");
  const [visible, setVisible] = useState(initial?.visible ?? true);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [removePhoto, setRemovePhoto] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) { setPreview(""); return; }
    const u = URL.createObjectURL(file);
    setPreview(u);
    return () => URL.revokeObjectURL(u);
  }, [file]);

  const pick = (f: File | undefined) => {
    if (!f) return;
    if (!/^image\/(png|jpe?g|webp)$/.test(f.type)) return setErr("Use a PNG, JPG or WebP image.");
    if (f.size > MAX) return setErr("The photo must be 2 MB or smaller.");
    setErr(""); setFile(f); setRemovePhoto(false);
  };
  const current = file ? preview : removePhoto ? "" : initial ? photoSrc(initial) : "";

  const save = async () => {
    if (!name.trim()) return setErr("Enter the person's name.");
    setBusy(true); setErr("");
    try {
      const fd = new FormData();
      if (initial) fd.append("id", initial.id);
      fd.append("name", name.trim()); fd.append("role", role.trim()); fd.append("group", grp);
      fd.append("linkedin", linkedin.trim()); fd.append("visible", visible ? "1" : "0");
      if (file) fd.append("photo", file, file.name);
      else if (removePhoto) fd.append("removePhoto", "1");
      onSaved(await api<Member>({ method: "POST", body: fd }));
    } catch (e) { setErr(e instanceof Error ? e.message : "Could not save."); } finally { setBusy(false); }
  };

  return (
    <Modal wide title={initial ? "Edit person" : "Add person"} sub="Shown on the public Leadership page." onClose={onClose}
      footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="solid" disabled={busy} onClick={save}>{busy ? "Saving…" : "Save"}</Btn></>}>
      <div className="grid gap-4 sm:grid-cols-[140px_1fr]">
        <div>
          <p className="text-xs font-semibold text-zinc-700">Photo</p>
          <div className="mt-1 aspect-[4/5] w-full overflow-hidden rounded-lg border border-zinc-200 bg-zinc-100">
            {current
              // eslint-disable-next-line @next/next/no-img-element
              ? <img src={current} alt="Photo preview" className="size-full object-cover object-top" />
              : <div className="grid size-full place-items-center text-[11px] text-zinc-400">No photo</div>}
          </div>
          <label className="mt-2 inline-flex h-8 w-full cursor-pointer items-center justify-center gap-1.5 rounded-md border border-primary/40 text-xs font-semibold text-primary hover:bg-primary/5">
            <Upload className="size-3.5" />{current ? "Change" : "Upload"}
            <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(e) => { pick(e.target.files?.[0]); if (input.current) input.current.value = ""; }} />
          </label>
          {current && <button type="button" onClick={() => { setFile(null); setRemovePhoto(true); }} className="mt-1 inline-flex w-full items-center justify-center gap-1 text-[11px] font-semibold text-rose-600 hover:underline"><X className="size-3" />Remove photo</button>}
          <p className="mt-1 text-[10px] text-zinc-500">PNG, JPG or WebP, up to 2 MB. A portrait (4:5) works best.</p>
        </div>
        <div className="space-y-3">
          <Field label="Name"><input className={inputCls} value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="e.g. Jeevan Muniandy" /></Field>
          <Field label="Position"><input className={inputCls} value={role} maxLength={160} onChange={(e) => setRole(e.target.value)} placeholder="e.g. Group Managing Director" /></Field>
          <Field label="Section">
            <select className={inputCls} value={grp} onChange={(e) => setGrp(e.target.value as Group)}>
              {GROUPS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </Field>
          <Field label="LinkedIn (optional)"><input className={inputCls} value={linkedin} maxLength={300} onChange={(e) => setLinkedin(e.target.value)} placeholder="https://www.linkedin.com/in/…" /></Field>
          <div className="flex items-center justify-between rounded-md border border-zinc-200 px-3 py-2">
            <span className="text-xs"><b className="font-semibold">Show on website</b><span className="block text-[11px] text-zinc-500">Turn off to hide without deleting.</span></span>
            <Toggle on={visible} onChange={setVisible} label="Show on website" />
          </div>
        </div>
      </div>
      {err && <p role="alert" className="mt-3 text-xs text-rose-600">{err}</p>}
    </Modal>
  );
}

export function TeamView() {
  const [items, setItems] = useState<Member[] | null>(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<Group>("leadership");
  const [edit, setEdit] = useState<Member | "new" | null>(null);
  const [busy, setBusy] = useState(false);
  const { confirm, dialog } = useConfirm();

  const load = useCallback(async () => {
    setError("");
    try { setItems((await api<{ items: Member[] }>()).items); } catch (e) { setError(e instanceof Error ? e.message : "Could not load the team."); setItems([]); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const list = (items ?? []).filter((m) => m.group === tab).sort((a, b) => a.sort - b.sort);
  const count = (g: Group) => (items ?? []).filter((m) => m.group === g).length;

  const saved = (m: Member) => {
    setItems((cur) => { const rest = (cur ?? []).filter((x) => x.id !== m.id); return [...rest, m]; });
    setTab(m.group); setEdit(null);
  };
  const move = async (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= list.length) return;
    const ids = list.map((m) => m.id);
    [ids[i], ids[j]] = [ids[j], ids[i]];
    setBusy(true); setError("");
    try { setItems((await api<{ items: Member[] }>({ method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids }) })).items); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not change the order."); } finally { setBusy(false); }
  };
  const remove = async (m: Member) => {
    if (!(await confirm({ title: `Remove ${m.name}?`, body: "They will disappear from the public Leadership page. This cannot be undone.", confirmLabel: "Remove" }))) return;
    setBusy(true); setError("");
    try { await api({ method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: m.id, name: m.name }) }); setItems((cur) => (cur ?? []).filter((x) => x.id !== m.id)); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not remove."); } finally { setBusy(false); }
  };

  return (
    <div>
      <PageHead title="Team" sub="People shown on the public Leadership page. Edit photos, names and positions, hide or reorder them."
        actions={<Btn variant="solid" onClick={() => setEdit("new")}><Plus className="size-4" />Add person</Btn>} />
      <Card>
        <div className="px-4 pt-2">
          <Tabs items={GROUPS.map(([v, l]) => [v, `${l} (${count(v)})`] as const)} value={tab} onChange={setTab} />
        </div>
        {error && <p role="alert" className="m-4 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{error}</p>}
        {items === null ? <p className="px-4 py-10 text-center text-xs text-zinc-500">Loading…</p> : list.length === 0 ? (
          <p className="px-4 py-10 text-center text-xs text-zinc-500">No one in this section yet. Use “Add person”.</p>
        ) : (
          <ul className="divide-y divide-zinc-100">
            {list.map((m, i) => (
              <li key={m.id} className="flex items-center gap-3 px-4 py-3">
                {m.photoUrl
                  // eslint-disable-next-line @next/next/no-img-element
                  ? <img src={photoSrc(m)} alt="" className="size-12 shrink-0 rounded-lg border border-zinc-200 object-cover object-top" />
                  : <Avatar name={m.name} size="size-12" />}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{m.name}</p>
                  <p className="truncate text-xs text-zinc-600">{m.role || "No position"}</p>
                </div>
                {!m.visible && <Badge tone="zinc"><EyeOff className="mr-1 inline size-3" />Hidden</Badge>}
                <div className="flex items-center gap-1">
                  <button type="button" aria-label="Move up" disabled={busy || i === 0} onClick={() => move(i, -1)} className="grid size-8 place-items-center rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-30"><ArrowUp className="size-4" /></button>
                  <button type="button" aria-label="Move down" disabled={busy || i === list.length - 1} onClick={() => move(i, 1)} className="grid size-8 place-items-center rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-30"><ArrowDown className="size-4" /></button>
                  <button type="button" aria-label={`Edit ${m.name}`} onClick={() => setEdit(m)} className="grid size-8 place-items-center rounded-md border border-primary/40 text-primary hover:bg-primary/5"><Pencil className="size-4" /></button>
                  <button type="button" aria-label={`Remove ${m.name}`} disabled={busy} onClick={() => remove(m)} className="grid size-8 place-items-center rounded-md border border-rose-200 text-rose-600 hover:bg-rose-50"><Trash2 className="size-4" /></button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <p className="mt-3 text-[11px] text-zinc-500">Changes appear on the public Leadership page straight after saving.</p>
      {edit && <MemberForm initial={edit === "new" ? undefined : edit} group={tab} onClose={() => setEdit(null)} onSaved={saved} />}
      {dialog}
    </div>
  );
}
