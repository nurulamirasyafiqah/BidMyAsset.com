"use client";

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ImageIcon, Upload, Undo2 } from "lucide-react";
import { Btn, Field, inputCls, Modal, Toggle, useConfirm } from "@/components/admin/ui";
import {
  defaultButtons, defaultDialog, imageError, isColor, isCssValue, isEmail, isGaId, isPhone, isUrl,
  FEE_DEFS, feeValueError, fromRecord, mergeTheme, type HouseRecord, type ButtonKey, type ButtonStyle, type DialogStyle, type Fee, type FeeKind, type House, type LegalPolicy,
} from "@/lib/auctionHouse";

const errCls = "mt-1 text-[11px] text-rose-600";
const Err = ({ m }: { m: string }) => (m ? <p role="alert" className={errCls}>{m}</p> : null);
const Group = ({ title, sub, children }: { title: string; sub?: string; children: ReactNode }) => (
  <div className="mb-4">
    <h3 className="text-sm font-bold">{title}</h3>
    {sub && <p className="mb-2 text-xs text-zinc-500">{sub}</p>}
    <div className="space-y-3 rounded-lg border border-zinc-200 p-3">{children}</div>
  </div>
);
const Footer = ({ onClose, onSave, disabled, label = "Save" }: { onClose: () => void; onSave: () => void; disabled?: boolean; label?: string }) => (
  <><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="solid" disabled={disabled} onClick={onSave}>{label}</Btn></>
);
/** Runs a save that may be async; keeps the modal open and shows the server's message when it fails. */
function useSave<P = Partial<House>>(onSave: (p: P) => void | Promise<void>) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const run = async (patch: P) => {
    setBusy(true); setErr("");
    try { await onSave(patch); } catch (e) { setErr(e instanceof Error ? e.message : "Save failed"); } finally { setBusy(false); }
  };
  return { busy, err, run };
}
const SaveErr = ({ m }: { m: string }) => (m ? <p role="alert" className="mb-3 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{m}</p> : null);
const areaCls = "w-full resize-y rounded-md border border-zinc-300 p-3 font-mono text-xs focus:border-primary focus:outline-none";


/* ---------- Branding asset picker (logo / favicon / banner) ---------- */
const kb = (n: number) => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function AssetPicker({ label, hint, accept, multiple, currentText, hasCurrent, currentUrls = [], files, error, onChange, removed, onRemove, onRestore }: {
  removed?: boolean; onRemove?: () => void; onRestore?: () => void;
  currentUrls?: string[]; label: string; hint: string; accept: string; multiple?: boolean; currentText: string; hasCurrent: boolean; files: File[]; error: string; onChange: (f: File[]) => void;
}) {
  const empty = !hasCurrent;
  const ref = useRef<HTMLInputElement>(null);
  const urls = useMemo(() => files.filter((f) => f.type.startsWith("image/")).slice(0, 4).map((f) => URL.createObjectURL(f)), [files]);
  useEffect(() => () => urls.forEach((u) => URL.revokeObjectURL(u)), [urls]);
  const changed = files.length > 0;
  const id = `asset-${label.toLowerCase()}`;
  return (
    <div className={`rounded-lg border p-3 ${error ? "border-rose-300 bg-rose-50/40" : "border-zinc-200 bg-white"}`}>
      <div className="flex items-center gap-3">
        <div className="flex size-14 shrink-0 items-center justify-center overflow-hidden rounded-md border border-dashed border-zinc-300 bg-zinc-50 text-zinc-400">
          {(urls[0] ?? currentUrls[0]) ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={urls[0] ?? currentUrls[0]} alt={`${label} preview`} className="size-full object-contain" /> : <ImageIcon className="size-5" />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="text-sm font-bold">{label}</p>
            <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${changed || removed ? "bg-amber-50 text-amber-700" : "bg-zinc-100 text-zinc-600"}`}>{changed ? (empty ? "New" : "Will be replaced") : removed ? "Will be removed" : empty ? "Empty" : "Current"}</span>
          </div>
          <p className="mt-0.5 truncate text-xs text-zinc-600">
            {changed ? (files.length === 1 ? `${files[0].name} · ${kb(files[0].size)}` : `${files.length} new images selected`) : currentText}
          </p>
          <p className="text-[11px] text-zinc-500">{hint}</p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <input ref={ref} id={id} type="file" accept={accept} multiple={multiple} className="sr-only"
            onChange={(e) => { onChange(Array.from(e.target.files ?? [])); e.target.value = ""; }} />
          <label htmlFor={id} className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-primary/40 bg-white px-3 text-xs font-semibold text-primary hover:bg-primary/5">
            <Upload className="size-3.5" />{changed ? "Choose another" : empty ? (multiple ? "Upload images" : "Upload") : multiple ? "Upload images" : "Replace"}
          </label>
          {changed && <button type="button" onClick={() => onChange([])} className="inline-flex items-center gap-1 text-[11px] font-semibold text-zinc-600 hover:underline"><Undo2 className="size-3" />Undo</button>}
          {!changed && removed && onRestore && <button type="button" onClick={onRestore} className="inline-flex items-center gap-1 text-[11px] font-semibold text-zinc-600 hover:underline"><Undo2 className="size-3" />Undo remove</button>}
          {!changed && !removed && hasCurrent && onRemove && <button type="button" onClick={onRemove} className="text-[11px] font-semibold text-rose-600 hover:underline">Remove</button>}
        </div>
      </div>
      {multiple && urls.length > 1 && (
        <div className="mt-2 flex gap-1.5 pl-[68px]">
          {urls.map((u, i) => /* eslint-disable-next-line @next/next/no-img-element */ <img key={u} src={u} alt={`New banner ${i + 1}`} className="size-10 rounded border border-zinc-200 object-cover" />)}
          {files.length > urls.length && <span className="grid size-10 place-items-center rounded border border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">+{files.length - urls.length}</span>}
        </div>
      )}
      {multiple && changed && !empty && <p className="mt-2 pl-[68px] text-[11px] text-zinc-500">The current banners will be replaced when you save.</p>}
      <Err m={error} />
    </div>
  );
}

/* ---------- Edit Auction House (profile) ---------- */
export function ProfileModal({ house, onSave, onClose }: { house: House; onSave: (p: Partial<House>) => void; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  const [serverErr, setServerErr] = useState("");
  const [d, setD] = useState({
    name: house.name, website: house.website, supportEmail: house.supportEmail, supportPhone: house.supportPhone,
    facebook: house.facebook, twitter: house.twitter, linkedin: house.linkedin, whatsapp: house.whatsapp,
    gaId: house.gaId, description: house.description,
  });
  const [files, setFiles] = useState<{ logo?: File; favicon?: File; banners: File[] }>({ banners: [] });
  // current files the admin marked for removal (applied on Save)
  const [gone, setGone] = useState<{ logo: boolean; favicon: boolean; banners: string[] }>({ logo: false, favicon: false, banners: [] });
  const fileName = (u: string) => decodeURIComponent(u.split("?")[0].split("/").pop() ?? "");
  const set = (k: keyof typeof d) => (e: { target: { value: string } }) => setD({ ...d, [k]: e.target.value });
  const bannerErr = files.banners.map((f) => imageError(f)).find(Boolean) ?? "";
  const e = {
    name: d.name.trim() ? "" : "Name is required.",
    website: isUrl(d.website) ? "" : "Enter a full URL starting with https://",
    supportEmail: isEmail(d.supportEmail) ? "" : "Enter a valid email address.",
    supportPhone: isPhone(d.supportPhone) ? "" : "Enter digits only (a leading + is fine).",
    whatsapp: !d.whatsapp || isPhone(d.whatsapp) ? "" : "Enter digits only, with country code.",
    gaId: isGaId(d.gaId) ? "" : "Use a format like G-XXXXXXXXXX.",
    logo: imageError(files.logo), favicon: imageError(files.favicon), banner: bannerErr,
  };
  const invalid = Object.values(e).some(Boolean);
  const pick = (k: "logo" | "favicon") => (ev: React.ChangeEvent<HTMLInputElement>) => setFiles({ ...files, [k]: ev.target.files?.[0] });
  return (
    <Modal wide title="Edit auction house" onClose={onClose}
      footer={<Footer onClose={onClose} disabled={invalid || busy} label={busy ? "Saving…" : "Save"} onSave={async () => {
        setBusy(true); setServerErr("");
        try {
          const fd = new FormData();
          Object.entries(d).forEach(([k, v]) => fd.append(k, k === "name" ? d.name.trim() : String(v)));
          if (files.logo) fd.append("logo", files.logo); else if (gone.logo) fd.append("removeLogo", "1");
          if (files.favicon) fd.append("favicon", files.favicon); else if (gone.favicon) fd.append("removeFavicon", "1");
          if (files.banners.length) files.banners.forEach((b) => fd.append("banners", b)); else gone.banners.forEach((n) => fd.append("removeBanner", n));
          const res = await fetch("/api/admin/house", { method: "POST", body: fd, cache: "no-store" }); // browser sets the multipart boundary
          const j = (await res.json().catch(() => ({}))) as HouseRecord & { message?: string; data?: Record<string, { message?: string }> };
          if (!res.ok) {
            const f = j.data ? Object.entries(j.data)[0] : undefined;
            throw new Error(f ? `${f[0]}: ${f[1]?.message ?? "invalid"}` : j.message || `Save failed (${res.status})`);
          }
          onSave(fromRecord(j));
        } catch (err) {
          setServerErr(err instanceof Error ? err.message : "Save failed");
        } finally { setBusy(false); }
      }} />}>
      {serverErr && <p role="alert" className="mb-3 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{serverErr}</p>}
      <Group title="Main details" sub="Basic information about the auction house.">
        <Field label="Name"><input className={inputCls} value={d.name} onChange={set("name")} /><Err m={e.name} /></Field>
      </Group>
      <Group title="Contact & website" sub="Contact details and web presence.">
        <Field label="Website"><input className={inputCls} value={d.website} onChange={set("website")} /><Err m={e.website} /></Field>
        <Field label="Domain"><input className={`${inputCls} bg-zinc-100 text-zinc-500`} value={house.domain} disabled /><p className="mt-1 text-[11px] text-zinc-500">The domain is set when the auction house is created and can’t be changed.</p></Field>
        <Field label="Support email"><input className={inputCls} value={d.supportEmail} onChange={set("supportEmail")} /><Err m={e.supportEmail} /></Field>
        <Field label="Support phone"><input className={inputCls} value={d.supportPhone} onChange={set("supportPhone")} /><Err m={e.supportPhone} /></Field>
      </Group>
      <Group title="Social" sub="Social media and messaging links.">
        <Field label="Facebook"><input className={inputCls} value={d.facebook} onChange={set("facebook")} /></Field>
        <Field label="Twitter"><input className={inputCls} value={d.twitter} onChange={set("twitter")} /></Field>
        <Field label="LinkedIn"><input className={inputCls} value={d.linkedin} onChange={set("linkedin")} /></Field>
        <Field label="WhatsApp"><input className={inputCls} value={d.whatsapp} onChange={set("whatsapp")} /><Err m={e.whatsapp} /></Field>
      </Group>
      <Group title="Analytics" sub="Tracking and analytics configuration.">
        <Field label="Google Analytics ID"><input className={inputCls} value={d.gaId} onChange={set("gaId")} placeholder="G-XXXXXXXXXX" /><Err m={e.gaId} /></Field>
      </Group>
      <Group title="Branding assets" sub="Used on the public site. PNG, JPG, WebP or SVG, up to 2 MB each.">
        <AssetPicker label="Logo" hint="Shown in the site header. Wide image, transparent background works best." accept="image/png,image/jpeg,image/webp,image/svg+xml"
          currentText={gone.logo ? "Will be removed when you save" : house.logoName || "No file uploaded"} hasCurrent={!!house.logoName && !gone.logo} currentUrls={house.logoUrl && !gone.logo ? [house.logoUrl] : []} files={files.logo ? [files.logo] : []} error={e.logo}
          removed={gone.logo} onRemove={() => setGone({ ...gone, logo: true })} onRestore={() => setGone({ ...gone, logo: false })}
          onChange={(f) => { setFiles({ ...files, logo: f[0] }); if (f[0]) setGone({ ...gone, logo: false }); }} />
        <AssetPicker label="Favicon" hint="Small browser-tab icon. Square image, at least 64 × 64 px." accept="image/png,image/jpeg,image/webp,image/svg+xml"
          currentText={gone.favicon ? "Will be removed when you save" : house.faviconName || "No file uploaded"} hasCurrent={!!house.faviconName && !gone.favicon} currentUrls={house.faviconUrl && !gone.favicon ? [house.faviconUrl] : []} files={files.favicon ? [files.favicon] : []} error={e.favicon}
          removed={gone.favicon} onRemove={() => setGone({ ...gone, favicon: true })} onRestore={() => setGone({ ...gone, favicon: false })}
          onChange={(f) => { setFiles({ ...files, favicon: f[0] }); if (f[0]) setGone({ ...gone, favicon: false }); }} />
        <AssetPicker label="Banner" multiple hint="Homepage banner images. PNG, JPG or WebP. You can select several." accept="image/png,image/jpeg,image/webp"
          currentText={house.bannerCount ? `${house.bannerCount} banner image${house.bannerCount === 1 ? "" : "s"} uploaded` : "No banners uploaded"} hasCurrent={house.bannerCount > 0} currentUrls={house.bannerUrls ?? []} files={files.banners} error={e.banner} onChange={(f) => setFiles({ ...files, banners: f })} />
        {files.banners.length === 0 && (house.bannerUrls ?? []).length > 0 && (
          <div>
            <p className="mb-1.5 text-[11px] text-zinc-500">Current banners. Click × to remove one when you save.</p>
            <div className="flex flex-wrap gap-2">
              {(house.bannerUrls ?? []).map((u) => {
                const n = fileName(u), off = gone.banners.includes(n);
                return (
                  <div key={u} className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={u} alt={`Banner ${n}`} className={`h-14 w-24 rounded border border-zinc-200 object-cover ${off ? "opacity-30" : ""}`} />
                    <button type="button" aria-label={off ? `Keep banner ${n}` : `Remove banner ${n}`} title={off ? "Keep" : "Remove"}
                      onClick={() => setGone({ ...gone, banners: off ? gone.banners.filter((x) => x !== n) : [...gone.banners, n] })}
                      className={`absolute -right-1.5 -top-1.5 grid size-5 place-items-center rounded-full border text-[11px] font-bold ${off ? "border-zinc-300 bg-white text-zinc-700" : "border-rose-200 bg-rose-50 text-rose-600"}`}>{off ? "↺" : "×"}</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </Group>
      <Group title="Description" sub="Describe the auction house for bidders and partners.">
        <Field label="Description (HTML)"><textarea className={`${areaCls} h-24`} value={d.description} onChange={set("description")} /></Field>
        <p className="text-[11px] text-zinc-500">HTML is cleaned on save: scripts and event handlers are removed.</p>
      </Group>
    </Modal>
  );
}

/* ---------- Edit Email Configuration (SMTP) ---------- */
export function SmtpModal({ house, onSave, onClose }: { house: House; onSave: (p: Partial<House> & { smtpPassword?: string }) => void | Promise<void>; onClose: () => void }) {
  const [d, setD] = useState({ host: house.smtp.host, port: house.smtp.port, username: house.smtp.username, password: "", from: house.smtp.from, fromName: house.smtp.fromName });
  const [to, setTo] = useState("");
  const [test, setTest] = useState<{ ok: boolean; m: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const { busy, err, run } = useSave(onSave);
  const set = (k: keyof typeof d) => (e: React.ChangeEvent<HTMLInputElement>) => setD({ ...d, [k]: e.target.value });
  const portErr = d.port && !(/^\d+$/.test(d.port) && +d.port >= 1 && +d.port <= 65535) ? "Port must be a number from 1 to 65535." : "";
  const fromErr = d.from.trim() && !isEmail(d.from.trim()) ? "Enter a valid email address." : "";
  const needFrom = d.host.trim() && !d.from.trim() && !isEmail(d.username.trim()) ? "Enter the sender address (the From email)." : "";
  const sendTest = async () => {
    setTesting(true); setTest(null);
    try {
      const r = await fetch("/api/admin/house/smtp-test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ to: to.trim() }), cache: "no-store" });
      const j = (await r.json().catch(() => ({}))) as { message?: string };
      setTest(r.ok ? { ok: true, m: `Test email sent to ${to.trim()}.` } : { ok: false, m: j.message || `Failed (${r.status})` });
    } catch { setTest({ ok: false, m: "Could not reach the server." }); } finally { setTesting(false); }
  };
  return (
    <Modal title="Edit email configuration" onClose={onClose}
      footer={<Footer onClose={onClose} disabled={!!portErr || !!fromErr || !!needFrom || busy} label={busy ? "Saving…" : "Save"} onSave={() =>
        run({ smtp: { host: d.host.trim(), port: d.port, username: d.username.trim(), passwordSet: house.smtp.passwordSet || !!d.password, from: d.from.trim(), fromName: d.fromName.trim() }, smtpPassword: d.password })} />}>
      <div className="space-y-3">
        <SaveErr m={err} />
        <Field label="Host"><input className={inputCls} value={d.host} onChange={set("host")} placeholder="smtp.example.com" /></Field>
        <Field label="Port"><input className={inputCls} value={d.port} onChange={set("port")} placeholder="465" inputMode="numeric" /><Err m={portErr} />
          <p className="mt-1 text-[11px] text-zinc-500">465 uses SSL/TLS; 587 and 25 upgrade to TLS automatically.</p></Field>
        <Field label="Username"><input className={inputCls} value={d.username} onChange={set("username")} autoComplete="off" /></Field>
        <Field label="Password"><input type="password" className={inputCls} value={d.password} onChange={set("password")} autoComplete="new-password"
          placeholder={house.smtp.passwordSet ? "••••••••" : ""} />
          {house.smtp.passwordSet && <p className="mt-1 text-[11px] text-zinc-500">Leave empty to keep the existing password.</p>}</Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Sender address (From)"><input className={inputCls} value={d.from} onChange={set("from")} placeholder="no-reply@example.com" /><Err m={fromErr || needFrom} /></Field>
          <Field label="Sender name"><input className={inputCls} value={d.fromName} onChange={set("fromName")} placeholder="BidMyAsset" /></Field>
        </div>
        <div className="rounded-lg border border-zinc-200 p-3">
          <p className="text-xs font-semibold">Send a test email</p>
          <p className="mb-2 text-[11px] text-zinc-500">Uses the settings that are already saved. Save first, then test.</p>
          <div className="flex gap-2"><input className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} placeholder="you@example.com" />
            <Btn variant="ghost" disabled={testing || !isEmail(to.trim())} onClick={sendTest}>{testing ? "Sending…" : "Send"}</Btn></div>
          {test && <p role="status" className={`mt-2 text-[11px] ${test.ok ? "text-emerald-600" : "text-rose-600"}`}>{test.m}</p>}
        </div>
      </div>
    </Modal>
  );
}

/* ---------- Internet Buying Fee ---------- */
export function FeeModal({ house, onSave, onClose }: { house: House; onSave: (p: Partial<House>) => void | Promise<void>; onClose: () => void }) {
  const { busy, err, run } = useSave(onSave);
  const [kind, setKind] = useState<FeeKind>(house.fee?.kind ?? "flat_pct");
  // values are kept per structure, so switching options doesn't wipe what was typed
  const [vals, setVals] = useState<Record<string, string>>(() => {
    const f = house.fee as Record<string, unknown> | null;
    return f ? Object.fromEntries(Object.entries(f).filter(([k]) => k !== "kind").map(([k, v]) => [`${f.kind}.${k}`, String(v)])) : {};
  });
  const def = FEE_DEFS.find((d) => d.kind === kind)!;
  const get = (k: FeeKind, key: string) => vals[`${k}.${key}`] ?? "";
  const invalid = def.fields.some((f) => feeValueError(f, get(kind, f.key)));
  const save = () => run({ fee: { kind, ...Object.fromEntries(def.fields.map((f) => [f.key, Number(get(kind, f.key))])) } as Fee });
  return (
    <Modal wide title="Internet buying fee" onClose={onClose} footer={<>
      {house.fee && <button type="button" disabled={busy} onClick={() => run({ fee: null })} className="mr-auto px-2 text-xs font-semibold text-rose-600 hover:underline disabled:opacity-50">Remove fee</button>}
      <Footer onClose={onClose} disabled={invalid || busy} label={busy ? "Saving…" : "Save"} onSave={save} /></>}>
      <SaveErr m={err} />
      <p className="text-xs text-zinc-500">Choose one internet buying fee structure and provide its values. Only the selected option is shown in the summary.</p>
      <p className="mt-2 text-xs text-zinc-500">The fee is charged on the winning (hammer) price: it is added to every new invoice and shown next to the bid on the website.</p>
      <p className="mt-2 text-xs text-zinc-500">Note: the currency is applied when the auction is created.</p>
      <div className="mt-3 space-y-2" role="radiogroup" aria-label="Fee structure">
        {FEE_DEFS.map((d) => (
          <div key={d.kind}>
            <label className="flex cursor-pointer items-center gap-2 text-xs">
              <input type="radio" name="fee" checked={kind === d.kind} onChange={() => setKind(d.kind)} className="accent-primary" />{d.label}
            </label>
            {kind === d.kind && (
              <div className={`mt-2 grid gap-3 pl-6 ${d.fields.length === 3 ? "sm:grid-cols-3" : "sm:grid-cols-2"}`}>
                {d.fields.map((f) => {
                  const v = get(d.kind, f.key);
                  const err = v === "" ? "" : feeValueError(f, v);
                  return (
                    <div key={f.key}>
                      <Field label={f.label}>
                        <input type="number" min={0} max={f.pct ? 100 : undefined} step="any" inputMode="decimal" className={inputCls} value={v} aria-invalid={!!err}
                          onChange={(e) => setVals({ ...vals, [`${d.kind}.${f.key}`]: e.target.value })} />
                      </Field>
                      <Err m={err} />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </Modal>
  );
}

/* ---------- Theming & Config ---------- */
const BTN_FIELDS: [keyof ButtonStyle, string, boolean][] = [
  ["background", "Background", true], ["text", "Text", true], ["border", "Border", true], ["radius", "Border radius", false],
  ["fontSize", "Font size", false], ["fontWeight", "Font weight", false], ["padding", "Padding", false], ["shadow", "Shadow", false],
  ["hoverBackground", "Hover background", true], ["hoverText", "Hover text", true], ["hoverBorder", "Hover border", true], ["hoverShadow", "Hover shadow", false],
];
const BTN_TITLES: Record<ButtonKey, [string, string]> = {
  primary: ["Primary button", "Main call-to-action button styling."],
  secondary: ["Secondary button", "Supportive button used for secondary actions."],
  outline: ["Outline button", "Buttons with transparent background and emphasized border."],
};

function PreviewBtn({ s, label }: { s: ButtonStyle; label: string }) {
  const [on, setOn] = useState(false);
  return (
    <button type="button" onMouseEnter={() => setOn(true)} onMouseLeave={() => setOn(false)} onFocus={() => setOn(true)} onBlur={() => setOn(false)}
      style={{
        background: on ? s.hoverBackground : s.background, color: on ? s.hoverText : s.text, border: `1px solid ${on ? s.hoverBorder : s.border}`,
        borderRadius: s.radius, fontSize: s.fontSize, fontWeight: s.fontWeight, padding: s.padding, boxShadow: on ? s.hoverShadow : s.shadow, transition: "all .15s",
      }}>{label}</button>
  );
}


const DIALOG_GROUPS: { title: string; sub: string; fields: [keyof DialogStyle, string, boolean, boolean?][] }[] = [
  { title: "Container", sub: "Overall dialog chrome and elevation.", fields: [["background", "Background", true], ["border", "Border", true], ["text", "Text color", true], ["radius", "Border radius", false], ["shadow", "Shadow", false]] },
  { title: "Header", sub: "Styling for the dialog header and title.", fields: [["headerPadding", "Header padding", false], ["headerGap", "Header gap", false], ["titleFontSize", "Title font size", false], ["titleFontWeight", "Title font weight", false]] },
  { title: "Body & Footer", sub: "Spacing for dialog content and footer actions.", fields: [["contentPadding", "Content padding", false], ["footerPadding", "Footer padding", false], ["footerGap", "Footer gap", false]] },
];
const COLOR_OK = (v: string) => isColor(v) || /^(transparent|none|rgba?\([\d\s.,%]+\))$/i.test(v);

function DialogPreview({ d, btn }: { d: DialogStyle; btn: Record<ButtonKey, ButtonStyle> }) {
  const small = (s: ButtonStyle): ButtonStyle => ({ ...s, padding: "4px 12px", fontSize: "0.7rem" });
  return (
    <div role="presentation" style={{ background: d.background, color: d.text, border: `1px solid ${d.border}`, borderRadius: d.radius, boxShadow: d.shadow }}>
      <div style={{ padding: d.headerPadding, display: "flex", flexDirection: "column", gap: d.headerGap }}>
        <h4 style={{ fontSize: d.titleFontSize, fontWeight: d.titleFontWeight, margin: 0 }}>Dialog Title</h4>
      </div>
      <div style={{ padding: d.contentPadding, fontSize: "0.72rem" }}>Preview how your dialog body text will render with the configured palette and spacing.</div>
      <div style={{ padding: d.footerPadding, display: "flex", justifyContent: "flex-end", gap: d.footerGap }}>
        <PreviewBtn s={small(btn.outline)} label="Cancel" /><PreviewBtn s={small(btn.primary)} label="Confirm" />
      </div>
    </div>
  );
}

export function ThemeModal({ house, onSave, onClose }: { house: House; onSave: (p: Partial<House>) => void | Promise<void>; onClose: () => void }) {
  const { busy, err, run } = useSave(onSave);
  const [t, setT] = useState(house.theme);
  const { confirm, dialog } = useConfirm();
  // Defaults come from mergeTheme(null) as a deep copy, so editing afterwards can never touch the shared default objects.
  const fresh = () => JSON.parse(JSON.stringify(mergeTheme(null))) as House["theme"];
  const RESET_WHAT = { all: "colours, ratings, button and dialog styles", buttons: "button style", dialog: "dialog style" } as const;
  const resetTheme = async (what: "all" | "buttons" | "dialog") => {
    const ok = await confirm({ title: "Reset to defaults?", body: `Your ${RESET_WHAT[what]} changes will be replaced with the defaults. Nothing changes on the website until you click Save.`, confirmLabel: "Reset to defaults" });
    if (!ok) return;
    setT((x) => (what === "all" ? fresh() : what === "buttons" ? { ...x, buttons: fresh().buttons } : { ...x, dialog: fresh().dialog }));
  };
  const changed = JSON.stringify(t) !== JSON.stringify(house.theme);
  const isDefault = JSON.stringify(t) === JSON.stringify(fresh());
  const [tab, setTab] = useState<"button" | "dialog">("button");
  const setBtn = (k: ButtonKey, f: keyof ButtonStyle, v: string) => setT({ ...t, buttons: { ...t.buttons, [k]: { ...t.buttons[k], [f]: v } } });
  const bad = (k: ButtonKey, f: keyof ButtonStyle, color: boolean) => (color ? !(isColor(t.buttons[k][f]) || /^(transparent|none|rgba?\([\d\s.,%]+\))$/i.test(t.buttons[k][f])) : !isCssValue(t.buttons[k][f]));
  const setDlg = (f: keyof DialogStyle, v: string) => setT({ ...t, dialog: { ...t.dialog, [f]: v } });
  const dBad = (f: keyof DialogStyle, color: boolean) => (color ? !COLOR_OK(t.dialog[f]) : !isCssValue(t.dialog[f]));
  const anyBad = (["primary", "secondary", "outline"] as ButtonKey[]).some((k) => BTN_FIELDS.some(([f, , c]) => bad(k, f, c))) || !isColor(t.primary) || !isColor(t.secondary) || DIALOG_GROUPS.some((g) => g.fields.some(([f, , c]) => dBad(f, c)));
  const colorBox = (v: string, on: (v: string) => void, label: string) => (
    <div className="flex gap-2">
      <input aria-label={label} className={inputCls} value={v} onChange={(e) => on(e.target.value)} placeholder="#0037E1" />
      <input type="color" aria-label={`${label} picker`} value={/^#[0-9a-f]{6}$/i.test(v) ? v : "#000000"} onChange={(e) => on(e.target.value)} className="h-9 w-10 shrink-0 cursor-pointer rounded border border-zinc-300 bg-white p-0.5" />
    </div>
  );
  return (
    <Modal wide title="Edit theming & config" onClose={onClose}
      footer={<>
        <button type="button" disabled={busy || isDefault} onClick={() => resetTheme("all")} className="mr-auto px-2 text-xs font-semibold text-rose-600 hover:underline disabled:cursor-not-allowed disabled:opacity-40 disabled:no-underline">Reset all to defaults</button>
        <Footer onClose={onClose} disabled={anyBad || busy || !changed} label={busy ? "Saving…" : "Save"} onSave={() => run({ theme: t })} />
      </>}>
      <SaveErr m={err} />
      {changed && <p role="status" className="mb-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">{isDefault ? "Defaults restored here. Click Save to apply them to the website." : "You have unsaved changes. Click Save to apply them to the website."}</p>}
      <p className="mb-3 text-[11px] text-zinc-500">Saved to the database and applied on the public website. Only the values you change from the defaults restyle the site (buttons and dialogs apply in light mode).</p>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Primary color">{colorBox(t.primary, (v) => setT({ ...t, primary: v }), "Primary color")}</Field>
        <Field label="Secondary color">{colorBox(t.secondary, (v) => setT({ ...t, secondary: v }), "Secondary color")}</Field>
      </div>
      {(!isColor(t.primary) || !isColor(t.secondary)) && <Err m="Use a hex color like #0037E1." />}
      <div className="mt-3 flex items-center gap-3 text-xs font-semibold text-zinc-700">
        Allow questions & rating <Toggle on={t.ratings} onChange={(v) => setT({ ...t, ratings: v })} label="Allow questions and rating" />
        <span className="font-normal text-zinc-500">{t.ratings ? "Enabled" : "Disabled"}</span>
      </div>

      <div role="tablist" className="mt-4 grid grid-cols-2 border-b border-zinc-200 text-xs font-semibold">
        {([["button", "Button theme"], ["dialog", "Dialog theme"]] as const).map(([id, l]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={`-mb-px border-b-2 py-2 ${tab === id ? "border-primary text-primary" : "border-transparent text-zinc-600"}`}>{l}</button>
        ))}
      </div>

      {tab === "dialog" ? (
        <div className="mt-3 space-y-3">
          {DIALOG_GROUPS.map((g) => (
            <fieldset key={g.title} className="rounded-lg border border-zinc-200 p-3">
              <legend className="px-1 text-xs font-bold">{g.title}</legend>
              <p className="mb-2 text-[11px] text-zinc-500">{g.sub}</p>
              <div className="grid grid-cols-2 gap-x-3 gap-y-2">
                {g.fields.map(([f, label, color]) => (
                  <div key={f}>
                    <Field label={label}>
                      <div className="flex gap-1.5">
                        <input className={`${inputCls} h-8 text-xs`} value={t.dialog[f]} onChange={(e) => setDlg(f, e.target.value)} aria-invalid={dBad(f, color)} />
                        {color && (/^#[0-9a-f]{6}$/i.test(t.dialog[f])
                          ? <input type="color" aria-label={`${label} picker`} value={t.dialog[f]} onChange={(e) => setDlg(f, e.target.value)} className="h-8 w-8 shrink-0 cursor-pointer rounded border border-zinc-300 bg-white p-0.5" />
                          : <span aria-hidden className="h-8 w-8 shrink-0 rounded border border-zinc-300" style={{ background: COLOR_OK(t.dialog[f]) ? t.dialog[f] : "transparent" }} />)}
                      </div>
                    </Field>
                    {dBad(f, color) && <p className={errCls}>Not a valid value.</p>}
                  </div>
                ))}
              </div>
            </fieldset>
          ))}
          <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
            <div className="flex items-center justify-between">
              <div><p className="text-xs font-bold">Live preview</p><p className="text-[11px] text-zinc-500">Preview renders using your current configuration. Hover states are shown on focus.</p></div>
              <Btn variant="outline" className="h-7 px-3 text-[11px]" onClick={() => resetTheme("dialog")}>Reset dialog to defaults</Btn>
            </div>
            <div className="mt-3 grid gap-4 sm:grid-cols-[auto_1fr]">
              <div><p className="mb-2 text-[10px] font-bold uppercase text-zinc-500">Buttons</p>
                <div className="flex flex-wrap gap-2"><PreviewBtn s={t.buttons.primary} label="Primary" /><PreviewBtn s={t.buttons.secondary} label="Secondary" /><PreviewBtn s={t.buttons.outline} label="Outline" /></div></div>
              <div><p className="mb-2 text-[10px] font-bold uppercase text-zinc-500">Dialog</p><DialogPreview d={t.dialog} btn={t.buttons} /></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {(Object.keys(BTN_TITLES) as ButtonKey[]).map((k) => (
            <fieldset key={k} className="rounded-lg border border-zinc-200 p-3">
              <legend className="px-1 text-xs font-bold">{BTN_TITLES[k][0]}</legend>
              <p className="mb-2 text-[11px] text-zinc-500">{BTN_TITLES[k][1]}</p>
              <div className="grid grid-cols-2 gap-x-3 gap-y-2">
                {BTN_FIELDS.map(([f, label, color]) => (
                  <div key={f}>
                    <Field label={label}>
                      <div className="flex gap-1.5">
                        <input className={`${inputCls} h-8 text-xs`} value={t.buttons[k][f]} onChange={(e) => setBtn(k, f, e.target.value)} aria-invalid={bad(k, f, color)} />
                        {color && <input type="color" aria-label={`${label} picker`} value={/^#[0-9a-f]{6}$/i.test(t.buttons[k][f]) ? t.buttons[k][f] : "#000000"} onChange={(e) => setBtn(k, f, e.target.value)} className="h-8 w-8 shrink-0 cursor-pointer rounded border border-zinc-300 bg-white p-0.5" />}
                      </div>
                    </Field>
                    {bad(k, f, color) && <p className={errCls}>Not a valid value.</p>}
                  </div>
                ))}
              </div>
            </fieldset>
          ))}
          <div className="rounded-lg border border-zinc-200 p-3">
            <div className="flex items-center justify-between">
              <div><p className="text-xs font-bold">Live preview</p><p className="text-[11px] text-zinc-500">Hover states show on hover or focus.</p></div>
              <Btn variant="outline" className="h-7 px-3 text-[11px]" onClick={() => resetTheme("buttons")}>Reset buttons to defaults</Btn>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <PreviewBtn s={t.buttons.primary} label="Primary" /><PreviewBtn s={t.buttons.secondary} label="Secondary" /><PreviewBtn s={t.buttons.outline} label="Outline" />
            </div>
          </div>
        </div>
      )}
      {dialog}
    </Modal>
  );
}

/* ---------- Payment Credentials ---------- */
export function PaymentModal({ house, onSave, onClose }: { house: House; onSave: (p: Partial<House> & { paymentSecret?: string }) => void | Promise<void>; onClose: () => void }) {
  const [def, setDef] = useState(house.payment.defaultGateway);
  const [secret, setSecret] = useState("");
  const [code, setCode] = useState(house.payment.categoryCode);
  const [sandbox, setSandbox] = useState(house.payment.sandbox);
  const { busy, err, run } = useSave(onSave);
  return (
    <Modal title="Payment credentials" onClose={onClose}
      footer={<Footer onClose={onClose} disabled={busy} label={busy ? "Saving…" : "Save"} onSave={() => run({ payment: { defaultGateway: def, secretSet: house.payment.secretSet || !!secret, categoryCode: code.trim(), sandbox }, paymentSecret: secret })} />}>
      <SaveErr m={err} />
      <p className="border-b-2 border-primary pb-2 text-center text-xs font-semibold">Toyyibpay</p>
      <label className="mt-3 flex items-center gap-2 text-xs"><input type="checkbox" checked={def} onChange={(e) => setDef(e.target.checked)} className="accent-primary" />Default gateway</label>
      <div className="mt-3 space-y-3">
        <Field label="Secret key"><input type="password" className={inputCls} value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="new-password" placeholder={house.payment.secretSet ? "••••••••" : "Enter Toyyibpay secret key"} />
          <p className="mt-1 text-[11px] text-zinc-500">Leave empty to keep the existing value. Enter a new value to update.</p></Field>
        <Field label="Category code"><input className={inputCls} value={code} onChange={(e) => setCode(e.target.value)} placeholder="Enter Toyyibpay category code" /></Field>
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={sandbox} onChange={(e) => setSandbox(e.target.checked)} className="accent-primary" />Sandbox mode (dev.toyyibpay.com, for testing only)</label>
        <p className="rounded-md bg-zinc-100 px-3 py-2 text-[11px] text-zinc-600">Bidders pay unpaid invoices from My Invoices (MYR only, minimum RM 1.00). Toyyibpay confirms the payment to the backend at <code>BMA_PUBLIC_URL</code>/api/bma/payments/toyyibpay/callback, so that address must be reachable from the internet (use a tunnel such as ngrok on localhost).</p>
      </div>
    </Modal>
  );
}

/* ---------- Add Legal Policy ---------- */
export function LegalModal({ initial, onSave, onClose }: { initial?: LegalPolicy; onSave: (p: LegalPolicy) => void | Promise<void>; onClose: () => void }) {
  const [d, setD] = useState({ name: initial?.name ?? "", privacy: initial?.privacy ?? "", terms: initial?.terms ?? "" });
  const [busy, setBusy] = useState(false);
  const [saveErr, setSaveErr] = useState("");
  const nameErr = d.name.trim() ? "" : "Policy name is required.";
  const bodyErr = d.privacy.trim() || d.terms.trim() ? "" : "Add a privacy policy, terms of use, or both.";
  const submit = async () => {
    setBusy(true); setSaveErr("");
    try { await onSave({ id: initial?.id ?? `lp-${Date.now()}`, name: d.name.trim(), privacy: d.privacy, terms: d.terms }); }
    catch (e) { setSaveErr(e instanceof Error ? e.message : "Save failed"); } finally { setBusy(false); }
  };
  return (
    <Modal wide title={initial ? "Edit legal policy" : "Add legal policy"} onClose={onClose}
      footer={<>
        <span className="mr-auto self-center text-[11px] text-zinc-500">{initial ? "Changes go live on the website when you save." : "You can add a policy at any time."}</span>
        <Footer onClose={onClose} disabled={!!nameErr || !!bodyErr || busy} label={busy ? "Saving…" : "Save"} onSave={submit} />
      </>}>
      <div className="space-y-3">
        <SaveErr m={saveErr} />
        <Field label="Policy name"><input className={inputCls} value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} placeholder="e.g. Privacy & Terms – Marketplace" /></Field>
        <Field label="Privacy policy (HTML allowed)"><textarea className={`${areaCls} h-36`} value={d.privacy} onChange={(e) => setD({ ...d, privacy: e.target.value })} placeholder="<p>We collect data…</p>" /></Field>
        <Field label="Terms of use (HTML allowed)"><textarea className={`${areaCls} h-36`} value={d.terms} onChange={(e) => setD({ ...d, terms: e.target.value })} placeholder="<ul><li>Bidders agree…</li></ul>" /></Field>
        <Err m={d.name || d.privacy || d.terms ? bodyErr : ""} />
        <p className="rounded-md bg-zinc-100 px-3 py-2 text-[11px] text-zinc-600">Saved policies are published at /privacy and /terms, and linked from the registration form. Only basic formatting is kept (headings, lists, links, tables); scripts and styles are removed on save.</p>
      </div>
    </Modal>
  );
}
