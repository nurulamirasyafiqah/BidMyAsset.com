"use client";

import { useState } from "react";
import { CheckCircle2, Download, Image as ImageIcon, Printer, Sparkles } from "lucide-react";
import { Btn, Card } from "@/components/admin/ui";
import { PlaceholderImage } from "@/components/PlaceholderImage";
import { StudioGate } from "@/lib/studioApi";
import { fmtMoney, fmtWhen, type Intel, type LotStat, type Outcome } from "@/lib/intelData";
import { buildXlsx, downloadBlob, type XCell } from "@/lib/xlsx";
import { IntelFrame, LoadNote, NotFound, lookupAuction, useIntel } from "@/components/admin/IntelShared";

type Cell = string | number;
type Report = { id: string; name: string; desc: string; cols: string[]; rows: (m: Intel) => Cell[][]; note?: string };
const D = "—";
const OUT: Record<Outcome, string> = { SOLD: "Sold", PENDING: "Sold pending", NO_SALE: "No sale", OPEN: "Open" };
const mo = (m: Intel, n: number) => fmtMoney(n, m.currency);
const when = (m: Intel, ms: number) => fmtWhen(ms, m.tz);
const soldLots = (m: Intel) => m.lots.filter((l) => l.outcome === "SOLD");

/** Each bidder's best bid on a lot, excluding the winner: the "underbids". */
function underbids(m: Intel): Cell[][] {
  const out: Cell[][] = [];
  m.lots.forEach((l) => {
    if (!l.winner) return;
    const best = new Map<number, (typeof l.bids)[number]>();
    l.bids.forEach((b) => { if (b.bidder.no !== l.winner!.no && (!best.has(b.bidder.no) || b.amount > best.get(b.bidder.no)!.amount)) best.set(b.bidder.no, b); });
    best.forEach((b) => out.push([when(m, b.ms), l.no, mo(m, b.amount), b.bidder.no, mo(m, l.high)]));
  });
  return out;
}

const booklet = (m: Intel): Cell[][] => m.lots.map((l) => [l.no, l.title, l.consignor || D, l.reserve ? mo(m, l.reserve) : "None", mo(m, l.startBid), mo(m, l.increment)]);

const REPORTS: Report[] = [
  { id: "online-winning", name: "Online Winning Bids", desc: "Track every internet bidder that finished on top. Use this to confirm allocations and payouts.", cols: ["Lot #", "Lot title", "Bidder no.", "Winning bid"], rows: (m) => soldLots(m).map((l) => [l.no, l.title, l.winner!.no, mo(m, l.high)]) },
  { id: "all-winning", name: "All Winning Bids", desc: "Every winning bid across all channels (this platform runs online auctions only, so it matches Online Winning Bids).", cols: ["Lot #", "Lot title", "Bidder no.", "Winning bid"], rows: (m) => soldLots(m).map((l) => [l.no, l.title, l.winner!.no, mo(m, l.high)]) },
  { id: "online-sales", name: "Online Sales", desc: "Lots sold to internet bidders with final hammer values.", cols: ["Lot #", "Lot title", "Buyer", "Sale price"], rows: (m) => soldLots(m).map((l) => [l.no, l.title, l.winner!.name, mo(m, l.high)]) },
  { id: "all-sales", name: "All Sales", desc: "Every sold lot with final hammer values.", cols: ["Lot #", "Lot title", "Buyer", "Sale price"], rows: (m) => soldLots(m).map((l) => [l.no, l.title, l.winner!.name, mo(m, l.high)]) },
  { id: "chat", name: "Chat Transcripts", desc: "Conversation history between bidders and auction staff during the sale.", cols: ["Date time", "Bidder", "Message"], rows: () => [], note: "This platform has no bidder chat, so there are no transcripts. Bidder questions are in Auction Studio → Questions & Review." },
  { id: "bidding-transcripts", name: "Bidding Transcripts", desc: "Time-stamped bid activity so you can audit increments and resolve bidding questions quickly.", cols: ["Date time", "Lot#", "Bid amount", "Bidder type", "Bidder no.", "Item status"],
    rows: (m) => m.bids.map((b) => [when(m, b.ms), b.lotNo, mo(m, b.amount), "Internet", b.bidder.no, OUT[m.lots.find((l) => l.id === b.lotId)?.outcome ?? "OPEN"]]) },
  { id: "underbids", name: "Internet Underbids", desc: "Each losing bidder's best bid on a lot, next to the winning bid.", cols: ["Date time", "Lot#", "Bid amount", "Bidder no.", "Winning bid"], rows: underbids },
  { id: "logged-in", name: "Logged In Bidders", desc: "Registered bidders who signed in while the auction was running (sign-ins are kept for 31 days).", cols: ["Bidder no.", "Name", "Email", "First sign-in", "Sign-ins"],
    rows: (m) => m.logins.map((g) => [g.bidder.no, g.bidder.name, g.bidder.email, when(m, g.first), g.count]) },
  { id: "absentee", name: "Absentee Bids", desc: "Maximum bids placed before the auction opened. They open the lot at the starting bid and then bid automatically, one step at a time, up to the bidder's maximum.", cols: ["Lot#", "Bidder no.", "Maximum bid", "Placed at"],
    rows: (m) => m.maxBids.filter((b) => b.ms < m.startMs).map((b) => [b.lotNo, b.bidder.no, mo(m, b.amount), when(m, b.ms)]), note: "No maximum bids were placed before the auction opened." },
  { id: "reserves", name: "Reserves", desc: "Reserve status for every lot against the highest bid received.", cols: ["Lot no.", "Lot title", "Reserve", "High bid", "Status"],
    rows: (m) => m.lots.map((l) => [l.no, l.title, l.reserve ? mo(m, l.reserve) : "None", l.bids.length ? mo(m, l.high) : D, l.reserveStatus]) },
  { id: "no-sales", name: "No Sales Lots", desc: "Lots that closed without a sale.", cols: ["Lot no.", "Lot title", "Reserve", "High bid"],
    rows: (m) => m.lots.filter((l) => l.outcome === "NO_SALE").map((l) => [l.no, l.title, l.reserve ? mo(m, l.reserve) : "None", l.bids.length ? mo(m, l.high) : D]) },
  { id: "pending", name: "Lots Sold Pending", desc: "Closed lots whose top bid is below the reserve in a Subject to Confirmation auction: the seller decides.", cols: ["Lot no.", "Lot title", "High bid", "Awaiting"],
    rows: (m) => m.lots.filter((l) => l.outcome === "PENDING").map((l) => [l.no, l.title, mo(m, l.high), "Seller confirmation"]) },
  { id: "auctioneer", name: "Auctioneer Booklet", desc: "Auctioneer-ready roster with consignor, reserve and bidding steps.", cols: ["Lot no.", "Lot title", "Consignor", "Reserve", "Starting bid", "Increment"], rows: booklet },
  { id: "ringman", name: "Ringman Booklet", desc: "Ringman-ready roster with consignor, reserve and bidding steps.", cols: ["Lot no.", "Lot title", "Consignor", "Reserve", "Starting bid", "Increment"], rows: booklet },
  { id: "catalog", name: "Sale Catalog", desc: "Ready-to-share sale catalog with optional imagery for marketing teams.", cols: ["Lot no.", "Lot title", "Starting bid", "Category"], rows: (m) => m.lots.map((l) => [l.no, l.title, mo(m, l.startBid), l.category || D]) },
  { id: "summary", name: "Auction Summary Report", desc: "High-level auction performance metrics spanning lots, bidders and revenue.", cols: [], rows: () => [] },
];
const CUSTOM = "custom";

const dur = (ms: number) => { if (!(ms > 0)) return D; const s = Math.floor(ms / 1000); return `${Math.floor(s / 3600)} hours ${Math.floor((s % 3600) / 60)} minutes ${s % 60} seconds`; };

export function summary(m: Intel): Record<string, [string, Cell][]> {
  const c = (o: Outcome) => m.lots.filter((l) => l.outcome === o).length;
  const sold = soldLots(m), total = sold.reduce((n, l) => n + l.high, 0);
  const bidding = new Set(m.bids.map((b) => b.bidder.no)).size;
  return {
    Items: [["No. of Items", m.lots.length], ["Sold Items", c("SOLD")], ["Sold Online", c("SOLD")], ["No Sale Items", c("NO_SALE")], ["Pending Items", c("PENDING")], ["Still Open", c("OPEN")],
      ["Reserve Not Met", m.lots.filter((l) => l.reserveStatus === "Reserve not met" && l.closed).length]],
    Financials: [["Total Online Sales", mo(m, total)], ["Total Onsite Sales", mo(m, 0)], ["Total Sales", mo(m, total)], ["Total Tax (invoiced)", mo(m, m.invoices.tax)], ["Buyer's Premium (invoiced)", mo(m, m.invoices.fees)],
      ["Consignor Commission", D], ["Auction Revenue (invoiced fees)", mo(m, m.invoices.fees)], ["Invoices Issued / Paid", `${m.invoices.invoices} / ${m.invoices.paid}`]],
    "Bidding Activity": [["Registered Bidders", m.regs.length], ["Approved Bidders", m.regs.filter((r) => r.status === "APPROVED").length], ["Online Bidders Logged In", m.logins.length], ["Bidding Bidders", bidding],
      ["Online Bids", m.bids.length], ["Onsite Bids", 0], ["Pre Bids", m.bids.filter((b) => b.ms < m.startMs).length], ["Auction Duration", dur(m.endMs - m.startMs)]],
  };
}

const th = "px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-zinc-600";
const empty = "rounded-lg border border-dashed border-zinc-300 bg-zinc-50 px-4 py-5 text-center text-[11px] text-zinc-500";

function BidTrajectory({ pts, cur }: { pts: { at: string; amount: number }[]; cur: string }) {
  const w = 600, h = 120, pad2 = 14;
  const max = Math.max(...pts.map((p) => p.amount)), min = Math.min(...pts.map((p) => p.amount));
  const x = (i: number) => (pts.length === 1 ? w / 2 : pad2 + (i * (w - pad2 * 2)) / (pts.length - 1));
  const y = (v: number) => (max === min ? h / 2 : h - pad2 - ((v - min) / (max - min)) * (h - pad2 * 2));
  return (
    <svg viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Bid trajectory" className="h-28 w-full rounded-lg border border-zinc-200 bg-white">
      {pts.length > 1 && <polyline fill="none" stroke="currentColor" strokeWidth="2" className="text-primary" points={pts.map((p, i) => `${x(i)},${y(p.amount)}`).join(" ")} />}
      {pts.map((p, i) => <circle key={i} cx={x(i)} cy={y(p.amount)} r="4" className="fill-primary"><title>{`${p.at} · ${fmtMoney(p.amount, cur)}`}</title></circle>)}
    </svg>
  );
}

function CustomLots({ m }: { m: Intel }) {
  return (
    <div className="space-y-4">
      {m.lots.map((l: LotStat) => {
        const current = l.bids.length ? l.high : l.startBid, savings = current - l.startBid;
        const pct = l.startBid > 0 ? Math.round((savings / l.startBid) * 100) : 0;
        const best = new Map<number, { name: string; no: number; amount: number }>();
        l.bids.forEach((b) => { const c = best.get(b.bidder.no); if (!c || b.amount > c.amount) best.set(b.bidder.no, { name: b.bidder.name, no: b.bidder.no, amount: b.amount }); });
        const ranked = [...best.values()].sort((x, y) => y.amount - x.amount);
        const hist = [...l.bids].reverse();
        return (
          <section key={l.id} className="rounded-xl border border-zinc-200 bg-white">
            <header className="flex flex-wrap items-start justify-between gap-3 border-b border-zinc-100 p-4">
              <div>
                <h3 className="text-lg font-bold">Lot {l.no} · {l.title}</h3>
                <p className="mt-0.5 text-xs text-zinc-600">Wrap-up {when(m, m.endMs)}</p>
                <div className="mt-2 flex flex-wrap gap-1.5 text-[10px]"><span className="rounded border border-zinc-200 px-1.5 py-0.5">{OUT[l.outcome]}</span><span className="rounded border border-zinc-200 px-1.5 py-0.5">{l.bids.length} bids · {l.bidderCount} bidders</span></div>
              </div>
              <div className="flex gap-1.5 text-[9px] font-semibold"><span className="rounded border border-zinc-300 px-1.5 py-0.5">#{l.no}</span><span className="rounded border border-zinc-300 px-1.5 py-0.5">{m.auction.type.toUpperCase()}</span></div>
            </header>
            <div className="space-y-5 p-4">
              <div className="flex flex-wrap gap-2 text-[11px]">
                {([["Starting bid", mo(m, l.startBid)], ["Current price", mo(m, current)], ["Savings", `${mo(m, savings)} (${pct}%)`]] as const).map(([k, v]) => (
                  <span key={k} className="rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1.5"><span className="mr-1.5 text-[9px] font-semibold uppercase tracking-wide text-zinc-500">{k}</span><span className="font-bold">{v}</span></span>
                ))}
              </div>
              <div>
                <h4 className="mb-2 text-xs font-bold">Bidder ranking</h4>
                {ranked.length === 0 ? <p className={empty}>Bidder ranking data will appear once bids are placed.</p> : (
                  <ol className="divide-y divide-zinc-100 rounded-lg border border-zinc-200 text-[11px]">
                    {ranked.map((b, r) => <li key={b.no} className="flex items-center justify-between px-3 py-2"><span><span className="mr-2 font-bold">#{r + 1}</span>Bidder {b.no} · {b.name}</span><span className="font-semibold">{mo(m, b.amount)}</span></li>)}
                  </ol>
                )}
              </div>
              <div>
                <h4 className="mb-2 text-xs font-bold">Bidding history</h4>
                {hist.length === 0 ? <p className={empty}>Once bidding starts, history will appear here automatically.</p> : (
                  <div className="overflow-x-auto rounded-lg border border-zinc-200">
                    <table className="w-full min-w-[320px] text-left text-[11px]">
                      <thead className="border-b border-zinc-200"><tr><th className={th}>Date time</th><th className={th}>Bidder no.</th><th className={th}>Bid amount</th></tr></thead>
                      <tbody className="divide-y divide-zinc-100">{hist.map((b) => <tr key={b.id}><td className="px-3 py-2">{when(m, b.ms)}</td><td className="px-3 py-2">{b.bidder.no}</td><td className="px-3 py-2 font-semibold">{mo(m, b.amount)}</td></tr>)}</tbody>
                    </table>
                  </div>
                )}
              </div>
              <div>
                <h4 className="mb-2 text-xs font-bold">Bid trajectories</h4>
                {l.bids.length === 0 ? <p className={empty}>Chart visualisation becomes available when bidders place at least one bid.</p> : <BidTrajectory cur={m.currency} pts={l.bids.map((b) => ({ at: when(m, b.ms), amount: b.amount }))} />}
              </div>
            </div>
          </section>
        );
      })}
      <p className="text-[11px] text-zinc-500">Showing {m.lots.length} {m.lots.length === 1 ? "lot" : "lots"} from this auction's bid records.</p>
    </div>
  );
}

function exportXlsx(m: Intel, report: Report | undefined, sel: string) {
  const a = m.auction, file = (n: string) => `${a.title}-${n}.xlsx`.replace(/[^\w.-]+/g, "-");
  if (sel === "summary") {
    const rows: XCell[][] = [["Section", "Metric", "Value"]];
    Object.entries(summary(m)).forEach(([s, list]) => list.forEach(([k, v]) => rows.push([s, k, v])));
    return downloadBlob(buildXlsx([{ name: "Summary", rows }]), file("Auction-Summary"));
  }
  if (sel === CUSTOM) {
    const lots: XCell[][] = [["Lot #", "Lot title", "Status", "Starting bid", "Reserve", "High bid", "Bids", "Bidders", "Winning bidder no."]];
    m.lots.forEach((l) => lots.push([l.no, l.title, OUT[l.outcome], l.startBid, l.reserve, l.bids.length ? l.high : 0, l.bids.length, l.bidderCount, l.winner?.no ?? ""]));
    const bids: XCell[][] = [["Date time", "Lot #", "Lot title", "Bidder no.", "Bidder", "Amount"]];
    m.bids.forEach((b) => bids.push([when(m, b.ms), b.lotNo, b.lotTitle, b.bidder.no, b.bidder.name, b.amount]));
    return downloadBlob(buildXlsx([{ name: "Lots", rows: lots }, { name: "Bids", rows: bids }]), file("Custom-Report"));
  }
  if (!report) return;
  downloadBlob(buildXlsx([{ name: report.name, rows: [report.cols, ...report.rows(m)] }]), file(report.name));
}

function ReportsWorkspaceInner({ id }: { id: string }) {
  const a = lookupAuction(id);
  const { m, err, busy, reload } = useIntel(a);
  const [sel, setSel] = useState<string>(REPORTS[0].id);
  const [img, setImg] = useState(true);
  if (!a) return <NotFound />;

  const report = REPORTS.find((r) => r.id === sel);
  const rows = m && report ? report.rows(m) : [];
  const isSummary = sel === "summary", isCustom = sel === CUSTOM, isCatalog = sel === "catalog";
  const rowCount = !m ? 0 : isCustom ? m.bids.length : isSummary ? m.lots.length : rows.length;
  const showCols = isCatalog && img ? [...(report?.cols ?? []), "Image"] : report?.cols ?? [];

  return (
    <IntelFrame a={a} label="Reports workspace" title="Reports" sub={`${a.lots} lots · ${m ? `${m.bids.length} bids · ${m.bidders.length} bidders` : "…"}`} reload={reload} busy={busy}
      actions={<><Btn variant="ghost" className="h-8 text-xs" onClick={() => window.print()}><Printer className="size-3.5" />PDF</Btn>
        <Btn variant="solid" className="h-8 bg-ink text-xs hover:bg-ink/90" disabled={!m} onClick={() => m && exportXlsx(m, report, sel)}><Download className="size-3.5" />Excel</Btn></>}>
      <div className="grid gap-4 md:grid-cols-[260px_1fr]">
        <Card className="self-start p-3 print:hidden">
          <p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Report library</p>
          <h2 className="text-sm font-bold">Insights catalogue</h2>
          <p className="mb-3 text-[11px] text-zinc-500">Browse all reporting lenses. Select one to render metrics on the right.</p>
          <ul className="max-h-[330px] space-y-1 overflow-y-auto pr-1" role="listbox" aria-label="Reports">
            {REPORTS.map((r) => (
              <li key={r.id} role="option" aria-selected={sel === r.id}>
                <button onClick={() => setSel(r.id)} className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-[11px] ${sel === r.id ? "border-ink font-semibold" : "border-transparent text-zinc-800 hover:bg-zinc-50"}`}>
                  {r.name}{sel === r.id ? <CheckCircle2 className="size-3.5 text-sky-500" /> : <span className="text-[9px] font-semibold tracking-wide text-zinc-300">VIEW</span>}
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-2 border-t border-zinc-200 pt-2">
            <button onClick={() => setSel(CUSTOM)} className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-[11px] ${isCustom ? "border-ink font-semibold" : "border-transparent hover:bg-zinc-50"}`}>
              Generate Custom Report{isCustom ? <CheckCircle2 className="size-3.5 text-sky-500" /> : <Sparkles className="size-3.5 text-amber-500" />}
            </button>
          </div>
        </Card>

        <div className="min-w-0 space-y-4">
          <LoadNote busy={busy} err={err} />
          {m && (
            <Card className="p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Current view</p>
              <h2 className="mt-1 flex items-center gap-2 text-lg font-bold">{isCustom ? "Custom report" : report!.name}
                {isCustom ? <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[10px] font-semibold text-sky-700">Custom</span> : <span className="rounded bg-zinc-100 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-600">{rowCount} rows</span>}</h2>
              <p className="mt-1 text-[11px] text-zinc-600">{isCustom ? "Every lot with its bids, ranking and trajectory. Excel exports the lot table and all bids." : report!.desc}</p>

              {isSummary ? (
                <div className="mt-4 grid gap-3 lg:grid-cols-3">
                  {Object.entries(summary(m)).map(([title, list]) => (
                    <section key={title} className="rounded-lg border border-zinc-200 p-3">
                      <h3 className="mb-3 flex items-center gap-1.5 text-xs font-bold"><Sparkles className="size-3 text-amber-500" />{title}</h3>
                      <dl className="space-y-2 text-[10px]">{list.map(([k, v]) => <div key={k} className="flex justify-between gap-3"><dt className="text-zinc-600">{k}</dt><dd className="text-right font-semibold">{v}</dd></div>)}</dl>
                    </section>
                  ))}
                  <p className="text-[10px] text-zinc-500 lg:col-span-3">Sales are the winning bids on sold lots. Tax and fees come from the invoices issued for this auction, so they grow as invoices are created.</p>
                </div>
              ) : isCustom ? (
                <div className="mt-4">
                  <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
                    {([["Lots tracked", m.lots.length], ["Bidders ranked", new Set(m.bids.map((b) => b.bidder.no)).size], ["Bids captured", m.bids.length], ["Currency", m.currency]] as const).map(([l, v]) => <div key={l} className="rounded-lg border border-zinc-200 p-3"><p className="text-[9px] font-bold uppercase tracking-wide text-zinc-500">{l}</p><p className="mt-1 text-lg font-bold">{v}</p></div>)}
                  </div>
                  <div className="mt-4 grid gap-3 md:grid-cols-[1.3fr_1fr]">
                    <div className="h-48 overflow-hidden rounded-lg">{a.images?.[0] ? <img src={a.images[0].url} alt="" className="h-full w-full object-cover" /> : <PlaceholderImage tone={Number(a.id) || 1} className="h-full w-full [&_svg]:size-16" />}</div>
                    <div className="rounded-lg border border-zinc-200 p-3 text-xs"><p className="mb-2 text-[9px] font-bold uppercase tracking-wide text-zinc-500">Timeline</p>
                      <dl className="space-y-1.5">{([["Starts", m.startMs], ["Ends", m.endMs]] as const).map(([k, ms]) => <div key={k} className="flex justify-between gap-3"><dt className="text-zinc-600">{k}</dt><dd className="font-semibold">{when(m, ms)}</dd></div>)}</dl></div>
                  </div>
                </div>
              ) : (
                <>
                  {isCatalog && (
                    <div className="mt-3 flex items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2 text-[11px]"><ImageIcon className="size-3.5 text-zinc-500" />Show catalog imagery
                      <span role="group" aria-label="Show catalog imagery" className="flex overflow-hidden rounded border border-zinc-300">
                        {([[true, "Yes"], [false, "No"]] as const).map(([v, l]) => <button key={l} aria-pressed={img === v} onClick={() => setImg(v)} className={`px-2 py-0.5 text-[10px] font-semibold ${img === v ? "bg-ink text-white" : "bg-white text-primary"}`}>{l}</button>)}
                      </span></div>
                  )}
                  {rows.length === 0 ? (
                    <p className="mt-4 rounded-lg border border-zinc-200 bg-zinc-50 px-4 py-8 text-center text-xs text-zinc-500">{report!.note ?? "No data available for this report yet."}</p>
                  ) : (
                    <div className="mt-3 overflow-x-auto rounded-lg border border-zinc-200">
                      <table className="w-full min-w-[480px] text-left text-[11px]">
                        <thead className="border-b border-zinc-200"><tr>{showCols.map((c) => <th key={c} className={th}>{c}</th>)}</tr></thead>
                        <tbody className="divide-y divide-zinc-100">
                          {rows.map((r, i) => (
                            <tr key={i}>{r.map((c, j) => <td key={j} className={`px-3 py-2.5 ${j === 2 && sel === "bidding-transcripts" ? "font-semibold" : ""}`}>{c}</td>)}
                              {isCatalog && img && <td className="px-3 py-2"><div className="h-8 w-14 overflow-hidden rounded">{m.lots[i]?.image ? <img src={m.lots[i].image} alt="" className="h-full w-full object-cover" /> : <PlaceholderImage tone={i + 1} className="h-full w-full [&_svg]:size-5" />}</div></td>}</tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}
            </Card>
          )}
          {m && isCustom && <CustomLots m={m} />}
        </div>
      </div>
      <p className="mt-3 text-[10px] text-zinc-500">Bidder numbers follow registration order in this auction. Times are shown in the auction time zone ({m?.tz ?? a.tz}).</p>
    </IntelFrame>
  );
}

export const ReportsWorkspace = (p: { id: string }) => <StudioGate><ReportsWorkspaceInner {...p} /></StudioGate>;

