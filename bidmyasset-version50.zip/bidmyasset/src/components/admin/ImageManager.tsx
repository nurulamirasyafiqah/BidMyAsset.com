"use client";

import { useRef, useState } from "react";
import { ImageIcon, Star, Trash2, Upload } from "lucide-react";
import { useConfirm } from "@/components/admin/ui";
import type { Img } from "@/lib/admin";
import { imageProblem, reorderImages, studio, uploadImages } from "@/lib/studioApi";

/**
 * Upload / view / delete / reorder photos of an auction (cover images) or a lot. Stored in PocketBase
 * (collection auctions|lots, field images) and shown on the public site. The first image is the cover / main photo.
 */
export function ImageManager({ kind, id, images, max, onChange }: { kind: "auction" | "lot"; id: string; images: Img[]; max: number; onChange: (i: Img[]) => void }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const { confirm, dialog } = useConfirm();

  const run = async (fn: () => Promise<Img[]>) => {
    setBusy(true); setErr("");
    try { onChange(await fn()); } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong"); } finally { setBusy(false); }
  };
  const add = (list: FileList | null) => {
    const files = Array.from(list ?? []);
    if (input.current) input.current.value = "";
    if (!files.length) return;
    const bad = files.map(imageProblem).find(Boolean);
    if (bad) return setErr(bad);
    if (images.length + files.length > max) return setErr(`You can keep up to ${max} images (you have ${images.length}).`);
    void run(() => uploadImages(kind, id, files));
  };
  const remove = async (i: Img) => { if (await confirm({ title: "Delete this image?", body: "It will also disappear from the public site.", confirmLabel: "Delete" })) void run(() => uploadImages(kind, id, [], [i.name])); };
  const makeCover = (i: Img) => void run(() => reorderImages(kind, id, [i.name, ...images.filter((x) => x.name !== i.name).map((x) => x.name)]));

  return (
    <div>
      {!studio.live && <p role="alert" className="mb-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-800">The backend is unreachable, so uploads can’t be saved. Start the backend and reload.</p>}
      <p className="text-[11px] text-zinc-500">JPG, PNG or WebP, up to 10 MB each, max {max} images. The first image is the {kind === "lot" ? "main photo" : "cover"} shown on the website.</p>
      <label className={`mt-2 inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-primary/40 px-3 text-xs font-semibold text-primary hover:bg-primary/5 ${busy ? "pointer-events-none opacity-60" : ""}`}>
        <Upload className="size-3.5" />{busy ? "Working…" : "Upload images"}
        <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" multiple className="sr-only" disabled={busy} onChange={(e) => add(e.target.files)} />
      </label>
      {err && <p role="alert" className="mt-2 text-[11px] text-rose-600">{err}</p>}
      {images.length === 0 ? (
        <p className="mt-3 flex items-center gap-2 text-[11px] text-zinc-500"><ImageIcon className="size-4" />No images uploaded yet.</p>
      ) : (
        <ul className="mt-3 flex flex-wrap gap-2">
          {images.map((i, n) => (
            <li key={i.name} className="relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={i.url} alt={`Image ${n + 1}`} className="h-24 w-36 rounded-md border border-zinc-200 object-cover" />
              {n === 0 && <span className="absolute left-1 top-1 rounded bg-primary px-1.5 py-0.5 text-[9px] font-bold text-white">{kind === "lot" ? "MAIN" : "COVER"}</span>}
              <div className="absolute right-1 top-1 flex gap-1">
                {n > 0 && <button type="button" aria-label="Make cover" title="Make this the first image" disabled={busy} onClick={() => makeCover(i)} className="grid size-6 place-items-center rounded-full bg-white/90 text-amber-600 shadow hover:bg-white"><Star className="size-3" /></button>}
                <button type="button" aria-label="Delete image" disabled={busy} onClick={() => remove(i)} className="grid size-6 place-items-center rounded-full bg-white/90 text-rose-600 shadow hover:bg-white"><Trash2 className="size-3" /></button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {dialog}
    </div>
  );
}
