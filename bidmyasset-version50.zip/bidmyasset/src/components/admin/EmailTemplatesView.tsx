"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { loadCompany, saveCompany } from "@/lib/companyClient";
import { Mail, RefreshCw, Save, Search, Send } from "lucide-react";
import { Badge, Btn, Card, Field, inputCls, Modal, Toggle, useConfirm } from "@/components/admin/ui";
import { defaultTemplates, renderPreview, unknownVariables, type EmailTemplate } from "@/lib/emailTemplates";

const byKey = (list: EmailTemplate[]) => Object.fromEntries(list.map((t) => [t.key, t])) as Record<string, EmailTemplate>;
const same = (a: EmailTemplate, b: EmailTemplate) => a.subject === b.subject && a.body === b.body && a.enabled === b.enabled;

export function EmailTemplatesView() {
  const { confirm, dialog } = useConfirm();
  const [saved, setSaved] = useState(() => byKey(defaultTemplates));
  const [draft, setDraft] = useState(() => byKey(defaultTemplates));
  const [activeKey, setActiveKey] = useState(defaultTemplates[0].key);
  const [q, setQ] = useState("");
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [testTo, setTestTo] = useState("");
  const [notice, setNotice] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [confirmAll, setConfirmAll] = useState(false);
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  // saved templates come from the company record; anything never edited keeps its default
  const merge = (over: Record<string, Partial<EmailTemplate>> | null | undefined) =>
    byKey(defaultTemplates.map((d) => ({ ...d, ...(over?.[d.key] ? { subject: over[d.key].subject ?? d.subject, body: over[d.key].body ?? d.body, enabled: over[d.key].enabled ?? d.enabled } : {}) })));
  useEffect(() => {
    loadCompany()
      .then((d) => { const m = merge(d.emailTemplates as Record<string, Partial<EmailTemplate>> | null); setSaved(m); setDraft(m); })
      .catch((e) => setNotice({ tone: "err", text: e instanceof Error ? e.message : "Could not load templates." }))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const payload = (m: Record<string, EmailTemplate>) => Object.fromEntries(defaultTemplates.map((d) => [d.key, { subject: m[d.key].subject, body: m[d.key].body, enabled: m[d.key].enabled }]));

  const t = draft[activeKey];
  const list = useMemo(
    () => defaultTemplates.filter((d) => `${d.name} ${d.key}`.toLowerCase().includes(q.toLowerCase())),
    [q],
  );

  const problems = (x: EmailTemplate) => unknownVariables(`${x.subject}\n${x.body}`, x.variables);
  const dirtyKeys = defaultTemplates.filter((d) => !same(draft[d.key], saved[d.key])).map((d) => d.key);
  const badKeys = dirtyKeys.filter((k) => problems(draft[k]).length > 0);
  const bad = problems(t);

  const patch = (p: Partial<EmailTemplate>, key = activeKey) => {
    setNotice(null);
    setDraft((d) => ({ ...d, [key]: { ...d[key], ...p } }));
  };
  const resetOne = async () => { if (!(await confirm({ title: "Reset this template?", body: "Your changes to the subject and body will be replaced with the default.", confirmLabel: "Reset template" }))) return; patch({ subject: defaultTemplates.find((d) => d.key === activeKey)!.subject, body: defaultTemplates.find((d) => d.key === activeKey)!.body }); };
  const resetAll = async () => {
    setConfirmAll(false); setBusy(true);
    try { await saveCompany({ emailTemplates: payload(byKey(defaultTemplates)) }); setDraft(byKey(defaultTemplates)); setSaved(byKey(defaultTemplates)); setNotice({ tone: "ok", text: "All templates reset to defaults." }); }
    catch (e) { setNotice({ tone: "err", text: e instanceof Error ? e.message : "Could not reset templates." }); }
    finally { setBusy(false); }
  };
  const save = async () => {
    setBusy(true);
    try {
      const doc = await saveCompany({ emailTemplates: payload(draft) });
      const m = merge(doc.emailTemplates as Record<string, Partial<EmailTemplate>> | null); // body comes back sanitized by the server
      setSaved(m); setDraft(m);
      setNotice({ tone: "ok", text: `Saved ${dirtyKeys.length} template${dirtyKeys.length === 1 ? "" : "s"}.` });
    } catch (e) { setNotice({ tone: "err", text: e instanceof Error ? e.message : "Could not save templates." }); }
    finally { setBusy(false); }
  };
  const insertVar = (v: string) => {
    const el = bodyRef.current;
    const tag = `{{${v}}}`;
    if (!el) return patch({ body: t.body + tag });
    const [s, e] = [el.selectionStart, el.selectionEnd];
    patch({ body: t.body.slice(0, s) + tag + t.body.slice(e) });
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(s + tag.length, s + tag.length); });
  };
  const sendTest = async () => {
    if (!/^\S+@\S+\.\S+$/.test(testTo)) return setNotice({ tone: "err", text: "Enter a valid email address to send a test." });
    try {
      const res = await fetch("/api/admin/house/smtp-test", { method: "POST", headers: { "Content-Type": "application/json" }, cache: "no-store",
        body: JSON.stringify({ to: testTo, subject: `[Test] ${renderPreview(t.subject)}`, html: renderPreview(t.body) }) });
      const j = (await res.json().catch(() => ({}))) as { message?: string };
      setNotice(res.ok ? { tone: "ok", text: `Test email sent to ${testTo}.` } : { tone: "err", text: j.message || `Could not send the test (${res.status}).` });
    } catch { setNotice({ tone: "err", text: "Could not reach the server." }); }
  };

  const canSave = dirtyKeys.length > 0 && badKeys.length === 0 && !busy && !loading;

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-100 bg-zinc-50 px-5 py-4">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-lg bg-primary text-white"><Mail className="size-5" /></span>
          <div>
            <h2 className="text-base font-bold">Email templates</h2>
            <p className="text-xs text-zinc-500">Customize automated communications for your auction house.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Btn className="h-8 text-xs" onClick={() => setConfirmAll(true)}><RefreshCw className="size-3.5" />Reset all</Btn>
          <Btn variant="solid" className="h-8 text-xs" disabled={!canSave} onClick={save}><Save className="size-3.5" />Save changes{dirtyKeys.length > 0 && ` (${dirtyKeys.length})`}</Btn>
        </div>
      </div>

      {notice && (
        <p role="status" className={`border-b px-5 py-2 text-xs ${notice.tone === "ok" ? "border-emerald-100 bg-emerald-50 text-emerald-700" : "border-rose-100 bg-rose-50 text-rose-600"}`}>{notice.text}</p>
      )}
      {badKeys.length > 0 && (
        <p role="alert" className="border-b border-amber-200 bg-amber-50 px-5 py-2 text-xs text-amber-800">
          Can’t save yet: {badKeys.length} edited template{badKeys.length === 1 ? " uses" : "s use"} variables that don’t exist. Fix them or reset the template.
        </p>
      )}

      <div className="grid md:grid-cols-[300px_1fr]">
        <div className="border-b border-zinc-100 p-3 md:border-b-0 md:border-r">
          <label className="relative mb-2 block">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-zinc-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search templates" aria-label="Search templates"
              className="h-8 w-full rounded-md border border-zinc-300 pl-8 pr-2 text-xs focus:border-primary focus:outline-none" />
          </label>
          <ul className="max-h-[640px] overflow-y-auto">
            {list.length === 0 && <li className="py-6 text-center text-xs text-zinc-500">No templates match “{q}”.</li>}
            {list.map((d) => {
              const x = draft[d.key];
              const edited = dirtyKeys.includes(d.key);
              return (
                <li key={d.key} className={`flex items-start gap-2 border-l-2 px-3 py-2.5 ${activeKey === d.key ? "border-primary bg-zinc-100" : "border-transparent hover:bg-zinc-50"}`}>
                  <button className="min-w-0 flex-1 text-left" onClick={() => setActiveKey(d.key)} aria-current={activeKey === d.key}>
                    <span className="block truncate text-xs font-semibold">{d.name}{edited && <span className="ml-1 text-amber-600" title="Unsaved changes">•</span>}</span>
                    <span className="block truncate font-mono text-[10px] text-zinc-500">{d.key}</span>
                    <span className="block text-[10px] text-zinc-500">{d.scope}</span>
                  </button>
                  <Toggle on={x.enabled} onChange={(v) => patch({ enabled: v }, d.key)} label={`Enable ${d.name}`} />
                </li>
              );
            })}
          </ul>
        </div>

        <div className="p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <h3 className="text-sm font-bold">{t.name}</h3>
              <p className="mt-0.5 text-xs text-zinc-500">{t.description}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={t.enabled ? "blue" : "zinc"}>{t.enabled ? "Enabled" : "Disabled"}</Badge>
              <Btn className="h-7 px-3 text-[11px]" onClick={resetOne}><RefreshCw className="size-3" />Reset template</Btn>
            </div>
          </div>

          <div className="mt-4 space-y-4">
            <Field label="Subject">
              <input className={inputCls} value={t.subject} onChange={(e) => patch({ subject: e.target.value })} />
            </Field>

            <div>
              <div className="mb-1 flex items-center justify-between">
                <span className="text-xs font-semibold text-zinc-700">Email body</span>
                <div role="tablist" className="flex rounded-md border border-zinc-200 text-[11px] font-semibold">
                  {(["edit", "preview"] as const).map((m) => (
                    <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)}
                      className={`px-3 py-1 first:rounded-l-md last:rounded-r-md ${mode === m ? "bg-primary text-white" : "text-zinc-600 hover:bg-zinc-50"}`}>{m === "edit" ? "HTML" : "Preview"}</button>
                  ))}
                </div>
              </div>
              {mode === "edit" ? (
                <textarea ref={bodyRef} value={t.body} onChange={(e) => patch({ body: e.target.value })} spellCheck={false} aria-label="Email body HTML"
                  className="h-64 w-full resize-y rounded-md border border-zinc-300 p-3 font-mono text-[11px] leading-relaxed focus:border-primary focus:outline-none" />
              ) : (
                <div className="rounded-md border border-zinc-300">
                  <p className="border-b border-zinc-200 bg-zinc-50 px-3 py-2 text-xs"><span className="text-zinc-500">Subject: </span>{renderPreview(t.subject)}</p>
                  {/* sandbox="" → no scripts, no same-origin: template HTML can't touch the admin page */}
                  <iframe title="Email preview" sandbox="" srcDoc={`<body style="font:14px/1.5 Arial,sans-serif;margin:16px">${renderPreview(t.body)}</body>`} className="h-64 w-full bg-white" />
                </div>
              )}
              {bad.length > 0 && (
                <p role="alert" className="mt-1.5 text-xs text-rose-600">
                  Unknown variable{bad.length > 1 ? "s" : ""}: {bad.map((v) => `{{${v}}}`).join(", ")}. Use only the variables listed below.
                </p>
              )}
            </div>
          </div>

          <div className="mt-5 grid gap-5 border-t border-zinc-100 pt-4 lg:grid-cols-[1fr_300px]">
            <div>
              <p className="text-xs font-semibold text-zinc-700">Available variables</p>
              <p className="mb-2 text-[11px] text-zinc-500">Click to insert at the cursor in the body.</p>
              <div className="flex flex-wrap gap-1.5">
                {t.variables.map((v) => (
                  <button key={v} onClick={() => { setMode("edit"); insertVar(v); }} className="rounded bg-zinc-100 px-2 py-1 font-mono text-[10px] text-zinc-700 hover:bg-zinc-200">{v}</button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-zinc-700">Send test email</p>
              <div className="mt-1.5 flex gap-2">
                <input type="email" value={testTo} onChange={(e) => setTestTo(e.target.value)} placeholder="name@example.com" aria-label="Test email address" className={inputCls} />
                <Btn className="h-9 shrink-0" onClick={sendTest}><Send className="size-3.5" />Send</Btn>
              </div>
              <p className="mt-1.5 text-[11px] text-zinc-500">Sends this template with sample content to check styling and formatting.</p>
            </div>
          </div>
        </div>
      </div>

      {confirmAll && (
        <Modal title="Reset all templates?" sub="Every template returns to its default subject, body and on/off state. Unsaved and saved edits are lost."
          onClose={() => setConfirmAll(false)}
          footer={<><Btn variant="ghost" onClick={() => setConfirmAll(false)}>Cancel</Btn><Btn variant="solid" onClick={resetAll}>Reset all</Btn></>}>
          <p className="text-xs text-zinc-600">This can’t be undone.</p>
        </Modal>
      )}
      {dialog}
    </Card>
  );
}
