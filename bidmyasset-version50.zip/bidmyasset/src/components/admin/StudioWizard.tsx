"use client";

import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, ImagePlus } from "lucide-react";
import { Btn, Choice, Field, inputCls, Toggle } from "@/components/admin/ui";
import { Overlay } from "@/components/admin/StudioParts";
import type { StudioAuction } from "@/lib/admin";
import { createAuction, imageProblem, studio } from "@/lib/studioApi";

const STEPS = [
  ["Auction basics", "Name, company, timezone, and currency details."],
  ["Schedule & type", "Set the opening/closing times and auction type."],
  ["Media & summary", "Add a cover image and a short auction description."],
  ["Bid settings & review", "Confirm bidder workflow and review the details."],
] as const;
const TIMES = Array.from({ length: 48 }, (_, i) => { const h = Math.floor(i / 2), m = i % 2 ? "30" : "00"; return `${((h + 11) % 12) + 1}:${m} ${h < 12 ? "AM" : "PM"}`; });
const TYPES = [["Reserve", "Winning bids must meet the reserve price"], ["Absolute", "Highest bid wins, no reserve"], ["Subject to Confirmation", "Winning bids require seller approval before becoming binding sales."]] as const;
const toDMY = (iso: string) => (iso ? iso.split("-").reverse().join("/") : "—");
const longDate = (iso: string, t: string) => iso ? `${new Date(iso + "T00:00:00").toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })} at ${t}` : "—";

export function AddAuctionWizard({ onClose, onCreate }: { onClose: () => void; onCreate: (a: StudioAuction) => void }) {
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ title: "", company: "BidMyAsset Group", tz: "Malaysia (MYT)", currency: "US Dollar (USD)", sd: "", st: "4:00 PM", ed: "", et: "5:00 PM", stagger: false, type: "Subject to Confirmation", desc: "", approval: "auto" as "auto" | "manual", hide: false });
  const [covers, setCovers] = useState<File[]>([]);
  const coverUrls = useMemo(() => covers.map((c) => URL.createObjectURL(c)), [covers]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));

  const errors = [
    !f.title.trim() ? "Enter an auction title." : "",
    !f.sd ? "Pick a start date." : !f.ed ? "Pick an end date." : f.ed < f.sd ? "End date can’t be before the start date." : "",
    "", "",
  ];
  const next = ["Schedule & type", "Media & summary", "Bid settings & review"];
  const canNext = !errors[step];

  const create = async () => {
    setErr("");
    if (studio.live) { // real draft auction + cover images stored in PocketBase (publish it from the auction page)
      setBusy(true);
      try { onCreate(await createAuction({ title: f.title.trim(), tz: f.tz, currency: f.currency, sd: f.sd, st: f.st, ed: f.ed, et: f.et, type: f.type, desc: f.desc, approval: f.approval, hide: f.hide, stagger: f.stagger }, covers)); }
      catch (e) { setErr(e instanceof Error ? e.message : "Could not create the auction"); }
      finally { setBusy(false); }
      return;
    }
    onCreate({ id: String(1200 + Math.floor(Math.random() * 800)), title: f.title.trim(), company: f.company, code: crypto.randomUUID(), status: "DRAFT", lots: 0, active: 0,
      starts: `${toDMY(f.sd)} ${f.st}`, ends: toDMY(f.ed), type: "Timed", tz: f.tz, currency: f.currency, auctionType: f.type, description: f.desc, approval: f.approval, hideBidders: f.hide, stagger: f.stagger });
  };

  return (
    <Overlay title="Add auction" sub="Follow the guided steps to build a new auction." onClose={onClose}>
      <div className="grid h-full grid-cols-1 md:grid-cols-[300px_1fr]">
        <aside className="hidden overflow-y-auto border-r border-zinc-200 bg-zinc-50 p-4 md:block">
          <ol className="space-y-1">
            {STEPS.map(([t, s], i) => (
              <li key={t}>
                <button disabled={i > step} onClick={() => setStep(i)} aria-current={i === step ? "step" : undefined}
                  className={`flex w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left ${i === step ? "border-sky-300 bg-white shadow-sm" : "border-transparent"} ${i > step ? "opacity-50" : ""}`}>
                  <span className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-full text-[10px] font-bold ${i <= step ? "bg-sky-500 text-white" : "border border-zinc-300 text-zinc-400"}`}>{i < step ? <Check className="size-3" /> : i + 1}</span>
                  <span><span className="block text-xs font-semibold">{t}</span><span className="block text-[11px] text-zinc-500">{s}</span></span>
                </button>
              </li>
            ))}
          </ol>
        </aside>

        <div className="flex min-h-0 flex-col">
          <div className="flex-1 overflow-y-auto px-6 py-6">
            <div className="mx-auto max-w-xl">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-500">Step {step + 1} of 4</p>
              <h1 className="text-[26px] font-bold">{STEPS[step][0]}</h1>
              <p className="mb-5 text-sm text-zinc-500">{STEPS[step][1]}</p>

              {step === 0 && (
                <div className="space-y-4">
                  <div><Field label="Auction title *"><input className={inputCls} placeholder="e.g. Fall Antique Auction" value={f.title} onChange={(e) => set("title", e.target.value)} autoFocus /></Field>
                    <p className="mt-1 text-[11px] text-zinc-500">Bidders will see this title on landing pages, catalog emails, and dashboards.</p></div>
                  <div><Field label="Company *"><select className={inputCls} value={f.company} onChange={(e) => set("company", e.target.value)}><option>BidMyAsset Group</option></select></Field>
                    <p className="mt-1 text-[11px] text-zinc-500">The selected company controls branding, billing defaults, and contacts for this auction.</p></div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Timezone *"><select className={inputCls} value={f.tz} onChange={(e) => set("tz", e.target.value)}><option>Malaysia (MYT)</option><option>Singapore (SGT)</option><option>Thailand (ICT)</option></select></Field>
                    <Field label="Currency"><select className={inputCls} value={f.currency} onChange={(e) => set("currency", e.target.value)}><option>US Dollar (USD)</option><option>Malaysian Ringgit (MYR)</option><option>Singapore Dollar (SGD)</option></select></Field>
                  </div>
                  <p className="text-[11px] text-zinc-500">These defaults apply to all lots created during the builder workflow.</p>
                </div>
              )}

              {step === 1 && (
                <div className="space-y-5">
                  {([["Auction opening", "Set the date and time bidders can begin placing offers. This applies to all lots in the auction.", "Start date *", "Start time *", "sd", "st"],
                    ["Auction closing", "Define when bidding stops. Staggered closing rules and anti-snipe settings can be managed later in the builder.", "End date *", "End time *", "ed", "et"]] as const).map(([h, d, dl, tl, dk, tk]) => (
                    <section key={h} className="rounded-xl border border-zinc-200 p-4">
                      <div className="flex items-start justify-between gap-3"><div><h3 className="text-sm font-bold">{h}</h3><p className="text-[11px] text-zinc-500">{d}</p></div><span className="shrink-0 rounded border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-[10px] text-zinc-600">Times use {f.tz}</span></div>
                      <div className="mt-3 grid gap-3 sm:grid-cols-2">
                        <Field label={dl}><input type="date" className={inputCls} value={f[dk]} min={dk === "ed" ? f.sd || undefined : undefined} onChange={(e) => set(dk, e.target.value)} /></Field>
                        <Field label={tl}><select className={inputCls} value={f[tk]} onChange={(e) => set(tk, e.target.value)}>{TIMES.map((t) => <option key={t}>{t}</option>)}</select></Field>
                      </div>
                      {dk === "ed" && (
                        <div className="mt-3 flex items-center justify-between rounded-lg bg-zinc-50 px-3 py-2.5"><div><p className="text-xs font-semibold">Lot staggering</p><p className="text-[11px] text-zinc-500">Offset each lot’s end time from the auction close using a shared gap.</p></div>
                          <Toggle on={f.stagger} onChange={(v) => set("stagger", v)} label="Lot staggering" /></div>
                      )}
                    </section>
                  ))}
                  <div><Field label="Auction type *"><select className={inputCls} value={f.type} onChange={(e) => set("type", e.target.value)}>{TYPES.map(([t]) => <option key={t}>{t}</option>)}</select></Field>
                    <p className="mt-1 text-[11px] text-zinc-500">{TYPES.find(([t]) => t === f.type)![1]}</p></div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div><Field label="Auction description"><textarea rows={6} className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none" placeholder="Tell bidders what makes this auction special." value={f.desc} onChange={(e) => set("desc", e.target.value)} /></Field>
                    <p className="mt-1 text-[11px] text-zinc-500">Share logistics, previews, or highlights. You can expand on this later from the builder.</p></div>
                  <div><p className="mb-1 text-xs font-semibold text-zinc-700">Cover images</p>
                    <div className="grid place-items-center gap-2 rounded-xl border border-dashed border-zinc-300 p-6 text-center">
                      {coverUrls.length ? <div className="flex flex-wrap justify-center gap-2">{/* eslint-disable-next-line @next/next/no-img-element */ coverUrls.map((u, i) => <img key={u} src={u} alt={`Cover preview ${i + 1}`} className="h-24 w-36 rounded-md object-cover" />)}</div> : <ImagePlus className="size-6 text-zinc-300" />}
                      <p className="text-[11px] text-zinc-500">JPG, PNG or WebP, up to 10 MB each (max 10). The first image is the cover. You can change them later in the builder.</p>
                      <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-primary/40 px-3 text-xs font-semibold text-primary hover:bg-primary/5">
                        Choose images<input type="file" accept="image/png,image/jpeg,image/webp" multiple className="sr-only" onChange={(e) => {
                          const files = Array.from(e.target.files ?? []).slice(0, 10); e.target.value = "";
                          const bad = files.map(imageProblem).find(Boolean);
                          if (bad) return setErr(bad);
                          setErr(""); setCovers(files);
                        }} /></label>
                      {covers.length > 0 && <button type="button" className="text-[11px] font-semibold text-zinc-600 hover:underline" onClick={() => setCovers([])}>Remove all</button>}
                    </div></div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div><p className="text-xs font-semibold">Bidder approval workflow</p><p className="mb-2 text-[11px] text-zinc-500">Choose how bidders are approved to participate in this auction.</p>
                    <div className="space-y-2">
                      <Choice active={f.approval === "auto"} title="Auto approval" sub="Bidders are automatically approved and can start bidding immediately." onClick={() => set("approval", "auto")} />
                      <Choice active={f.approval === "manual"} title="Manual approval" sub="Review and approve each bidder before they can participate in this auction." onClick={() => set("approval", "manual")} />
                    </div>
                    <label className="mt-3 flex items-center gap-2 rounded-lg border border-zinc-200 px-3 py-2 text-xs"><input type="checkbox" checked={f.hide} onChange={(e) => set("hide", e.target.checked)} />Hide bidder details from other bidders</label>
                    <p className="mt-2 text-[11px] text-zinc-500">You can adjust bidder workflows later from the auction builder if requirements change.</p></div>
                  <section className="rounded-xl border border-zinc-200 bg-zinc-50 p-4 text-xs">
                    <p className="mb-2 text-[10px] font-bold uppercase tracking-wide text-zinc-500">Summary</p>
                    <dl className="grid gap-2">
                      {([["Title", f.title || "—"], ["Format", "Timed online"], ["Auction type", f.type], ["Timezone", f.tz], ["Currency", f.currency], ["Schedule", `${longDate(f.sd, f.st)} → ${longDate(f.ed, f.et)}`], ["Company", f.company]] as const).map(([k, v]) => <div key={k}><dt className="text-zinc-500">{k}</dt><dd className="font-semibold">{v}</dd></div>)}
                    </dl>
                  </section>
                  <section className="rounded-xl border border-zinc-200 p-4 text-xs"><p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Description</p><p className="mt-1">{f.desc || "No description provided yet."}</p></section>
                  <section className="rounded-xl border border-zinc-200 p-4 text-xs"><p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Cover images</p><p className="mt-1">{covers.length ? `${covers.length} image${covers.length === 1 ? "" : "s"} selected.` : "No images uploaded yet."}</p></section>
                </div>
              )}
            </div>
          </div>

          <footer className="flex items-center justify-between border-t border-zinc-200 px-6 py-3">
            {step === 0 ? <Btn variant="ghost" className="h-8 text-xs" onClick={onClose}>Cancel</Btn> : <Btn variant="ghost" className="h-8 text-xs" onClick={() => setStep(step - 1)}><ArrowLeft className="size-3.5" />Back</Btn>}
            <div className="flex items-center gap-3">
              {(errors[step] || err) && <span role="alert" className="text-[11px] text-rose-600">{errors[step] || err}</span>}
              {step < 3
                ? <Btn variant="solid" className="h-8 text-xs" disabled={!canNext} onClick={() => setStep(step + 1)}>{next[step]}<ArrowRight className="size-3.5" /></Btn>
                : <Btn variant="solid" className="h-8 text-xs" disabled={busy} onClick={create}>{busy ? "Creating…" : "Add auction"}</Btn>}
            </div>
          </footer>
        </div>
      </div>
    </Overlay>
  );
}
