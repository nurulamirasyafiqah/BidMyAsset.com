"use client";

import { useEffect, type ReactNode } from "react";
import { Btn } from "@/components/admin/ui";

/** Full-screen admin panel with the navy title bar used by the Add auction / Lot Builder / Bidder Registration flows. */
export function Overlay({ title, sub, onClose, actions, children }: { title: string; sub?: ReactNode; onClose: () => void; actions?: ReactNode; children: ReactNode }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", h);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", h); document.body.style.overflow = prev; };
  }, [onClose]);
  return (
    <div role="dialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-[55] flex flex-col bg-white">
      <header className="flex items-center justify-between gap-3 bg-[#03224f] px-5 py-2.5 text-white">
        <div className="min-w-0"><h2 className="text-sm font-bold leading-tight">{title}</h2>{sub && <p className="truncate text-[11px] text-white/80">{sub}</p>}</div>
        <div className="flex items-center gap-2">
          {actions}
          <button onClick={onClose} className="rounded-md bg-[#1b3a8f] px-3 py-1 text-xs font-semibold hover:bg-[#2447b0]">Close</button>
        </div>
      </header>
      <div className="min-h-0 flex-1">{children}</div>
    </div>
  );
}

export function Confirm({ title, body, confirmLabel, onCancel, onConfirm }: { title: string; body: string; confirmLabel: string; onCancel: () => void; onConfirm: () => void }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [onCancel]);
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <div role="alertdialog" aria-modal="true" aria-label={title} className="w-full max-w-sm rounded-xl bg-white p-5 shadow-2xl">
        <h3 className="text-sm font-bold">{title}</h3>
        <p className="mt-1 text-xs text-zinc-600">{body}</p>
        <div className="mt-4 flex justify-end gap-2"><Btn variant="ghost" className="h-8 text-xs" onClick={onCancel}>Cancel</Btn><Btn variant="solid" className="h-8 text-xs" onClick={onConfirm}>{confirmLabel}</Btn></div>
      </div>
    </div>
  );
}

export const fmtUS = (iso: string) => {
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });
  const time = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }).toLowerCase();
  return `${date} ${time}`;
};
