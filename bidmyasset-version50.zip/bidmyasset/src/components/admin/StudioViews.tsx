"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { BarChart3, ChevronRight, Copy, Eye, Image as ImageIcon, ListChecks, MessageSquare, MoreHorizontal, Pause, Play, Plus, Settings, ShieldCheck, Trash2, Users } from "lucide-react";
import { Badge, Btn, Card, DataTable, Field, inputCls, Modal, PageHead, RefreshBtn, SearchBox, Tabs, useConfirm } from "@/components/admin/ui";
import { Confirm } from "@/components/admin/StudioParts";
import { AddAuctionWizard } from "@/components/admin/StudioWizard";
import { RegistrationPanel } from "@/components/admin/StudioRegistration";
import { BidHistoryTab, QuestionsTab } from "@/components/admin/StudioActivity";
import { LotBuilder } from "@/components/admin/StudioLotBuilder";
import { SECTION_VIEWS } from "@/components/admin/StudioBuilderSections";
import { StudioGate, studio, studioLots, cloneAuction, setPublished, setAuctionPaused, deleteLots } from "@/lib/studioApi";
import { builderSections, lotsFor, studioAuctions, type StudioAuction, type StudioLot } from "@/lib/admin";

const TONE = { RUNNING: "blue", DRAFT: "orange", UPCOMING: "amber", CLOSED: "zinc" } as const;
const TILES = [
  ["RUNNING", "Running", "Currently live"], ["DRAFT", "Draft", "Ready when you are"], ["UPCOMING", "Upcoming", "Scheduled ahead"], ["CLOSED", "Closed", "Completed"],
] as const;

// Session-level mock store so lot edits survive moving between the list, details and builder. TODO: replace with API calls.
const lotStore = studioLots; // filled from PocketBase by StudioGate
const getLots = (a: StudioAuction) => { if (!lotStore.has(a.id)) lotStore.set(a.id, lotsFor(a)); return lotStore.get(a.id)!; };
const TIME_OPTS = Array.from({ length: 48 }, (_, i) => `${String(Math.floor(i / 2)).padStart(2, "0")}:${i % 2 ? "30" : "00"}`);
const toDMY = (iso: string) => iso.split("-").reverse().join("/");

function CloneModal({ a, onClose, onClone }: { a: StudioAuction; onClose: () => void; onClone: (n: StudioAuction) => void }) {
  const [f, setF] = useState({ name: a.title, sd: "", st: "", ed: "", et: "", withLots: true });
  const bad = !f.name.trim() || !f.sd || !f.st || !f.ed || !f.et || f.ed < f.sd;
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const doClone = async () => {
    setBusy(true); setErr("");
    try {
      // Real copy (draft: settings, cover images and, optionally, all lots with their photos) when the backend is live; demo copy otherwise.
      if (studio.live) onClone(await cloneAuction(a, { title: f.name.trim(), sd: f.sd, st: f.st, ed: f.ed, et: f.et, withLots: f.withLots }));
      else onClone({ ...a, id: String(1200 + Math.floor(Math.random() * 800)), title: f.name.trim(), code: crypto.randomUUID(), status: "DRAFT", active: 0, starts: `${toDMY(f.sd)} ${f.st}:00`, ends: toDMY(f.ed) });
    } catch (e) { setErr(e instanceof Error ? e.message : "Could not clone"); } finally { setBusy(false); }
  };
  return (
    <Modal title="Clone Auction" sub="Duplicate the selected auction and configure the new schedule before saving." onClose={onClose}
      footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="solid" disabled={bad || busy} onClick={doClone}>{busy ? "Cloning…" : "Clone auction"}</Btn></>}>
      <div className="space-y-3">
        <Field label="Auction name"><input className={inputCls} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus onFocus={(e) => e.target.select()} /></Field>
        <div className="grid grid-cols-2 gap-3"><Field label="Start date"><input type="date" className={inputCls} value={f.sd} onChange={(e) => setF({ ...f, sd: e.target.value })} /></Field>
          <Field label="Start time"><select className={inputCls} value={f.st} onChange={(e) => setF({ ...f, st: e.target.value })}><option value="">Select start time</option>{TIME_OPTS.map((t) => <option key={t}>{t}</option>)}</select></Field>
          <Field label="End date"><input type="date" className={inputCls} min={f.sd || undefined} value={f.ed} onChange={(e) => setF({ ...f, ed: e.target.value })} /></Field>
          <Field label="End time"><select className={inputCls} value={f.et} onChange={(e) => setF({ ...f, et: e.target.value })}><option value="">Select end time</option>{TIME_OPTS.map((t) => <option key={t}>{t}</option>)}</select></Field></div>
        {f.ed && f.sd && f.ed < f.sd && <p role="alert" className="text-[11px] text-rose-600">End date can’t be before the start date.</p>}
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={f.withLots} onChange={(e) => setF({ ...f, withLots: e.target.checked })} />Copy all lots with their photos and bid settings (copied as drafts)</label>
        <p className="text-[11px] text-zinc-500">Settings and cover images are always copied. Bids, registrations, invoices and the published/paused state are not.</p>
        {err && <p role="alert" className="text-[11px] text-rose-600">{err}</p>}
      </div>
    </Modal>
  );
}

function RowMenu({ a, onReg, onClone }: { a: StudioAuction; onReg: () => void; onClone: () => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const cls = "flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-zinc-50";
  return (
    <div ref={ref} className="relative">
      <button aria-label={`More actions for ${a.title}`} aria-expanded={open} onClick={() => setOpen((v) => !v)} className="grid size-7 place-items-center rounded border border-zinc-200 hover:bg-zinc-50"><MoreHorizontal className="size-4" /></button>
      {open && (
        <ul className="absolute right-0 z-20 mt-1 w-48 rounded-lg border border-zinc-200 bg-white py-1 text-xs shadow-lg">
          <li><button className={cls} onClick={() => { setOpen(false); onReg(); }}><Users className="size-3.5 text-zinc-500" />Live Registration</button></li>
          <li><Link href={`/admin/auction-studio/${a.id}?tab=bids`} onClick={() => setOpen(false)} className={cls}><ListChecks className="size-3.5 text-zinc-500" />Bid History</Link></li>
          <li><Link href={`/admin/auction-studio/${a.id}?tab=qa`} onClick={() => setOpen(false)} className={cls}><MessageSquare className="size-3.5 text-zinc-500" />Questions &amp; Review</Link></li>
          <li><button className={cls} onClick={() => { setOpen(false); onClone(); }}><Copy className="size-3.5 text-zinc-500" />Clone auction</button></li>
        </ul>
      )}
    </div>
  );
}

function StudioListInner() {
  const { confirm, dialog } = useConfirm();
  const [status, setStatus] = useState<StudioAuction["status"]>("RUNNING");
  const [q, setQ] = useState("");
  const [, bump] = useState(0);
  const [wizard, setWizard] = useState(false);
  const [clone, setClone] = useState<StudioAuction | null>(null);
  const [reg, setReg] = useState<StudioAuction | null>(null);
  const [toast, setToast] = useState("");
  const countOf = (s: StudioAuction["status"]) => studioAuctions.filter((a) => a.status === s).length;
  const rows = studioAuctions.filter((a) => a.status === status && `${a.title} ${a.company} ${a.code}`.toLowerCase().includes(q.toLowerCase()));
  const label = TILES.find(([s]) => s === status)![1];
  const add = (a: StudioAuction, msg: string) => { if (!studioAuctions.includes(a)) studioAuctions.unshift(a); setStatus("DRAFT"); setWizard(false); setClone(null); setToast(msg); bump((n) => n + 1); setTimeout(() => setToast(""), 3500); };
  return (
    <>
      <PageHead title="Auction Studio" sub="Manage drafts, live runs, and wrap-ups in one workspace"
        chips={<span className="flex items-center gap-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" />Viewing: {label} ({countOf(status)})</span>}
        actions={<><RefreshBtn /><Btn variant="solid" onClick={() => setWizard(true)}><Plus className="size-4" />Add Auction</Btn></>} />
      {toast && <p role="status" className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{toast}</p>}

      <div className="rounded-2xl bg-zinc-50 p-3">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {TILES.map(([s, l, sub]) => (
            <button key={s} onClick={() => setStatus(s)} aria-pressed={status === s}
              className={`rounded-xl border p-3.5 text-left transition ${status === s ? "border-primary bg-sky-50 ring-1 ring-primary/30" : "border-zinc-200 bg-white hover:bg-zinc-50"}`}>
              <Badge tone={TONE[s]}>{l}</Badge>
              <p className="mt-2 text-2xl font-semibold">{countOf(s)}</p><p className="text-[11px] text-zinc-500">{sub}</p>
            </button>
          ))}
        </div>
      </div>

      <Card className="mt-5">
        <div className="flex items-center gap-3 px-5 pt-5"><h2 className="text-base font-bold">Auctions ({countOf(status)})</h2></div>
        <div className="flex items-center gap-3 px-5 py-3"><SearchBox value={q} onChange={setQ} placeholder="Search auctions..." className="w-72" /></div>
        <DataTable empty={`No ${label.toLowerCase()} auctions match your search.`} head={["Auction", "Lots", "Image", "Starts", "Ends", "Type", "Actions"]}
          rows={rows.map((a) => [
            <div key="a"><p className="flex items-center gap-2 text-[13px] font-semibold"><Link href={`/admin/auction-studio/${a.id}`} className="hover:text-primary">{a.title}</Link><Badge tone={TONE[a.status]}>{a.status}</Badge></p><p className="text-zinc-500">{a.company}</p><p className="text-[10px] text-zinc-400">{a.code}</p></div>,
            <div key="l"><p className="font-semibold">{a.lots}</p><p className="text-zinc-500">{a.active} active</p></div>,
            a.images?.[0] ? /* eslint-disable-next-line @next/next/no-img-element */ <img key="i" src={a.images[0].url} alt="" className="h-9 w-12 rounded object-cover" /> : <span key="i" className="grid h-9 w-12 place-items-center rounded bg-zinc-200 text-zinc-400"><ImageIcon className="size-4" /></span>,
            a.starts, a.ends, <Badge key="t" tone="zinc">{a.type}</Badge>,
            <div key="x" className="flex items-center gap-1.5">
              <Link href={`/admin/auction-studio/${a.id}`} aria-label={`Open auction ${a.title}`} title="Open auction" className="grid size-7 place-items-center rounded border border-zinc-200 hover:bg-zinc-50"><Eye className="size-4" /></Link>
              <Link href={`/admin/auction-studio/${a.id}/builder`} aria-label={`Open builder for ${a.title}`} title="Auction Builder" className="grid size-7 place-items-center rounded border border-zinc-200 hover:bg-zinc-50"><Settings className="size-4" /></Link>
              <RowMenu a={a} onReg={() => setReg(a)} onClone={async () => { if (await confirm({ title: "Duplicate this auction?", body: `A copy of “${a.title}” will be created as a draft, with its settings and cover images (and its lots, if you leave that ticked). You can set its name and schedule next.`, confirmLabel: "Duplicate", tone: "primary" })) setClone(a); }} />
            </div>,
          ])} />
      </Card>

      {wizard && <AddAuctionWizard onClose={() => setWizard(false)} onCreate={(a) => add(a, `“${a.title}” was added to Draft.`)} />}
      {clone && <CloneModal a={clone} onClose={() => setClone(null)} onClone={(n) => add(n, `Cloned as “${n.title}” in Draft.`)} />}
      {reg && <RegistrationPanel auction={reg} onClose={() => setReg(null)} />}
      {dialog}
    </>
  );
}

const DTABS = [["lots", "Lots"], ["reg", "Registrations"], ["bids", "Bid History"], ["qa", "Questions & Review"]] as const;
type DTab = (typeof DTABS)[number][0];
const isTab = (t?: string): t is DTab => DTABS.some(([k]) => k === t);

function StudioDetailInner({ id, initialTab }: { id: string; initialTab?: string }) {
  const a = studioAuctions.find((x) => x.id === id);
  const [tab, setTab] = useState<DTab>(isTab(initialTab) ? initialTab : "lots");
  const [flt, setFlt] = useState<"All" | "Draft" | "Live" | "Closed">("All");
  const [q, setQ] = useState("");
  const [lots, setLots] = useState<StudioLot[]>(() => (a ? getLots(a) : []));
  const [del, setDel] = useState<StudioLot | null>(null);
  const [builder, setBuilder] = useState(false);
  const [builderLot, setBuilderLot] = useState<string | undefined>();
  const [cloneOpen, setCloneOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [paused, setPaused] = useState(!!a?.paused);
  const { confirm, dialog } = useConfirm();
  if (!a) return <Card className="p-10 text-center"><p className="font-semibold">Auction not found</p><Link href="/admin/auction-studio" className="mt-3 inline-block text-sm font-semibold text-primary">Back to Auction Studio</Link></Card>;

  const FILT = { All: () => true, Draft: (l: StudioLot) => l.status === "Draft", Live: (l: StudioLot) => l.status === "Active", Closed: (l: StudioLot) => l.status === "Closed" };
  const shown = lots.filter(FILT[flt]).filter((l) => `${l.title} ${l.no}`.toLowerCase().includes(q.toLowerCase()));
  const n = (f: keyof typeof FILT) => lots.filter(FILT[f]).length;
  const sync = (l: StudioLot[]) => { lotStore.set(a.id, l); setLots(l); };
  const canPause = a.status === "RUNNING";
  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(""), 3500); };
  const togglePause = async () => {
    if (!canPause) return;
    const ok = await confirm(paused
      ? { title: "Resume this auction?", body: "Bidding will reopen and lots will continue closing on their scheduled times.", confirmLabel: "Resume", tone: "primary" }
      : { title: "Pause this auction?", body: "Bidders won't be able to place bids until you resume it. Lot closing times are not changed automatically.", confirmLabel: "Pause auction" });
    if (!ok) return;
    try { await setAuctionPaused(a, !paused); setPaused(!paused); flash(paused ? "Auction resumed." : "Auction paused."); }
    catch (e) { flash(e instanceof Error ? e.message : "Could not change the pause state"); }
  };
  // real "last updated": the auction record's own timestamp, shown in the auction's time zone
  const stamp = a.updatedAt ? new Date(a.updatedAt).toLocaleString("en-US", { timeZone: a.tz, month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "") : "";

  return (
    <>
      <nav aria-label="Breadcrumb" className="mb-3 flex items-center gap-1.5 text-xs text-zinc-500"><span>Admin</span><ChevronRight className="size-3" /><Link href="/admin/auction-studio" className="hover:text-primary">Auction Studio</Link><ChevronRight className="size-3" /><span className="text-zinc-800">{a.title}</span></nav>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          {a.images?.[0] ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={a.images[0].url} alt="" className="h-14 w-16 rounded object-cover" /> : <span className="grid h-14 w-16 place-items-center rounded bg-zinc-200 text-zinc-400"><ImageIcon className="size-5" /></span>}
          <div>
            <h1 className="flex items-center gap-2 text-xl font-bold">{a.title}{paused ? <Badge tone="amber">Paused</Badge> : <Badge tone={TONE[a.status]}>{a.status === "RUNNING" ? "Running" : a.status}</Badge>}</h1>
            <p className="text-[11px] text-zinc-500"><b className="text-zinc-700">#{a.sequence ?? a.id}</b> · ID: {a.code} · {a.type.toUpperCase()} · {a.company}</p>
            <p className="text-[11px] text-zinc-600">Starts {a.starts} · Ends {a.ends} · {a.tz ?? "Asia/Kuala_Lumpur"}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="flex justify-end gap-2"><Link href={`/admin/auction-studio/${a.id}/builder`} className="inline-flex h-8 items-center rounded-md border border-primary/40 px-3 text-xs font-semibold text-primary hover:bg-primary/5">Auction Builder</Link>
            <Btn className="h-8 text-xs" onClick={() => { setBuilderLot(undefined); setBuilder(true); }}>Lot Builder</Btn>
            {studio.live && <Btn variant={a.published ? "outline" : "solid"} className="h-8 text-xs" onClick={async () => {
              const ok = await confirm(a.published ? { title: "Unpublish this auction?", body: "It disappears from the public website and bidder portal.", confirmLabel: "Unpublish" } : { title: "Publish this auction?", body: "It becomes visible on the website with its cover image and lot photos.", confirmLabel: "Publish", tone: "primary" });
              if (!ok) return;
              try { await setPublished(a.id, !a.published); window.location.reload(); } catch (e) { flash(e instanceof Error ? e.message : "Could not change visibility"); }
            }}>{a.published ? "Unpublish" : "Publish"}</Btn>}
            <button aria-label="Duplicate auction" title="Duplicate auction" onClick={async () => { if (await confirm({ title: "Duplicate this auction?", body: `A copy of “${a.title}” will be created as a draft, with its settings and cover images (and its lots, if you leave that ticked). You can set its name and schedule next.`, confirmLabel: "Duplicate", tone: "primary" })) setCloneOpen(true); }} className="grid size-8 place-items-center rounded-md border border-primary/40 text-primary hover:bg-primary/5"><Copy className="size-3.5" /></button>
            {canPause && <button aria-label={paused ? "Resume auction" : "Pause auction"} title={paused ? "Resume auction" : "Pause auction"} onClick={togglePause} className="grid size-8 place-items-center rounded-md border border-primary/40 text-primary hover:bg-primary/5">{paused ? <Play className="size-3.5" /> : <Pause className="size-3.5" />}</button>}</div>
          {stamp && <p className="mt-1 text-[10px] text-zinc-500">Last updated {stamp}</p>}
        </div>
      </div>
      {paused && <div role="alert" className="mb-3 flex items-center justify-between gap-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800"><span className="flex items-center gap-2"><Pause className="size-4" /><b>This auction is paused.</b> Bidding is suspended until you resume it.</span><button onClick={togglePause} className="font-semibold underline">Resume</button></div>}
      {toast && <p role="status" className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{toast}</p>}
      <Tabs items={DTABS} value={tab} onChange={setTab} />
      <Card>
        {tab === "lots" ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-4">
              <h2 className="text-sm font-bold">Lots ({lots.length})</h2>
              <div className="flex items-center gap-2">
                <div className="flex overflow-hidden rounded-md border border-zinc-200 text-[11px] font-semibold">
                  {(["All", "Draft", "Live", "Closed"] as const).map((f) => <button key={f} onClick={() => setFlt(f)} aria-pressed={flt === f} className={`px-2.5 py-1 ${flt === f ? "bg-zinc-100" : "bg-white text-zinc-500 hover:bg-zinc-50"}`}>{f} <span className="text-zinc-400">{n(f)}</span></button>)}
                </div>
                <SearchBox value={q} onChange={setQ} placeholder="Search lots..." className="w-44" />
              </div>
            </div>
            <div className="mt-3"><DataTable head={["#", "Lot", "Status", "Closes", "Actions"]} empty="No lots match the current filter."
              rows={shown.map((l) => [
                `#${l.no}`,
                <div key="l" className="flex items-center gap-3">{l.images?.[0] ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={l.images[0].url} alt="" className="size-9 rounded object-cover" /> : <span className="grid size-9 place-items-center rounded bg-zinc-200 text-zinc-400"><ImageIcon className="size-4" /></span>}<div><p className="text-[13px] font-semibold">{l.title}</p><p className="text-zinc-500">Lot {l.no}</p></div></div>,
                <Badge key="s" tone={l.status === "Active" ? "blue" : l.status === "Draft" ? "orange" : "zinc"}>{l.status}</Badge>,
                <div key="c"><p className="text-red-600">{l.closes.replace(" · ", " · ")}</p><p className="text-zinc-500">{a.tz ?? "Asia/Kuala_Lumpur"}</p></div>,
                <div key="x" className="flex gap-1.5"><button aria-label={`View lot ${l.no}`} title="Open this lot in the Lot Builder" onClick={() => { setBuilderLot(l.id); setBuilder(true); }} className="grid size-7 place-items-center rounded border border-zinc-200 hover:bg-zinc-50"><Eye className="size-3.5" /></button>
                  <button aria-label={`Delete lot ${l.no}`} onClick={() => setDel(l)} className="grid size-7 place-items-center rounded border border-rose-200 text-rose-600 hover:bg-rose-50"><Trash2 className="size-3.5" /></button></div>,
              ])} /></div>
            {a.lots > lots.length && <p className="px-5 pb-3 text-[11px] text-zinc-500">Showing the first {lots.length} of {a.lots} lots (mock data).</p>}
          </>
        ) : tab === "bids" ? <BidHistoryTab auction={a} />
          : tab === "qa" ? <QuestionsTab auction={a} />
          : <RegistrationPanel inline auction={a} onClose={() => setTab("lots")} />}
      </Card>

      {builder && <LotBuilder auction={a} lots={lots} initialSel={builderLot} onClose={() => { setBuilder(false); setPaused(!!a.paused); }} onChange={sync} />}
      {cloneOpen && <CloneModal a={a} onClose={() => setCloneOpen(false)} onClone={(c) => { if (!studioAuctions.includes(c)) studioAuctions.unshift(c); setCloneOpen(false); setToast(`Cloned as “${c.title}” in Draft.`); setTimeout(() => setToast(""), 3500); }} />}
      {dialog}
      {del && <Confirm title="Delete lot" body="Are you sure you want to delete this lot? This action cannot be undone." confirmLabel="Delete" onCancel={() => setDel(null)} onConfirm={async () => {
        const gone = del;
        try { if (studio.live) await deleteLots([gone.id]); sync(lots.filter((x) => x.id !== gone.id)); }
        catch (e) { flash(e instanceof Error ? e.message : "Could not delete the lot"); }
        setDel(null);
      }} />}
    </>
  );
}

const STATE_TONE = { Complete: "blue", Optional: "orange", Required: "red", "Not saved": "zinc" } as const;
const STORED_KEY: Record<string, string> = { Contacts: "contacts", Address: "address", "Bidder Registration": "registration", "Commission & Tax": "commission", "Payment Configuration": "payment", "Catalog Notification": "catalog", "Legal Policy": "legal", "Financial Supplier": "bank" };
/** Section status from what is actually stored. */
function stateOf(name: string, a: StudioAuction, lots: StudioLot[]): keyof typeof STATE_TONE {
  if (name === "Auction Info") return a.title && a.starts && a.ends && a.category ? "Complete" : "Required";
  if (name === "Lot Bid Details") return lots.length === 0 ? "Optional" : lots.every((l) => l.startBid > 0) ? "Complete" : "Required";
  if (name === "Documents") return a.documents?.length ? "Complete" : "Optional";
  if (name === "Consignors") return lots.some((l) => l.consignor.trim()) ? "Complete" : "Optional";
  const key = STORED_KEY[name];
  if (key === "legal" || key === "bank") { // one chosen item: saved only when an id is set
    const v = a.builder?.[key] as Record<string, unknown> | undefined;
    const id = key === "legal" ? v?.policyId : v?.bankId;
    return typeof id === "string" && id !== "" ? "Complete" : "Optional";
  }
  if (key) { const v = a.builder?.[key]; return v === undefined || v === null || (Array.isArray(v) && v.length === 0) ? "Optional" : "Complete"; }
  return "Not saved";
}
function StudioBuilderInner({ id }: { id: string }) {
  const a = studioAuctions.find((x) => x.id === id);
  const [active, setActive] = useState<string>(builderSections[0].name);
  const [toast, setToast] = useState("");
  const [lotsOpen, setLotsOpen] = useState(false);
  const [lots, setLots] = useState<StudioLot[]>(() => (a ? getLots(a) : []));
  const sec = builderSections.find((s) => s.name === active)!;
  if (!a) return <Card className="p-10 text-center"><p className="font-semibold">Auction not found</p><Link href="/admin/auction-studio" className="mt-3 inline-block text-sm font-semibold text-primary">Back to Auction Studio</Link></Card>;
  const saved = (m: string) => {
    setToast(m); setTimeout(() => setToast(""), 3000);
    const fresh = studioAuctions.find((x) => x.id === id); // saves can reload the studio data (new lot values, new auction record)
    if (fresh) setLots(getLots(fresh));
  };
  return (
    <>
      <PageHead title="Auction Builder" sub="Configure every auction module from a single workspace."
        chips={<><span className="rounded bg-ink px-2 py-0.5 text-[11px] font-semibold text-white">{a.title}</span><span className="rounded bg-zinc-200 px-2 py-0.5 text-[11px] font-semibold">Timed</span><span className="rounded bg-zinc-200 px-2 py-0.5 text-[11px] font-semibold">Sequence #{a.sequence ?? id}</span></>}
        actions={<><Link href={`/admin/auction-studio/${id}`} className="inline-flex h-9 items-center rounded-md border border-primary/40 px-4 text-sm font-semibold text-primary hover:bg-primary/5">Open Auction Details</Link><Btn variant="outline" onClick={() => setLotsOpen(true)}>Add Lots</Btn></>} />
      {toast && <p role="status" className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{toast}</p>}
      <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
        <Card className="p-4 lg:sticky lg:top-4 lg:self-start">
          <h2 className="text-base font-bold">Sections</h2><p className="text-xs text-zinc-500">Track required steps and jump between modules.</p>
          <div className="my-3 flex gap-2"><Badge tone="red">Required</Badge><Badge tone="orange">Optional</Badge><Badge tone="blue">Complete</Badge><Badge tone="zinc">Not saved</Badge></div>
          <ul className="max-h-[60vh] space-y-2 overflow-y-auto pr-1">
            {builderSections.map((s) => (
              <li key={s.name}>
                <button onClick={() => setActive(s.name)} aria-current={active === s.name} className={`flex w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left ${active === s.name ? "border-ink bg-white ring-1 ring-ink" : "border-zinc-200 bg-zinc-50 hover:bg-zinc-100"}`}>
                  <ShieldCheck className="mt-0.5 size-4 shrink-0 text-zinc-500" />
                  <span className="min-w-0 flex-1"><span className="block text-xs font-semibold">{s.name}</span><span className="block truncate text-[11px] text-zinc-500">{s.short}</span></span>
                  <Badge tone={STATE_TONE[stateOf(s.name, a, lots)]}>{stateOf(s.name, a, lots)}</Badge>
                </button>
              </li>
            ))}
          </ul>
        </Card>
        <Card className="p-5">
          <div className="mb-4 flex items-start justify-between"><div><h2 className="text-base font-bold">{sec.title}</h2><p className="text-xs text-zinc-500">{sec.sub}</p></div><Badge tone={STATE_TONE[stateOf(sec.name, a, lots)]}>{stateOf(sec.name, a, lots)}</Badge></div>
          {/* Every section stays mounted (hidden) so unsaved edits survive switching sections. */}
          {builderSections.map((s) => { const V = SECTION_VIEWS[s.name]; return <div key={s.name} hidden={active !== s.name}><V a={a} saved={saved} lots={lots} /></div>; })}
        </Card>
      </div>
      {lotsOpen && <LotBuilder auction={a} lots={lots} onClose={() => setLotsOpen(false)} onChange={(l) => { lotStore.set(a.id, l); setLots(l); }} />}
    </>
  );
}

// Load real auctions/lots from PocketBase before the Studio screens read the shared lists.
export const StudioList = () => <StudioGate><StudioListInner /></StudioGate>;
export const StudioDetail = (p: { id: string; initialTab?: string }) => <StudioGate><StudioDetailInner {...p} /></StudioGate>;
export const StudioBuilder = (p: { id: string }) => <StudioGate><StudioBuilderInner {...p} /></StudioGate>;
