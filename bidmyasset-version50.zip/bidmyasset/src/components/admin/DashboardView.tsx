"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CalendarDays, Filter, Info, RefreshCw } from "lucide-react";
import { Btn, Card, DataTable, Delta, PageHead, Segmented } from "@/components/admin/ui";
import { formatMoney } from "@/lib/format";
import { DateRangePopover, fmtRange, previousRange, toISO, type DateRange } from "@/components/admin/DateRangePopover";

const RANGES = [["7", "Last 7 Days"], ["30", "Last 30 Days"], ["90", "Last 90 Days"], ["365", "Last 12 Months"], ["all", "Lifetime"], ["custom", "Custom Range"]] as const;
type Range = (typeof RANGES)[number][0];
const PRESETS = RANGES.filter(([id]) => id !== "custom") as unknown as readonly (readonly [Exclude<Range, "custom">, string])[];
const rangeLabel = (r: Range, c: DateRange | null) => (r === "custom" && c ? fmtRange(c) : RANGES.find(([id]) => id === r)![1]);
const vs = (r: Range, c: DateRange | null) => (r === "all" ? "vs previous period" : r === "custom" ? (c ? `vs ${fmtRange(previousRange(c))}` : "vs previous range") : r === "365" ? "vs last 12 months" : `vs last ${r} days`);

type DayRow = { d: string; n: number };
type Money = Record<string, number>;
type Dash = {
  lifetime: boolean; current: Record<string, number>; delta: Record<string, number>; alerts: Record<string, number>;
  daily: { admin: DayRow[]; bidder: DayRow[] };
  financial: { sales: { cur: Money; prev: Money }; fees: { cur: Money; prev: Money } };
  sellThrough: { rate: number; prevRate: number | null; sold: number; offered: number; series: { title: string; end: string; rate: number; sold: number; offered: number }[] };
  companies: { name: string; auctions: number; revenue: Money; rate: number; bidders: number }[];
};
// Every card is linked to the database (GET /api/bma/admin/dashboard).
const KPIS: readonly (readonly [string, string])[] = [
  ["Total Activities", "activities"], ["Total New Bidder Registered", "newBidders"], ["Total Auctions", "auctions"], ["Total Bidders Participated", "participated"],
  ["Total Bids Placed", "bids"], ["Total Lots Sold", "lotsSold"], ["Total Invoices Generated", "invoices"], ["Total Invoices Settled", "settled"],
];
const pct = (cur: number, prev: number | undefined) => (prev ? Math.round(((cur - prev) / prev) * 100) : cur > 0 ? 100 : 0);

/** Calendar days (local) from `from` to today, or the span of the data when lifetime. */
function dayKeys(range: Range, custom: DateRange | null, first?: string) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  let start = new Date(today), end = new Date(today);
  if (range === "custom" && custom) { start = new Date(`${custom.start}T00:00:00`); end = new Date(`${custom.end}T00:00:00`); }
  else if (range === "all") { start = first ? new Date(`${first}T00:00:00`) : new Date(today.getTime() - 29 * 864e5); }
  else start.setDate(start.getDate() - (Number(range) - 1));
  const out: string[] = [];
  for (const d = new Date(start); d <= end && out.length < 800; d.setDate(d.getDate() + 1)) out.push(toISO(d));
  return out;
}

/** Percentage-point change chip (same look as Delta, but in points). */
function Pts({ v }: { v: number }) {
  const down = v < 0;
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold ${down ? "border-rose-200 bg-rose-50 text-rose-600" : "border-sky-200 bg-sky-50 text-sky-700"}`}>{v > 0 ? "+" : ""}{v} pts</span>;
}

function MoneyTile({ title, desc, cur, prev, lifetime }: { title: string; desc: string; cur?: Money; prev?: Money; lifetime: boolean }) {
  const ccy = Object.keys(cur ?? {}).filter((c) => (cur?.[c] ?? 0) > 0).sort();
  return (
    <div className="rounded-lg border border-zinc-200 p-3.5">
      <p className="text-sm font-semibold text-zinc-700">{title}</p>
      {!cur ? <p className="mt-3 text-2xl font-semibold">…</p> : ccy.length === 0 ? <p className="mt-3 text-2xl font-semibold">—</p> : (
        <ul className="mt-3 space-y-1.5">
          {ccy.map((c) => (
            <li key={c} className="flex items-center justify-between gap-2">
              <span className="text-xl font-semibold">{formatMoney(cur[c], c).trim()}</span>
              {!lifetime && <Delta v={pct(cur[c], prev?.[c])} />}
            </li>
          ))}
        </ul>
      )}
      <p className="mt-2 text-xs text-zinc-500">{desc}{cur && ccy.length === 0 ? " · none in this period" : ""}</p>
    </div>
  );
}

function SellThroughBars({ series }: { series: Dash["sellThrough"]["series"] }) {
  if (series.length === 0) return <div className="mt-3 grid h-40 place-items-center rounded-lg bg-zinc-50 text-center text-xs text-zinc-500"><div><Info className="mx-auto mb-2 size-4 text-zinc-400" />No closed auctions in this period</div></div>;
  const W = 420, H = 130, pad = 6, bw = (W - pad * 2) / series.length;
  return (
    <svg viewBox={`0 0 ${W} ${H + 30}`} className="mt-3 h-44 w-full" role="img" aria-label="Sell-through rate per closed auction">
      {[0, 50, 100].map((t) => <line key={t} x1={pad} x2={W - pad} y1={H - (t / 100) * (H - 14)} y2={H - (t / 100) * (H - 14)} stroke="#e5e7eb" strokeDasharray="2 3" />)}
      {series.map((r, i) => {
        const h = (r.rate / 100) * (H - 14), x = pad + i * bw + bw * 0.18, w = bw * 0.64;
        return (
          <g key={`${r.title}-${i}`}>
            <rect x={x} y={H - h} width={w} height={Math.max(h, 2)} rx={3} fill={r.sold ? "#0037e1" : "#d4d4d8"}><title>{`${r.title} · ${r.sold}/${r.offered} lots sold (${r.rate}%) · closed ${r.end}`}</title></rect>
            <text x={x + w / 2} y={H - h - 4} textAnchor="middle" fontSize="9" fill="#3f3f46">{r.rate}%</text>
            <text x={x + w / 2} y={H + 13} textAnchor="middle" fontSize="8" fill="#52525b">{r.title.length > 11 ? `${r.title.slice(0, 10)}…` : r.title}</text>
            <text x={x + w / 2} y={H + 24} textAnchor="middle" fontSize="8" fill="#71717a">{r.end.slice(5).replace("-", "/")}</text>
          </g>
        );
      })}
    </svg>
  );
}

function RoleActivity({ keys, admin, bidder }: { keys: string[]; admin: Record<string, number>; bidder: Record<string, number> }) {
  const A = keys.map((k) => admin[k] ?? 0), B = keys.map((k) => bidder[k] ?? 0);
  const top = Math.max(4, ...A, ...B), max = Math.ceil(top / 4) * 4;
  const W = 620, H = 230, L = 34, B_ = 26, T = 8, n = keys.length;
  const x = (i: number) => L + (i * (W - L - 10)) / Math.max(1, n - 1);
  const y = (v: number) => T + ((max - v) * (H - T - B_)) / max;
  const area = (vals: number[]) => {
    const pts = vals.map((v, i) => `${x(i)},${y(v)}`);
    return { line: `M${pts.join(" L")}`, fill: `M${x(0)},${y(0)} L${pts.join(" L")} L${x(n - 1)},${y(0)} Z` };
  };
  const a = area(A), b = area(B), step = Math.max(1, Math.ceil(n / 8));
  return (
    <svg viewBox={`0 0 ${W} ${H + 20}`} className="mt-3 w-full" role="img" aria-label="Role activity by day for admins and bidders">
      {[0, 1, 2, 3, 4].map((t) => (
        <g key={t}>
          <line x1={L} x2={W - 10} y1={y((max * t) / 4)} y2={y((max * t) / 4)} stroke="#e5e7eb" strokeDasharray="2 3" />
          <text x={L - 6} y={y((max * t) / 4) + 3} textAnchor="end" fontSize="10" fill="#52525b">{(max * t) / 4}</text>
        </g>
      ))}
      {keys.map((k, i) => (i % step === 0 ? <text key={k} x={x(i)} y={H - 8} textAnchor="middle" fontSize="9" fill="#52525b">{k.slice(5).replace("-", "/")}</text> : null))}
      <path d={a.fill} fill="#a21caf" fillOpacity="0.18" /><path d={a.line} fill="none" stroke="#a21caf" strokeWidth="1.5" />
      <path d={b.fill} fill="#f59e0b" fillOpacity="0.2" /><path d={b.line} fill="none" stroke="#f59e0b" strokeWidth="1.5" />
      <g transform={`translate(${W / 2 - 40} ${H + 10})`} fontSize="9">
        <circle cx="0" cy="0" r="3" fill="#a21caf" /><text x="7" y="3" fill="#a21caf">admin</text>
        <circle cx="50" cy="0" r="3" fill="#f59e0b" /><text x="57" y="3" fill="#d97706">bidder</text>
      </g>
    </svg>
  );
}

export function DashboardView() {
  const [range, setRange] = useState<Range>("30");
  const [custom, setCustom] = useState<DateRange | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const closePicker = useCallback(() => setPickerOpen(false), []);
  const label = rangeLabel(range, custom);
  const [data, setData] = useState<Dash | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [updated, setUpdated] = useState<Date | null>(null);
  const [tzName, setTzName] = useState("");
  useEffect(() => { setTzName(Intl.DateTimeFormat().resolvedOptions().timeZone); }, []);
  const seq = useRef(0); // ignore a slow response that arrives after a newer request
  const load = useCallback(async () => {
    if (range === "custom" && !custom) return;
    const mine = ++seq.current;
    setLoading(true); setErr("");
    try {
      const qs = new URLSearchParams({ tz: String(-new Date().getTimezoneOffset()) });
      if (range !== "all") {
        const end = range === "custom" ? new Date(`${custom!.end}T00:00:00`) : new Date(), start = range === "custom" ? new Date(`${custom!.start}T00:00:00`) : new Date();
        end.setHours(0, 0, 0, 0); end.setDate(end.getDate() + 1); // end of the last day (exclusive)
        if (range !== "custom") start.setHours(0, 0, 0, 0), start.setDate(start.getDate() - (Number(range) - 1));
        qs.set("from", start.toISOString()); qs.set("to", end.toISOString());
      }
      const res = await fetch(`/api/admin/dashboard?${qs}`, { cache: "no-store" });
      const j = (await res.json()) as Dash & { message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      if (mine !== seq.current) return;
      setData(j); setUpdated(new Date());
    } catch (e) { if (mine === seq.current) setErr(e instanceof Error ? e.message : "Failed to load dashboard"); }
    finally { if (mine === seq.current) setLoading(false); }
  }, [range, custom]);
  useEffect(() => { void load(); }, [load]);
  const al = data?.alerts, num = (v: number | undefined) => (v === undefined ? "…" : v);
  const alerts = [
    { label: "Draft Auctions", text: `${num(al?.draft)} auctions in draft status`, n: al?.draft, warn: false },
    { label: "Upcoming Auctions", text: `${num(al?.upcoming)} auctions scheduled`, n: al?.upcoming, warn: false },
    { label: "Live Auctions", text: `${num(al?.live)} auctions currently live`, n: al?.live, warn: false },
    { label: "Closed Auctions", text: `${num(al?.closed)} auctions closed`, n: al?.closed, warn: false },
    { label: "Pending Allocations", text: `${num(al?.pendingAllocations)} sold lots awaiting an invoice`, n: al?.pendingAllocations, warn: true },
    { label: "Pending Invoices", text: `${num(al?.pendingInvoices)} invoices pending settlement`, n: al?.pendingInvoices, warn: true },
  ];
  const firstDay = [...(data?.daily.admin ?? []), ...(data?.daily.bidder ?? [])].map((r) => r.d).sort()[0];
  const keys = dayKeys(range, custom, firstDay);
  const toMap = (rows: DayRow[] | undefined) => Object.fromEntries((rows ?? []).map((r) => [r.d, r.n]));

  return (
    <>
      <p className="mb-1 flex items-center gap-2 text-xs text-zinc-500"><CalendarDays className="size-3.5" />Trending <span className="size-1 rounded-full bg-zinc-400" /> {tzName || "…"}</p>
      <PageHead title="Performance Dashboard" sub="Insights for auction activity, revenue performance, and operational alerts for your auction house." />

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1.5 border-r border-zinc-300 pr-3 text-xs text-zinc-600"><Filter className="size-3.5" />Filter</span>
          <div className="flex flex-wrap items-center gap-2">
            <Segmented items={PRESETS} value={range as Exclude<Range, "custom">} onChange={(r) => { setRange(r); setPickerOpen(false); }} />
            <div className="relative">
              <button role="tab" aria-selected={range === "custom"} aria-haspopup="dialog" aria-expanded={pickerOpen} onClick={() => setPickerOpen((o) => !o)}
                className={`rounded-full border px-3 py-1 text-[11px] font-semibold transition ${range === "custom" ? "border-primary bg-primary text-white" : "border-primary/30 bg-white text-primary hover:bg-primary/5"} ${pickerOpen ? "ring-2 ring-primary/30" : ""}`}>
                {range === "custom" && custom ? fmtRange(custom) : "Custom Range"}
              </button>
              {pickerOpen && (
                <DateRangePopover applied={custom} onClose={closePicker}
                  onApply={(r) => { setCustom(r); setRange("custom"); setPickerOpen(false); }}
                  onReset={() => { setCustom(null); if (range === "custom") setRange("30"); }} />
              )}
            </div>
          </div>
        </div>
        <Btn disabled={loading} onClick={() => void load()}><RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />Refresh</Btn>
      </div>

      {err && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{err}</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {KPIS.map(([label, key]) => (
          <Card key={label} className="p-5">
            <p className="text-sm text-zinc-600">{label}</p>
            <p className="mt-2 flex items-center gap-2 text-3xl font-semibold">
              {data ? (data.current[key] ?? 0).toLocaleString("en-US") : "…"}
              {data && !data.lifetime && <Delta v={data.delta[key] ?? 0} />}
            </p>
            <p className="mt-3 text-xs text-zinc-500">{data?.lifetime ? "all time" : vs(range, custom)}</p>
          </Card>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.45fr_1fr]">
        <Card className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-base font-bold">Financial Snapshot</h2>
              <p className="text-xs text-zinc-600">Multi-currency totals aligned with the selected timeframe.</p>
            </div>
            <span className="rounded-full border border-zinc-300 px-3 py-1 text-[11px] font-semibold">{label}</span>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <MoneyTile title="Internet Buying Fees" desc="Marketplace fees on invoices issued in the period" cur={data?.financial.fees.cur} prev={data?.financial.fees.prev} lifetime={!!data?.lifetime} />
            <MoneyTile title="Total Sales" desc="Hammer price of lots sold in auctions that closed in the period" cur={data?.financial.sales.cur} prev={data?.financial.sales.prev} lifetime={!!data?.lifetime} />
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="text-base font-bold">Sell-through Rate</h2>
          <p className="text-xs text-zinc-600">Conversion of lots to sales with historical comparison.</p>
          <div className="mt-3 flex items-center justify-between rounded-lg bg-zinc-50 px-4 py-3">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-zinc-500">Current sell-through</p>
              <p className="text-2xl font-semibold">{!data ? "…" : data.sellThrough.offered > 0 ? `${data.sellThrough.rate}%` : "—"}</p>
              {data && data.sellThrough.offered > 0 && <p className="text-[11px] text-zinc-500">{data.sellThrough.sold} of {data.sellThrough.offered} lots sold</p>}
            </div>
            {data && !data.lifetime && data.sellThrough.offered > 0 && data.sellThrough.prevRate !== null && <Pts v={Math.round((data.sellThrough.rate - data.sellThrough.prevRate) * 10) / 10} />}
          </div>
          <SellThroughBars series={data?.sellThrough.series ?? []} />
        </Card>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.7fr_1fr]">
        <Card className="p-5">
          <h2 className="text-base font-bold">Role Activity</h2>
          <p className="text-xs text-zinc-600">Daily activity of admins vs bidders. Bidder activity includes logins, bids, registrations, watchlist adds and new accounts; together the two lines add up to Total Activities.</p>
          <RoleActivity keys={keys} admin={toMap(data?.daily.admin)} bidder={toMap(data?.daily.bidder)} />
        </Card>

        <Card className="p-5">
          <h2 className="text-base font-bold">Operational Alerts</h2>
          <p className="text-xs text-zinc-600">Items requiring attention across registrations, auctions, and invoicing.</p>
          <ul className="mt-4 space-y-2.5">
            {alerts.map((a) => (
              <li key={a.label} className={`flex items-start gap-2.5 rounded-lg border px-3 py-2.5 ${a.warn ? "border-amber-200 bg-amber-50 text-amber-800" : "border-zinc-200 bg-zinc-50"}`}>
                <Info className="mt-0.5 size-4 shrink-0" />
                <div className="min-w-0 flex-1"><p className="text-xs font-semibold">{a.label}</p><p className="text-xs">{a.text}</p></div>
                <span className="rounded-full border border-zinc-300 bg-white px-2 text-[11px] font-semibold text-zinc-700">{a.n ?? "—"}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-zinc-500">Last updated {updated ? updated.toLocaleString("en-US", { dateStyle: "short", timeStyle: "short" }) : "—"}</p>
        </Card>
      </div>

      <Card className="mt-5 p-5">
        <h2 className="text-base font-bold">Top Performing Companies</h2>
        <p className="text-xs text-zinc-600">Comparison of revenue, sell-through, and bidder engagement.</p>
        <div className="mt-3">
          <DataTable
            head={["Company", "Auctions closed", "Revenue", "Sell-through", "Bidders"]}
            empty={data ? "We’ll surface top performers once there are enough completed auctions for the selected period." : "Loading…"}
            rows={(data?.companies ?? []).map((c) => [
              <span key="n" className="font-semibold">{c.name}</span>,
              c.auctions,
              Object.keys(c.revenue).length ? Object.entries(c.revenue).map(([cc, v]) => formatMoney(v, cc).trim()).join(" · ") : "—",
              `${c.rate}%`,
              c.bidders,
            ])}
          />
        </div>
      </Card>
    </>
  );
}
