"use client";

import { useCallback, useEffect, useRef, useState, useTransition, type ReactNode } from "react";
import { RefreshCw, Search, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { trackAdmin } from "@/lib/trackAdmin";

export function PageHead({ title, sub, actions, chips }: { title: string; sub?: string; actions?: ReactNode; chips?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-[26px] font-bold leading-tight">{title}</h1>
        {sub && <p className="mt-1 text-sm text-zinc-600">{sub}</p>}
        {chips && <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-zinc-600">{chips}</div>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export const Card = ({ children, className = "" }: { children: ReactNode; className?: string }) => (
  <section className={`rounded-xl border border-zinc-200 bg-white shadow-sm ${className}`}>{children}</section>
);

export function Btn({ children, onClick, variant = "outline", className = "", disabled, type = "button" }: {
  children: ReactNode; onClick?: () => void; variant?: "outline" | "solid" | "ghost"; className?: string; disabled?: boolean; type?: "button" | "submit";
}) {
  const v = {
    outline: "border border-primary/40 bg-white text-primary hover:bg-primary/5",
    solid: "bg-primary text-white hover:bg-primary-700",
    ghost: "border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50",
  }[variant];
  return (
    <button type={type} disabled={disabled} onClick={onClick}
      className={`inline-flex h-9 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition disabled:opacity-50 ${v} ${className}`}>
      {children}
    </button>
  );
}

/** Re-runs the page's server data fetch; spins until the new data has arrived. */
export function RefreshBtn({ small = false, onRefresh }: { small?: boolean; onRefresh?: () => void }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [hold, setHold] = useState(false); // keep spinning briefly so fast refreshes are visible
  const busy = pending || hold;
  return (
    <Btn className={small ? "h-8 text-xs" : undefined} disabled={busy} onClick={() => { setHold(true); setTimeout(() => setHold(false), 600); start(() => router.refresh()); onRefresh?.(); }}>
      <RefreshCw className={`${small ? "size-3.5" : "size-4"} ${busy ? "animate-spin" : ""}`} />Refresh
    </Btn>
  );
}

export function SearchBox({ value, onChange, placeholder, className = "" }: { value: string; onChange: (v: string) => void; placeholder: string; className?: string }) {
  return (
    <label className={`relative block ${className}`}>
      <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-400" />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder}
        className="h-9 w-full rounded-md border border-zinc-300 bg-white pl-9 pr-3 text-sm placeholder:text-zinc-400 focus:border-primary focus:outline-none" />
    </label>
  );
}

type Tone = "blue" | "green" | "amber" | "red" | "zinc" | "orange";
export function Badge({ tone = "blue", children }: { tone?: Tone; children: ReactNode }) {
  const t: Record<Tone, string> = {
    blue: "bg-sky-100 text-sky-800", green: "bg-emerald-50 text-emerald-700", amber: "bg-amber-50 text-amber-700 border border-amber-200",
    red: "bg-rose-50 text-rose-600", zinc: "bg-zinc-100 text-zinc-600", orange: "bg-orange-50 text-orange-600",
  };
  return <span className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${t[tone]}`}>{children}</span>;
}

export function Delta({ v }: { v: number }) {
  const down = v < 0;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${down ? "border-rose-200 bg-rose-50 text-rose-600" : "border-sky-200 bg-sky-50 text-sky-700"}`}>
      <svg viewBox="0 0 16 16" className="size-3" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        {down ? <path d="M2 4l5 5 3-3 4 4M14 10v-3m0 3h-3" /> : <path d="M2 12l5-5 3 3 4-4M14 6v3m0-3h-3" />}
      </svg>
      {Math.abs(v)}%
    </span>
  );
}

export function Avatar({ name, size = "size-8" }: { name: string; size?: string }) {
  const ini = name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  return <span className={`grid ${size} shrink-0 place-items-center rounded-full bg-blue-100 text-[11px] font-semibold text-primary`}>{ini}</span>;
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)}
      className={`relative h-5 w-9 rounded-full transition ${on ? "bg-primary" : "bg-zinc-300"}`}>
      <span className={`absolute top-0.5 size-4 rounded-full bg-white shadow transition-all ${on ? "left-[18px]" : "left-0.5"}`} />
    </button>
  );
}

export function Segmented<T extends string>({ items, value, onChange }: { items: readonly (readonly [T, string])[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="flex flex-wrap items-center gap-2" role="tablist">
      {items.map(([id, label]) => (
        <button key={id} role="tab" aria-selected={value === id} onClick={() => onChange(id)}
          className={`rounded-full border px-3 py-1 text-[11px] font-semibold transition ${value === id ? "border-primary bg-primary text-white" : "border-primary/30 bg-white text-primary hover:bg-primary/5"}`}>{label}</button>
      ))}
    </div>
  );
}

export function Tabs<T extends string>({ items, value, onChange }: { items: readonly (readonly [T, string])[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="mb-4 flex gap-1 border-b border-zinc-200" role="tablist">
      {items.map(([id, label]) => (
        <button key={id} role="tab" aria-selected={value === id} onClick={() => onChange(id)}
          className={`-mb-px border-b-2 px-4 py-2 text-sm font-semibold transition ${value === id ? "border-primary text-primary" : "border-transparent text-zinc-600 hover:text-ink"}`}>{label}</button>
      ))}
    </div>
  );
}

function useEsc(onClose: () => void) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [onClose]);
}

export function Modal({ title, sub, onClose, children, footer, wide }: { title: string; sub?: string; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEsc(onClose);
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center overflow-y-auto bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`w-full ${wide ? "max-w-xl" : "max-w-md"} rounded-xl bg-white shadow-2xl`}>
        <div className="flex items-start justify-between gap-3 px-5 pt-5">
          <div>
            <h2 className="text-base font-bold">{title}</h2>
            {sub && <p className="mt-1 text-xs text-zinc-500">{sub}</p>}
          </div>
          <button aria-label="Close" onClick={onClose} className="rounded p-1 text-zinc-500 hover:bg-zinc-100"><X className="size-4" /></button>
        </div>
        <div className="px-5 py-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-zinc-100 px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function Drawer({ title, sub, onClose, children, footer, wide }: { title: string; sub?: string; onClose: () => void; children: ReactNode; footer: ReactNode; wide?: boolean }) {
  useEsc(onClose);
  return (
    <div className="fixed inset-0 z-[60] flex justify-end bg-black/50" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside role="dialog" aria-modal="true" aria-label={title} className={`flex h-full w-full ${wide ? "max-w-md" : "max-w-sm"} flex-col bg-white shadow-2xl`}>
        <div className="flex items-start justify-between border-b border-zinc-100 px-5 py-4">
          <div>
            <h2 className="text-base font-bold">{title}</h2>
            {sub && <p className="mt-1 text-xs text-zinc-500">{sub}</p>}
          </div>
          <button aria-label="Close" onClick={onClose} className="rounded p-1 text-zinc-500 hover:bg-zinc-100"><X className="size-4" /></button>
        </div>
        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-4">{children}</div>
        <div className="flex items-center gap-2 border-t border-zinc-100 px-5 py-3">{footer}</div>
      </aside>
    </div>
  );
}

export function Choice({ active, title, sub, onClick, dot }: { active: boolean; title: string; sub: string; onClick: () => void; dot?: string }) {
  return (
    <button onClick={onClick} className={`block w-full rounded-lg border px-3 py-2.5 text-left transition ${active ? "border-primary bg-sky-50 ring-1 ring-primary/40" : "border-zinc-200 hover:bg-zinc-50"}`}>
      <span className="flex items-center gap-2 text-sm font-semibold">{dot && <span className={`size-2 rounded-full ${dot}`} />}{title}</span>
      <span className="mt-0.5 block text-xs text-zinc-500">{sub}</span>
    </button>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block text-xs font-semibold text-zinc-700">{label}<div className="mt-1 font-normal">{children}</div></label>;
}
export const inputCls = "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-sm placeholder:text-zinc-400 focus:border-primary focus:outline-none";

export function DataTable({ head, rows, empty = "No records found.", plainHead }: { head: string[]; rows: ReactNode[][]; empty?: string; plainHead?: boolean }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-xs">
        <thead className={`border-b border-zinc-200 ${plainHead ? "text-xs font-semibold text-ink" : "text-[10px] font-bold uppercase tracking-wide text-zinc-600"}`}>
          <tr>{head.map((h) => <th key={h} className="px-4 py-2.5">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-zinc-100">
          {rows.length === 0
            ? <tr><td colSpan={head.length} className="px-4 py-10 text-center text-zinc-500">{empty}</td></tr>
            : rows.map((r, i) => <tr key={i} className="hover:bg-zinc-50">{r.map((c, j) => <td key={j} className="px-4 py-3 align-middle">{c}</td>)}</tr>)}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- "Are you sure?" dialog ---------- */
export type ConfirmOpts = { title: string; body?: string; confirmLabel?: string; tone?: "danger" | "primary"; noLog?: boolean };

export function ConfirmDialog({ opts, onResult }: { opts: ConfirmOpts; onResult: (ok: boolean) => void }) {
  useEsc(() => onResult(false));
  const danger = opts.tone !== "primary";
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onResult(false)}>
      <div role="alertdialog" aria-modal="true" aria-label={opts.title} className="w-full max-w-sm rounded-xl bg-white p-5 shadow-2xl">
        <h3 className="text-sm font-bold">{opts.title}</h3>
        {opts.body && <p className="mt-1 text-xs text-zinc-600">{opts.body}</p>}
        <div className="mt-4 flex justify-end gap-2">
          <Btn variant="ghost" className="h-8 text-xs" onClick={() => onResult(false)}>Cancel</Btn>
          <button type="button" autoFocus onClick={() => onResult(true)}
            className={`inline-flex h-8 items-center rounded-md px-4 text-xs font-semibold text-white ${danger ? "bg-rose-600 hover:bg-rose-700" : "bg-primary hover:bg-primary-700"}`}>{opts.confirmLabel ?? "Confirm"}</button>
        </div>
      </div>
    </div>
  );
}

/** const { confirm, dialog } = useConfirm();  ...  if (await confirm({ title: "Delete?" })) doIt();  ...  render {dialog} once. */
export function useConfirm() {
  const [st, setSt] = useState<{ opts: ConfirmOpts; resolve: (ok: boolean) => void } | null>(null);
  const busy = useRef(false);
  // A second ask while one is already showing (e.g. Esc pressed twice) resolves to "no" instead of stacking dialogs.
  const confirm = useCallback((opts: ConfirmOpts) => new Promise<boolean>((resolve) => { if (busy.current) return resolve(false); busy.current = true; setSt({ opts, resolve }); }), []);
  const dialog = st ? <ConfirmDialog opts={st.opts} onResult={(ok) => { busy.current = false; if (ok && !st.opts.noLog && window.location.pathname.startsWith("/admin")) trackAdmin(`${st.opts.confirmLabel ?? "Confirmed"}: ${st.opts.title.replace(/\?$/, "")}`); st.resolve(ok); setSt(null); }} /> : null;
  return { confirm, dialog };
}
