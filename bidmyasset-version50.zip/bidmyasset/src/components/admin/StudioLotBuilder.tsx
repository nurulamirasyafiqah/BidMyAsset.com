"use client";

import { useMemo, useState, type ReactNode } from "react";
import { Clock, Download, Pause, Play, Plus, Search, Trash2, Upload } from "lucide-react";
import { Btn, Field, inputCls, Toggle } from "@/components/admin/ui";
import { Confirm, Overlay } from "@/components/admin/StudioParts";
import { ImageManager } from "@/components/admin/ImageManager";
import { deleteLots, saveLot, setAuctionPaused, studio, lotPayload, importLotsSheet, importLotImagesZip, staggerLots, reloadLots, ImportError } from "@/lib/studioApi";
import { downloadLotTemplate } from "@/lib/lotTemplate";
import { consignors, type StudioAuction, type StudioLot } from "@/lib/admin";
import { useCategoryLibrary } from "@/lib/useCategories";

type Tab = "Draft" | "Live" | "Closed";
const TAB_STATUS: Record<Tab, StudioLot["status"]> = { Draft: "Draft", Live: "Active", Closed: "Closed" };
const BULK = [["category", "Category", "Assign a new subcategory to every selected lot."], ["quantity", "Quantity", "Set an inventory quantity for all selected lots."], ["pricing", "Pricing", "Update financial terms on the selected lots."], ["schedule", "Schedule", "Align closing dates and times across selected lots."], ["meta", "Meta", "Apply new hashtags or highlights across the selection."], ["increment", "Increment strategy", "Adjust increment profile for the selected lots."], ["consignor", "Consignor", "Assign consignor for all selected lots."], ["features", "Features", "Queue feature notes to append or replace on selected lots."]] as const;
type BulkKey = (typeof BULK)[number][0];
const dot = (l: StudioLot) => (!l.category ? "bg-rose-500" : !l.consignor ? "bg-amber-500" : "bg-sky-500");
const num = (v: string) => (v === "" ? 0 : Number(v));

type Tier = { from: number; increment: number };
const sortTiers = (t: Tier[]) => [...t].sort((a, b) => a.from - b.from);
/** "" when the tiers are usable: every increment above 0, no two tiers starting at the same amount. */
const tierError = (t?: Tier[]) => {
  if (!t?.length) return "";
  if (t.some((x) => !(x.increment > 0))) return "Every tier needs an increment above 0.";
  if (t.some((x) => !(x.from >= 0))) return "A tier can’t start below 0.";
  if (new Set(t.map((x) => x.from)).size !== t.length) return "Two tiers start at the same amount.";
  return "";
};
/** A lot with tiers mirrors the first tier in its plain increment (the server does the same). */
const withTiers = (t?: Tier[]): Partial<StudioLot> => ({ tiers: t, ...(t?.length ? { increment: sortTiers(t)[0].increment } : {}) });
const companyTiers = (): Tier[] => (studio.companyBid?.tiers ?? []).map((x) => { const r = x as { from?: unknown; increment?: unknown }; return { from: Number(r.from), increment: Number(r.increment) }; }).filter((x) => x.increment > 0 && x.from >= 0);
const fmtMoney = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 2 });

function Seg<T extends string>({ value, onChange, opts }: { value: T; onChange: (v: T) => void; opts: [T, string][] }) {
  return <div role="radiogroup" className="inline-flex rounded-md border border-zinc-300 p-0.5 text-[11px] font-semibold">{opts.map(([k, l]) => <button key={k} type="button" role="radio" aria-checked={value === k} onClick={() => onChange(k)} className={`rounded px-3 py-1 ${value === k ? "bg-primary text-white" : "text-zinc-600 hover:bg-zinc-100"}`}>{l}</button>)}</div>;
}

/** Tiered increments: the step that applies depends on the current bid. */
function TierEditor({ tiers, onChange }: { tiers: Tier[]; onChange: (t: Tier[]) => void }) {
  const co = companyTiers();
  const set = (i: number, p: Partial<Tier>) => onChange(tiers.map((t, k) => (k === i ? { ...t, ...p } : t)));
  const err = tierError(tiers);
  const sorted = sortTiers(tiers).filter((t) => t.increment > 0);
  return (
    <div className="rounded-lg border border-zinc-200 p-3">
      <div className="grid grid-cols-[1fr_1fr_28px] gap-2 text-[10px] font-bold uppercase tracking-wide text-zinc-500"><span>When the bid reaches</span><span>Increment</span><span /></div>
      {tiers.map((t, i) => (
        <div key={i} className="mt-1.5 grid grid-cols-[1fr_1fr_28px] items-center gap-2">
          <input type="number" min={0} aria-label={`Tier ${i + 1} starts at`} className={inputCls} value={t.from} onChange={(e) => set(i, { from: num(e.target.value) })} />
          <input type="number" min={0} aria-label={`Tier ${i + 1} increment`} className={inputCls} value={t.increment || ""} placeholder="e.g. 500" onChange={(e) => set(i, { increment: num(e.target.value) })} />
          <button type="button" aria-label={`Remove tier ${i + 1}`} disabled={tiers.length <= 1} onClick={() => onChange(tiers.filter((_, k) => k !== i))} className="grid size-7 place-items-center rounded text-zinc-500 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-30"><Trash2 className="size-3.5" /></button>
        </div>
      ))}
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <Btn variant="ghost" className="h-7 text-[11px]" onClick={() => onChange([...tiers, { from: Math.max(0, ...tiers.map((t) => t.from)) + 1000, increment: tiers[tiers.length - 1]?.increment ?? 0 }])}><Plus className="size-3" />Add tier</Btn>
        {co.length > 0 && <Btn variant="ghost" className="h-7 text-[11px]" onClick={() => onChange(co)}>Use company tiers</Btn>}
      </div>
      {err ? <p role="alert" className="mt-2 text-[11px] text-rose-600">{err}</p> : sorted.length > 0 && <p className="mt-2 text-[11px] text-zinc-500">{sorted.map((t, i) => `${i === 0 && t.from > 0 ? "Below " + fmtMoney(t.from) + " and from " : "From "}${fmtMoney(t.from)}: +${fmtMoney(t.increment)}`).join(" · ")}</p>}
    </div>
  );
}

function Notice({ title, tone, onClose, children }: { title: string; tone: "ok" | "warn"; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className="flex max-h-[80vh] w-full max-w-lg flex-col rounded-xl bg-white p-5 shadow-2xl">
        <h3 className={`text-sm font-bold ${tone === "ok" ? "text-emerald-700" : "text-rose-700"}`}>{title}</h3>
        <div className="mt-2 min-h-0 flex-1 overflow-y-auto text-xs text-zinc-700">{children}</div>
        <div className="mt-4 flex justify-end"><Btn variant="solid" className="h-8 text-xs" onClick={onClose}>OK</Btn></div>
      </div>
    </div>
  );
}

/** Spreads closing times by a fixed gap, ending at the auction's end (the bid pipeline only honours lot times earlier than the auction's). */
function StaggerModal({ auction, lots, sel, onClose, onDone }: { auction: StudioAuction; lots: StudioLot[]; sel: string[]; onClose: () => void; onDone: (n: number) => void }) {
  const info = (auction.builder?.info ?? {}) as Record<string, unknown>;
  const open = lots.filter((l) => l.status !== "Closed").sort((a, b) => a.no - b.no);
  const picked = open.filter((l) => sel.includes(l.id));
  const [scope, setScope] = useState<"sel" | "all">(picked.length > 1 ? "sel" : "all");
  const [gap, setGap] = useState(String(info.gap ?? "5"));
  const [unit, setUnit] = useState<"Seconds" | "Minutes" | "Hours">(info.unit === "Seconds" || info.unit === "Hours" ? info.unit : "Minutes");
  const [reverse, setReverse] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const target = scope === "sel" ? picked : open;
  const g = Number(gap), secs = g * { Seconds: 1, Minutes: 60, Hours: 3600 }[unit];
  const tz = auction.tz ?? "Asia/Kuala_Lumpur";
  const start = Date.parse(auction.startsAtIso ?? ""), end = Date.parse(auction.endsAtIso ?? "");
  const n = target.length;
  const at = (k: number) => end - (reverse ? k : n - 1 - k) * secs * 1000;
  const earliest = n ? at(reverse ? n - 1 : 0) : NaN;
  const fmt = (ms: number) => new Intl.DateTimeFormat("en-GB", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).format(new Date(ms)).replace(",", " ·");
  const problem = !studio.live ? "Staggering saves to the database, and the backend is not reachable right now."
    : !n ? "There are no open lots to stagger."
    : !(g > 0) || !Number.isFinite(secs) ? "Enter a gap above 0."
    : secs > 7 * 86400 ? "The gap can’t be longer than 7 days."
    : earliest < start ? `${n} lots × this gap doesn’t fit: the first lot would close before the auction starts.`
    : earliest <= Date.now() ? "This gap would make a lot close in the past." : "";
  const preview = target.length <= 5 ? target.map((l, k) => [l, k] as const) : [...target.slice(0, 3).map((l, k) => [l, k] as const), null, ...target.slice(-2).map((l, k) => [l, n - 2 + k] as const)];
  const go = async () => {
    setBusy(true); setErr("");
    try { const r = await staggerLots(auction, { ids: target.map((l) => l.id), gap: g, unit, reverse }); onDone(r.lots); }
    catch (e) { setErr(e instanceof Error ? e.message : "Could not stagger the lots"); setBusy(false); }
  };
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && !busy && onClose()}>
      <div role="dialog" aria-modal="true" aria-label="Staggered closing" className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-xl bg-white p-5 shadow-2xl">
        <h3 className="text-sm font-bold">Staggered closing</h3>
        <p className="mt-1 text-xs text-zinc-600">Lots close one after another, a fixed gap apart, in lot-number order. {reverse ? "Lot 1 closes with the auction and each later lot closes earlier." : "The last lot closes with the auction and each earlier lot closes sooner."}</p>
        <div className="mt-3 space-y-3">
          <div><p className="text-xs font-semibold text-zinc-700">Apply to</p><div className="mt-1"><Seg value={scope} onChange={setScope} opts={[["sel", `Selected lots (${picked.length})`], ["all", `All open lots (${open.length})`]]} /></div></div>
          <div className="grid grid-cols-[1fr_130px] gap-3">
            <Field label="Gap between lots"><input type="number" min={1} className={inputCls} value={gap} onChange={(e) => setGap(e.target.value)} /></Field>
            <Field label="Unit"><select className={inputCls} value={unit} onChange={(e) => setUnit(e.target.value as typeof unit)}><option>Seconds</option><option>Minutes</option><option>Hours</option></select></Field>
          </div>
          <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={reverse} onChange={(e) => setReverse(e.target.checked)} />Lot 1 closes last (at the auction end)</label>
          {!problem && n > 0 && <ul className="divide-y divide-zinc-100 rounded border border-zinc-200 text-[11px]">{preview.map((x, i) => x ? <li key={x[0].id} className="flex justify-between px-2 py-1"><span>Lot {x[0].no}</span><span className="text-zinc-600">{fmt(at(x[1]))}</span></li> : <li key={`gap${i}`} className="px-2 py-1 text-center text-zinc-400">…</li>)}</ul>}
          {(problem || err) && <p role="alert" className="text-[11px] text-rose-600">{err || problem}</p>}
          <p className="text-[11px] text-zinc-500">Times are in {tz}. Lots already closed are left alone. You can still change any lot’s closing time afterwards.</p>
        </div>
        <div className="mt-4 flex justify-end gap-2"><Btn variant="ghost" className="h-8 text-xs" onClick={onClose} disabled={busy}>Cancel</Btn><Btn variant="solid" className="h-8 text-xs" disabled={!!problem || busy} onClick={go}>{busy ? "Applying…" : `Stagger ${n} lot${n === 1 ? "" : "s"}`}</Btn></div>
      </div>
    </div>
  );
}

function Sec({ title, sub, children }: { title: string; sub?: string; children: ReactNode }) {
  return <section className="mt-5"><h3 className="text-sm font-bold">{title}</h3>{sub && <p className="text-[11px] text-zinc-500">{sub}</p>}<div className="mt-2 rounded-xl border border-zinc-200 p-4">{children}</div></section>;
}

export function LotBuilder({ auction, lots: initial, initialSel, onClose, onChange }: { auction: StudioAuction; lots: StudioLot[]; initialSel?: string; onClose: () => void; onChange: (l: StudioLot[]) => void }) {
  const [lots, setLotsState] = useState(initial);
  const lib = useCategoryLibrary();
  const setLots = (fn: (l: StudioLot[]) => StudioLot[]) => setLotsState((p) => { const n = fn(p); onChange(n); return n; });
  const first = initial.find((l) => l.id === initialSel);
  const [tab, setTab] = useState<Tab>(first ? (first.status === "Active" ? "Live" : first.status === "Closed" ? "Closed" : "Draft") : initial.some((l) => l.status === "Active") ? "Live" : "Draft");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string[]>(first ? [first.id] : initial[0] ? [initial[0].id] : []);
  const [paused, setPaused] = useState(!!auction.paused);
  const canPause = auction.status === "RUNNING"; // same rule as the Pause button on the auction page
  const [confirm, setConfirm] = useState(false);
  const [toast, setToast] = useState("");
  const [bulkOn, setBulkOn] = useState<Partial<Record<BulkKey, boolean>>>({});
  const [bulk, setBulk] = useState({ category: "", quantity: "1", startBid: "", reserve: "", closeDate: "", closeTime: "", hashtags: "", highlights: "", increment: "", consignor: "", features: "" });
  const [incMode, setIncMode] = useState<"constant" | "tiered">("constant");
  const [bulkTiers, setBulkTiers] = useState<Tier[]>(() => { const c = companyTiers(); return c.length ? c : [{ from: 0, increment: 0 }]; });
  const [busy, setBusy] = useState("");
  const [stagger, setStagger] = useState(false);
  const [report, setReport] = useState<null | { title: string; tone: "ok" | "warn"; lines: string[]; rows?: { row: number; message: string }[]; lists?: { label: string; items: string[] }[] }>(null);

  const inTab = useMemo(() => lots.filter((l) => l.status === TAB_STATUS[tab] && `${l.title} ${l.no}`.toLowerCase().includes(q.toLowerCase())), [lots, tab, q]);
  const count = (t: Tab) => lots.filter((l) => l.status === TAB_STATUS[t]).length;
  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };
  const togglePause = async () => {
    try { await setAuctionPaused(auction, !paused); setPaused(!paused); flash(paused ? "Auction resumed." : "Auction paused. Bidders can't place bids until you resume."); }
    catch (e) { flash(e instanceof Error ? e.message : "Could not change the pause state"); }
  };
  const toggle = (id: string) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const allSel = inTab.length > 0 && inTab.every((l) => sel.includes(l.id));
  const cur = sel.length === 1 ? lots.find((l) => l.id === sel[0]) : undefined;
  const patch = (id: string, p: Partial<StudioLot>) => setLots((l) => l.map((x) => (x.id === id ? { ...x, ...p } : x)));

  const addLot = async () => {
    const no = lots.reduce((m, l) => Math.max(m, l.no), 0) + 1;
    let id = `${auction.id}-${no}-${Date.now()}`, lotNo = no;
    if (studio.live) { // create the real lot first so photos can be attached to it
      try { const r = await saveLot({ auction: auction.id, title: `New lot ${no}` }); id = r.id; lotNo = r.lotNumber; }
      catch (e) { return flash(e instanceof Error ? e.message : "Could not add the lot"); }
    }
    const n: StudioLot = { id, no: lotNo, title: `New lot ${no}`, sku: "", qty: 1, category: "", address: "", status: "Draft", closes: "—", closeDate: "", closeTime: "", startBid: 0, reserve: 0, increment: 0, overview: "", hashtags: "", highlights: "", consignor: "" };
    setLots((l) => [...l, n]); setTab("Draft"); setSel([n.id]);
  };
  const del = async () => {
    if (studio.live) { try { await deleteLots(sel); } catch (e) { setConfirm(false); return flash(e instanceof Error ? e.message : "Could not delete"); } }
    setLots((l) => l.filter((x) => !sel.includes(x.id))); setSel([]); setConfirm(false);
  };
  // persist lot fields to PocketBase (no-op when the backend is unreachable)
  const persist = (ls: StudioLot[]) => {
    if (!studio.live) return Promise.resolve([]);
    for (const l of ls) { const e = tierError(l.tiers); if (e) return Promise.reject(new Error(`Lot ${l.no}: ${e}`)); }
    return Promise.all(ls.map((l) => saveLot(lotPayload({ ...l, tiers: l.tiers && sortTiers(l.tiers) }, auction))));
  };
  // re-read the lots after the server changed them (import / stagger)
  const refresh = async () => { const fresh = await reloadLots(auction); auction.lots = fresh.length; setLots(() => fresh); setSel((s) => s.filter((id) => fresh.some((l) => l.id === id))); };
  const needLive = () => { if (studio.live) return true; setReport({ title: "Not available offline", tone: "warn", lines: ["The database could not be reached, so there is nothing to import into."] }); return false; };
  const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? "" : "s"}`;
  const onSheet = async (file?: File) => {
    if (!file || !needLive()) return;
    setBusy("Importing spreadsheet…");
    try {
      const r = await importLotsSheet(auction, file); await refresh(); setTab("Draft");
      setReport({ title: "Spreadsheet imported", tone: "ok", lines: [`${plural(r.created, "lot")} added as drafts.`, ...(r.updated ? [`${plural(r.updated, "existing lot")} updated.`] : []), ...(r.skipped ? [`${plural(r.skipped, "empty or note row")} skipped.`] : [])] });
    } catch (e) { setReport({ title: "Spreadsheet not imported", tone: "warn", lines: [e instanceof Error ? e.message : "Could not import the spreadsheet"], rows: e instanceof ImportError ? e.rows : [] }); }
    finally { setBusy(""); }
  };
  const onZip = async (file?: File) => {
    if (!file || !needLive()) return;
    setBusy("Importing photos…");
    try {
      const r = await importLotImagesZip(auction, file); await refresh();
      setReport({ title: r.images ? "Photos imported" : "No photos were added", tone: r.images ? "ok" : "warn",
        lines: [r.images ? `${plural(r.images, "photo")} added to ${plural(r.lots, "lot")}.` : "None of the files matched a lot. Name each photo or its folder after the lot number or SKU, e.g. 12.jpg, 12_2.jpg, Lot 12/front.jpg or ABC-123.jpg."],
        lists: [{ label: "No matching lot", items: r.unmatched }, { label: "Skipped", items: r.skipped }].filter((x) => x.items.length > 0) });
    } catch (e) { setReport({ title: "Photos not imported", tone: "warn", lines: [e instanceof Error ? e.message : "Could not import the ZIP"] }); }
    finally { setBusy(""); }
  };
  const applyBulk = () => {
    const on = BULK.filter(([k]) => bulkOn[k]);
    if (!on.length) return;
    let tiers: Tier[] | undefined;
    if (bulkOn.increment) {
      if (incMode === "tiered") { const e = tierError(bulkTiers); if (e) return flash(e); tiers = sortTiers(bulkTiers); }
      else if (!(num(bulk.increment) > 0)) return flash("Enter an increment above 0.");
    }
    const next = lots.map((x) => {
      if (!sel.includes(x.id)) return x;
      const p: Partial<StudioLot> = {};
      if (bulkOn.category && bulk.category) p.category = bulk.category;
      if (bulkOn.quantity) p.qty = num(bulk.quantity) || 1;
      if (bulkOn.pricing) { if (bulk.startBid) p.startBid = num(bulk.startBid); if (bulk.reserve) p.reserve = num(bulk.reserve); }
      if (bulkOn.schedule && bulk.closeDate) { p.closeDate = bulk.closeDate; p.closeTime = bulk.closeTime || x.closeTime; p.closes = `${bulk.closeDate.split("-").reverse().join("/")} · ${p.closeTime}`; }
      if (bulkOn.meta) { if (bulk.hashtags) p.hashtags = bulk.hashtags; if (bulk.highlights) p.highlights = bulk.highlights; }
      if (bulkOn.increment) { if (tiers) Object.assign(p, withTiers(tiers)); else Object.assign(p, { increment: num(bulk.increment), tiers: undefined }); } // a constant increment replaces any tiers
      if (bulkOn.consignor && bulk.consignor) p.consignor = bulk.consignor;
      if (bulkOn.features && bulk.features) p.overview = x.overview ? `${x.overview}\n${bulk.features}` : bulk.features;
      return { ...x, ...p };
    });
    setLots(() => next); setBulkOn({});
    persist(next.filter((x) => sel.includes(x.id))).then(() => flash(`Updated ${sel.length} lots`)).catch((e) => flash(e instanceof Error ? e.message : "Could not save"));
  };

  return (
    <Overlay title="Lot Builder" sub={<>Auction: <b>{auction.title}</b> <span className="ml-2 rounded bg-sky-500 px-1.5 text-[10px] font-bold">Lots: {lots.length}</span></>} onClose={onClose}
      actions={canPause && <button onClick={() => void togglePause()} className="inline-flex items-center gap-1.5 rounded-md bg-[#1b3a8f] px-3 py-1 text-xs font-semibold hover:bg-[#2447b0]">{paused ? <Play className="size-3.5" /> : <Pause className="size-3.5" />}{paused ? "Resume Auction" : "Pause Auction"}</button>}>
      <div className="grid h-full grid-cols-[280px_1fr] bg-white">
        <aside className="flex min-h-0 flex-col border-r border-zinc-200 bg-zinc-50 p-3">
          <label className="relative block"><Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-zinc-400" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search lots..." aria-label="Search lots" className="h-8 w-full rounded-md border border-zinc-300 bg-white pl-8 pr-2 text-xs" /></label>
          <div className="mt-2 grid grid-cols-3 text-[10px] font-semibold" role="tablist">{(["Draft", "Live", "Closed"] as Tab[]).map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`py-1.5 ${tab === t ? "bg-sky-500 text-white" : "bg-zinc-100 text-zinc-500 hover:bg-zinc-200"}`}>{t.toUpperCase()} ({count(t)})</button>)}</div>
          <div className="mt-2 flex items-center gap-3 text-[10px] text-zinc-600"><span className="flex items-center gap-1"><i className="size-2 rounded-full bg-rose-500" />Required</span><span className="flex items-center gap-1"><i className="size-2 rounded-full bg-amber-500" />Attention</span><span className="flex items-center gap-1"><i className="size-2 rounded-full bg-sky-500" />Complete</span></div>
          <label className="mt-2 flex items-center justify-between border-b border-zinc-200 pb-2 text-[11px]"><span className="flex items-center gap-2"><input type="checkbox" checked={allSel} onChange={() => setSel(allSel ? [] : inTab.map((l) => l.id))} />Select all in view</span><span className="text-zinc-500">{sel.length} selected</span></label>
          <ul className="mt-2 min-h-0 flex-1 space-y-2 overflow-y-auto">
            {inTab.length === 0 && <li className="py-6 text-center text-[11px] text-zinc-500">No lots in this view.</li>}
            {inTab.map((l) => (
              <li key={l.id}><div className={`rounded-lg border bg-white p-2.5 text-left ${sel.includes(l.id) ? "border-sky-400 ring-1 ring-sky-300" : "border-zinc-200"}`}>
                <div className="flex items-start gap-2"><input type="checkbox" aria-label={`Select lot ${l.no}`} className="mt-0.5" checked={sel.includes(l.id)} onChange={() => toggle(l.id)} />
                  <button onClick={() => setSel([l.id])} className="min-w-0 flex-1 text-left"><span className="flex items-center justify-between"><span className="text-[10px] font-bold text-zinc-500">LOT {l.no}</span><span className="flex items-center gap-1 rounded bg-rose-50 px-1.5 text-[9px] font-semibold text-rose-600"><i className={`size-1.5 rounded-full ${dot(l)}`} />Required</span></span>
                    <span className="block text-xs font-semibold leading-snug">{l.title}</span><span className="mt-1 flex justify-between text-[10px] text-zinc-500"><span>{l.category || "Category not assigned"}</span><span>{l.status}</span></span></button></div></div></li>
            ))}
          </ul>
        </aside>

        <section className="flex min-h-0 flex-col">
          <div className="flex flex-wrap items-center gap-2 border-b border-zinc-200 px-4 py-2">
            <div className="flex items-center gap-1 rounded-lg border border-sky-200 bg-sky-50/50 p-1"><span className="px-1 text-[9px] font-bold text-sky-700">BUILDER</span>
              <Btn variant="solid" className="h-7 px-2.5 text-[11px]" onClick={addLot}><Plus className="size-3" />Add lot</Btn>
              <Btn variant="outline" className="h-7 px-2.5 text-[11px]" onClick={downloadLotTemplate}><Download className="size-3" />Template</Btn>
              <label className={`inline-flex h-7 items-center gap-1 rounded-md border border-primary/40 bg-white px-2.5 text-[11px] font-semibold text-primary ${busy ? "pointer-events-none opacity-50" : "cursor-pointer hover:bg-primary/5"}`}><Upload className="size-3" />Spreadsheet<input type="file" accept=".csv,.xlsx" className="sr-only" disabled={!!busy} onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; onSheet(f); }} /></label>
              <label className={`inline-flex h-7 items-center gap-1 rounded-md border border-primary/40 bg-white px-2.5 text-[11px] font-semibold text-primary ${busy ? "pointer-events-none opacity-50" : "cursor-pointer hover:bg-primary/5"}`}><Upload className="size-3" />Image ZIP<input type="file" accept=".zip" className="sr-only" disabled={!!busy} onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; onZip(f); }} /></label></div>
            <div className="flex items-center gap-1 rounded-lg border border-zinc-200 p-1"><span className="px-1 text-[9px] font-bold text-zinc-500">LIFECYCLE</span><Btn variant="outline" className="h-7 px-2.5 text-[11px]" onClick={() => setStagger(true)}><Clock className="size-3" />Staggered closing</Btn></div>
            <div className="flex items-center gap-1 rounded-lg border border-rose-200 p-1"><span className="px-1 text-[9px] font-bold text-rose-600">DANGER</span><button disabled={!sel.length} onClick={() => setConfirm(true)} className="inline-flex h-7 items-center gap-1 rounded-md bg-rose-600 px-2.5 text-[11px] font-semibold text-white hover:bg-rose-700 disabled:opacity-40"><Trash2 className="size-3" />{sel.length > 1 ? "Delete lots" : "Delete lot"}</button></div>
            {busy && <span role="status" className="ml-auto rounded bg-sky-50 px-2 py-1 text-[11px] text-sky-700">{busy}</span>}
            {!busy && toast && <span role="status" className="ml-auto rounded bg-emerald-50 px-2 py-1 text-[11px] text-emerald-700">{toast}</span>}
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
            {sel.length === 0 && <p className="py-20 text-center text-sm text-zinc-500">Select a lot to edit it, or tick several lots to update them together.</p>}

            {sel.length > 1 && (
              <div className="mx-auto max-w-3xl space-y-3">
                <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-4 text-xs"><p className="font-semibold text-sky-800"><span className="mr-2 inline-grid size-5 place-items-center rounded-full bg-sky-500 text-[10px] text-white">{sel.length}</span>{sel.length} lots selected for bulk update</p><p className="mt-1 text-sky-700">Enable a section below to queue changes. Only toggled sections with new values will be applied.</p>
                  <ul className="mt-2 divide-y divide-sky-100 rounded border border-sky-100 bg-white">{lots.filter((l) => sel.includes(l.id)).map((l) => <li key={l.id} className="flex justify-between px-2 py-1 text-[11px]"><span>Lot {l.no} : {l.title}</span><span className="rounded bg-rose-50 px-1.5 text-[9px] text-rose-600">Required</span></li>)}</ul></div>
                {BULK.map(([k, t, s]) => (
                  <section key={k} className="rounded-xl border border-zinc-200 p-4"><div className="flex items-center justify-between"><div><h3 className="text-sm font-bold">{t}</h3><p className="text-[11px] text-zinc-500">{s}</p></div><Toggle on={!!bulkOn[k]} onChange={(v) => setBulkOn((p) => ({ ...p, [k]: v }))} label={`Bulk update ${t}`} /></div>
                    {!bulkOn[k] ? <p className="mt-1 text-[11px] text-zinc-500">Toggle this section on to queue changes.</p> : (
                      <div className="mt-3 grid gap-3 sm:grid-cols-2">
                        {k === "category" && <Field label="Category"><select className={inputCls} value={bulk.category} onChange={(e) => setBulk({ ...bulk, category: e.target.value })}><option value="">Select category</option>{Object.entries(lib).map(([g, items]) => <optgroup key={g} label={g}>{items.map((i) => <option key={i} value={i}>{i}</option>)}</optgroup>)}</select></Field>}
                        {k === "quantity" && <Field label="Quantity"><input type="number" min={1} className={inputCls} value={bulk.quantity} onChange={(e) => setBulk({ ...bulk, quantity: e.target.value })} /></Field>}
                        {k === "pricing" && <><Field label="Starting bid"><input type="number" min={0} className={inputCls} value={bulk.startBid} onChange={(e) => setBulk({ ...bulk, startBid: e.target.value })} /></Field><Field label="Reserve price"><input type="number" min={0} className={inputCls} value={bulk.reserve} onChange={(e) => setBulk({ ...bulk, reserve: e.target.value })} /></Field></>}
                        {k === "schedule" && <><Field label="End date"><input type="date" className={inputCls} value={bulk.closeDate} onChange={(e) => setBulk({ ...bulk, closeDate: e.target.value })} /></Field><Field label="End time"><input type="time" step={1} className={inputCls} value={bulk.closeTime} onChange={(e) => setBulk({ ...bulk, closeTime: e.target.value })} /></Field></>}
                        {k === "meta" && <><Field label="Hashtags"><input className={inputCls} placeholder="#tag1, #tag2" value={bulk.hashtags} onChange={(e) => setBulk({ ...bulk, hashtags: e.target.value })} /></Field><Field label="Highlights"><input className={inputCls} placeholder="Key selling points, separated by commas" value={bulk.highlights} onChange={(e) => setBulk({ ...bulk, highlights: e.target.value })} /></Field></>}
                        {k === "increment" && <div className="space-y-3 sm:col-span-2"><div><p className="text-xs font-semibold text-zinc-700">Strategy</p><div className="mt-1"><Seg value={incMode} onChange={setIncMode} opts={[["constant", "Constant increment"], ["tiered", "Tiered increments"]]} /></div></div>
                          {incMode === "constant" ? <Field label="Constant increment"><input type="number" min={0} className={inputCls} value={bulk.increment} onChange={(e) => setBulk({ ...bulk, increment: e.target.value })} /></Field> : <TierEditor tiers={bulkTiers} onChange={setBulkTiers} />}
                          <p className="text-[11px] text-zinc-500">{incMode === "constant" ? "Replaces any tiers on the selected lots." : "Replaces the increment on the selected lots; the step depends on the current bid."}</p></div>}
                        {k === "consignor" && <Field label="Consignor"><select className={inputCls} value={bulk.consignor} onChange={(e) => setBulk({ ...bulk, consignor: e.target.value })}><option value="">Select consignor</option>{consignors.map((c) => <option key={c.name}>{c.name}</option>)}</select></Field>}
                        {k === "features" && <div className="sm:col-span-2"><Field label="Feature notes (appended)"><textarea rows={3} className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm" value={bulk.features} onChange={(e) => setBulk({ ...bulk, features: e.target.value })} /></Field></div>}
                      </div>)}
                  </section>
                ))}
                <section className="rounded-xl border border-zinc-200 bg-zinc-50 p-4"><p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">Consignors</p><ul className="mt-2 divide-y divide-zinc-200 rounded border border-zinc-200 bg-white">{consignors.map((c) => <li key={c.name} className="flex items-center gap-2 px-3 py-1.5 text-xs"><span className="grid size-5 place-items-center rounded bg-zinc-100 text-[9px] font-bold">{c.initials}</span>{c.name}</li>)}</ul></section>
                <div className="sticky bottom-0 flex justify-end gap-2 border-t border-zinc-100 bg-white py-3"><Btn variant="ghost" className="h-8 text-xs" onClick={() => { setBulkOn({}); }}>Reset</Btn><Btn variant="solid" className="h-8 text-xs" disabled={!Object.values(bulkOn).some(Boolean)} onClick={applyBulk}>Apply changes</Btn></div>
              </div>
            )}

            {cur && (
              <div className="mx-auto max-w-3xl">
                <h3 className="text-sm font-bold">Basic details</h3><p className="text-[11px] text-zinc-500">Title, identifiers, and categorisation for the lot.</p>
                <div className="mt-2 space-y-3 rounded-xl border border-zinc-200 p-4">
                  <Field label="Title"><input className={inputCls} value={cur.title} onChange={(e) => patch(cur.id, { title: e.target.value })} /></Field>
                  <div className="grid gap-3 sm:grid-cols-2"><Field label="Lot number"><input type="number" min={1} className={inputCls} value={cur.no} onChange={(e) => patch(cur.id, { no: num(e.target.value) })} /></Field><Field label="SKU"><input className={inputCls} placeholder="SKU or inventory code" value={cur.sku} onChange={(e) => patch(cur.id, { sku: e.target.value })} /></Field>
                    <Field label="Quantity"><input type="number" min={1} className={inputCls} value={cur.qty} onChange={(e) => patch(cur.id, { qty: num(e.target.value) })} /></Field>
                    <Field label="Category"><select className={inputCls} value={cur.category} onChange={(e) => patch(cur.id, { category: e.target.value })}><option value="">Select category</option>{cur.category && !Object.values(lib).some((l) => l.includes(cur.category)) && <option>{cur.category}</option>}{Object.entries(lib).map(([g, items]) => <optgroup key={g} label={g}>{items.map((i) => <option key={i}>{i}</option>)}</optgroup>)}</select></Field></div>
                  <Field label="Address"><input className={inputCls} placeholder="Select address" value={cur.address} onChange={(e) => patch(cur.id, { address: e.target.value })} /></Field>
                </div>
                <Sec title="Description" sub="Inspection notes, highlights, and pickup logistics."><Field label="Overview"><textarea rows={6} className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm" value={cur.overview} onChange={(e) => patch(cur.id, { overview: e.target.value })} /></Field></Sec>
                <Sec title="Pricing & increments" sub="Starting price, reserves, and bidding thresholds.">
                  <div className="grid gap-3 sm:grid-cols-2"><Field label="Starting bid"><input type="number" min={0} className={inputCls} value={cur.startBid} onChange={(e) => patch(cur.id, { startBid: num(e.target.value) })} /></Field><Field label="Reserve price"><input type="number" min={0} className={inputCls} value={cur.reserve} onChange={(e) => patch(cur.id, { reserve: num(e.target.value) })} /></Field>
                  </div>
                  <div className="mt-3 space-y-2"><div><p className="text-xs font-semibold text-zinc-700">Increment strategy</p><div className="mt-1"><Seg value={cur.tiers?.length ? "tiered" : "constant"} onChange={(v) => patch(cur.id, v === "tiered" ? withTiers(cur.tiers?.length ? cur.tiers : [{ from: 0, increment: cur.increment }]) : { tiers: undefined })} opts={[["constant", "Constant increment"], ["tiered", "Tiered increments"]]} /></div></div>
                    {cur.tiers?.length ? <TierEditor tiers={cur.tiers} onChange={(t) => patch(cur.id, withTiers(t))} /> : <Field label="Constant increment"><input type="number" min={0} className={inputCls} value={cur.increment} onChange={(e) => patch(cur.id, { increment: num(e.target.value) })} /></Field>}</div>
                  {cur.reserve > 0 && cur.reserve < cur.startBid && <p role="alert" className="mt-2 text-[11px] text-rose-600">Reserve price is lower than the starting bid.</p>}
                </Sec>
                <Sec title="Schedule" sub="Lot closing details align bidding expectations.">
                  <div className="grid gap-3 sm:grid-cols-2"><Field label="End date"><input type="date" className={inputCls} value={cur.closeDate} onChange={(e) => patch(cur.id, { closeDate: e.target.value, closes: `${e.target.value.split("-").reverse().join("/")} · ${cur.closeTime}` })} /></Field>
                    <Field label="End time"><input type="time" step={1} className={inputCls} value={cur.closeTime} onChange={(e) => patch(cur.id, { closeTime: e.target.value, closes: `${cur.closeDate.split("-").reverse().join("/")} · ${e.target.value}` })} /></Field>
                    <Field label="Timezone"><input readOnly className={`${inputCls} bg-zinc-100`} value="Asia/Kuala_Lumpur" /></Field></div>
                </Sec>
                <Sec title="Marketing" sub="Tags and highlights boost discovery.">
                  <div className="grid gap-3 sm:grid-cols-2"><Field label="Hashtags"><input className={inputCls} placeholder="#tag1, #tag2" value={cur.hashtags} onChange={(e) => patch(cur.id, { hashtags: e.target.value })} /></Field><Field label="Highlights"><input className={inputCls} placeholder="Key selling points, separated by commas" value={cur.highlights} onChange={(e) => patch(cur.id, { highlights: e.target.value })} /></Field></div>
                </Sec>
                <Sec title="Consignor" sub="Assign ownership for reporting and settlement."><Field label="Consignor"><select className={inputCls} value={cur.consignor} onChange={(e) => patch(cur.id, { consignor: e.target.value })}><option value="">Select consignor</option>{consignors.map((c) => <option key={c.name}>{c.name}</option>)}</select></Field></Sec>
                <Sec title="Media" sub="Photos shown on the public lot page and lot cards. Saved to the database as soon as you upload."><ImageManager key={cur.id} kind="lot" id={cur.id} images={cur.images ?? []} max={30} onChange={(i) => patch(cur.id, { images: i })} /></Sec>
                <div className="sticky bottom-0 mt-4 flex justify-end border-t border-zinc-100 bg-white py-3"><Btn variant="solid" className="h-8 text-xs" onClick={() => persist([cur]).then(() => flash("Changes saved")).catch((e) => flash(e instanceof Error ? e.message : "Could not save"))}>Save changes</Btn></div>
              </div>
            )}
          </div>
        </section>
      </div>
      {stagger && <StaggerModal auction={auction} lots={lots} sel={sel} onClose={() => setStagger(false)} onDone={async (n) => { setStagger(false); try { await refresh(); flash(`Staggered ${n} lot${n === 1 ? "" : "s"}`); } catch (e) { flash(e instanceof Error ? e.message : "Staggered, but could not reload the lots"); } }} />}
      {report && <Notice title={report.title} tone={report.tone} onClose={() => setReport(null)}>
        {report.lines.map((l, i) => <p key={i} className="mb-1">{l}</p>)}
        {!!report.rows?.length && <ul className="mt-2 divide-y divide-zinc-100 rounded border border-zinc-200">{report.rows.map((r, i) => <li key={i} className="px-2 py-1"><b>Row {r.row}:</b> {r.message}</li>)}</ul>}
        {report.lists?.map((g) => <div key={g.label} className="mt-2"><p className="font-semibold">{g.label} ({g.items.length})</p><ul className="mt-1 max-h-32 overflow-y-auto rounded border border-zinc-200 px-2 py-1 text-[11px] text-zinc-600">{g.items.map((f, i) => <li key={i} className="truncate">{f}</li>)}</ul></div>)}
      </Notice>}
      {confirm && <Confirm title={sel.length > 1 ? "Delete lots" : "Delete lot"} body={`Are you sure you want to delete ${sel.length > 1 ? `these ${sel.length} lots` : "this lot"}? This action cannot be undone.`} confirmLabel="Delete" onCancel={() => setConfirm(false)} onConfirm={del} />}
    </Overlay>
  );
}
