"use client";

import { useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Btn, Card, PageHead } from "@/components/admin/ui";
import { formatPhone } from "@/lib/phone";
import { CountrySelect, StateSelect, useDials, useGeoNames } from "@/components/GeoNames";
import { api } from "@/lib/client-api";
import type { UserProfile } from "@/lib/portal";
import { isUrl } from "@/lib/auctionHouse";
import { NotificationSettings, PreferencesSettings } from "@/components/settings/SettingsPanels";

// Details and password are saved straight to the signed-in user's PocketBase record (same as the bidder portal).

const inputCls = "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/15";
const Lbl = ({ text, children, error }: { text: string; children: ReactNode; error?: string }) => (
  <div>
    <label className="block text-[10px] font-semibold uppercase tracking-wide text-zinc-500">{text}<div className="mt-1 font-normal normal-case tracking-normal text-ink">{children}</div></label>
    {error && <p role="alert" className="mt-1 text-[11px] text-rose-600">{error}</p>}
  </div>
);

type Details = {
  firstName: string; lastName: string; company: string; designation: string; website: string; signatureName: string;
  address1: string; address2: string; city: string; state: string; postalCode: string; country: string;
};
const PERSONAL: [keyof Details, string, string?][] = [
  ["firstName", "First name"], ["lastName", "Last name"], ["company", "Company"], ["designation", "Designation"],
  ["website", "Website", "https://example.com"], ["signatureName", "Signature name"],
];
const ADDRESS: [keyof Details, string][] = [
  ["address1", "Address line 1"], ["address2", "Address line 2"], ["city", "City"], ["state", "State / Province"], ["postalCode", "Postal code"], ["country", "Country"],
];

const toDetails = (p: UserProfile): Details => ({
  firstName: p.firstName, lastName: p.lastName, company: p.company, designation: p.designation, website: p.website, signatureName: p.signatureName,
  address1: p.address1, address2: p.address2, city: p.city, state: p.state, postalCode: p.postalCode, country: p.country,
});

function detailErrors(d: Details): Partial<Record<keyof Details, string>> {
  const e: Partial<Record<keyof Details, string>> = {};
  if (!d.firstName.trim()) e.firstName = "First name is required.";
  if (!d.lastName.trim()) e.lastName = "Last name is required.";
  if (d.website.trim() && !isUrl(d.website.trim())) e.website = "Enter a full URL starting with https://";
  if (d.postalCode && !/^[A-Za-z0-9][A-Za-z0-9 -]{0,9}$/.test(d.postalCode.trim())) e.postalCode = "Use letters, numbers, spaces or dashes (up to 10).";
  return e;
}

/* ---------- password rules ---------- */
const RULES: [string, (p: string) => boolean][] = [
  ["At least 9 characters", (p) => p.length >= 9],
  ["Contains an uppercase letter", (p) => /[A-Z]/.test(p)],
  ["Contains a lowercase letter", (p) => /[a-z]/.test(p)],
  ["Contains a number", (p) => /\d/.test(p)],
  ["Contains a special character", (p) => /[^A-Za-z0-9]/.test(p)],
];
const STRENGTH = [
  { label: "Weak", bar: "bg-rose-500" }, { label: "Weak", bar: "bg-rose-500" }, { label: "Weak", bar: "bg-rose-500" },
  { label: "Fair", bar: "bg-amber-500" }, { label: "Good", bar: "bg-sky-500" }, { label: "Strong", bar: "bg-emerald-500" },
];

const Dot = ({ ok }: { ok: boolean }) => (
  <svg viewBox="0 0 16 16" className={`size-3.5 shrink-0 ${ok ? "text-emerald-600" : "text-zinc-300"}`} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <circle cx="8" cy="8" r="6.5" />{ok ? <path d="M5.2 8.2l2 2 3.6-4" /> : <path d="M5.8 5.8l4.4 4.4M10.2 5.8l-4.4 4.4" />}
  </svg>
);

function Security({ userId, onDone }: { userId: string; onDone: (msg: string) => void }) {
  const [err, setErr] = useState("");
  const [cur, setCur] = useState("");
  const [pw, setPw] = useState("");
  const [conf, setConf] = useState("");
  const met = RULES.map(([, t]) => t(pw));
  const n = met.filter(Boolean).length;
  const st = STRENGTH[n];
  const mismatch = conf !== "" && conf !== pw ? "Passwords don’t match." : "";
  const same = pw !== "" && pw === cur ? "The new password must be different from the current one." : "";
  const ok = cur !== "" && n === RULES.length && conf === pw && !same;
  return (
    <>
      <div className="flex items-start justify-between">
        <div><h2 className="text-sm font-bold">Security</h2><p className="text-xs text-zinc-500">Change your password to keep your account secure.</p></div>
        <button onClick={() => onDone("")} className="text-xs font-medium hover:underline">Cancel</button>
      </div>
      <div className="mt-4 space-y-4">
        <Lbl text="Current password"><input type="password" className={inputCls} value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" maxLength={128} /></Lbl>
        <Lbl text="New password" error={same}><input type="password" className={inputCls} value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" maxLength={128} aria-describedby="pw-rules" /></Lbl>
        <div id="pw-rules" className="rounded-md border border-zinc-200 bg-zinc-50 p-3">
          <div className="flex items-center justify-between text-[11px]"><span>Strength: <b>{st.label}</b></span><span className="text-zinc-500">{n}/{RULES.length} met</span></div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-blue-100" role="progressbar" aria-label="Password strength" aria-valuemin={0} aria-valuemax={RULES.length} aria-valuenow={n}>
            <div className={`h-full rounded-full transition-all ${st.bar}`} style={{ width: `${(n / RULES.length) * 100}%` }} />
          </div>
          <ul className="mt-3 grid gap-x-6 gap-y-1.5 sm:grid-cols-2">
            {RULES.map(([label], i) => (
              <li key={label} className={`flex items-center gap-2 text-[11px] ${met[i] ? "text-emerald-700" : "text-zinc-600"}`}><Dot ok={met[i]} />{label}<span className="sr-only">{met[i] ? " (met)" : " (not met)"}</span></li>
            ))}
          </ul>
        </div>
        <Lbl text="Confirm new password" error={mismatch}><input type="password" className={inputCls} value={conf} onChange={(e) => setConf(e.target.value)} autoComplete="new-password" maxLength={128} /></Lbl>
      </div>
      {err && <p role="alert" className="mt-3 text-[11px] text-rose-600">{err}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <Btn onClick={() => onDone("")}>Cancel</Btn>
        <Btn variant="solid" disabled={!ok} onClick={async () => {
          setErr("");
          try {
            await api(`api/collections/users/records/${userId}`, { method: "PATCH", body: { oldPassword: cur, password: pw, passwordConfirm: conf } });
            onDone("Password updated. Signing you out…");
            // PocketBase invalidates old tokens on password change → sign in again.
            setTimeout(async () => { await fetch("/api/logout", { method: "POST" }); window.location.href = "/login"; }, 1200);
          } catch (x) { setErr((x as Error).message); }
        }}>Update Password</Btn>
      </div>
    </>
  );
}

export function ProfileView({ mode, profile }: { mode: "profile" | "settings"; profile: UserProfile }) {
  const router = useRouter();
  const [saveErr, setSaveErr] = useState("");
  const [saved, setSaved] = useState<Details>(toDetails(profile));
  const [draft, setDraft] = useState<Details>(toDetails(profile));
  const [editing, setEditing] = useState(false);
  const [changingPw, setChangingPw] = useState(false);
  const [toast, setToast] = useState("");
  const geo = useGeoNames(saved.country, saved.state);
  const dials = useDials();
  const shown = (k: keyof Details) => (k === "country" ? geo.country : k === "state" ? geo.state : "") || saved[k];
  const errs = detailErrors(draft);
  const hasErr = Object.keys(errs).length > 0;
  const fullName = `${saved.firstName} ${saved.lastName}`.trim() || profile.email;
  const initials = (`${saved.firstName[0] ?? ""}${saved.lastName[0] ?? ""}` || profile.email[0] || "?").toUpperCase();
  const set = (k: keyof Details) => (e: React.ChangeEvent<HTMLInputElement>) => setDraft({ ...draft, [k]: e.target.value });
  const field = (k: keyof Details, label: string, ph?: string) => (
    <Lbl key={k} text={label} error={errs[k]}>
      {k === "country" ? <CountrySelect label={label} value={draft.country} onChange={(v) => setDraft({ ...draft, country: v, state: "" })} className={inputCls} />
        : k === "state" ? <StateSelect label={label} country={draft.country} value={draft.state} onChange={(v) => setDraft({ ...draft, state: v })} className={inputCls} />
        : <input className={inputCls} value={draft[k]} onChange={set(k)} placeholder={ph} maxLength={120} aria-invalid={!!errs[k]} />}
    </Lbl>
  );
  const row = (k: string, v: ReactNode) => (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-zinc-100 bg-white px-4 py-3 shadow-sm">
      <span className="text-[10px] font-semibold uppercase tracking-wide text-zinc-500">{k}</span><span className="min-w-0 truncate text-xs">{v}</span>
    </div>
  );

  return (
    <>
      <PageHead title={mode === "profile" ? "Profile Settings" : "Account Settings"} sub={mode === "profile" ? "Your personal and contact details." : "Manage your password and account security."} />
      {toast && <p role="status" className="mb-4 rounded-md border border-emerald-100 bg-emerald-50 px-4 py-2 text-xs text-emerald-700">{toast}</p>}
      <div className={mode === "profile" ? "grid items-start gap-5 lg:grid-cols-[360px_1fr]" : "mx-auto max-w-3xl"}>
        {mode === "profile" && <Card className="p-5 text-center">
          <span className="mx-auto grid size-16 place-items-center rounded-full bg-blue-100 text-lg font-semibold text-primary">{initials}</span>
          <p className="mt-3 text-base font-bold">{fullName}</p>
          <span className="mt-1.5 inline-block rounded bg-blue-100 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-primary">Auction house admin</span>
          <div className="mt-5 space-y-2.5 text-left">
            {row("Full name", fullName)}
            {row("Primary email", <span className="text-primary">{profile.email}</span>)}
            {row("Phone", formatPhone(profile.phone, profile.phoneCountry || saved.country, dials))}
          </div>
        </Card>}

        <div className="space-y-5">
          {mode === "profile" && <Card className="p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold">Profile details</h2>
              {!editing && <Btn className="h-8 text-xs" onClick={() => { setDraft(saved); setEditing(true); setToast(""); }}>Edit Profile</Btn>}
            </div>
            {editing ? (
              <>
                <div className="mt-4 grid gap-x-5 gap-y-4 sm:grid-cols-2">{PERSONAL.map(([k, l, ph]) => field(k, l, ph))}</div>
                <hr className="my-5 border-zinc-200" />
                <div className="grid gap-x-5 gap-y-4 sm:grid-cols-2">{ADDRESS.map(([k, l]) => field(k, l))}</div>
                <hr className="my-5 border-zinc-200" />
                {saveErr && <p role="alert" className="mb-3 text-[11px] text-rose-600">{saveErr}</p>}
                <div className="flex justify-end gap-2">
                  <Btn onClick={() => { setDraft(saved); setEditing(false); }}>Cancel</Btn>
                  <Btn variant="solid" disabled={hasErr} onClick={async () => {
                    const clean = Object.fromEntries(Object.entries(draft).map(([k, v]) => [k, v.trim()])) as Details;
                    setSaveErr("");
                    try {
                      await api(`api/collections/users/records/${profile.id}`, { method: "PATCH", body: clean });
                      setSaved(clean); setEditing(false); setToast("Profile saved.");
                      router.refresh(); // update the name shown in the header
                    } catch (x) { setSaveErr((x as Error).message); }
                  }}>Save Changes</Btn>
                </div>
              </>
            ) : (
              <dl className="mt-4 grid gap-4 text-xs sm:grid-cols-2">
                {[...PERSONAL, ...ADDRESS].map(([k, l]) => (
                  <div key={k}><dt className="text-[10px] font-semibold uppercase tracking-wide text-zinc-500">{l}</dt><dd className="mt-0.5 break-words">{shown(k) || <span className="text-zinc-400">Not provided</span>}</dd></div>
                ))}
              </dl>
            )}
          </Card>}

          {mode === "settings" && <Card className="p-5">
            {changingPw ? (
              <Security userId={profile.id} onDone={(msg) => { setChangingPw(false); setToast(msg); }} />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div><h2 className="text-sm font-bold">Security</h2><p className="text-xs text-zinc-500">Change your password to keep your account secure.</p></div>
                  <Btn className="h-8 text-xs" onClick={() => { setChangingPw(true); setToast(""); }}>Change Password</Btn>
                </div>
                <p className="mt-3 text-xs text-zinc-500">Use a strong, unique password that includes uppercase and lowercase letters, numbers, and special characters.</p>
              </>
            )}
          </Card>}

          {mode === "settings" && <NotificationSettings scope="admin" />}
          {mode === "settings" && <PreferencesSettings scope="admin" />}
          {mode === "settings" && (
            <p className="text-xs text-zinc-500">Admin accounts are enabled, disabled or removed by a super admin in <Link href="/admin/admin-users" className="font-semibold text-primary hover:underline">Admin Users</Link>. Email wording is edited in Email Templates.</p>
          )}
          {mode === "settings" && (
            <p className="text-xs text-zinc-500">Looking for your name, company or address? Those are in <Link href="/admin/profile" className="font-semibold text-primary hover:underline">Profile Settings</Link>.</p>
          )}
        </div>
      </div>
    </>
  );
}
