"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Btn, Card } from "@/components/admin/ui";
import { studioAuctions, type StudioAuction } from "@/lib/admin";
import { studio } from "@/lib/studioApi";
import { loadIntel, type Intel } from "@/lib/intelData";

/** Loads the Intelligence model for one auction (bids + registrations + invoices). `reload` refetches. */
export function useIntel(a: StudioAuction | undefined) {
  const [m, setM] = useState<Intel | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(true);
  const reload = useCallback(() => {
    if (!a) return;
    if (!studio.live) { setBusy(false); setErr("Not connected to the backend, so there is no bid data to analyse."); return; }
    setBusy(true); setErr("");
    loadIntel(a).then((x) => { setM(x); setBusy(false); }).catch((e) => { setErr(e instanceof Error ? e.message : "Could not load the auction data"); setBusy(false); });
  }, [a]);
  useEffect(() => { reload(); }, [reload]);
  return { m, err, busy, reload };
}

export const backHref = (a: StudioAuction) => `/admin/auction-intelligence${a.status === "CLOSED" ? "?mode=closed" : ""}`;

export function NotFound() {
  return <Card className="p-10 text-center"><p className="font-semibold">Auction not found</p><Link href="/admin/auction-intelligence" className="mt-3 inline-block text-sm font-semibold text-primary">Back to Intelligence</Link></Card>;
}

/** Page frame shared by every Intelligence screen: back link, title, live/closed badge, refresh and optional actions. */
export function IntelFrame({ a, label, title, sub, reload, busy, actions, children }: { a: StudioAuction; label: string; title: string; sub: string; reload: () => void; busy: boolean; actions?: ReactNode; children: ReactNode }) {
  const live = a.status === "RUNNING";
  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link href={backHref(a)} className="inline-flex h-7 items-center gap-1.5 rounded-md bg-zinc-200 px-2.5 text-[11px] font-semibold hover:bg-zinc-300"><ArrowLeft className="size-3" />Back to Intelligence</Link>
        <div className="flex items-center gap-2">{actions}<Btn variant="outline" className="h-8 text-xs" disabled={busy} onClick={reload}>{busy ? "Loading…" : "Refresh"}</Btn></div>
      </div>
      <p className="mt-4 text-[10px] font-bold uppercase tracking-wide text-zinc-500">{label}</p>
      <h1 className="flex flex-wrap items-center gap-2 text-2xl font-bold">{a.title}
        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold ${live ? "border-sky-200 bg-sky-50 text-sky-700" : "border-zinc-200 bg-zinc-50 text-zinc-600"}`}><span className={`size-1.5 rounded-full ${live ? "bg-sky-500" : "bg-zinc-400"}`} />{live ? "Live" : "Closed"}</span></h1>
      <p className="mt-0.5 text-xs text-zinc-600"><b>{title}</b> · {sub}</p>
      <div className="mt-4">{children}</div>
    </div>
  );
}

export const LoadNote = ({ busy, err }: { busy: boolean; err: string }) =>
  err ? <p role="alert" className="rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-700">{err}</p>
    : busy ? <p role="status" className="py-10 text-center text-xs text-zinc-500">Loading auction data…</p> : null;

export const lookupAuction = (id: string) => studioAuctions.find((x) => x.id === id);
