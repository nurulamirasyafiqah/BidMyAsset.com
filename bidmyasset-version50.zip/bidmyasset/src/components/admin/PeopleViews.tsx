"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Activity, Bell, BellOff, CalendarDays, Check, CheckCircle2, ChevronDown, Filter, Gavel, Globe2, Mail, Plus, RefreshCw, SlidersHorizontal, Timer, Trophy, Undo2, UserCheck, UserPlus, UserX } from "lucide-react";
import { useRouter } from "next/navigation";
import { Avatar, Badge, Btn, Card, Choice, DataTable, Drawer, Field, inputCls, Modal, PageHead, RefreshBtn, SearchBox, Toggle, useConfirm } from "@/components/admin/ui";
import { type AdminUserRow, type BidderRow } from "@/lib/admin";
import { getCountries } from "@/lib/geo";
import { formatPhone } from "@/lib/phone";
import { withMinSpin } from "@/lib/minSpin";
import { formatMoney } from "@/lib/format";

type ActivityItem = { id: string; at: string; title: string; ip: string; ok: boolean };
function ActivityModal({ user, onClose }: { user: AdminUserRow; onClose: () => void }) {
  const [range, setRange] = useState<"today" | "7" | "30" | "all">("all");
  const [all, setAll] = useState<ActivityItem[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/admin/users/activity?email=${encodeURIComponent(user.email)}`, { cache: "no-store" });
        const j = (await res.json()) as { items?: ActivityItem[]; message?: string };
        if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
        setAll(j.items ?? []);
      } catch (e) { setErr(e instanceof Error ? e.message : "Failed to load"); }
    })();
  }, [user.email]);
  const day = 86400000, now = Date.now(), start = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
  const at = (a: ActivityItem) => new Date(a.at.replace(" ", "T")).getTime();
  const items = (all ?? []).filter((a) => range === "all" ? true : range === "today" ? at(a) >= start : now - at(a) <= Number(range) * day);
  return (
    <Modal title="Admin user activity" sub={`${user.name} (${user.email})`} onClose={onClose} footer={<Btn variant="ghost" onClick={onClose}>Close</Btn>}>
      <div className="mb-3 flex flex-wrap gap-2" role="tablist">
        {([["today", "Today"], ["7", "Last 7 days"], ["30", "Last 30 days"], ["all", "All activity"]] as const).map(([v, l]) => (
          <button key={v} role="tab" aria-selected={range === v} onClick={() => setRange(v)} className={`rounded-md border px-2.5 py-1 text-[11px] font-semibold ${range === v ? "border-primary bg-primary text-white" : "border-zinc-300 bg-white hover:bg-zinc-50"}`}>{l}</button>
        ))}
      </div>
      <ul className="max-h-72 space-y-3 overflow-y-auto pr-1">
        {err && <li role="alert" className="py-8 text-center text-xs text-rose-600">{err}</li>}
        {!err && all === null && <li className="py-8 text-center text-xs text-zinc-500">Loading…</li>}
        {!err && all !== null && items.length === 0 && <li className="py-8 text-center text-xs text-zinc-500">No activity in this period.</li>}
        {items.map((a) => (
          <li key={a.id} className="rounded-lg border border-zinc-200 p-3 text-xs">
            <div className="flex items-center justify-between"><span className="flex items-center gap-2 font-semibold">Activity <Badge tone={a.ok ? "blue" : "red"}>{a.ok ? "Success" : "Failed"}</Badge></span><span className="text-[10px] text-zinc-500">{new Date(at(a)).toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" })} · {new Date(at(a)).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }).toLowerCase()}</span></div>
            <p className="mt-2">{a.title}</p><p className="mt-1 text-[10px] text-zinc-500">• IP {a.ip}</p>
          </li>
        ))}
      </ul>
    </Modal>
  );
}

const parseUS = (s: string) => new Date(s.replace(" am", " AM").replace(" pm", " PM")).getTime() || 0;
const dayStart = (iso: string) => new Date(`${iso}T00:00:00`).getTime();
const dayEnd = (iso: string) => new Date(`${iso}T23:59:59.999`).getTime();
const stampNow = () => new Date().toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");

/** Radio-style option row used by the filter drawers. */
function RadioRow({ active, title, sub, onClick, side = "right" }: { active: boolean; title: string; sub?: string; onClick: () => void; side?: "left" | "right" }) {
  const dot = <span aria-hidden className={`grid size-3.5 shrink-0 place-items-center rounded-full border ${active ? "border-primary" : "border-zinc-300"}`}>{active && <span className="size-1.5 rounded-full bg-primary" />}</span>;
  return (
    <button type="button" role="radio" aria-checked={active} onClick={onClick}
      className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2.5 text-left transition ${active ? "border-primary bg-sky-50 ring-1 ring-primary/40" : "border-zinc-200 hover:bg-zinc-50"}`}>
      {side === "left" && dot}
      <span className="min-w-0 flex-1"><span className={`block text-xs font-semibold ${active ? "text-primary" : ""}`}>{title}</span>{sub && <span className="block text-[10px] text-zinc-500">{sub}</span>}</span>
      {side === "right" && dot}
    </button>
  );
}

function FilterSection({ icon, title, sub, children }: { icon: ReactNode; title: string; sub: string; children: ReactNode }) {
  return (
    <section>
      <div className="mb-3 flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-sky-50 text-primary">{icon}</span>
        <div><h3 className="text-xs font-bold">{title}</h3><p className="text-[10px] text-zinc-500">{sub}</p></div>
      </div>
      {children}
    </section>
  );
}

type AStatus = "all" | "active" | "inactive";
type ASort = "newest" | "oldest" | "name" | "active";
type AFilters = { status: AStatus; from: string; to: string; sort: ASort };
const A_DEFAULT: AFilters = { status: "all", from: "", to: "", sort: "newest" };
const A_STATUS = [["all", "All statuses"], ["active", "Active"], ["inactive", "Inactive"]] as const;
const A_SORT = [["newest", "Newest registrations", "Latest admin users first"], ["oldest", "Oldest registrations", "Earliest admin users first"], ["name", "Name A → Z", "Alphabetical by full name"], ["active", "Active users first", "Surface active admins before inactive"]] as const;

/** Switch an admin/auctioneer account off or on (they are signed out and can't log in while off). */
async function postDisabled(email: string, disabled: boolean) {
  const res = await fetch("/api/admin/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, disabled }) });
  const j = (await res.json().catch(() => ({}))) as { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
}

export function AdminUsersView() {
  const [rows, setRows] = useState<AdminUserRow[]>([]);
  const [loadErr, setLoadErr] = useState("");
  const [actErr, setActErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    setLoadErr(""); setRefreshing(true);
    try {
      const res = await withMinSpin(() => fetch("/api/admin/users", { cache: "no-store" }));
      const j = (await res.json()) as { items?: { name: string; email: string; created: string; disabled?: boolean }[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setRows((j.items ?? []).map((u) => ({ name: u.name, email: u.email, active: !u.disabled, onboarding: "Onboarded" as const, registered: new Date(u.created.replace(" ", "T")).toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "").replace(/ (AM|PM)$/, (m) => m.toLowerCase()) })));
    } catch (e) { setLoadErr(e instanceof Error ? e.message : "Failed to load"); }
    finally { setRefreshing(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const setAdmin = async (email: string, isAdmin: boolean) => {
    setBusy(true); setActErr("");
    try {
      const res = await fetch("/api/admin/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, isAdmin }) });
      const j = (await res.json().catch(() => ({}))) as { message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      await load();
      return true;
    } catch (e) { setActErr(e instanceof Error ? e.message : "Failed"); return false; }
    finally { setBusy(false); }
  };
  const [q, setQ] = useState("");
  const [invite, setInvite] = useState(false);
  const [filter, setFilter] = useState(false);
  const [applied, setApplied] = useState<AFilters>(A_DEFAULT);
  const [draft, setDraft] = useState<AFilters>(A_DEFAULT);
  const [f, setF] = useState({ email: "" });
  const [sent, setSent] = useState<string | null>(null);
  const [activity, setActivity] = useState<AdminUserRow | null>(null);
  const { confirm, dialog } = useConfirm();
  const router = useRouter();

  const activeCount = rows.filter((r) => r.active).length;
  const filterCount = (applied.status !== "all" ? 1 : 0) + (applied.from || applied.to ? 1 : 0) + (applied.sort !== "newest" ? 1 : 0);
  const shown = rows
    .filter((r) => `${r.name} ${r.email}`.toLowerCase().includes(q.toLowerCase()))
    .filter((r) => (applied.status === "all" ? true : applied.status === "active" ? r.active : !r.active))
    .filter((r) => { const t = parseUS(r.registered); return (!applied.from || t >= dayStart(applied.from)) && (!applied.to || t <= dayEnd(applied.to)); })
    .sort((a, b) => {
      const newest = parseUS(b.registered) - parseUS(a.registered);
      if (applied.sort === "name") return a.name.localeCompare(b.name);
      if (applied.sort === "oldest") return -newest;
      if (applied.sort === "active") return Number(b.active) - Number(a.active) || newest;
      return newest;
    });
  const dupe = rows.some((r) => r.email.toLowerCase() === f.email.trim().toLowerCase());
  const valid = /^\S+@\S+\.\S+$/.test(f.email) && !dupe && !busy;
  const rangeBad = !!draft.from && !!draft.to && draft.from > draft.to;

  const setActive = async (r: AdminUserRow, on: boolean) => {
    if (busy) return;
    if (!on && !(await confirm({ title: `Disable ${r.name}?`, body: "They will be signed out and won’t be able to log in or use the admin console until re-enabled.", confirmLabel: "Disable", noLog: true }))) return;
    setBusy(true); setActErr("");
    try { await postDisabled(r.email, !on); await load(); }
    catch (e) { setActErr(e instanceof Error ? e.message : "Failed"); }
    finally { setBusy(false); }
  };
  const removeAdmin = async (r: AdminUserRow) => {
    const ok = await confirm({ title: `Remove admin access for ${r.name}?`, body: "They stay a normal bidder account but can no longer open the admin console.", confirmLabel: "Remove access", noLog: true });
    if (ok) await setAdmin(r.email, false);
  };
  const openFilter = () => { setDraft(applied); setFilter(true); };

  return (
    <>
      <PageHead title="Admin Users" sub="Manage access and onboarding status for your internal admin team"
        chips={<><span className="flex items-center gap-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" />{activeCount} active</span><span>BidMyAsset</span></>}
        actions={<><Btn disabled={refreshing} onClick={() => void load()}><RefreshCw className={`size-4 ${refreshing ? "animate-spin" : ""}`} />Refresh</Btn><Btn variant="solid" onClick={() => { setActErr(""); setInvite(true); }}><UserPlus className="size-4" />Add admin</Btn></>} />
      {sent && <p role="status" className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{sent} is now an admin.</p>}
      {loadErr && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
      {actErr && !invite && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{actErr}</p>}
      <Card>
        <div className="flex items-center justify-between gap-3 p-4"><SearchBox value={q} onChange={setQ} placeholder="Search by name or email" className="w-72" />
          <Btn variant="ghost" className="h-8 text-xs" onClick={openFilter}><SlidersHorizontal className="size-3.5" />Filters &amp; sort{filterCount > 0 && <span className="rounded-full bg-primary px-1.5 text-[10px] text-white">{filterCount}</span>}</Btn></div>
        <DataTable empty="No admin users match." head={["Name", "Email", "Status", "Registered on", "Onboarding", "Actions"]}
          rows={shown.map((r) => [
            <span key="n" className="flex items-center gap-2.5"><Avatar name={r.name} /><span><span className="block text-[13px] font-semibold">{r.name}</span><span className="block text-[11px] text-zinc-500">Admin user</span></span></span>,
            r.email,
            <Badge key="s" tone={r.active ? "blue" : "zinc"}>{r.active ? "Active" : "Inactive"}</Badge>,
            r.registered,
            <Badge key="o" tone={r.onboarding === "Onboarded" ? "blue" : "amber"}>{r.onboarding}</Badge>,
            <span key="a" className="flex items-center gap-1.5">
              <Toggle on={r.active} onChange={(v) => void setActive(r, v)} label={`Enable ${r.name}`} />
              <button aria-label={`View activity for ${r.name}`} title="View activity" onClick={() => setActivity(r)} className="grid size-7 place-items-center rounded border border-zinc-200 hover:bg-zinc-50"><Activity className="size-4" /></button>
              <button aria-label={`Remove admin access for ${r.name}`} title="Remove admin access" disabled={busy} onClick={() => removeAdmin(r)} className="grid size-7 place-items-center rounded border border-rose-200 text-rose-600 hover:bg-zinc-50 disabled:opacity-50"><UserX className="size-4" /></button>
            </span>,
          ])} />
      </Card>

      {activity && <ActivityModal user={activity} onClose={() => setActivity(null)} />}
      {invite && (
        <Modal title="Add admin" sub="Give an existing account access to the admin console. They must already be registered on the website." onClose={() => setInvite(false)}
          footer={<><Btn variant="ghost" onClick={() => setInvite(false)}>Cancel</Btn>
            <Btn variant="solid" disabled={!valid} onClick={async () => { if (await setAdmin(f.email.trim(), true)) { setSent(f.email.trim()); setF({ email: "" }); setInvite(false); } }}>Add admin</Btn></>}>
          <Field label="Email address"><input type="email" className={inputCls} placeholder="admin@email.com" value={f.email} onChange={(e) => setF({ email: e.target.value })} /></Field>
          {dupe && <p role="alert" className="mt-1 text-[11px] text-rose-600">This person is already an admin.</p>}
          {actErr && <p role="alert" className="mt-1 text-[11px] text-rose-600">{actErr}</p>}
        </Modal>
      )}
      {filter && (
        <Drawer title="Filters & sort" sub="Fine-tune the admin list using status, registration timeline, and sort order." onClose={() => setFilter(false)}
          footer={<><Btn variant="ghost" className="flex-1" onClick={() => setDraft(A_DEFAULT)}><Undo2 className="size-4" />Reset all</Btn>
            <Btn variant="solid" className="flex-1" disabled={rangeBad} onClick={() => { setApplied(draft); setFilter(false); }}>Apply filters</Btn></>}>
          <FilterSection icon={<CheckCircle2 className="size-4" />} title="Status" sub="Highlight active or inactive admin users.">
            <div role="radiogroup" aria-label="Status" className="space-y-2">{A_STATUS.map(([v, t]) => <RadioRow key={v} active={draft.status === v} title={t} onClick={() => setDraft({ ...draft, status: v })} />)}</div>
          </FilterSection>
          <FilterSection icon={<CalendarDays className="size-4" />} title="Registration timeline" sub="Focus on admins who joined within a specific date range.">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Start date"><input type="date" className={inputCls} max={draft.to || undefined} value={draft.from} onChange={(e) => setDraft({ ...draft, from: e.target.value })} /></Field>
              <Field label="End date"><input type="date" className={inputCls} min={draft.from || undefined} value={draft.to} onChange={(e) => setDraft({ ...draft, to: e.target.value })} /></Field>
            </div>
            {rangeBad && <p role="alert" className="mt-1.5 text-[11px] text-rose-600">Start date can’t be after the end date.</p>}
          </FilterSection>
          <FilterSection icon={<Filter className="size-4" />} title="Sort order" sub="Choose how admin users are ranked in the list.">
            <div role="radiogroup" aria-label="Sort order" className="space-y-2">{A_SORT.map(([v, t, s]) => <RadioRow key={v} side="left" active={draft.sort === v} title={t} sub={s} onClick={() => setDraft({ ...draft, sort: v })} />)}</div>
          </FilterSection>
        </Drawer>
      )}
      {dialog}
    </>
  );
}

/* ---------- Company → Users → Auctioneers ---------- */
// Auctioneers are the platform's admin accounts (same data as Admin Users): real list, real Add / Remove access,
// and the same Filters & sort drawer (status, registration timeline, sort order).
export function AuctioneersPanel() {
  const [rows, setRows] = useState<AdminUserRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [loadErr, setLoadErr] = useState("");
  const [actErr, setActErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    setLoadErr(""); setRefreshing(true);
    try {
      const res = await withMinSpin(() => fetch("/api/admin/users", { cache: "no-store" }));
      const j = (await res.json()) as { items?: { name: string; email: string; created: string; disabled?: boolean }[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setRows((j.items ?? []).map((u) => ({ name: u.name, email: u.email, active: !u.disabled, onboarding: "Onboarded" as const, registered: new Date(u.created.replace(" ", "T")).toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "").replace(/ (AM|PM)$/, (m) => m.toLowerCase()) })));
      setLoaded(true);
    } catch (e) { setLoadErr(e instanceof Error ? e.message : "Failed to load"); }
    finally { setRefreshing(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const setAdmin = async (email: string, isAdmin: boolean) => {
    setBusy(true); setActErr("");
    try {
      const res = await fetch("/api/admin/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, isAdmin }) });
      const j = (await res.json().catch(() => ({}))) as { message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      await load();
      return true;
    } catch (e) { setActErr(e instanceof Error ? e.message : "Failed"); return false; }
    finally { setBusy(false); }
  };
  const [q, setQ] = useState("");
  const [invite, setInvite] = useState(false);
  const [filter, setFilter] = useState(false);
  const [applied, setApplied] = useState<AFilters>(A_DEFAULT);
  const [draft, setDraft] = useState<AFilters>(A_DEFAULT);
  const [email, setEmail] = useState("");
  const { confirm, dialog } = useConfirm();

  const filterCount = (applied.status !== "all" ? 1 : 0) + (applied.from || applied.to ? 1 : 0) + (applied.sort !== "newest" ? 1 : 0);
  const shown = rows
    .filter((r) => `${r.name} ${r.email}`.toLowerCase().includes(q.toLowerCase()))
    .filter((r) => (applied.status === "all" ? true : applied.status === "active" ? r.active : !r.active))
    .filter((r) => { const t = parseUS(r.registered); return (!applied.from || t >= dayStart(applied.from)) && (!applied.to || t <= dayEnd(applied.to)); })
    .sort((a, b) => {
      const newest = parseUS(b.registered) - parseUS(a.registered);
      if (applied.sort === "name") return a.name.localeCompare(b.name);
      if (applied.sort === "oldest") return -newest;
      if (applied.sort === "active") return Number(b.active) - Number(a.active) || newest;
      return newest;
    });
  const dupe = rows.some((r) => r.email.toLowerCase() === email.trim().toLowerCase());
  const valid = /^\S+@\S+\.\S+$/.test(email.trim()) && !dupe && !busy;
  const rangeBad = !!draft.from && !!draft.to && draft.from > draft.to;
  const openFilter = () => { setDraft(applied); setFilter(true); };
  const setActive = async (r: AdminUserRow, on: boolean) => {
    if (busy) return;
    if (!on && !(await confirm({ title: `Disable ${r.name}?`, body: "They will be signed out and won’t be able to log in or use the admin console until re-enabled.", confirmLabel: "Disable", noLog: true }))) return;
    setBusy(true); setActErr("");
    try { await postDisabled(r.email, !on); await load(); }
    catch (e) { setActErr(e instanceof Error ? e.message : "Failed"); }
    finally { setBusy(false); }
  };
  const remove = async (r: AdminUserRow) => {
    if (await confirm({ title: `Remove ${r.name}?`, body: "They stay a normal bidder account but can no longer open the admin console.", confirmLabel: "Remove access", noLog: true })) await setAdmin(r.email, false);
  };
  const stats = [["Total", rows.length, "All auctioneers under this company"], ["Onboarded", rows.filter((r) => r.onboarding === "Onboarded").length, "Active in the system"],
    ["Invited", rows.filter((r) => r.onboarding !== "Onboarded").length, "Awaiting account completion"], ["Active", rows.filter((r) => r.active).length, "Enabled accounts"]] as const;

  return (
    <>
      <div className="mb-3 rounded-lg border border-zinc-200 bg-zinc-50 px-4 py-2.5"><p className="text-sm font-bold">Auctioneers</p><p className="text-xs text-zinc-500">Manage primary auction hosts and supervisors.</p></div>
      <Card className="p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><h3 className="text-base font-bold">Auctioneers</h3><p className="text-xs text-zinc-500">Auctioneers are the admin accounts of this platform (same list as Admin Users).</p></div>
          <div className="flex gap-2"><RefreshBtn small onRefresh={() => void load()} /><Btn variant="solid" className="h-8 text-xs" onClick={() => { setActErr(""); setEmail(""); setInvite(true); }}><UserPlus className="size-3.5" />Add Auctioneer</Btn></div>
        </div>
        {loadErr && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
        {actErr && !invite && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{actErr}</p>}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {stats.map(([l, n, sub]) => (
            <div key={l} className="rounded-lg bg-zinc-50 p-3"><p className="text-[10px] font-bold uppercase text-zinc-500">{l}</p><p className="text-xl font-semibold">{loaded ? n : "…"}</p><p className="text-[10px] text-zinc-500">{sub}</p></div>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between gap-3"><SearchBox value={q} onChange={setQ} placeholder="Search auctioneers..." className="w-64" />
          <Btn variant="ghost" className="h-8 text-xs" onClick={openFilter}><SlidersHorizontal className="size-3.5" />Filters &amp; sort{filterCount > 0 && <span className="rounded-full bg-primary px-1.5 text-[10px] text-white">{filterCount}</span>}</Btn></div>
        <p className="my-2 text-[11px] text-zinc-500">Showing {shown.length} auctioneer{shown.length === 1 ? "" : "s"}</p>
        <DataTable head={["Name", "Email", "Registered", "Status", "Actions"]} empty={loaded ? "No auctioneers match." : "Loading…"}
          rows={shown.map((r) => [
            <span key="n" className="flex items-center gap-2 font-semibold"><Avatar name={r.name} size="size-7" />{r.name}</span>,
            r.email, r.registered,
            <Badge key="s" tone={r.active ? "blue" : "zinc"}>{r.active ? r.onboarding : "Disabled"}</Badge>,
            <span key="x" className="flex items-center gap-2"><Toggle on={r.active} onChange={(v) => void setActive(r, v)} label={`Enable ${r.name}`} /><button aria-label={`Remove admin access for ${r.name}`} title="Remove admin access" disabled={busy} onClick={() => void remove(r)} className="grid size-7 place-items-center rounded border border-rose-200 text-rose-600 hover:bg-zinc-50 disabled:opacity-50"><UserX className="size-4" /></button></span>,
          ])} />
      </Card>
      {invite && (
        <Modal title="Add auctioneer" sub="Give an existing account access to the admin console. They must already be registered on the website." onClose={() => setInvite(false)}
          footer={<><Btn variant="ghost" onClick={() => setInvite(false)}>Cancel</Btn>
            <Btn variant="solid" disabled={!valid} onClick={async () => { if (await setAdmin(email.trim(), true)) { setEmail(""); setInvite(false); } }}>Add auctioneer</Btn></>}>
          <Field label="Email address"><input type="email" className={inputCls} placeholder="auctioneer@email.com" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          {dupe && <p role="alert" className="mt-1 text-[11px] text-rose-600">This person is already an auctioneer.</p>}
          {actErr && <p role="alert" className="mt-1 text-[11px] text-rose-600">{actErr}</p>}
        </Modal>
      )}
      {filter && (
        <Drawer title="Filters & sort" sub="Fine-tune the auctioneer list using status, registration timeline, and sort order." onClose={() => setFilter(false)}
          footer={<><Btn variant="ghost" className="flex-1" onClick={() => setDraft(A_DEFAULT)}><Undo2 className="size-4" />Reset all</Btn>
            <Btn variant="solid" className="flex-1" disabled={rangeBad} onClick={() => { setApplied(draft); setFilter(false); }}>Apply filters</Btn></>}>
          <FilterSection icon={<CheckCircle2 className="size-4" />} title="Status" sub="Highlight active or inactive auctioneers.">
            <div role="radiogroup" aria-label="Status" className="space-y-2">{A_STATUS.map(([v, t]) => <RadioRow key={v} active={draft.status === v} title={t} onClick={() => setDraft({ ...draft, status: v })} />)}</div>
          </FilterSection>
          <FilterSection icon={<CalendarDays className="size-4" />} title="Registration timeline" sub="Focus on auctioneers who joined within a specific date range.">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Start date"><input type="date" className={inputCls} max={draft.to || undefined} value={draft.from} onChange={(e) => setDraft({ ...draft, from: e.target.value })} /></Field>
              <Field label="End date"><input type="date" className={inputCls} min={draft.from || undefined} value={draft.to} onChange={(e) => setDraft({ ...draft, to: e.target.value })} /></Field>
            </div>
            {rangeBad && <p role="alert" className="mt-1.5 text-[11px] text-rose-600">Start date can’t be after the end date.</p>}
          </FilterSection>
          <FilterSection icon={<Filter className="size-4" />} title="Sort order" sub="Choose how auctioneers are ranked in the list.">
            <div role="radiogroup" aria-label="Sort order" className="space-y-2">{A_SORT.map(([v, t, sub]) => <RadioRow key={v} side="left" active={draft.sort === v} title={t} sub={sub.replace("admin users", "auctioneers").replace("admins", "auctioneers")} onClick={() => setDraft({ ...draft, sort: v })} />)}</div>
          </FilterSection>
        </Drawer>
      )}
      {dialog}
    </>
  );
}

/* ---------- Bidders Directory ---------- */

const SORTS = [["new", "Newest registrations"], ["old", "Oldest registrations"], ["most", "Most bids placed"], ["fewest", "Fewest bids placed"]] as const;
const PSORTS = [["new", "Newest registrations"], ["old", "Oldest registrations"]] as const;
const INTERESTS = ["Agriculture", "Heavy equipment", "Trailers", "Trucks", "Vehicles"] as const;
const DIAL = [["+1", "US"], ["+60", "MY"], ["+65", "SG"], ["+62", "ID"], ["+91", "IN"], ["+61", "AU"], ["+44", "GB"]] as const;

// Saved in PocketBase (collection "prospects") via /api/admin/prospects.
type Prospect = { id: string; first: string; last: string; email: string; dial: string; phone: string; role: string; company: string; website: string;
  l1: string; l2: string; city: string; state: string; country: string; zip: string; interests: string[]; addedAt: string; invited: boolean };
type ProspectInput = Omit<Prospect, "id" | "addedAt" | "invited">;
const BLANK = { first: "", last: "", email: "", dial: "+1", phone: "", role: "", company: "", website: "", l1: "", l2: "", city: "", state: "", country: "", zip: "", interests: [] as string[] };

function ProspectDrawer({ existing, onSave, onClose }: { existing: Prospect[]; onSave: (p: ProspectInput) => Promise<string>; onClose: () => void }) {
  const [f, setF] = useState(BLANK);
  const [saving, setSaving] = useState(false);
  const [serverErr, setServerErr] = useState("");
  const [touched, setTouched] = useState(false);
  const { confirm, dialog } = useConfirm();
  const set = (k: keyof typeof BLANK) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const dirty = JSON.stringify(f) !== JSON.stringify(BLANK);
  const email = f.email.trim().toLowerCase();
  const errs = {
    first: !f.first.trim() ? "First name is required." : "",
    email: !/^\S+@\S+\.\S+$/.test(email) ? "Enter a valid email address." : existing.some((p) => p.email.toLowerCase() === email) ? "A prospect with this email already exists." : "",
    website: f.website.trim() && !/^https?:\/\/\S+\.\S+/.test(f.website.trim()) ? "Use a full URL starting with http:// or https://" : "",
  };
  const bad = Object.values(errs).some(Boolean);
  const tryClose = async () => {
    if (!dirty || await confirm({ title: "Discard this bidder?", body: "You have unsaved details. If you close now, they will be lost.", confirmLabel: "Discard" })) onClose();
  };
  const save = async () => {
    setTouched(true);
    if (bad || saving) return;
    setSaving(true); setServerErr("");
    const msg = await onSave({ ...f, first: f.first.trim(), last: f.last.trim(), email: f.email.trim(), website: f.website.trim() });
    setSaving(false);
    if (msg) setServerErr(msg);
  };
  const sec = "rounded-xl border border-zinc-200 p-4";
  const err = (m: string) => touched && m ? <p role="alert" className="mt-1 text-[11px] text-rose-600">{m}</p> : null;
  return (
    <Drawer wide title="Non-registered bidder onboarding" sub="Capture bidder contact details so your team can pre-qualify or invite them to register later." onClose={tryClose}
      footer={<><span className="flex-1" /><Btn variant="outline" onClick={tryClose}>Cancel</Btn><Btn variant="solid" disabled={saving} onClick={() => void save()}>{saving ? "Saving…" : "Save bidder"}</Btn></>}>
      {serverErr && <p role="alert" className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{serverErr}</p>}
      <section className={sec}>
        <h3 className="text-xs font-bold">Bidder details</h3><p className="mb-3 text-[11px] text-zinc-500">Collect the bidder’s core contact information.</p>
        <div className="grid grid-cols-2 gap-3">
          <div><Field label="First name"><input autoFocus className={inputCls} value={f.first} onChange={set("first")} /></Field>{err(errs.first)}</div>
          <Field label="Last name"><input className={inputCls} value={f.last} onChange={set("last")} /></Field>
          <div className="col-span-2"><Field label="Primary email"><input type="email" className={inputCls} value={f.email} onChange={set("email")} /></Field>{err(errs.email)}</div>
          <Field label="Primary phone"><div className="flex gap-1.5"><select aria-label="Country code" className="h-9 w-20 shrink-0 rounded-md border border-zinc-300 bg-white px-1 text-xs" value={f.dial} onChange={set("dial")}>{DIAL.map(([d, c]) => <option key={d} value={d}>{c} {d}</option>)}</select>
            <input inputMode="tel" className={inputCls} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/[^\d\s-]/g, "") })} /></div></Field>
          <Field label="Role / title"><input className={inputCls} placeholder="Owner, Procurement…" value={f.role} onChange={set("role")} /></Field>
          <Field label="Company name"><input className={inputCls} value={f.company} onChange={set("company")} /></Field>
          <div><Field label="Company website"><input className={inputCls} placeholder="https://example.com" value={f.website} onChange={set("website")} /></Field>{err(errs.website)}</div>
        </div>
      </section>
      <section className={sec}>
        <h3 className="text-xs font-bold">Address</h3><p className="mb-3 text-[11px] text-zinc-500">Provide the bidder’s primary business location. This helps with territory planning and compliance.</p>
        <div className="space-y-3">
          <Field label="Address line 1"><input className={inputCls} value={f.l1} onChange={set("l1")} /></Field>
          <Field label="Address line 2 (optional)"><input className={inputCls} value={f.l2} onChange={set("l2")} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="City"><input className={inputCls} value={f.city} onChange={set("city")} /></Field>
            <Field label="State / Province"><input className={inputCls} value={f.state} onChange={set("state")} /></Field>
            <Field label="Country"><input className={inputCls} value={f.country} onChange={set("country")} /></Field>
            <Field label="Postal code"><input className={inputCls} value={f.zip} onChange={set("zip")} /></Field>
          </div>
        </div>
      </section>
      <section className={sec}>
        <h3 className="text-xs font-bold">Interest categories</h3><p className="mb-3 text-[11px] text-zinc-500">Attach the bidder to relevant equipment categories so future campaigns reach the right people.</p>
        <div className="grid grid-cols-2 gap-2">
          {INTERESTS.map((c) => (
            <label key={c} className="flex cursor-pointer items-center gap-2 rounded-md border border-zinc-200 px-3 py-2 text-xs font-medium hover:bg-zinc-50">
              <input type="checkbox" className="size-3.5 accent-primary" checked={f.interests.includes(c)} onChange={() => setF((x) => ({ ...x, interests: x.interests.includes(c) ? x.interests.filter((i) => i !== c) : [...x.interests, c] }))} />{c}
            </label>
          ))}
        </div>
      </section>
      {dialog}
    </Drawer>
  );
}

export function BiddersView() {
  const router = useRouter();
  const { confirm, dialog } = useConfirm();
  const [tab, setTab] = useState<"reg" | "non">("reg");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<(typeof SORTS)[number][0]>("new");
  const [psort, setPsort] = useState<(typeof PSORTS)[number][0]>("new");
  const [list, setList] = useState<BidderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadErr, setLoadErr] = useState("");
  const [dials, setDials] = useState<Record<string, string>>({});
  useEffect(() => { getCountries().then((c) => setDials(Object.fromEntries(c.map((x) => [x.value, x.dial])))).catch(() => {}); }, []);
  const phoneOf = (b: BidderRow) => formatPhone(b.phone, b.phoneCountry || b.country, dials);
  const load = useCallback(async () => {
    setLoading(true); setLoadErr("");
    try {
      const res = await withMinSpin(() => fetch("/api/admin/bidders", { cache: "no-store" }));
      const j = (await res.json()) as { items?: { id: string; name: string; email: string; phone: string; created: string; bids: number; registrations: number; completed: boolean; phoneCountry: string; country: string; notify: boolean }[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setList((j.items ?? []).map((u) => ({ ...u, registered: new Date(u.created.replace(" ", "T")).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).replace(",", "") })));
    } catch (e) { setLoadErr(e instanceof Error ? e.message : "Failed to load"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const loadProspects = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/prospects", { cache: "no-store" });
      const j = (await res.json()) as { items?: Prospect[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setProspects(j.items ?? []);
    } catch (e) { setLoadErr(e instanceof Error ? e.message : "Failed to load non-registered bidders"); }
  }, []);
  useEffect(() => { void loadProspects(); }, [loadProspects]);
  const [add, setAdd] = useState(false);
  const [toast, setToast] = useState("");
  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(""), 3500); };

  const rows = list.filter((b) => `${b.name} ${b.email} ${b.phone} ${phoneOf(b)}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => (sort === "most" ? b.bids - a.bids : sort === "fewest" ? a.bids - b.bids : 0));
  const ordered = sort === "old" ? [...rows].reverse() : rows;
  const pRows = prospects
    .filter((p) => `${p.first} ${p.last} ${p.company} ${p.email} ${p.dial}${p.phone}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => (psort === "old" ? a.addedAt.localeCompare(b.addedAt) : b.addedAt.localeCompare(a.addedAt)));

  const setNotify = async (b: BidderRow, v: boolean) => {
    if (!v && !(await confirm({ title: "Turn off notifications?", body: `${b.name} will stop receiving auction and bid notifications.`, confirmLabel: "Turn off", noLog: true }))) return;
    setLoadErr("");
    setList((l) => l.map((x) => (x.id === b.id ? { ...x, notify: v } : x)));
    try {
      const res = await fetch("/api/admin/bidders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.id, notify: v }) });
      if (!res.ok) throw new Error(((await res.json().catch(() => ({}))) as { message?: string }).message ?? `Request failed (${res.status})`);
    } catch (e) {
      setList((l) => l.map((x) => (x.id === b.id ? { ...x, notify: !v } : x))); // roll back
      setLoadErr(e instanceof Error ? e.message : "Failed to update notifications");
    }
  };
  const invite = async (p: Prospect) => {
    if (!(await confirm({ title: `Invite ${p.first} to register?`, body: `An invitation email will be sent to ${p.email}.`, confirmLabel: "Send invite", tone: "primary", noLog: true }))) return;
    try {
      const res = await fetch("/api/admin/prospects", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: p.id }) });
      const j = (await res.json().catch(() => ({}))) as { item?: Prospect; message?: string };
      if (!res.ok || !j.item) throw new Error(j.message ?? `Request failed (${res.status})`);
      const item = j.item;
      setProspects((l) => l.map((x) => (x.id === p.id ? item : x)));
      flash(`${p.email} marked as invited. (Invitation emails aren't connected yet.)`);
    } catch (e) { flash(e instanceof Error ? e.message : "Failed to update prospect"); }
  };
  const remove = async (p: Prospect) => {
    if (!(await confirm({ title: "Remove this prospect?", body: `${p.first} ${p.last} will be removed from the global bidder directory.`, confirmLabel: "Remove", noLog: true }))) return;
    try {
      const res = await fetch(`/api/admin/prospects?id=${encodeURIComponent(p.id)}`, { method: "DELETE" });
      if (!res.ok) throw new Error(((await res.json().catch(() => ({}))) as { message?: string }).message ?? `Request failed (${res.status})`);
      setProspects((l) => l.filter((x) => x.id !== p.id));
    } catch (e) { flash(e instanceof Error ? e.message : "Failed to remove prospect"); }
  };
  const fmtDate = (iso: string) => new Date(iso).toLocaleString("en-US", { month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");

  return (
    <>
      <PageHead title="Bidders Directory" sub="Monitor registered bidders and nurture global prospects from a single workspace"
        chips={<><span className="flex items-center gap-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" />Active</span><span>Timezone: Asia/Kuala_Lumpur</span></>} />
      <div className="mb-3 flex gap-2" role="tablist">
        {([["reg", "Registered bidders"], ["non", "Non-registered bidders"]] as const).map(([id, l]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => { setTab(id); setQ(""); }} className={`rounded-md px-3 py-1.5 text-xs font-semibold ${tab === id ? "bg-primary text-white" : "text-zinc-700 hover:bg-zinc-200"}`}>{l}</button>
        ))}
      </div>
      {toast && <p role="status" className="mb-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{toast}</p>}
      {tab === "reg" ? (
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3 p-4">
            <SearchBox value={q} onChange={setQ} placeholder="Search by name, email, or phone" className="w-72" />
            <div className="flex items-center gap-2">
              <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort bidders" className="h-9 rounded-md border border-zinc-300 bg-white px-3 text-xs">
                {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
              <Btn className="h-9 text-xs" disabled={loading} onClick={() => void load()}><RefreshCw className={`size-3.5 ${loading ? "animate-spin" : ""}`} />Refresh</Btn>
            </div>
          </div>
          {loadErr && <p role="alert" className="mx-4 mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
          <DataTable empty={loading ? "Loading…" : "No bidders found."} head={["Status", "Bidder", "Email", "Phone", "Registered on", "Bids", "Registrations", "Notifications"]}
            rows={ordered.map((b) => [
              <div key="s"><Badge tone={b.completed ? "blue" : "amber"}>{b.completed ? "Completed" : "Incomplete"}</Badge></div>,
              <div key="n"><p className="text-[13px] font-semibold">{b.name}</p></div>,
              b.email, phoneOf(b), b.registered, <b key="b">{b.bids}</b>,
              <b key="r">{b.registrations}</b>,
              <span key="t" className="flex items-center gap-2"><Toggle on={b.notify} label={`Notifications for ${b.name}`} onChange={(v) => setNotify(b, v)} />{b.notify ? <Bell className="size-4 text-primary" /> : <BellOff className="size-4 text-zinc-400" />}</span>,
            ])} />
        </Card>
      ) : (
        <Card>
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-zinc-200 px-5 py-4">
            <div><h2 className="text-sm font-bold">Global bidder directory</h2><p className="text-xs text-zinc-600">Maintain a prospect list of non-registered bidders. Convert them when they’re ready to participate.</p></div>
            <div className="flex items-center gap-2"><Btn className="h-8 text-xs" disabled={loading} onClick={() => { void load(); void loadProspects(); }}><RefreshCw className={`size-3.5 ${loading ? "animate-spin" : ""}`} />Refresh</Btn><Btn variant="solid" className="h-8 text-xs" onClick={() => setAdd(true)}><UserPlus className="size-3.5" />Add non-registered bidder</Btn></div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 px-5 py-3">
            <SearchBox value={q} onChange={setQ} placeholder="Search by name, company, email, or phone" className="w-80" />
            <select value={psort} onChange={(e) => setPsort(e.target.value as typeof psort)} aria-label="Sort prospects" className="h-9 rounded-md border border-zinc-300 bg-white px-3 text-xs">{PSORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
          </div>
          {pRows.length === 0 ? (
            <div className="grid place-items-center px-6 py-16 text-center">
              <Globe2 className="size-9 text-zinc-400" strokeWidth={1.5} />
              <p className="mt-3 text-sm font-bold">{prospects.length === 0 ? "No non-registered bidders yet" : "No bidders match your search"}</p>
              <p className="mt-1 max-w-sm text-xs text-zinc-500">{prospects.length === 0 ? "Capture potential bidders who haven’t completed a full registration flow. They’ll appear here once added." : "Try a different name, company, email, or phone number."}</p>
            </div>
          ) : (
            <DataTable plainHead head={["Prospect", "Company", "Email", "Phone", "Interests", "Added on", "Actions"]}
              rows={pRows.map((p) => [
                <div key="n"><p className="text-[13px] font-semibold">{p.first} {p.last}</p><p className="text-[10px] text-zinc-500">{p.role || "—"}</p></div>,
                p.company || "—", p.email, p.phone ? `(${p.dial}) ${p.phone}` : "—",
                <span key="i" className="flex flex-wrap gap-1">{p.interests.length ? p.interests.map((i) => <Badge key={i} tone="blue">{i}</Badge>) : <span className="text-zinc-400">—</span>}</span>,
                fmtDate(p.addedAt),
                <span key="x" className="flex items-center gap-1.5">
                  {p.invited ? <Badge tone="amber">Invited</Badge> : <Btn variant="outline" className="h-7 px-2.5 text-[11px]" onClick={() => invite(p)}><Mail className="size-3" />Invite</Btn>}
                  <Btn variant="ghost" className="h-7 px-2.5 text-[11px] text-rose-600" onClick={() => remove(p)}>Remove</Btn>
                </span>,
              ])} />
          )}
          <div className="flex items-center justify-between border-t border-zinc-200 bg-zinc-50/60 px-5 py-3 text-xs text-zinc-600">
            <span>Page 1 of 1 • {prospects.length} total bidders</span>
            <span className="flex gap-2"><Btn variant="outline" className="h-7 px-3 text-[11px]" disabled>Previous</Btn><Btn variant="outline" className="h-7 px-3 text-[11px]" disabled>Next</Btn></span>
          </div>
        </Card>
      )}
      {add && <ProspectDrawer existing={prospects} onClose={() => setAdd(false)} onSave={async (input) => {
        try {
          const res = await fetch("/api/admin/prospects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
          const j = (await res.json().catch(() => ({}))) as { item?: Prospect; message?: string };
          if (!res.ok || !j.item) return j.message ?? `Request failed (${res.status})`;
          const p = j.item;
          setProspects((l) => [p, ...l]); setAdd(false); flash(`${p.first} ${p.last} was added to the global bidder directory.`);
          return "";
        } catch { return "Couldn't reach the server. Try again."; }
      }} />}
      {dialog}
    </>
  );
}

/* ---------- Hammer Sales ---------- */

type Opt = readonly [string, string, string];
const SORT_OPTS: readonly Opt[] = [["fresh", "Freshly closed", "Newest wrap-ups first"], ["next", "Next to action", "Earliest start dates"], ["wrap", "Wrap-up first", "Soonest ending lots"], ["vol", "Lot volume", "Largest catalogues"], ["bid", "Bid energy", "Highest bid counts"]];
const FLOW_OPTS: readonly Opt[] = [["all", "All flows", "Closed auctions with or without wrap-up actions"], ["action", "Action needed", "Auctions with outstanding allocations or invoices"], ["done", "Fully wrapped", "Auctions with allocations and invoices completed"]];
const TIMELINES = ["All time", "Last 30 days", "Last 60 days", "Quarter to date", "Year to date", "Custom range"] as const;

/** Two-line dropdown: selected item is dark blue with a check, as in the design. */
function TwoLineSelect({ label, value, options, onChange, width = "w-44" }: { label: string; value: string; options: readonly Opt[]; onChange: (v: string) => void; width?: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const down = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    const key = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", down); document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", down); document.removeEventListener("keydown", key); };
  }, [open]);
  const cur = options.find((o) => o[0] === value)!;
  return (
    <div ref={ref} className={`relative ${width}`}>
      <button type="button" aria-label={label} aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen((v) => !v)}
        className="flex h-11 w-full items-center justify-between gap-2 rounded-md border border-zinc-300 bg-white px-3 text-left hover:bg-zinc-50">
        <span className="min-w-0"><span className="block truncate text-xs font-medium leading-tight">{cur[1]}</span><span className="block truncate text-[10px] leading-tight text-zinc-500">{cur[2]}</span></span>
        <ChevronDown className="size-3.5 shrink-0 text-zinc-400" />
      </button>
      {open && (
        <ul role="listbox" aria-label={label} className="absolute right-0 z-30 mt-1 w-72 rounded-lg border border-zinc-200 bg-white p-1 shadow-xl">
          {options.map(([v, t, s]) => {
            const on = v === value;
            return (
              <li key={v} role="option" aria-selected={on}>
                <button type="button" onClick={() => { onChange(v); setOpen(false); }} className={`flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-left ${on ? "bg-[#1f4e8c] text-white" : "hover:bg-zinc-50"}`}>
                  <span><span className="block text-xs font-medium">{t}</span><span className={`block text-[10px] ${on ? "text-white/70" : "text-zinc-500"}`}>{s}</span></span>
                  {on && <Check className="size-3.5 shrink-0" />}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

type HammerAuction = { id: string; slug: string; title: string; sequence: number; startsAt: string; endsAt: string; timezone: string; currency: string; type: string; lotCount: number; bidCount: number; lotsAwarded: number; hammerTotal: number; invoices: number; flow: "none" | "action" | "done" };
const HS_PAGE = 10;
const KL = "Asia/Kuala_Lumpur";
const fmtKL = (iso: string) => new Date(iso).toLocaleString("en-GB", { timeZone: KL, day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

/** Start of the timeline window in ms (null = no lower bound). */
function timelineFrom(tl: (typeof TIMELINES)[number]): number | null {
  const now = new Date(), day = 86400000;
  if (tl === "Last 30 days") return now.getTime() - 30 * day;
  if (tl === "Last 60 days") return now.getTime() - 60 * day;
  if (tl === "Year to date") return new Date(now.getFullYear(), 0, 1).getTime();
  if (tl === "Quarter to date") return new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1).getTime();
  return null;
}

export function HammerSalesView() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("fresh");
  const [flow, setFlow] = useState("all");
  const [timed, setTimed] = useState(true); // Auction types → Timed (the only type that exists today)
  const [tl, setTl] = useState<(typeof TIMELINES)[number]>("All time");
  const [range, setRange] = useState({ from: "", to: "" });
  const [items, setItems] = useState<HammerAuction[] | null>(null);
  const [err, setErr] = useState("");
  const [page, setPage] = useState(1);
  const rangeBad = !!range.from && !!range.to && range.from > range.to;
  const dmy = (iso: string) => iso.split("-").reverse().join("/");
  const viewLabel = tl === "Custom range" && (range.from || range.to) ? `${range.from ? dmy(range.from) : "…"} – ${range.to ? dmy(range.to) : "…"}` : tl;
  const chipCls = "rounded-md border px-3 py-1.5 text-xs font-medium transition";

  const load = useCallback(async () => {
    try {
      const res = await withMinSpin(() => fetch("/api/admin/hammer-sales", { cache: "no-store" }));
      const j = (await res.json().catch(() => ({}))) as { items?: HammerAuction[]; message?: string };
      if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
      setItems(j.items ?? []); setErr("");
    } catch (e) { setErr(e instanceof Error ? e.message : "Failed to load closed auctions"); setItems((x) => x ?? []); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { setPage(1); }, [q, sort, flow, timed, tl, range.from, range.to]);

  const view = (() => {
    const lo = tl === "Custom range" ? (range.from ? new Date(`${range.from}T00:00:00+08:00`).getTime() : null) : timelineFrom(tl);
    const hi = tl === "Custom range" && range.to ? new Date(`${range.to}T23:59:59+08:00`).getTime() : null;
    const needle = q.trim().toLowerCase();
    const list = (items ?? []).filter((a) => {
      const end = new Date(a.endsAt).getTime();
      if (lo !== null && end < lo) return false;
      if (hi !== null && end > hi) return false;
      if (flow !== "all" && a.flow !== flow) return false;
      if (needle && !(a.title.toLowerCase().includes(needle) || String(a.sequence).includes(needle))) return false;
      return true;
    });
    const by: Record<string, (a: HammerAuction, b: HammerAuction) => number> = {
      fresh: (a, b) => b.endsAt.localeCompare(a.endsAt),
      next: (a, b) => a.startsAt.localeCompare(b.startsAt),
      wrap: (a, b) => a.endsAt.localeCompare(b.endsAt),
      vol: (a, b) => b.lotCount - a.lotCount,
      bid: (a, b) => b.bidCount - a.bidCount,
    };
    return [...list].sort(by[sort] ?? by.fresh);
  })();
  const withBids = view.filter((a) => a.lotsAwarded > 0).length;
  const pages = Math.max(1, Math.ceil(view.length / HS_PAGE));
  const cur = Math.min(page, pages);
  const rows = view.slice((cur - 1) * HS_PAGE, cur * HS_PAGE);
  const stats = [
    { tag: "With bids", tone: "bg-sky-100 text-sky-800", n: String(withBids), cap: "Closed events capturing bidder activity", Icon: Trophy, ic: "bg-sky-100 text-sky-600" },
    { tag: "No bids", tone: "bg-orange-100 text-orange-700", n: String(view.length - withBids), cap: "Closed but awaiting allocations", Icon: Gavel, ic: "bg-orange-100 text-orange-600" },
    { tag: "Current view", tone: "bg-blue-100 text-blue-800", n: String(view.length), cap: viewLabel, Icon: CalendarDays, ic: "bg-blue-100 text-blue-600" },
  ];
  const flowBadge = (a: HammerAuction) => a.flow === "done" ? <Badge key="f">Fully wrapped</Badge> : a.flow === "action" ? <span key="f" className="rounded bg-orange-100 px-1.5 py-0.5 text-[10px] font-semibold text-orange-700">Action needed</span> : <span key="f" className="text-[10px] text-zinc-500">No bids</span>;
  return (
    <>
      <PageHead title="Hammer Sales" sub="Review closed auctions, hammer activity, and wrap-up readiness"
        chips={<><span className="flex items-center gap-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" />{view.length} closed auction{view.length === 1 ? "" : "s"}</span><span>{viewLabel}</span></>}
        actions={<RefreshBtn onRefresh={() => void load()} />} />
      {err && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{err}</p>}

      <div className="rounded-2xl bg-zinc-100 p-3">
        <div className="grid gap-3 sm:grid-cols-3">
          {stats.map(({ tag, tone, n, cap, Icon, ic }) => (
            <Card key={tag} className="flex items-start justify-between p-4">
              <div>
                <span className={`inline-block rounded px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide ${tone}`}>{tag}</span>
                <p className="mt-2 text-2xl font-bold leading-none">{items === null ? "…" : n}</p>
                <p className="mt-1.5 text-[11px] text-zinc-500">{cap}</p>
              </div>
              <span className={`grid size-8 place-items-center rounded-md ${ic}`}><Icon className="size-4" /></span>
            </Card>
          ))}
        </div>
      </div>

      <Card className="mt-5 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <SearchBox value={q} onChange={setQ} placeholder="Search auction name or sequence..." className="w-80" />
          <div className="flex items-center gap-2">
            <TwoLineSelect label="Sort auctions" value={sort} options={SORT_OPTS} onChange={setSort} />
            <TwoLineSelect label="Filter by flow" value={flow} options={FLOW_OPTS} onChange={setFlow} width="w-44" />
          </div>
        </div>
        <p className="mt-5 flex items-center gap-2 text-xs font-medium"><Filter className="size-3.5 text-zinc-500" />Auction types</p>
        <div className="mt-2" role="group" aria-label="Auction types">
          <button type="button" onClick={() => setTimed((v) => !v)} aria-pressed={timed}
            className={`${chipCls} inline-flex items-center gap-1.5 ${timed ? "border-primary bg-primary text-white" : "border-primary/40 bg-white text-primary hover:bg-primary/5"}`}><Timer className="size-3.5" />Timed</button>
        </div>
        <p className="mt-5 flex items-center gap-2 text-xs font-medium"><CalendarDays className="size-3.5 text-zinc-500" />Timeline</p>
        <div className="mt-2 flex flex-wrap gap-2" role="group" aria-label="Timeline">
          {TIMELINES.map((t) => <button key={t} onClick={() => setTl(t)} aria-pressed={tl === t} className={`${chipCls} ${tl === t ? "border-primary bg-primary text-white" : "border-primary/40 bg-white text-primary hover:bg-primary/5"}`}>{t}</button>)}
        </div>
        {tl === "Custom range" && (
          <div className="mt-3 flex flex-wrap items-end gap-3">
            <Field label="From"><input type="date" className={`${inputCls} w-40`} max={range.to || undefined} value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} /></Field>
            <Field label="To"><input type="date" className={`${inputCls} w-40`} min={range.from || undefined} value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} /></Field>
            {rangeBad && <p role="alert" className="pb-2 text-[11px] text-rose-600">From date can’t be after the To date.</p>}
          </div>
        )}
        <p className="mt-3 flex items-center gap-2 text-[11px] text-zinc-600"><span className="rounded border border-primary/40 px-1.5 py-0.5 text-[10px] text-primary">{viewLabel}</span>in Asia/Kuala_Lumpur</p>
      </Card>

      <Card className="mt-5">
        <div className="flex items-start justify-between px-5 py-4">
          <div><h2 className="text-sm font-bold">Closed auction performance</h2><p className="text-[11px] text-zinc-500">Showing {view.length} result{view.length === 1 ? "" : "s"}</p></div>
          <span className="flex items-center gap-1.5 text-[11px] text-zinc-600"><span className="size-2 rounded-full bg-sky-500" />Lots awarded</span>
        </div>
        <div className="border-t border-zinc-200 px-1">
          <DataTable plainHead head={["Auction", "Schedule", "Activity", "Actions"]} empty={items === null ? "Loading…" : "No closed auctions match this view yet. Adjust filters or try another range."}
            rows={rows.map((a) => [
              <span key="a"><span className="block font-semibold">{a.title}</span><span className="text-[10px] text-zinc-500">#{a.sequence} · Timed</span></span>,
              <span key="s" className="text-[11px] leading-snug">{fmtKL(a.startsAt)}<br />→ {fmtKL(a.endsAt)}</span>,
              <span key="x" className="block min-w-40">
                <span className="text-[11px]"><b>{a.lotsAwarded}</b> / {a.lotCount} lots awarded · {a.bidCount} bids</span>
                <span className="mt-1 block h-1.5 w-40 overflow-hidden rounded-full bg-zinc-200"><span className="block h-full bg-sky-500" style={{ width: `${a.lotCount ? Math.min(100, (a.lotsAwarded / a.lotCount) * 100) : 0}%` }} /></span>
                <span className="mt-1 block text-[10px] text-zinc-500">Hammer total {new Intl.NumberFormat("en-US", { style: "currency", currency: a.currency || "MYR", maximumFractionDigits: 0 }).format(a.hammerTotal)} · {a.invoices} invoice{a.invoices === 1 ? "" : "s"}</span>
              </span>,
              <span key="b" className="flex flex-wrap items-center gap-2">{flowBadge(a)}<Btn variant="outline" className="h-7 px-2.5 text-[11px]" onClick={() => router.push(`/admin/auction-studio/${a.id}`)}>Open</Btn></span>,
            ])} />
        </div>
        <div className="flex items-center justify-between border-t border-zinc-200 px-5 py-3 text-[11px] text-zinc-500"><span>Showing {rows.length ? (cur - 1) * HS_PAGE + 1 : 0}–{(cur - 1) * HS_PAGE + rows.length} of {view.length}</span><span className="flex items-center gap-2"><Btn variant="outline" className="h-7 px-2.5 text-[11px]" disabled={cur <= 1} onClick={() => setPage(cur - 1)}>Previous</Btn><span className="text-ink">Page {cur}</span><Btn variant="outline" className="h-7 px-2.5 text-[11px]" disabled={cur >= pages} onClick={() => setPage(cur + 1)}>Next</Btn></span></div>
      </Card>
    </>
  );
}

type InvoiceRow = {
  id: string; number: string; status: "UNPAID" | "PAID"; currency: string; hammer: number; commission: number; internetFee: number; tax: number; amount: number;
  created: string; bidder: string; email: string; auctionTitle: string; lotNumber: number; lotTitle: string;
};
type Candidate = { id: string; lotNumber: number; title: string; hammer: number; bidder: string; email: string; invoiced: boolean };
type CandidateAuction = { id: string; title: string; currency: string; lots: Candidate[] };

async function adminJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { cache: "no-store", ...init });
  const j = (await res.json().catch(() => ({}))) as T & { message?: string };
  if (!res.ok) throw new Error(j.message ?? `Request failed (${res.status})`);
  return j;
}

/** New invoice: pick an awarded lot (bidder and hammer price are filled in) or enter them by hand. Fees and tax are added by the server. */
function NewInvoiceModal({ onClose, onCreated }: { onClose: () => void; onCreated: (number: string) => void }) {
  const [cands, setCands] = useState<CandidateAuction[] | null>(null);
  const [loadErr, setLoadErr] = useState("");
  const [auction, setAuction] = useState("");
  const [lot, setLot] = useState("");
  const [email, setEmail] = useState("");
  const [hammer, setHammer] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  useEffect(() => {
    adminJson<{ auctions: CandidateAuction[] }>("/api/admin/invoice-candidates").then((j) => setCands(j.auctions)).catch((e) => { setLoadErr(e instanceof Error ? e.message : "Could not load awarded lots"); setCands([]); });
  }, []);
  const a = cands?.find((x) => x.id === auction);
  const open = (a?.lots ?? []).filter((l) => !l.invoiced);
  const pickLot = (id: string) => {
    setLot(id);
    const l = open.find((x) => x.id === id);
    if (l) { setEmail(l.email); setHammer(String(l.hammer)); }
  };
  const amount = Number(hammer);
  const valid = !!auction && !!lot && /^\S+@\S+\.\S+$/.test(email.trim()) && amount > 0 && !busy;
  const create = async () => {
    setBusy(true); setErr("");
    try {
      const j = await adminJson<{ number: string }>("/api/admin/invoices", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ auction, lot, email: email.trim(), hammer: amount }) });
      onCreated(j.number);
    } catch (e) { setErr(e instanceof Error ? e.message : "Could not create the invoice"); setBusy(false); }
  };
  return (
    <Modal title="New invoice" sub="Choose an awarded lot. The bidder and hammer price are filled in; you can correct them." onClose={onClose}
      footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="solid" disabled={!valid} onClick={() => void create()}>{busy ? "Creating…" : "Create invoice"}</Btn></>}>
      {loadErr && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
      <div className="space-y-3">
        <Field label="Auction">
          <select className={inputCls} value={auction} onChange={(e) => { setAuction(e.target.value); setLot(""); setEmail(""); setHammer(""); }} disabled={cands === null}>
            <option value="">{cands === null ? "Loading…" : cands.length ? "Choose an auction" : "No auction has bids yet"}</option>
            {(cands ?? []).map((x) => <option key={x.id} value={x.id}>{x.title}</option>)}
          </select>
        </Field>
        <Field label="Lot">
          <select className={inputCls} value={lot} onChange={(e) => pickLot(e.target.value)} disabled={!auction}>
            <option value="">{!auction ? "Choose an auction first" : open.length ? "Choose a lot" : "Every awarded lot already has an invoice"}</option>
            {open.map((l) => <option key={l.id} value={l.id}>Lot {l.lotNumber} · {l.title} — {formatMoney(l.hammer, a?.currency ?? "")}{l.bidder ? ` · ${l.bidder}` : ""}</option>)}
          </select>
        </Field>
        <Field label="Bidder email"><input type="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="bidder@email.com" /></Field>
        <Field label={`Hammer price${a?.currency ? ` (${a.currency})` : ""}`}><input type="number" min="0" step="0.01" className={inputCls} value={hammer} onChange={(e) => setHammer(e.target.value)} /></Field>
      </div>
      <p className="mt-3 text-[11px] text-zinc-500">Commission, internet buying fee and tax are added automatically from Company and Auction House settings. The bidder gets an in-app notice.</p>
      {err && <p role="alert" className="mt-2 text-[11px] text-rose-600">{err}</p>}
    </Modal>
  );
}

export function InvoiceMgmtView() {
  const [rows, setRows] = useState<InvoiceRow[] | null>(null);
  const [loadErr, setLoadErr] = useState("");
  const [actErr, setActErr] = useState("");
  const [toast, setToast] = useState("");
  const [busyId, setBusyId] = useState("");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState<"new" | "old" | "high">("new");
  const [date, setDate] = useState<"all" | "30" | "60">("all");
  const [status, setStatus] = useState<string[]>([]);
  const [draft, setDraft] = useState({ sort, date, status });
  const [create, setCreate] = useState(false);
  const active = (sort !== "new" ? 1 : 0) + (date !== "all" ? 1 : 0) + status.length;
  const toggle = (s: string) => setDraft((d) => ({ ...d, status: d.status.includes(s) ? d.status.filter((x) => x !== s) : [...d.status, s] }));
  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(""), 3000); };

  const load = useCallback(async () => {
    setLoadErr("");
    try { setRows((await withMinSpin(() => adminJson<{ items: InvoiceRow[] }>("/api/admin/invoices"))).items); }
    catch (e) { setLoadErr(e instanceof Error ? e.message : "Could not load invoices"); setRows([]); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const setPaid = async (r: InvoiceRow, paid: boolean) => {
    setBusyId(r.id); setActErr("");
    try {
      await adminJson("/api/admin/invoices", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: r.id, status: paid ? "PAID" : "UNPAID" }) });
      setRows((l) => (l ?? []).map((x) => (x.id === r.id ? { ...x, status: paid ? "PAID" : "UNPAID" } : x)));
      flash(`${r.number} marked as ${paid ? "paid" : "unpaid"}.`);
    } catch (e) { setActErr(e instanceof Error ? e.message : "Could not update the invoice"); }
    finally { setBusyId(""); }
  };

  const needle = q.trim().toLowerCase();
  const day = 86400000;
  const shown = (rows ?? [])
    .filter((r) => !needle || `${r.number} ${r.bidder} ${r.email} ${r.auctionTitle} ${r.lotTitle}`.toLowerCase().includes(needle))
    .filter((r) => status.length === 0 || status.includes(r.status))
    .filter((r) => date === "all" || Date.now() - new Date(r.created).getTime() <= Number(date) * day)
    .sort((a, b) => sort === "high" ? b.amount - a.amount : sort === "old" ? +new Date(a.created) - +new Date(b.created) : +new Date(b.created) - +new Date(a.created));

  return (
    <>
      <PageHead title="Invoice Management" sub="Issue invoices for awarded lots and track which are paid"
        chips={<><span className="flex items-center gap-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" />{rows ? rows.length : "…"} invoices</span><span>All issued dates</span></>}
        actions={<><RefreshBtn onRefresh={() => void load()} /><Btn variant="solid" onClick={() => setCreate(true)}><Plus className="size-4" />New invoice</Btn></>} />
      <Card className="p-4">
        <div className="flex items-center justify-between gap-3"><SearchBox value={q} onChange={setQ} placeholder="Search invoices, bidders or auctions" className="w-72" />
          <Btn variant="ghost" className="h-9 text-xs" onClick={() => { setDraft({ sort, date, status }); setOpen(true); }}><SlidersHorizontal className="size-3.5" />Filter &amp; sort{active > 0 && <span className="rounded-full bg-primary px-1.5 text-[10px] text-white">{active}</span>}</Btn></div>
        {loadErr && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{loadErr}</p>}
        {actErr && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{actErr}</p>}
        {toast && <p role="status" className="mt-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{toast}</p>}
        <div className="mt-4">
          <DataTable head={["Invoice", "Bidder", "Auction / Lot", "Amount", "Status", "Issued", "Actions"]}
            empty={rows === null ? "Loading…" : rows.length === 0 ? "No invoices yet. Use New invoice to issue one." : "No invoices match this view."}
            rows={shown.map((r) => [
              <b key="n">{r.number}</b>,
              <div key="b"><p className="text-[13px] font-semibold">{r.bidder || "—"}</p><p className="text-zinc-500">{r.email}</p></div>,
              <span key="l">{r.auctionTitle || "—"}{r.lotNumber ? <span className="block text-zinc-500">Lot {r.lotNumber} · {r.lotTitle}</span> : null}</span>,
              <span key="a" className="whitespace-nowrap font-semibold">{formatMoney(r.amount, r.currency)}
                {r.hammer ? <span className="block text-[10px] font-normal text-zinc-500">hammer {formatMoney(r.hammer, r.currency)}{r.commission ? ` + commission ${formatMoney(r.commission, r.currency)}` : ""}{r.internetFee ? ` + fee ${formatMoney(r.internetFee, r.currency)}` : ""}{r.tax ? ` + tax ${formatMoney(r.tax, r.currency)}` : ""}</span> : null}</span>,
              <Badge key="s" tone={r.status === "PAID" ? "green" : "amber"}>{r.status === "PAID" ? "Paid" : "Unpaid"}</Badge>,
              <span key="d" className="whitespace-nowrap">{new Date(r.created).toLocaleDateString("en-GB")}</span>,
              r.status === "PAID"
                ? <Btn key="x" variant="ghost" className="h-7 text-[11px]" disabled={busyId === r.id} onClick={() => void setPaid(r, false)}><Undo2 className="size-3" />Mark unpaid</Btn>
                : <Btn key="x" variant="outline" className="h-7 text-[11px]" disabled={busyId === r.id} onClick={() => void setPaid(r, true)}><Check className="size-3" />Mark paid</Btn>,
            ])} />
        </div>
      </Card>
      {open && (
        <Drawer title="Filter & sort" sub="Refine the invoice list." onClose={() => setOpen(false)}
          footer={<><Btn variant="ghost" className="flex-1" onClick={() => setDraft({ sort: "new", date: "all", status: [] })}>Reset all</Btn><Btn variant="solid" className="flex-1" onClick={() => { setSort(draft.sort); setDate(draft.date); setStatus(draft.status); setOpen(false); }}>Apply</Btn></>}>
          <div><p className="mb-2 text-xs font-bold uppercase tracking-wide text-sky-600">Sort by</p><div className="space-y-2">
            {([["new", "Newest first", "Latest invoices on top"], ["old", "Oldest first", "Chronological order"], ["high", "High amount first", "Highest total first"]] as const).map(([v, t, sub]) => <Choice key={v} active={draft.sort === v} title={t} sub={sub} onClick={() => setDraft({ ...draft, sort: v })} />)}</div></div>
          <div><p className="mb-2 mt-4 text-xs font-bold uppercase tracking-wide text-sky-600">Date created</p><div className="flex gap-2">
            {([["all", "All dates"], ["30", "Last 30 days"], ["60", "Last 60 days"]] as const).map(([v, l]) => <button key={v} onClick={() => setDraft({ ...draft, date: v })} aria-pressed={draft.date === v} className={`rounded-full border px-3 py-1 text-xs font-semibold ${draft.date === v ? "border-primary bg-primary text-white" : "border-zinc-200"}`}>{l}</button>)}</div></div>
          <div><p className="mb-2 mt-4 text-xs font-bold uppercase tracking-wide text-sky-600">Status</p><div className="space-y-2">
            {([["UNPAID", "Unpaid", "Issued, waiting for payment", "bg-amber-500"], ["PAID", "Paid", "Payment confirmed", "bg-sky-500"]] as const).map(([v, t, sub, dot]) => <Choice key={v} dot={dot} active={draft.status.includes(v)} title={t} sub={sub} onClick={() => toggle(v)} />)}</div></div>
        </Drawer>
      )}
      {create && <NewInvoiceModal onClose={() => setCreate(false)} onCreated={(n) => { setCreate(false); flash(`Invoice ${n} created.`); void load(); }} />}
    </>
  );
}
