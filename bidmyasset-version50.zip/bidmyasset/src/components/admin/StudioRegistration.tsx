"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Badge, Btn, DataTable, Modal, SearchBox, useConfirm } from "@/components/admin/ui";
import { loadRegistrations, reviewRegistration, studio, type RegRow, type RegStatus } from "@/lib/studioApi";
import type { StudioAuction } from "@/lib/admin";

const TONE: Record<RegStatus, "orange" | "blue" | "red"> = { PENDING: "orange", APPROVED: "blue", REJECTED: "red" };
const LABEL: Record<RegStatus, string> = { PENDING: "Pending", APPROVED: "Approved", REJECTED: "Rejected" };
const FILTERS = [["ALL", "All"], ["PENDING", "Pending"], ["APPROVED", "Approved"], ["REJECTED", "Rejected"]] as const;

const when = (iso: string, tz: string) =>
  new Date(iso).toLocaleString("en-GB", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).replace(",", "");
const show = (v: unknown) => (Array.isArray(v) ? v.join(", ") : typeof v === "object" && v !== null ? JSON.stringify(v) : String(v ?? ""));

/**
 * Bidder registrations for one auction, read from and written to the real `registrations` collection.
 * Only APPROVED registrations can bid. `inline` renders in the page (Registrations tab); otherwise it opens as a dialog.
 */
export function RegistrationPanel({ auction: a, onClose, inline = false }: { auction: StudioAuction; onClose: () => void; inline?: boolean }) {
  const [rows, setRows] = useState<RegRow[] | null>(null);
  const [labels, setLabels] = useState<Record<string, string>>({});
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState("");
  const [flt, setFlt] = useState<"ALL" | RegStatus>("ALL");
  const [q, setQ] = useState("");
  const { confirm, dialog } = useConfirm();
  const tz = a.tz ?? "Asia/Kuala_Lumpur";

  const reload = useCallback(() => {
    setErr(""); setRows(null);
    loadRegistrations(a.id).then((r) => { setRows(r.items); setLabels(Object.fromEntries((r.questions ?? []).map((x) => [x.id, x.text]))); }).catch((e) => { setErr(e instanceof Error ? e.message : "Could not load registrations"); setRows([]); });
  }, [a.id]);
  useEffect(() => { if (studio.live) reload(); else setRows([]); }, [reload]);

  const set = async (r: RegRow, status: RegStatus) => {
    if (r.status === "APPROVED" && status !== "APPROVED") {
      const ok = await confirm({ title: `Reject ${r.name}?`, body: "They will no longer be able to bid in this auction. Bids they have already placed are not removed.", confirmLabel: "Reject" });
      if (!ok) return;
    }
    setBusy(r.id); setErr(""); setNote("");
    try {
      const res = await reviewRegistration(r.id, status);
      setRows((l) => (l ?? []).map((x) => (x.id === r.id ? { ...x, status } : x)));
      setNote(status === "APPROVED" ? `${r.name} can now bid.` : `${r.name} was rejected.${res.leadingBids ? ` They still lead ${res.leadingBids} lot${res.leadingBids === 1 ? "" : "s"}; check those bids.` : ""}`);
    } catch (e) { setErr(e instanceof Error ? e.message : "Could not update the registration"); }
    setBusy("");
  };

  const all = rows ?? [];
  const count = (s: "ALL" | RegStatus) => all.filter((x) => s === "ALL" || x.status === s).length;
  const shown = all.filter((x) => (flt === "ALL" || x.status === flt) && `${x.name} ${x.email}`.toLowerCase().includes(q.toLowerCase()));

  const body: ReactNode = (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex overflow-hidden rounded-md border border-zinc-200 text-[11px] font-semibold">
          {FILTERS.map(([k, label]) => <button key={k} onClick={() => setFlt(k)} aria-pressed={flt === k} className={`px-2.5 py-1 ${flt === k ? "bg-zinc-100" : "bg-white text-zinc-500 hover:bg-zinc-50"}`}>{label} <span className="text-zinc-400">{count(k)}</span></button>)}
        </div>
        <div className="flex items-center gap-2">
          <SearchBox value={q} onChange={setQ} placeholder="Search bidders..." className="w-44" />
          <Btn variant="outline" className="h-8 text-xs" onClick={reload}>Refresh</Btn>
        </div>
      </div>
      <p className="mt-2 text-[11px] text-zinc-500">{a.approval === "auto" ? "This auction approves registrations automatically." : "New registrations wait here as Pending. A bidder can only bid once approved."}</p>
      {!studio.live && <p role="status" className="mt-3 rounded-md bg-zinc-50 px-3 py-2 text-xs text-zinc-600">Registrations are only available when Auction Studio is connected to the backend.</p>}
      {err && <p role="alert" className="mt-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-700">{err}</p>}
      {note && <p role="status" className="mt-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{note}</p>}
      {rows === null ? <p className="mt-3 text-xs text-zinc-500">Loading registrations…</p> : (
        <div className="mt-3"><DataTable head={["Bidder", "Phone", "Registered", "Status", "Actions"]} empty={all.length ? "No registrations match the current filter." : "No one has registered for this auction yet."}
          rows={shown.map((r) => {
            const answers = Object.entries(r.answers ?? {}).filter(([, v]) => show(v) !== "");
            return [
              <div key="b"><p className="text-[13px] font-semibold">{r.name}</p><p className="text-zinc-500">{r.email}</p>
                {answers.length > 0 && <details className="mt-1 text-[11px]"><summary className="cursor-pointer text-primary">Registration answers</summary><dl className="mt-1 space-y-0.5">{answers.map(([k, v]) => <div key={k}><dt className="inline text-zinc-500">{labels[k] ?? k}: </dt><dd className="inline">{show(v)}</dd></div>)}</dl></details>}</div>,
              r.phone || "—",
              <span key="t" className="whitespace-nowrap">{when(r.at, tz)}</span>,
              <Badge key="s" tone={TONE[r.status] ?? "orange"}>{LABEL[r.status] ?? r.status}</Badge>,
              <div key="x" className="flex gap-1.5">
                {r.status !== "APPROVED" && <Btn className="h-7 text-[11px]" disabled={busy === r.id} onClick={() => set(r, "APPROVED")}>{r.status === "REJECTED" ? "Re-approve" : "Approve"}</Btn>}
                {r.status !== "REJECTED" && <Btn variant="outline" className="h-7 text-[11px]" disabled={busy === r.id} onClick={() => set(r, "REJECTED")}>Reject</Btn>}
              </div>,
            ];
          })} /></div>
      )}
      {dialog}
    </>
  );

  if (inline) return <div className="p-5"><h2 className="mb-3 text-sm font-bold">Registrations ({all.length})</h2>{body}</div>;
  return <Modal title="Bidder Registration" sub={a.title} onClose={onClose} footer={<Btn variant="ghost" onClick={onClose}>Close</Btn>}>{body}</Modal>;
}
