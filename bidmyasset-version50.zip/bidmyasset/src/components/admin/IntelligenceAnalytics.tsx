"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Download, Pause, Play, RotateCcw } from "lucide-react";
import { Btn, Card, SearchBox } from "@/components/admin/ui";
import { StudioGate } from "@/lib/studioApi";
import { bidsOverTime, fmtMoney, fmtWhen, pct, type Intel, type LotStat, type Outcome } from "@/lib/intelData";
import { buildXlsx, downloadBlob } from "@/lib/xlsx";
import { IntelFrame, LoadNote, NotFound, lookupAuction, useIntel } from "@/components/admin/IntelShared";

const th = "px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-zinc-600";
const OUT: Record<Outcome, string> = { SOLD: "Sold", PENDING: "Sold pending", NO_SALE: "No sale", OPEN: "Open" };
const COLOR: Record<Outcome, string> = { SOLD: "#2563eb", PENDING: "#f59e0b", NO_SALE: "#94a3b8", OPEN: "#16a34a" };
const mo = (m: Intel, n: number) => fmtMoney(n, m.currency);
const sum = (xs: number[]) => xs.reduce((n, x) => n + x, 0);

function Kpi({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return <div className="rounded-xl border border-zinc-200 bg-white p-4"><p className="text-[10px] font-bold uppercase tracking-wide text-zinc-500">{label}</p><p className="mt-1.5 text-2xl font-bold leading-none">{value}</p>{hint && <p className="mt-1.5 text-[11px] text-zinc-500">{hint}</p>}</div>;
}
const Section = ({ title, sub, children, className = "" }: { title: string; sub?: string; children: ReactNode; className?: string }) =>
  <Card className={`p-4 ${className}`}><h2 className="text-sm font-bold">{title}</h2>{sub && <p className="text-[11px] text-zinc-500">{sub}</p>}<div className="mt-3">{children}</div></Card>;
const Empty = ({ children }: { children: ReactNode }) => <p className="rounded-lg border border-dashed border-zinc-300 bg-zinc-50 px-4 py-6 text-center text-[11px] text-zinc-500">{children}</p>;

function Bars({ data, fmt = (n) => String(n) }: { data: { label: string; n: number }[]; fmt?: (n: number) => string }) {
  const max = Math.max(1, ...data.map((d) => d.n)), w = 600, h = 150, bw = Math.min(40, (w - 20) / data.length - 4);
  return (
    <div className="overflow-x-auto">
      <svg viewBox={`0 0 ${w} ${h + 22}`} role="img" aria-label="Bar chart" className="h-44 w-full min-w-[320px]">
        {data.map((d, i) => {
          const x = 10 + i * ((w - 20) / data.length) + ((w - 20) / data.length - bw) / 2, bh = (d.n / max) * h;
          return <g key={i}><rect x={x} y={h - bh} width={bw} height={bh} rx="3" fill="#2563eb"><title>{`${d.label}: ${fmt(d.n)}`}</title></rect>
            {(data.length <= 14 || i % Math.ceil(data.length / 14) === 0) && <text x={x + bw / 2} y={h + 14} textAnchor="middle" fontSize="9" fill="#71717a">{d.label}</text>}</g>;
        })}
      </svg>
    </div>
  );
}

function HBars({ data, fmt }: { data: { label: string; sub?: string; n: number }[]; fmt: (n: number) => string }) {
  const max = Math.max(1, ...data.map((d) => d.n));
  return (
    <ul className="space-y-2">{data.map((d, i) => (
      <li key={i} className="text-[11px]"><div className="flex justify-between gap-3"><span className="truncate font-semibold">{d.label}{d.sub && <span className="ml-1.5 font-normal text-zinc-500">{d.sub}</span>}</span><span className="shrink-0 text-zinc-600">{fmt(d.n)}</span></div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-zinc-100"><div className="h-full rounded-full bg-primary" style={{ width: `${(d.n / max) * 100}%` }} /></div></li>
    ))}</ul>
  );
}

function Donut({ parts }: { parts: { label: string; n: number; color: string }[] }) {
  const total = sum(parts.map((p) => p.n));
  if (!total) return <Empty>Nothing to chart yet.</Empty>;
  const r = 42, c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className="flex flex-wrap items-center gap-5">
      <svg viewBox="0 0 120 120" role="img" aria-label="Donut chart" className="size-32 -rotate-90">
        {parts.filter((p) => p.n > 0).map((p) => { const len = (p.n / total) * c, el = <circle key={p.label} cx="60" cy="60" r={r} fill="none" stroke={p.color} strokeWidth="16" strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-acc}><title>{`${p.label}: ${p.n}`}</title></circle>; acc += len; return el; })}
      </svg>
      <ul className="space-y-1.5 text-[11px]">{parts.map((p) => <li key={p.label} className="flex items-center gap-2"><span className="size-2.5 rounded-full" style={{ background: p.color }} /><span className="w-28 text-zinc-600">{p.label}</span><b>{p.n}</b><span className="text-zinc-400">({pct(p.n, total)})</span></li>)}</ul>
    </div>
  );
}

/* ---------- shared calculations ---------- */
function core(m: Intel) {
  const closed = m.lots.filter((l) => l.closed), sold = m.lots.filter((l) => l.outcome === "SOLD");
  const bidding = new Set(m.bids.map((b) => b.bidder.no)).size;
  const approved = m.regs.filter((r) => r.status === "APPROVED").length;
  const withReserve = m.lots.filter((l) => l.reserve > 0 && l.bids.length > 0);
  const uplift = sold.filter((l) => l.startBid > 0).map((l) => l.high / l.startBid - 1);
  return { closed, sold, bidding, approved, withReserve, uplift, sales: sum(sold.map((l) => l.high)), lotsWithBids: m.lots.filter((l) => l.bids.length > 0).length };
}

type Props = { id: string };
function useAuction(id: string) { const a = lookupAuction(id); return { a, ...useIntel(a) }; }

/* ---------- KPI analytics ---------- */
function KpiInner({ id }: Props) {
  const { a, m, err, busy, reload } = useAuction(id);
  if (!a) return <NotFound />;
  const c = m ? core(m) : null;
  const top = m ? [...m.lots].sort((x, y) => y.bids.length - x.bids.length).filter((l) => l.bids.length).slice(0, 5) : [];
  return (
    <IntelFrame a={a} label="Auction Intelligence" title="KPI analytics" sub="Headline performance indicators" reload={reload} busy={busy}>
      <LoadNote busy={busy} err={err} />
      {m && c && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="Total sales" value={mo(m, c.sales)} hint={`${c.sold.length} sold lot${c.sold.length === 1 ? "" : "s"}`} />
            <Kpi label="Sell-through" value={pct(c.sold.length, c.closed.length)} hint={`${c.sold.length} of ${c.closed.length} closed lots`} />
            <Kpi label="Avg. uplift on start" value={c.uplift.length ? `${Math.round((sum(c.uplift) / c.uplift.length) * 100)}%` : "—"} hint="Winning bid vs starting bid, sold lots" />
            <Kpi label="Bids per lot" value={m.lots.length ? (m.bids.length / m.lots.length).toFixed(1) : "—"} hint={`${m.bids.length} bids on ${m.lots.length} lots`} />
            <Kpi label="Lots with bids" value={pct(c.lotsWithBids, m.lots.length)} hint={`${c.lotsWithBids} of ${m.lots.length} lots`} />
            <Kpi label="Reserve met" value={pct(c.withReserve.filter((l) => l.reserveStatus === "Reserve met").length, c.withReserve.length)} hint={`${c.withReserve.length} lots with a reserve and bids`} />
            <Kpi label="Bidder participation" value={pct(c.bidding, c.approved)} hint={`${c.bidding} of ${c.approved} approved bidders bid`} />
            <Kpi label="Registration approval" value={pct(c.approved, m.regs.length)} hint={`${c.approved} of ${m.regs.length} registrations`} />
          </div>
          <Section title="Most contested lots" sub="Lots ranked by number of bids.">
            {top.length ? <HBars data={top.map((l) => ({ label: `Lot ${l.no} · ${l.title}`, sub: `${l.bidderCount} bidders`, n: l.bids.length }))} fmt={(n) => `${n} bids`} /> : <Empty>No bids have been placed in this auction yet.</Empty>}
          </Section>
          <p className="text-[10px] text-zinc-500">Computed from this auction's bids, registrations and lots. A lot counts as closed once its closing time has passed.</p>
        </div>
      )}
    </IntelFrame>
  );
}

/* ---------- Unified analytics ---------- */
function UnifiedInner({ id }: Props) {
  const { a, m, err, busy, reload } = useAuction(id);
  if (!a) return <NotFound />;
  const cats = m ? [...m.lots.reduce((mp, l) => { const k = l.category || "Uncategorised"; mp.set(k, [...(mp.get(k) ?? []), l]); return mp; }, new Map<string, LotStat[]>())] : [];
  const series = m ? bidsOverTime(m) : [];
  return (
    <IntelFrame a={a} label="Auction Intelligence" title="Unified analytics" sub="Bidding, categories and lots in one view" reload={reload} busy={busy}>
      <LoadNote busy={busy} err={err} />
      {m && (
        <div className="space-y-4">
          <Section title="Bidding activity" sub={`Bids per ${series.length > 1 && series[1].ms - series[0].ms === 3600000 ? "hour" : "day"} (${m.tz}).`}>
            {series.length ? <Bars data={series} /> : <Empty>No bids have been placed in this auction yet.</Empty>}
          </Section>
          <Section title="By category">
            <div className="overflow-x-auto rounded-lg border border-zinc-200"><table className="w-full min-w-[520px] text-left text-[11px]">
              <thead className="border-b border-zinc-200"><tr>{["Category", "Lots", "Bids", "Sold", "Sell-through", "Sales"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-zinc-100">
                {cats.length === 0 && <tr><td colSpan={6} className="px-3 py-6 text-center text-zinc-500">This auction has no lots yet.</td></tr>}
                {cats.map(([k, ls]) => { const sold = ls.filter((l) => l.outcome === "SOLD"), cl = ls.filter((l) => l.closed);
                  return <tr key={k}><td className="px-3 py-2 font-semibold">{k}</td><td className="px-3 py-2">{ls.length}</td><td className="px-3 py-2">{sum(ls.map((l) => l.bids.length))}</td><td className="px-3 py-2">{sold.length}</td><td className="px-3 py-2">{pct(sold.length, cl.length)}</td><td className="px-3 py-2 font-semibold">{mo(m, sum(sold.map((l) => l.high)))}</td></tr>; })}
              </tbody></table></div>
          </Section>
          <Section title="By lot">
            <div className="overflow-x-auto rounded-lg border border-zinc-200"><table className="w-full min-w-[640px] text-left text-[11px]">
              <thead className="border-b border-zinc-200"><tr>{["Lot", "Title", "Start", "High bid", "Uplift", "Bids", "Bidders", "Status"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-zinc-100">
                {m.lots.map((l) => <tr key={l.id}><td className="px-3 py-2">{l.no}</td><td className="px-3 py-2 font-semibold">{l.title}</td><td className="px-3 py-2">{mo(m, l.startBid)}</td><td className="px-3 py-2">{l.bids.length ? mo(m, l.high) : "—"}</td>
                  <td className="px-3 py-2">{l.bids.length && l.startBid > 0 ? `${Math.round((l.high / l.startBid - 1) * 100)}%` : "—"}</td><td className="px-3 py-2">{l.bids.length}</td><td className="px-3 py-2">{l.bidderCount}</td><td className="px-3 py-2">{OUT[l.outcome]}</td></tr>)}
              </tbody></table></div>
          </Section>
        </div>
      )}
    </IntelFrame>
  );
}

/* ---------- Analytics dashboard ---------- */
function DashboardInner({ id }: Props) {
  const { a, m, err, busy, reload } = useAuction(id);
  if (!a) return <NotFound />;
  const series = m ? bidsOverTime(m) : [];
  const per = new Map<number, { name: string; n: number }>();
  m?.bids.forEach((b) => per.set(b.bidder.no, { name: b.bidder.name, n: (per.get(b.bidder.no)?.n ?? 0) + 1 }));
  const topBidders = [...per.entries()].sort((x, y) => y[1].n - x[1].n).slice(0, 5);
  const topLots = m ? [...m.lots].sort((x, y) => y.bids.length - x.bids.length).filter((l) => l.bids.length).slice(0, 5) : [];
  const regs = m ? (["APPROVED", "PENDING", "REJECTED"] as const).map((s, i) => ({ label: s[0] + s.slice(1).toLowerCase(), n: m.regs.filter((r) => r.status === s).length, color: ["#2563eb", "#f59e0b", "#ef4444"][i] })) : [];
  return (
    <IntelFrame a={a} label="Auction Intelligence" title="Analytics dashboard" sub="Live picture of this auction" reload={reload} busy={busy}>
      <LoadNote busy={busy} err={err} />
      {m && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="Bids" value={m.bids.length} /><Kpi label="Bidders bidding" value={per.size} hint={`${m.regs.length} registered`} />
            <Kpi label="Highest bid" value={m.bids.length ? mo(m, Math.max(...m.bids.map((b) => b.amount))) : "—"} /><Kpi label="Open lots" value={m.lots.filter((l) => l.outcome === "OPEN").length} hint={`${m.lots.length} total`} />
          </div>
          <Section title="Bids over time" sub={`Bids per ${series.length > 1 && series[1].ms - series[0].ms === 3600000 ? "hour" : "day"} (${m.tz}).`}>{series.length ? <Bars data={series} /> : <Empty>No bids have been placed in this auction yet.</Empty>}</Section>
          <div className="grid gap-4 md:grid-cols-2">
            <Section title="Lot outcomes"><Donut parts={(["SOLD", "PENDING", "NO_SALE", "OPEN"] as const).map((o) => ({ label: OUT[o], n: m.lots.filter((l) => l.outcome === o).length, color: COLOR[o] }))} /></Section>
            <Section title="Registrations"><Donut parts={regs} /></Section>
            <Section title="Most contested lots">{topLots.length ? <HBars data={topLots.map((l) => ({ label: `Lot ${l.no} · ${l.title}`, n: l.bids.length }))} fmt={(n) => `${n} bids`} /> : <Empty>No bids yet.</Empty>}</Section>
            <Section title="Most active bidders">{topBidders.length ? <HBars data={topBidders.map(([no, v]) => ({ label: `#${no} ${v.name}`, n: v.n }))} fmt={(n) => `${n} bids`} /> : <Empty>No bids yet.</Empty>}</Section>
          </div>
        </div>
      )}
    </IntelFrame>
  );
}

/* ---------- Bidder analysis ---------- */
type Row = { no: number; name: string; email: string; reg: string; bids: number; lots: number; leading: number; won: number; best: number; value: number; last: number };
function bidderRows(m: Intel): Row[] {
  return m.bidders.map((b) => {
    const mine = m.bids.filter((e) => e.bidder.no === b.no);
    const lead = m.lots.filter((l) => l.winner?.no === b.no);
    return { no: b.no, name: b.name, email: b.email, reg: b.reg === "NONE" ? "No registration" : b.reg[0] + b.reg.slice(1).toLowerCase(), bids: mine.length, lots: new Set(mine.map((e) => e.lotId)).size,
      leading: lead.filter((l) => !l.closed).length, won: lead.filter((l) => l.outcome === "SOLD").length, best: Math.max(0, ...mine.map((e) => e.amount)),
      value: sum(lead.filter((l) => l.outcome === "SOLD" || !l.closed).map((l) => l.high)), last: Math.max(0, ...mine.map((e) => e.ms)) };
  });
}
const SORTS = [["bids", "Most bids"], ["value", "Highest value"], ["no", "Bidder no."]] as const;

function BidderInner({ id }: Props) {
  const { a, m, err, busy, reload } = useAuction(id);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<(typeof SORTS)[number][0]>("bids");
  const rows = useMemo(() => (m ? bidderRows(m) : []).filter((r) => `${r.name} ${r.email}`.toLowerCase().includes(q.toLowerCase()))
    .sort((x, y) => (sort === "no" ? x.no - y.no : y[sort] - x[sort] || x.no - y.no)), [m, q, sort]);
  if (!a) return <NotFound />;
  const active = rows.filter((r) => r.bids > 0).length;
  const exportIt = () => m && downloadBlob(buildXlsx([{ name: "Bidders", rows: [["Bidder no.", "Name", "Email", "Registration", "Bids", "Lots bid on", "Leading now", "Lots won", "Highest bid", "Value (won + leading)", "Last bid"],
    ...bidderRows(m).map((r) => [r.no, r.name, r.email, r.reg, r.bids, r.lots, r.leading, r.won, r.best, r.value, r.last ? fmtWhen(r.last, m.tz) : ""])] }]), `${a.title}-Bidder-Analysis.xlsx`.replace(/[^\w.-]+/g, "-"));
  return (
    <IntelFrame a={a} label="Auction Intelligence" title="Bidder analysis" sub="Who is bidding, and how much" reload={reload} busy={busy}
      actions={<Btn variant="solid" className="h-8 bg-ink text-xs hover:bg-ink/90" disabled={!m} onClick={exportIt}><Download className="size-3.5" />Excel</Btn>}>
      <LoadNote busy={busy} err={err} />
      {m && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="Registered" value={m.regs.length} /><Kpi label="Approved" value={m.regs.filter((r) => r.status === "APPROVED").length} />
            <Kpi label="Bidding" value={new Set(m.bids.map((b) => b.bidder.no)).size} hint="Bidders with at least one bid" /><Kpi label="Signed in" value={m.logins.length} hint="While the auction ran" />
          </div>
          <Card>
            <div className="flex flex-wrap items-center justify-between gap-3 p-4">
              <SearchBox value={q} onChange={setQ} placeholder="Search bidders..." className="w-72 max-w-full" />
              <div role="group" aria-label="Sort" className="flex overflow-hidden rounded border border-zinc-300">{SORTS.map(([v, l]) => <button key={v} aria-pressed={sort === v} onClick={() => setSort(v)} className={`px-2.5 py-1 text-[11px] font-semibold ${sort === v ? "bg-ink text-white" : "bg-white"}`}>{l}</button>)}</div>
            </div>
            <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-[11px]">
              <thead className="border-y border-zinc-200"><tr>{["No.", "Bidder", "Registration", "Bids", "Lots", "Leading", "Won", "Highest bid", "Value", "Last bid"].map((h) => <th key={h} className={th}>{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-zinc-100">
                {rows.length === 0 && <tr><td colSpan={10} className="px-3 py-8 text-center text-zinc-500">{m.bidders.length ? "No bidders match." : "Nobody has registered for this auction yet."}</td></tr>}
                {rows.map((r) => <tr key={r.no}><td className="px-3 py-2 font-bold">{r.no}</td><td className="px-3 py-2"><p className="font-semibold">{r.name}</p><p className="text-zinc-500">{r.email}</p></td><td className="px-3 py-2">{r.reg}</td>
                  <td className="px-3 py-2">{r.bids}</td><td className="px-3 py-2">{r.lots}</td><td className="px-3 py-2">{r.leading}</td><td className="px-3 py-2">{r.won}</td><td className="px-3 py-2">{r.best ? mo(m, r.best) : "—"}</td><td className="px-3 py-2 font-semibold">{r.value ? mo(m, r.value) : "—"}</td><td className="whitespace-nowrap px-3 py-2">{r.last ? fmtWhen(r.last, m.tz) : "—"}</td></tr>)}
              </tbody></table></div>
            <p className="px-4 py-3 text-[10px] text-zinc-500">{active} of {rows.length} listed bidders have bid. Value = winning bids on sold lots plus bids that currently lead open lots.</p>
          </Card>
        </div>
      )}
    </IntelFrame>
  );
}

/* ---------- Recordings: bid-by-bid replay ---------- */
function ReplayInner({ id }: Props) {
  const { a, m, err, busy, reload } = useAuction(id);
  const [at, setAt] = useState(0); // number of bids replayed so far
  const [play, setPlay] = useState(false);
  const total = m?.bids.length ?? 0;
  useEffect(() => { setAt(0); setPlay(false); }, [m]);
  useEffect(() => {
    if (!play) return;
    if (at >= total) { setPlay(false); return; }
    const t = setTimeout(() => setAt((n) => n + 1), 700);
    return () => clearTimeout(t);
  }, [play, at, total]);
  if (!a) return <NotFound />;
  const seen = m ? m.bids.slice(0, at) : [];
  const state = new Map<string, { lot: string; amount: number; who: string }>();
  seen.forEach((b) => state.set(b.lotId, { lot: `Lot ${b.lotNo} · ${b.lotTitle}`, amount: b.amount, who: `#${b.bidder.no} ${b.bidder.name}` }));
  return (
    <IntelFrame a={a} label="Auction Intelligence" title="Recordings" sub="Bid-by-bid replay of this auction" reload={reload} busy={busy}>
      <LoadNote busy={busy} err={err} />
      {m && (
        <div className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-wrap items-center gap-3">
              <Btn variant="solid" className="h-8 text-xs" disabled={!total} onClick={() => { if (at >= total) setAt(0); setPlay((p) => !p); }}>{play ? <><Pause className="size-3.5" />Pause</> : <><Play className="size-3.5" />{at >= total && total ? "Replay" : "Play"}</>}</Btn>
              <Btn variant="outline" className="h-8 text-xs" disabled={!total} onClick={() => { setPlay(false); setAt(0); }}><RotateCcw className="size-3.5" />Restart</Btn>
              <input type="range" min={0} max={total} value={at} disabled={!total} onChange={(e) => { setPlay(false); setAt(Number(e.target.value)); }} aria-label="Replay position" className="min-w-40 flex-1" />
              <span className="text-[11px] text-zinc-600">{at} / {total} bids{at > 0 ? ` · ${fmtWhen(m.bids[at - 1].ms, m.tz)}` : ""}</span>
            </div>
          </Card>
          {total === 0 ? <Empty>No bids have been placed in this auction yet, so there is nothing to replay.</Empty> : (
            <div className="grid gap-4 md:grid-cols-2">
              <Section title="Standing at this moment" sub="Highest bid on each lot so far.">
                {state.size === 0 ? <Empty>Press Play to start the replay.</Empty> : <ul className="divide-y divide-zinc-100 text-[11px]">{[...state.values()].map((s) => <li key={s.lot} className="flex items-center justify-between gap-3 py-2"><span><b>{s.lot}</b><br /><span className="text-zinc-500">{s.who}</span></span><b>{mo(m, s.amount)}</b></li>)}</ul>}
              </Section>
              <Section title="Bid feed" sub="Newest first.">
                {seen.length === 0 ? <Empty>No bids replayed yet.</Empty> : <ul className="max-h-80 divide-y divide-zinc-100 overflow-y-auto text-[11px]">{[...seen].reverse().map((b) => <li key={b.id} className="py-2"><span className="text-zinc-500">{fmtWhen(b.ms, m.tz)}</span><br /><b>#{b.bidder.no} {b.bidder.name}</b> bid <b>{mo(m, b.amount)}</b> on Lot {b.lotNo}</li>)}</ul>}
              </Section>
            </div>
          )}
          <p className="text-[10px] text-zinc-500">These are timed online auctions, so there is no live audio or video to record. The replay is rebuilt from the saved bid log.</p>
        </div>
      )}
    </IntelFrame>
  );
}

export const KpiAnalytics = (p: Props) => <StudioGate><KpiInner {...p} /></StudioGate>;
export const UnifiedAnalytics = (p: Props) => <StudioGate><UnifiedInner {...p} /></StudioGate>;
export const AnalyticsDashboard = (p: Props) => <StudioGate><DashboardInner {...p} /></StudioGate>;
export const BidderAnalysis = (p: Props) => <StudioGate><BidderInner {...p} /></StudioGate>;
export const Recordings = (p: Props) => <StudioGate><ReplayInner {...p} /></StudioGate>;
