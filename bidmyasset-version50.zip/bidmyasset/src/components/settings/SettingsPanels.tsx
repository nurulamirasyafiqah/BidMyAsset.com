"use client";

import { useState, type ReactNode } from "react";
import { Monitor, Moon, Sun, Lock } from "lucide-react";
import { LANGUAGES, TIMEZONES, ADMIN_NOTIFY, PORTAL_NOTIFY, resolveTimezone, usePrefs, type NotifyKey, type Scope, type Theme } from "@/lib/preferences";

const sel = "mt-1 h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

export function Switch({ on, onChange, label, disabled }: { on: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)}
      className={`relative h-5 w-9 shrink-0 rounded-full transition disabled:cursor-not-allowed disabled:opacity-50 ${on ? "bg-primary" : "bg-zinc-300"}`}>
      <span className={`absolute top-0.5 size-4 rounded-full bg-white shadow transition-all ${on ? "left-[18px]" : "left-0.5"}`} />
    </button>
  );
}

function Section({ title, sub, children }: { title: string; sub: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      <h2 className="text-base font-bold">{title}</h2>
      <p className="mt-0.5 text-sm text-zinc-500">{sub}</p>
      <div className="mt-5">{children}</div>
    </section>
  );
}

/** Notification toggles (WHETHER to notify, per channel). Wording of the emails lives in Admin → Email Templates. */
export function NotificationSettings({ scope }: { scope: Scope }) {
  const { prefs, update, saveError } = usePrefs(scope);
  const rows = scope === "portal" ? PORTAL_NOTIFY : ADMIN_NOTIFY;
  const set = (k: NotifyKey, ch: "inApp" | "email", v: boolean) =>
    update((p) => ({ ...p, notify: { ...p.notify, [k]: { ...(p.notify[k] ?? { inApp: true, email: true }), [ch]: v } } }));

  return (
    <Section title="Notification settings" sub="Choose how you want to hear about activity. Changes save automatically.">
      {saveError && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{saveError} Your change is kept in this browser and will be tried again on the next change.</p>}
      <div className="overflow-hidden rounded-xl border border-zinc-200">
        <div className="grid grid-cols-[1fr_64px_64px] gap-2 bg-zinc-50 px-4 py-2 text-[10px] font-semibold uppercase tracking-wide text-zinc-500">
          <span>Event</span><span className="text-center">In-app</span><span className="text-center">Email</span>
        </div>
        <ul className="divide-y divide-zinc-100">
          {rows.map((r) => {
            const c = prefs.notify[r.key] ?? { inApp: true, email: true };
            return (
              <li key={r.key} className="grid grid-cols-[1fr_64px_64px] items-center gap-2 px-4 py-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-sm font-medium">{r.label}{r.locked && <Lock className="size-3 text-zinc-400" aria-label="Always on" />}</p>
                  <p className="text-xs text-zinc-500">{r.hint}{r.locked && " Always on."}</p>
                </div>
                <span className="grid place-items-center"><Switch label={`${r.label} in-app`} on={r.locked || c.inApp} disabled={r.locked} onChange={(v) => set(r.key, "inApp", v)} /></span>
                <span className="grid place-items-center"><Switch label={`${r.label} email`} on={r.locked || c.email} disabled={r.locked} onChange={(v) => set(r.key, "email", v)} /></span>
              </li>
            );
          })}
        </ul>
      </div>
    </Section>
  );
}

const THEMES: [Theme, string, typeof Sun][] = [["light", "Light", Sun], ["dark", "Dark", Moon], ["system", "System", Monitor]];

export function PreferencesSettings({ scope }: { scope: Scope }) {
  const { prefs, update, saveError } = usePrefs(scope);
  const known = TIMEZONES.some(([id]) => id === prefs.timezone);
  return (
    <Section title="Preferences" sub="Language, time display and appearance for your account.">
      {saveError && <p role="alert" className="mb-3 rounded-md bg-rose-50 px-3 py-2 text-xs text-rose-600">{saveError} Your change is kept in this browser and will be tried again on the next change.</p>}
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="block text-sm font-medium">Language
          <select className={sel} value={prefs.language} onChange={(e) => update((p) => ({ ...p, language: e.target.value as typeof p.language }))}>
            {LANGUAGES.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}
          </select>
          <span className="mt-1 block text-xs font-normal text-zinc-500">Switches the menus, invoices and lot page to Bahasa Malaysia. Screens that are not translated yet stay in English.</span>
        </label>
        <label className="block text-sm font-medium">My timezone
          <select className={sel} value={prefs.timezone} onChange={(e) => update((p) => ({ ...p, timezone: e.target.value }))}>
            {!known && <option value={prefs.timezone}>{prefs.timezone}</option>}
            {TIMEZONES.map(([id, l]) => <option key={id} value={id}>{l}</option>)}
          </select>
          <span className="mt-1 block text-xs font-normal text-zinc-500">
            Shows when you were notified{prefs.timezone === "auto" && ` (now: ${resolveTimezone("auto")})`}. Auction open/close times and countdowns always use the auction’s own timezone.
          </span>
        </label>
      </div>
      <fieldset className="mt-6">
        <legend className="text-sm font-medium">Appearance</legend>
        <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="Theme">
          {THEMES.map(([id, label, I]) => (
            <button key={id} type="button" role="radio" aria-checked={prefs.theme === id} onClick={() => update((p) => ({ ...p, theme: id }))}
              className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition ${prefs.theme === id ? "border-primary bg-primary/5 text-primary ring-1 ring-primary/30" : "border-zinc-200 hover:bg-zinc-50"}`}>
              <I className="size-4" />{label}
            </button>
          ))}
        </div>
      </fieldset>
    </Section>
  );
}
