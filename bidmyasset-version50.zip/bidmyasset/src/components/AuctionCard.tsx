import Link from "next/link";
import { CalendarDays, Hand, Layers, MapPin } from "lucide-react";
import { getStatus, type Auction } from "@/lib/data";
import { formatRange } from "@/lib/format";
import { Countdown } from "./Countdown";
import { PlaceholderImage } from "./PlaceholderImage";
import { StatusBadge } from "./StatusBadge";

export function AuctionCard({ auction, serverNow, base = "/auctions" }: { auction: Auction; serverNow: number; base?: string }) {
  const status = getStatus(auction, serverNow);
  const label = status === "UPCOMING" ? "Starting in" : status === "LIVE" ? "Ending in" : "Closed";

  return (
    <Link
      href={`${base}/${auction.slug}`}
      className="group flex flex-col rounded-2xl border border-zinc-200 bg-white p-2 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-xl">
        {auction.images?.[0]
          ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={auction.images[0]} alt={auction.title} loading="lazy" className="size-full object-cover transition group-hover:scale-[1.02]" />
          : <PlaceholderImage tone={auction.tone} className="size-full" />}
        {auction.imageCount > 1 && (
          <div className="absolute bottom-12 left-1/2 flex -translate-x-1/2 gap-1 rounded-full bg-black/50 px-2 py-1">
            {Array.from({ length: Math.min(auction.imageCount, 5) }).map((_, i) => (
              <span key={i} className={`size-1.5 rounded-full ${i === 0 ? "bg-white" : "bg-white/50"}`} />
            ))}
          </div>
        )}
        <div className="absolute inset-x-2 bottom-2 flex items-center justify-between rounded-lg bg-slate-900/55 px-3 py-2 backdrop-blur-sm">
          <StatusBadge status={status} />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-white/60">
            {label}{" "}
            <span className="ml-1 text-xs font-bold normal-case tracking-normal text-white">
              {status === "CLOSED" ? "Auction closed" : <Countdown target={status === "UPCOMING" ? auction.startsAt : auction.endsAt} serverNow={serverNow} />}
            </span>
          </span>
        </div>
      </div>
      <div className="px-2 pb-2 pt-3">
        <h3 className="text-sm font-semibold leading-snug text-ink group-hover:text-primary">{auction.title}</h3>
        <ul className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-zinc-500">
          <li className="inline-flex items-center gap-1"><CalendarDays className="size-3" />{formatRange(auction.startsAt, auction.endsAt, auction.timezone)}</li>
          <li className="inline-flex items-center gap-1"><Layers className="size-3" /><b className="text-zinc-700">{auction.lotCount}</b> lots</li>
          <li className="inline-flex items-center gap-1"><MapPin className="size-3" />{[auction.city, auction.region].filter(Boolean).join(", ") || "Location to be announced"}</li>
        </ul>
        <p className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-zinc-400"><Hand className="size-3" />{auction.bidCount} bids</p>
      </div>
    </Link>
  );
}
