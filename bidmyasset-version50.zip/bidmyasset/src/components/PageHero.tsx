import Link from "next/link";
import type { ReactNode } from "react";

export type Crumb = { label: string; href?: string };

/** Light-blue banner used on the Timed Auctions pages. */
export function PageHero({
  crumbs, title, sub, kicker, compact = false, children,
}: { crumbs: Crumb[]; title: string; sub?: string; kicker?: string; compact?: boolean; children?: ReactNode }) {
  return (
    <section className="page-hero relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute -left-10 top-0 h-full w-1/3 -skew-x-[28deg] bg-white/15" />
        <div className="absolute right-0 top-0 h-full w-1/2 skew-x-[28deg] bg-white/20" />
      </div>
      <div className={`relative mx-auto max-w-6xl px-4 sm:px-6 ${compact ? "py-5" : "py-7"}`}>
        <nav aria-label="Breadcrumb" className="text-xs text-slate-500">
          {crumbs.map((c, i) => (
            <span key={i}>
              {i > 0 && <span className="mx-1.5">/</span>}
              {c.href ? <Link href={c.href} className="hover:text-primary">{c.label}</Link> : <span className="font-medium text-brand">{c.label}</span>}
            </span>
          ))}
        </nav>
        <h1 className="mt-2 text-2xl font-bold text-ink sm:text-[28px]">{title}</h1>
        {kicker && <p className="mt-1 text-[10px] font-medium uppercase tracking-widest text-slate-400">{kicker}</p>}
        {sub && <p className="mt-2 text-sm text-slate-500">{sub}</p>}
        {children}
      </div>
    </section>
  );
}
