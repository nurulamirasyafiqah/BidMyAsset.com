"use client";

import { useState } from "react";
import { Copy, Share2 } from "lucide-react";

/** Blueprint §25: every lot has its own link + share channels. */
export function ShareMenu({ title }: { title: string }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const url = () => (typeof window === "undefined" ? "" : window.location.href);
  const enc = encodeURIComponent;

  const channels = () => [
    { label: "WhatsApp", href: `https://wa.me/?text=${enc(`${title} ${url()}`)}` },
    { label: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${enc(url())}` },
    { label: "LinkedIn", href: `https://www.linkedin.com/sharing/share-offsite/?url=${enc(url())}` },
    { label: "X", href: `https://twitter.com/intent/tweet?url=${enc(url())}&text=${enc(title)}` },
    { label: "Telegram", href: `https://t.me/share/url?url=${enc(url())}&text=${enc(title)}` },
    { label: "Email", href: `mailto:?subject=${enc(title)}&body=${enc(url())}` },
  ];

  async function copy() {
    try {
      await navigator.clipboard.writeText(url());
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard blocked — ignore */
    }
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="inline-flex items-center gap-1.5 rounded-md border border-primary/30 bg-white px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/5"
      >
        <Share2 className="size-3.5" /> Share
      </button>
      {open && (
        <div className="absolute right-0 z-20 mt-2 w-44 rounded-lg border border-zinc-200 bg-white p-1 text-xs shadow-lg">
          <button onClick={copy} className="flex w-full items-center gap-2 rounded px-3 py-2 text-left hover:bg-zinc-50">
            <Copy className="size-3.5" /> {copied ? "Link copied" : "Copy link"}
          </button>
          {channels().map((c) => (
            <a key={c.label} href={c.href} target="_blank" rel="noopener noreferrer" className="block rounded px-3 py-2 hover:bg-zinc-50">
              {c.label}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
