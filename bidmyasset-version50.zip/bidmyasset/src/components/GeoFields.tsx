"use client";

import { useEffect, useState } from "react";
import { getCities, getCountries, getStates, type Option } from "@/lib/geo";

const control =
  "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:bg-zinc-50 disabled:text-zinc-400";

function Label({ children }: { children: React.ReactNode }) {
  return <label className="mb-1 block text-[11px] font-medium">{children}</label>;
}

/**
 * Country → State/Province → City dropdowns (cascading).
 * If a country has no states / a state has no cities in the dataset, that
 * field falls back to a plain text input so nobody gets stuck.
 */
export function GeoFields({
  defaults,
}: { defaults?: { country?: string; state?: string; city?: string } }) {
  const [countries, setCountries] = useState<Option[]>([]);
  const [states, setStates] = useState<Option[] | null>(null); // null = loading
  const [cities, setCities] = useState<Option[] | null>(null);
  const [country, setCountry] = useState(defaults?.country ?? "MY");
  const [state, setState] = useState(defaults?.state ?? "");
  const [city, setCity] = useState(defaults?.city ?? "");

  useEffect(() => {
    getCountries().then(setCountries).catch(() => {});
  }, []);

  useEffect(() => {
    let live = true;
    setStates(null);
    getStates(country).then((s) => live && setStates(s)).catch(() => live && setStates([]));
    return () => { live = false; };
  }, [country]);

  useEffect(() => {
    let live = true;
    setCities(null);
    if (!state) { setCities([]); return; }
    getCities(country, state).then((c) => live && setCities(c)).catch(() => live && setCities([]));
    return () => { live = false; };
  }, [country, state]);

  const noStates = states !== null && states.length === 0;
  const noCities = cities !== null && cities.length === 0 && (state !== "" || noStates);

  return (
    <>
      <div>
        <Label>Country</Label>
        <select
          name="country"
          required
          value={country}
          onChange={(e) => { setCountry(e.target.value); setState(""); setCity(""); }}
          className={control}
        >
          {(countries.length ? countries : [{ value: country, label: "Loading…" }]).map((c) => (
            <option key={c.value} value={c.value}>{c.label}</option>
          ))}
        </select>
      </div>

      <div>
        <Label>State/Province</Label>
        {noStates ? (
          <input name="state" required defaultValue={defaults?.state} className={control} />
        ) : (
          <select name="state" required value={state} disabled={states === null}
            onChange={(e) => { setState(e.target.value); setCity(""); }} className={control}>
            <option value="" disabled>{states === null ? "Loading…" : "Select state / province"}</option>
            {(states ?? []).map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        )}
      </div>

      <div>
        <Label>City</Label>
        {noCities ? (
          <input name="city" required defaultValue={defaults?.city} className={control} />
        ) : (
          <select name="city" required value={city} disabled={!state || cities === null}
            onChange={(e) => setCity(e.target.value)} className={control}>
            <option value="" disabled>{!state ? "Select a state first" : cities === null ? "Loading…" : "Select city"}</option>
            {(cities ?? []).map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        )}
      </div>
    </>
  );
}
