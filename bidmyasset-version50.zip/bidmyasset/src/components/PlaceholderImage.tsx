import { Cog } from "lucide-react";

const tones = [
  "from-amber-900 via-stone-700 to-stone-900",
  "from-emerald-900 via-lime-800 to-stone-800",
  "from-slate-500 via-slate-600 to-slate-800",
  "from-zinc-200 via-zinc-300 to-zinc-500",
  "from-sky-900 via-slate-700 to-stone-800",
  "from-teal-900 via-teal-700 to-stone-800",
  "from-slate-700 via-teal-800 to-stone-800",
  "from-lime-700 via-emerald-800 to-zinc-800",
];

/** Stand-in until real photos come from the asset store (Asset.images[]). */
export function PlaceholderImage({ tone = 0, className = "" }: { tone?: number; className?: string }) {
  return (
    <div className={`flex items-center justify-center bg-gradient-to-br ${tones[tone % tones.length]} ${className}`}>
      <Cog className="size-10 text-white/25" aria-hidden />
    </div>
  );
}
