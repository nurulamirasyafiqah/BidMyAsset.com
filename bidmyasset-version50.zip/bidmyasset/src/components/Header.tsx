import Link from "next/link";
import { Logo } from "./Logo";
import { T } from "@/components/T";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-200 bg-white">
      <div className="flex h-14 items-center justify-between px-4 sm:px-5">
        <div className="flex items-center gap-5">
          <Logo className="h-6" />
          <nav className="flex items-center gap-4 text-xs font-semibold text-zinc-800">
            <Link href="/about" className="hover:text-primary"><T>About</T></Link>
            <Link href="/leadership" className="hover:text-primary"><T>Leadership</T></Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/login" data-btn="outline" className="rounded border border-primary/40 bg-white px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/5">
            <T>Login</T>
          </Link>
          <Link href="/register" data-btn="primary" className="rounded bg-primary px-3 py-1.5 text-xs font-semibold text-white hover:bg-primary-700">
            <T>Register</T>
          </Link>
        </div>
      </div>
    </header>
  );
}
