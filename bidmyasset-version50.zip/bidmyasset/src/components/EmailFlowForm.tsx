"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { api, landingFor } from "@/lib/client-api";

const input =
  "h-9 w-full rounded-md border border-zinc-300 bg-white px-3 text-xs placeholder:text-zinc-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20";

type Props = {
  title: string;
  intro: string;
  button: string;
  sentMessage: string;
  /** OTP flow only: ask for the 6-digit code after the email is submitted. */
  askCode?: boolean;
};

/** Shared by "Login with OTP" and "Forgot Password": email → confirmation. */
export function EmailFlowForm({ title, intro, button, sentMessage, askCode = false }: Props) {
  const [sent, setSent] = useState(false);
  const [otpId, setOtpId] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  // Always show the same message so the form never reveals whether an email is registered
  // (PocketBase returns an otpId even for unknown emails).
  async function onEmail(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const email = (new FormData(e.currentTarget).get("email") as string).trim();
    setError("");
    try {
      if (askCode) {
        const r = await api<{ otpId: string }>("api/collections/users/request-otp", { body: { email } });
        setOtpId(r.otpId);
      } else {
        await api("api/collections/users/request-password-reset", { body: { email } });
      }
    } catch {
      /* swallow: same response either way */
    }
    setSent(true);
  }

  async function onCode(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const code = (new FormData(e.currentTarget).get("code") as string).trim();
    setError("");
    try {
      const res = await api("api/collections/users/auth-with-otp", { body: { otpId, password: code } });
      router.push(landingFor(new URLSearchParams(window.location.search).get("next"), res));
      router.refresh();
    } catch (err) {
      const m = err instanceof Error ? err.message : "";
      setError(m.startsWith("This account has been disabled") ? m : "That code is invalid or has expired.");
    }
  }

  return (
    <div className="w-full max-w-[336px]">
      <h1 className="text-2xl font-bold">{title}</h1>
      <p className="mt-0.5 text-xs leading-relaxed text-zinc-500">{intro}</p>

      <div className="mt-4 rounded-xl border border-zinc-200 bg-white p-4">
        {!sent ? (
          <form onSubmit={onEmail} className="space-y-3">
            <div>
              <label htmlFor="email" className="mb-1 block text-[11px] font-medium">Email</label>
              <input id="email" name="email" type="email" required placeholder="m@example.com" className={input} />
            </div>
            <button data-btn="primary" className="h-8 w-full rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700">{button}</button>
          </form>
        ) : askCode ? (
          <form onSubmit={onCode} className="space-y-3">
            <p role="status" className="rounded bg-emerald-50 p-2 text-[11px] text-emerald-800">{sentMessage}</p>
            {error && <p role="alert" className="text-[11px] font-medium text-red-600">{error}</p>}
            <div>
              <label htmlFor="code" className="mb-1 block text-[11px] font-medium">One-time password</label>
              <input id="code" name="code" inputMode="numeric" autoComplete="one-time-code" pattern="\d{6}" maxLength={6} required placeholder="6-digit code" className={`${input} tracking-[0.4em]`} />
            </div>
            <button data-btn="primary" className="h-8 w-full rounded-md bg-primary text-xs font-semibold text-white hover:bg-primary-700">Verify &amp; Login</button>
            <button type="button" onClick={() => setSent(false)} className="block w-full text-center text-[11px] text-primary underline">Use a different email</button>
          </form>
        ) : (
          <div className="space-y-3">
            <p role="status" className="rounded bg-emerald-50 p-2 text-[11px] text-emerald-800">{sentMessage}</p>
            <button type="button" onClick={() => setSent(false)} className="block w-full text-center text-[11px] text-primary underline">Use a different email</button>
          </div>
        )}
      </div>

      <div className="mt-6 space-y-4 text-center text-[11px]">
        <Link href="/login" className="inline-block underline">Back to Login</Link>
        <div>
          <Link href="/" className="inline-flex items-center gap-2 hover:text-primary"><ArrowLeft className="size-3" /> Go back</Link>
        </div>
      </div>
    </div>
  );
}
