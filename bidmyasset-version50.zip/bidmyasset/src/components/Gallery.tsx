"use client";
import { useState } from "react";
import { ImageOff } from "lucide-react";

/** Lot photo gallery: main image + thumbnails. Images are uploaded in Admin → Auction Studio (PocketBase). */
export function Gallery({ images, alt }: { images: string[]; alt: string }) {
  const [i, setI] = useState(0);
  if (!images.length) {
    return <div className="flex aspect-[2.2/1] items-center justify-center rounded-xl border border-zinc-200 bg-white"><div className="flex h-full w-1/2 items-center justify-center bg-zinc-200 text-zinc-400"><ImageOff className="size-7" /></div></div>;
  }
  return (
    <div>
      <div className="flex aspect-[16/10] items-center justify-center overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={images[i]} alt={`${alt} — photo ${i + 1} of ${images.length}`} className="size-full object-contain" />
      </div>
      {images.length > 1 && (
        <ul className="mt-2 flex flex-wrap gap-2">
          {images.map((u, n) => (
            <li key={u}><button type="button" onClick={() => setI(n)} aria-label={`Show photo ${n + 1}`} aria-current={n === i} className={`block overflow-hidden rounded-md border-2 ${n === i ? "border-primary" : "border-transparent"}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={u} alt="" className="h-14 w-20 object-cover" />
            </button></li>
          ))}
        </ul>
      )}
    </div>
  );
}
