package main

import (
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
)

// Admin → Performance Dashboard.
//
//	GET /api/bma/admin/dashboard?from=&to=&tz=   (from/to ISO timestamps; both omitted = lifetime, tz = browser UTC offset in minutes)
//
// Definitions (kept in step with Admin → Hammer Sales):
//
//	closed auction   published and endsAt has passed; a closed auction belongs to the period its endsAt falls in
//	lot sold         a lot that received at least one bid in a closed auction (its currentBid is the hammer price)
//	offered lot      every lot of a closed auction
//	sell-through     lots sold ÷ lots offered, closed auctions of the period
//	total sales      sum of hammer prices of lots sold, per auction currency
//	internet fees    sum of invoices.internetFee issued in the period, per invoice currency
//	pending alloc.   lots sold in closed auctions that do not have an invoice yet (all time, same rule as Hammer Sales)
//	activities       the events the User Activity Analytics feed shows, except account creation counts bidders only (admins excluded)
//
// Any failing query fails the whole request (it used to silently show 0).

const dashDBFmt = "2006-01-02 15:04:05.000Z"

type dashQuery struct {
	app core.App
	err error
}

func (q *dashQuery) count(sql string, p dbx.Params) int {
	if q.err != nil {
		return 0
	}
	var n int
	if err := q.app.DB().NewQuery(sql).Bind(p).Row(&n); err != nil {
		q.err = fmt.Errorf("%s: %w", strings.Join(strings.Fields(sql), " "), err)
		return 0
	}
	return n
}

type ccyRow struct {
	C string  `db:"c"`
	V float64 `db:"v"`
}

// sums runs a "SELECT <currency> AS c, SUM(..) AS v ... GROUP BY c" query; zero totals are dropped.
func (q *dashQuery) sums(sql string, p dbx.Params) map[string]float64 {
	out := map[string]float64{}
	if q.err != nil {
		return out
	}
	var rows []ccyRow
	if err := q.app.DB().NewQuery(sql).Bind(p).All(&rows); err != nil {
		q.err = fmt.Errorf("%s: %w", strings.Join(strings.Fields(sql), " "), err)
		return out
	}
	for _, r := range rows {
		if v := round2(r.V); v > 0 {
			out[r.C] = v
		}
	}
	return out
}

type dashWin struct {
	Counts  map[string]int
	Sales   map[string]float64
	Fees    map[string]float64
	Offered int
}

// window computes every period-based number for [f, t).
func (q *dashQuery) window(f, t, now time.Time) dashWin {
	p := dbx.Params{"f": f.Format(dashDBFmt), "t": t.Format(dashDBFmt), "n": now.Format(dashDBFmt)}
	win := " WHERE created >= {:f} AND created < {:t}"
	logs := win + " AND title NOT LIKE '%Viewed%'"
	// closed auctions whose endsAt falls in the window
	closed := " FROM lots l JOIN auctions a ON a.id = l.auction WHERE a.published = 1 AND a.endsAt >= {:f} AND a.endsAt < {:t} AND a.endsAt <= {:n}"

	w := dashWin{Counts: map[string]int{
		"newBidders":   q.count("SELECT COUNT(*) FROM users"+win+" AND COALESCE(isAdmin,0) = 0", p),
		"auctions":     q.count("SELECT COUNT(*) FROM auctions"+win, p),
		"participated": q.count("SELECT COUNT(DISTINCT bidder) FROM bids"+win, p),
		"bids":         q.count("SELECT COUNT(*) FROM bids"+win, p),
		"invoices":     q.count("SELECT COUNT(*) FROM invoices"+win, p),
		"settled":      q.count("SELECT COUNT(*) FROM invoices"+win+" AND status = 'PAID'", p),
		"lotsSold":     q.count("SELECT COUNT(*)"+closed+" AND l.bidCount > 0", p),
	}}
	w.Offered = q.count("SELECT COUNT(*)"+closed, p)
	w.Counts["activities"] = w.Counts["newBidders"] + w.Counts["bids"] +
		q.count("SELECT COUNT(*) FROM registrations"+win, p) + q.count("SELECT COUNT(*) FROM favourites"+win, p) +
		q.count("SELECT COUNT(*) FROM admin_activity"+logs, p) + q.count("SELECT COUNT(*) FROM user_activity"+logs, p)

	w.Sales = q.sums("SELECT a.currency AS c, COALESCE(SUM(l.currentBid),0) AS v"+closed+" AND l.bidCount > 0 GROUP BY a.currency", p)
	w.Fees = q.sums("SELECT COALESCE(NULLIF(i.currency,''), a.currency, '') AS c, COALESCE(SUM(i.internetFee),0) AS v "+
		"FROM invoices i LEFT JOIN auctions a ON a.id = i.auction WHERE i.created >= {:f} AND i.created < {:t} GROUP BY c HAVING c <> ''", p)
	return w
}

func pctChange(v, prev int) int {
	switch {
	case prev == 0 && v > 0:
		return 100
	case prev != 0:
		return int(math.Round(float64(v-prev) / float64(prev) * 100))
	}
	return 0
}

func rate1(sold, offered int) float64 {
	if offered == 0 {
		return 0
	}
	return math.Round(float64(sold)/float64(offered)*1000) / 10
}

func registerDashboardRoute(se *core.ServeEvent) {
	se.Router.GET("/api/bma/admin/dashboard", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		now := time.Now().UTC()
		qs := e.Request.URL.Query()
		from, to, lifetime := time.Time{}, now.Add(24*time.Hour), true
		if f, err := time.Parse(time.RFC3339, qs.Get("from")); err == nil {
			if t, err := time.Parse(time.RFC3339, qs.Get("to")); err == nil && t.After(f) {
				from, to, lifetime = f.UTC(), t.UTC(), false
			}
		}
		tz := 0
		if _, err := fmt.Sscanf(qs.Get("tz"), "%d", &tz); err != nil || tz < -840 || tz > 840 {
			tz = 0
		}

		q := &dashQuery{app: e.App}
		cur := q.window(from, to, now)
		prev := dashWin{Counts: map[string]int{}, Sales: map[string]float64{}, Fees: map[string]float64{}}
		if !lifetime {
			prev = q.window(from.Add(-to.Sub(from)), from, now) // the period of the same length right before
		}
		delta := map[string]int{}
		for k, v := range cur.Counts {
			delta[k] = 0
			if !lifetime {
				delta[k] = pctChange(v, prev.Counts[k])
			}
		}

		// auction status uses the same rule as the admin studio: draft / upcoming / live / closed
		np := dbx.Params{"n": now.Format(dashDBFmt)}
		alerts := map[string]int{
			"draft":           q.count("SELECT COUNT(*) FROM auctions WHERE COALESCE(published,0) = 0", nil),
			"upcoming":        q.count("SELECT COUNT(*) FROM auctions WHERE published = 1 AND startsAt > {:n}", np),
			"live":            q.count("SELECT COUNT(*) FROM auctions WHERE published = 1 AND startsAt <= {:n} AND endsAt > {:n}", np),
			"closed":          q.count("SELECT COUNT(*) FROM auctions WHERE published = 1 AND endsAt <= {:n}", np),
			"pendingInvoices": q.count("SELECT COUNT(*) FROM invoices WHERE status = 'UNPAID'", nil),
			// lots sold with no invoice yet = "action" in Hammer Sales, counted per lot
			"pendingAllocations": q.count("SELECT COALESCE(SUM(CASE WHEN aw > inv THEN aw - inv ELSE 0 END), 0) FROM ("+
				"SELECT (SELECT COUNT(*) FROM lots l WHERE l.auction = a.id AND l.bidCount > 0) AS aw, "+
				"(SELECT COUNT(*) FROM invoices i WHERE i.auction = a.id) AS inv FROM auctions a WHERE a.published = 1 AND a.endsAt <= {:n})", np),
		}

		// sell-through: this period, previous period and one bar per closed auction (latest 8)
		type serRow struct {
			Title   string `db:"title"`
			EndsAt  string `db:"endsAt"`
			Offered int    `db:"offered"`
			Sold    int    `db:"sold"`
		}
		series := []map[string]any{}
		if q.err == nil {
			var rows []serRow
			err := e.App.DB().NewQuery("SELECT a.title AS title, a.endsAt AS endsAt, COUNT(l.id) AS offered, " +
				"COALESCE(SUM(CASE WHEN l.bidCount > 0 THEN 1 ELSE 0 END), 0) AS sold " +
				"FROM auctions a JOIN lots l ON l.auction = a.id " +
				"WHERE a.published = 1 AND a.endsAt >= {:f} AND a.endsAt < {:t} AND a.endsAt <= {:n} GROUP BY a.id ORDER BY a.endsAt DESC LIMIT 8").
				Bind(dbx.Params{"f": from.Format(dashDBFmt), "t": to.Format(dashDBFmt), "n": now.Format(dashDBFmt)}).All(&rows)
			if err != nil {
				q.err = err
			}
			for i := len(rows) - 1; i >= 0; i-- { // oldest → newest
				r := rows[i]
				end := r.EndsAt
				if len(end) >= 10 {
					end = end[:10]
				}
				series = append(series, map[string]any{"title": r.Title, "end": end, "rate": rate1(r.Sold, r.Offered), "sold": r.Sold, "offered": r.Offered})
			}
		}
		var prevRate any
		if !lifetime && prev.Offered > 0 {
			prevRate = rate1(prev.Counts["lotsSold"], prev.Offered)
		}

		// companies: the platform has one company record today, so closed auctions roll up into one row
		companies := []map[string]any{}
		if cur.Offered > 0 || cur.Counts["lotsSold"] > 0 {
			p := dbx.Params{"f": from.Format(dashDBFmt), "t": to.Format(dashDBFmt), "n": now.Format(dashDBFmt)}
			closedA := q.count("SELECT COUNT(*) FROM auctions a WHERE a.published = 1 AND a.endsAt >= {:f} AND a.endsAt < {:t} AND a.endsAt <= {:n}", p)
			bidders := q.count("SELECT COUNT(DISTINCT b.bidder) FROM bids b JOIN auctions a ON a.id = b.auction "+
				"WHERE a.published = 1 AND a.endsAt >= {:f} AND a.endsAt < {:t} AND a.endsAt <= {:n}", p)
			name := "BidMyAsset Group"
			if rec := findCompany(e.App); rec != nil {
				if v, ok := decodeSection(rec.GetRaw("company")); ok {
					if m, ok := v.(map[string]any); ok {
						if n, _ := m["name"].(string); strings.TrimSpace(n) != "" {
							name = strings.TrimSpace(n)
						}
					}
				}
			}
			companies = append(companies, map[string]any{
				"name": name, "auctions": closedA, "revenue": cur.Sales,
				"rate": rate1(cur.Counts["lotsSold"], cur.Offered), "bidders": bidders,
			})
		}

		// Role Activity: admin = admin console log; bidder = bidder log + bids, registrations, watchlist adds, new accounts.
		// Together the two lines add up to the "Total Activities" card.
		off := fmt.Sprintf("%+d", tz)
		daily := func(src string) []map[string]any {
			out := []map[string]any{}
			if q.err != nil {
				return out
			}
			type day struct {
				D string `db:"d"`
				N int    `db:"n"`
			}
			var rows []day
			sql := "SELECT strftime('%Y-%m-%d', datetime(substr(created,1,19), '" + off + " minutes')) AS d, COUNT(*) AS n FROM (" + src +
				") WHERE created >= {:f} AND created < {:t} GROUP BY d ORDER BY d"
			if err := e.App.DB().NewQuery(sql).Bind(dbx.Params{"f": from.Format(dashDBFmt), "t": to.Format(dashDBFmt)}).All(&rows); err != nil {
				q.err = err
				return out
			}
			for _, r := range rows {
				out = append(out, map[string]any{"d": r.D, "n": r.N})
			}
			return out
		}
		adminDaily := daily("SELECT created FROM admin_activity WHERE title NOT LIKE '%Viewed%'")
		bidderDaily := daily("SELECT created FROM user_activity WHERE title NOT LIKE '%Viewed%' " +
			"UNION ALL SELECT created FROM bids " +
			"UNION ALL SELECT created FROM registrations " +
			"UNION ALL SELECT created FROM favourites " +
			"UNION ALL SELECT created FROM users WHERE COALESCE(isAdmin,0) = 0")

		if q.err != nil {
			e.App.Logger().Error("admin dashboard query failed", "error", q.err)
			return e.InternalServerError("Dashboard query failed — check the server log.", nil)
		}
		return e.JSON(200, map[string]any{
			"lifetime": lifetime, "current": cur.Counts, "delta": delta, "alerts": alerts,
			"daily": map[string]any{"admin": adminDaily, "bidder": bidderDaily},
			"financial": map[string]any{
				"sales": map[string]any{"cur": cur.Sales, "prev": prev.Sales},
				"fees":  map[string]any{"cur": cur.Fees, "prev": prev.Fees},
			},
			"sellThrough": map[string]any{
				"rate": rate1(cur.Counts["lotsSold"], cur.Offered), "prevRate": prevRate,
				"sold": cur.Counts["lotsSold"], "offered": cur.Offered, "series": series,
			},
			"companies": companies,
		})
	})
}
