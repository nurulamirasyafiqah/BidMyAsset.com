package main

import (
	"net/url"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/filesystem"
)

// Admin → Team: the people shown on the public /leadership page (migrations/99_zz_team.go).
//
//	GET  /api/bma/admin/team          → {items: [{id, name, role, group, photoName, photoUrl, linkedin, sort, visible}]}
//	POST /api/bma/admin/team          multipart: id (empty = new), name, role, group, linkedin, visible, photo (file), removePhoto=1
//	POST /api/bma/admin/team-delete   {id}
//	POST /api/bma/admin/team-order    {ids: [...]} → new order inside that group (10, 20, 30 …)
//
// Next checks the caller is an admin first; every value is validated again here.
var teamGroups = map[string]bool{"leadership": true, "advisor": true, "management": true}

func teamJSON(rec *core.Record) map[string]any {
	photo := rec.GetString("photo")
	purl := ""
	if photo != "" {
		purl = "/api/files/team_members/" + rec.Id + "/" + url.PathEscape(photo)
	}
	return map[string]any{
		"id": rec.Id, "name": rec.GetString("name"), "role": rec.GetString("role"), "group": rec.GetString("grp"),
		"photoName": photo, "photoUrl": purl, "linkedin": rec.GetString("linkedin"),
		"sort": rec.GetInt("sort"), "visible": rec.GetBool("visible"), "updated": rec.GetDateTime("updated").String(),
	}
}

func teamList(app core.App) ([]map[string]any, error) {
	recs, err := app.FindRecordsByFilter("team_members", "", "sort,created", 0, 0)
	if err != nil {
		return nil, err
	}
	items := []map[string]any{}
	for _, r := range recs {
		items = append(items, teamJSON(r))
	}
	return items, nil
}

func registerTeamRoutes(se *core.ServeEvent) {
	r := se.Router

	r.GET("/api/bma/admin/team", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		items, err := teamList(e.App)
		if err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	r.POST("/api/bma/admin/team", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if !strings.HasPrefix(e.Request.Header.Get("Content-Type"), "multipart/form-data") {
			return e.BadRequestError("Expected multipart/form-data", nil)
		}
		if err := e.Request.ParseMultipartForm(8 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		form := e.Request.MultipartForm
		val := func(k string) string {
			if v := form.Value[k]; len(v) > 0 {
				return strings.TrimSpace(v[0])
			}
			return ""
		}

		name, role, group, linkedin := val("name"), val("role"), val("group"), val("linkedin")
		if name == "" {
			return e.BadRequestError("name: enter the person's name.", nil)
		}
		if utf8.RuneCountInString(name) > 120 || utf8.RuneCountInString(role) > 160 {
			return e.BadRequestError("name or position is too long.", nil)
		}
		if !teamGroups[group] {
			return e.BadRequestError("group: choose Leadership Team, Strategic Advisors or Management Team.", nil)
		}
		if linkedin != "" {
			if u, err := url.Parse(linkedin); err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" || len(linkedin) > 300 {
				return e.BadRequestError("linkedin: enter a full URL starting with https://", nil)
			}
		}

		var rec *core.Record
		if id := val("id"); id != "" {
			found, err := e.App.FindRecordById("team_members", id)
			if err != nil {
				return e.NotFoundError("That person no longer exists.", nil)
			}
			rec = found
		} else {
			rec = core.NewRecord(mustCol(e.App, "team_members"))
			// new people go to the end of their group
			last, _ := e.App.FindRecordsByFilter("team_members", "grp = {:g}", "-sort", 1, 0, map[string]any{"g": group})
			next := 10
			if len(last) > 0 {
				next = last[0].GetInt("sort") + 10
			}
			rec.Set("sort", next)
		}
		if rec.GetString("grp") != group && !rec.IsNew() { // moved to another group: put him/her last there
			last, _ := e.App.FindRecordsByFilter("team_members", "grp = {:g}", "-sort", 1, 0, map[string]any{"g": group})
			next := 10
			if len(last) > 0 {
				next = last[0].GetInt("sort") + 10
			}
			rec.Set("sort", next)
		}
		rec.Set("name", name)
		rec.Set("role", role)
		rec.Set("grp", group)
		rec.Set("linkedin", linkedin)
		rec.Set("visible", val("visible") != "0")

		if fs := form.File["photo"]; len(fs) > 0 {
			f, err := filesystem.NewFileFromMultipart(fs[0])
			if err != nil {
				return e.BadRequestError("Invalid photo file", nil)
			}
			rec.Set("photo", f) // single-file field: replaces the old photo
		} else if val("removePhoto") == "1" {
			if cur := rec.GetString("photo"); cur != "" {
				rec.Set("photo-", cur)
			}
		}
		if err := e.App.Save(rec); err != nil {
			return e.BadRequestError("Could not save (photo must be PNG, JPG or WebP, up to 2 MB).", err)
		}
		return e.JSON(200, teamJSON(rec))
	})

	r.POST("/api/bma/admin/team-delete", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID string `json:"id"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("Invalid request", nil)
		}
		rec, err := e.App.FindRecordById("team_members", in.ID)
		if err != nil {
			return e.JSON(200, map[string]any{"ok": true}) // already gone
		}
		if err := e.App.Delete(rec); err != nil { // PocketBase also removes the stored photo
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	r.POST("/api/bma/admin/team-order", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			IDs []string `json:"ids"`
		}
		if err := e.BindBody(&in); err != nil || len(in.IDs) == 0 || len(in.IDs) > 200 {
			return e.BadRequestError("Invalid request", nil)
		}
		err := e.App.RunInTransaction(func(tx core.App) error {
			for i, id := range in.IDs {
				rec, err := tx.FindRecordById("team_members", id)
				if err != nil {
					continue
				}
				rec.Set("sort", (i+1)*10)
				if err := tx.Save(rec); err != nil {
					return err
				}
			}
			return nil
		})
		if err != nil {
			return e.InternalServerError("", err)
		}
		items, err := teamList(e.App)
		if err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"items": items, "n": strconv.Itoa(len(in.IDs))})
	})
}
