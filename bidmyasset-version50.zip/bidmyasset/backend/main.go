// BidMyAsset backend: Go + PocketBase (embedded as a framework).
// PocketBase provides the database (SQLite), auth (password, OTP, reset),
// realtime (SSE), file storage and the admin dashboard at /_/.
// Everything custom (bid pipeline, registrations, export/delete) lives in routes.go.
package main

import (
	"errors"
	"log"
	"os"
	"strings"

	"github.com/pocketbase/pocketbase"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/plugins/migratecmd"

	_ "bidmyasset/backend/migrations"
)

// weakAdminKeys are the placeholder values shipped in the .env examples; they must never be used for real.
var weakAdminKeys = map[string]bool{"change-me": true, "changeme": true, "replace-me": true, "secret": true, "password": true, "admin": true}

// adminKeyProblem explains why BMA_ADMIN_KEY cannot be used: missing, a known placeholder, or too short to be a real secret.
// Every /api/bma/admin/* route trusts this shared key, so a guessable one would hand out admin access.
// Checked when the server starts (`serve`) only, so `superuser` / `migrate` commands still work without it.
func adminKeyProblem() error {
	key := strings.TrimSpace(os.Getenv("BMA_ADMIN_KEY"))
	switch {
	case key == "":
		return errors.New("BMA_ADMIN_KEY is not set. Generate one (for example: openssl rand -hex 32), set it here and in the Next.js .env.local, then start again")
	case weakAdminKeys[strings.ToLower(key)]:
		return errors.New("BMA_ADMIN_KEY is still a placeholder value. Generate a real secret (for example: openssl rand -hex 32), set it here and in the Next.js .env.local, then start again")
	case len(key) < 16:
		return errors.New("BMA_ADMIN_KEY is too short (use at least 16 characters, for example: openssl rand -hex 32)")
	}
	return nil
}

func main() {
	app := pocketbase.New()

	migratecmd.MustRegister(app, app.RootCmd, migratecmd.Config{
		Automigrate: os.Getenv("BMA_AUTOMIGRATE") == "1", // only for local schema editing
	})

	registerInvoiceHook(app)
	registerConsignorAccess(app)

	app.OnServe().BindFunc(func(se *core.ServeEvent) error {
		if err := adminKeyProblem(); err != nil {
			return err
		}
		registerRoutes(se)
		registerStudioRoutes(se)
		registerCompanyRoutes(se)
		registerConsignorRoutes(se)
		registerHammerSalesRoutes(se)
		registerDashboardRoute(se)
		registerHouseSettingsRoutes(se)
		registerIntegrationsRoutes(se)
		registerTeamRoutes(se)
		registerBidActivityRoute(se)
		registerLiveRoutes(se)
		// absentee (pre-opening) maximum bids open their lots once the auction has started
		se.App.Cron().MustAdd("bma-absentee-bids", "* * * * *", func() { runAbsenteeBids(se.App) })
		if err := configureUsers(se.App); err != nil {
			return err
		}
		return se.Next()
	})

	if err := app.Start(); err != nil {
		log.Fatal(err)
	}
}
