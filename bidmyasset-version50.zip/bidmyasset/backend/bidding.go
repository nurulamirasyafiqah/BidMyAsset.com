package main

import (
	"math"
	"sort"
	"strconv"
	"strings"

	"github.com/pocketbase/pocketbase/core"
)

// Admin → Company → Lot Bid Details / Auctioneer Commission, applied to the platform:
//   - new lots created in Auction Studio start with the company's starting bid and increments;
//   - the bid pipeline understands tiered increments (lots.incrementMatrix);
//   - invoices created with a hammer price get the auctioneer commission (Company) and the internet buying fee
//     (Auction House → Fees & Commissions) computed from the saved structures.

type bidTier struct {
	From      float64
	Increment float64
}

type bidDefaults struct {
	Set       bool
	Start     float64
	Increment float64 // single increment (0 when tiered)
	Tiers     []bidTier
}

func round2(v float64) float64 { return math.Round(v*100) / 100 }

func tiersAny(t []bidTier) []map[string]any {
	out := []map[string]any{}
	for _, x := range t {
		out = append(out, map[string]any{"from": x.From, "increment": x.Increment})
	}
	return out
}

// companyBidDefaults resolves Company → Lot Bid Details into numbers. A percentage method is resolved
// against the starting bid, so a lot keeps the amounts it was created with.
func companyBidDefaults(app core.App) bidDefaults {
	var d bidDefaults
	rec := findCompany(app)
	if rec == nil {
		return d
	}
	raw, ok := decodeSection(rec.GetRaw("bidSettings"))
	if !ok {
		return d
	}
	m, _ := raw.(map[string]any)
	v, _ := m["v"].(map[string]any)
	if v == nil {
		return d
	}
	num := func(x any) float64 {
		s, _ := x.(string)
		n, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
		if err != nil || n < 0 {
			return 0
		}
		return n
	}
	d.Start = num(v["start"])
	pct := v["method"] == "percent"
	resolve := func(n float64) float64 {
		if pct {
			return round2(d.Start * n / 100)
		}
		return n
	}
	if v["strategy"] == "matrix" {
		rows, _ := m["matrix"].([]any)
		for _, r := range rows {
			row, _ := r.(map[string]any)
			if row == nil {
				continue
			}
			if inc := resolve(num(row["increment"])); inc > 0 {
				d.Tiers = append(d.Tiers, bidTier{From: num(row["from"]), Increment: inc})
			}
		}
		sort.Slice(d.Tiers, func(i, j int) bool { return d.Tiers[i].From < d.Tiers[j].From })
	} else {
		d.Increment = resolve(num(v["inc"]))
	}
	d.Set = true
	return d
}

// lotTiers reads lots.incrementMatrix (sorted by "from"); nil when the lot uses a single increment.
func lotTiers(lot *core.Record) []bidTier {
	raw, ok := decodeSection(lot.GetRaw("incrementMatrix"))
	if !ok {
		return nil
	}
	list, _ := raw.([]any)
	var out []bidTier
	for _, it := range list {
		m, _ := it.(map[string]any)
		from, _ := m["from"].(float64)
		inc, _ := m["increment"].(float64)
		if inc > 0 {
			out = append(out, bidTier{From: from, Increment: inc})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].From < out[j].From })
	return out
}

// bidIncrement is the step that applies when the current bid is `at`.
func bidIncrement(lot *core.Record, tiers []bidTier, at float64) float64 {
	if len(tiers) > 0 {
		inc := tiers[0].Increment
		for _, t := range tiers {
			if t.From <= at {
				inc = t.Increment
			}
		}
		return inc
	}
	inc := lot.GetFloat("increment")
	if inc <= 0 {
		inc = 1
	}
	return inc
}

// companyCommission returns the saved Auctioneer Commission structure, if any.
func companyCommission(app core.App) (map[string]any, bool) {
	rec := findCompany(app)
	if rec == nil {
		return nil, false
	}
	raw, ok := decodeSection(rec.GetRaw("commission"))
	if !ok {
		return nil, false
	}
	c, ok := raw.(map[string]any)
	return c, ok && c != nil
}

// computeCommission applies the auctioneer-commission structure to a hammer price (all six structures; see computeFee).
func computeCommission(c map[string]any, amount float64) (float64, bool) {
	return computeFee(c, amount)
}

// registerInvoiceHook: staff enter the hammer price of an invoice; the fees and the total are filled in:
//
//	commission   Company → Auctioneer Commission
//	internetFee  Auction House → Fees & Commissions (internet buying fee)
//	tax          Company → Taxes (federal + state %) on hammer + commission + internetFee
//	amount       hammer + commission + internetFee + tax   (an invoice created with an explicit amount keeps it)
//
// A fee that staff typed in by hand (non-zero) is never overwritten.
func registerInvoiceHook(app core.App) {
	app.OnRecordCreate("invoices").BindFunc(func(e *core.RecordEvent) error {
		hammer := e.Record.GetFloat("hammer")
		if hammer > 0 {
			if e.Record.GetFloat("commission") == 0 {
				if c, ok := companyCommission(e.App); ok {
					if fee, ok := computeCommission(c, hammer); ok {
						e.Record.Set("commission", fee)
					}
				}
			}
			if e.Record.GetFloat("internetFee") == 0 {
				if c, ok := houseInternetFee(e.App); ok {
					if fee, ok := computeFee(c, hammer); ok {
						e.Record.Set("internetFee", fee)
					}
				}
			}
			if e.Record.GetFloat("tax") == 0 {
				if rate := companyTaxRate(e.App); rate > 0 {
					sub := hammer + e.Record.GetFloat("commission") + e.Record.GetFloat("internetFee")
					e.Record.Set("tax", round2(sub*rate/100))
				}
			}
			if e.Record.GetFloat("amount") == 0 {
				e.Record.Set("amount", round2(hammer+e.Record.GetFloat("commission")+e.Record.GetFloat("internetFee")+e.Record.GetFloat("tax")))
			}
		}
		return e.Next()
	})
}
