package main

import (
	"encoding/json"
	"fmt"
	"html"
	"net/mail"
	"os"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/mailer"
)

// Auction Studio → Auction Builder. Admin routes need X-BMA-Admin-Key (Next checks the caller is an admin first).

var emailRe = regexp.MustCompile(`^[^\s@]+@[^\s@]+\.[^\s@]+$`)

// builderOf decodes auctions.builder (one JSON object, one key per Builder section).
func builderOf(rec *core.Record) map[string]any {
	out := map[string]any{}
	var raw []byte
	switch v := rec.GetRaw("builder").(type) {
	case []byte:
		raw = v
	case string:
		raw = []byte(v)
	case fmt.Stringer:
		raw = []byte(v.String())
	default:
		if v != nil {
			raw, _ = json.Marshal(v)
		}
	}
	if len(raw) > 0 {
		_ = json.Unmarshal(raw, &out)
	}
	if out == nil {
		out = map[string]any{}
	}
	return out
}

func num(v any) (float64, bool) {
	switch n := v.(type) {
	case float64:
		return n, true
	case string:
		var f float64
		if _, err := fmt.Sscan(strings.ReplaceAll(strings.TrimSpace(n), ",", ""), &f); err == nil {
			return f, true
		}
	}
	return 0, false
}

// companyBidJSON is Admin → Company → Lot Bid Details as the Builder shows it (the starting values of a new auction).
func companyBidJSON(app core.App) map[string]any {
	d := companyBidDefaults(app)
	return map[string]any{"set": d.Set, "start": d.Start, "increment": d.Increment, "tiers": tiersAny(d.Tiers)}
}

// applyBidDefaults gives a lot the auction's bid settings (builder.bid): starting bid + a single increment, or the company's tiers.
func applyBidDefaults(app core.App, lot *core.Record, b map[string]any) {
	if s, ok := num(b["start"]); ok && s >= 0 {
		lot.Set("startingBid", s)
	}
	if b["strategy"] == "tiered" {
		if d := companyBidDefaults(app); len(d.Tiers) > 0 {
			lot.Set("increment", d.Tiers[0].Increment)
			lot.Set("incrementMatrix", tiersAny(d.Tiers))
		}
		return
	}
	if inc, ok := num(b["increment"]); ok && inc > 0 {
		lot.Set("increment", inc)
		lot.Set("incrementMatrix", nil)
	}
}

type regQ struct {
	ID, Text string
	Req      bool
}

// auctionQuestions are this auction's own bidder-registration questions (Builder → Bidder Registration); empty = use the company questionnaire.
func auctionQuestions(a *core.Record) []regQ {
	out := []regQ{}
	list, _ := builderOf(a)["registration"].([]any)
	for _, it := range list {
		m, _ := it.(map[string]any)
		id, _ := m["id"].(string)
		text, _ := m["text"].(string)
		req, _ := m["req"].(bool)
		if id != "" && strings.TrimSpace(text) != "" {
			out = append(out, regQ{id, strings.TrimSpace(text), req})
		}
	}
	return out
}

func validateAuctionAnswers(qs []regQ, in map[string]any) (map[string]any, string) {
	out := map[string]any{}
	for _, q := range qs {
		s := ""
		switch v := in[q.ID].(type) {
		case string:
			s = strings.TrimSpace(v)
		case bool, float64:
			s = fmt.Sprint(v)
		}
		if s == "" {
			if q.Req {
				return nil, "Please answer: " + q.Text
			}
			continue
		}
		if utf8.RuneCountInString(s) > 1000 {
			return nil, "Answer too long: " + q.Text
		}
		out[q.ID] = s
	}
	return out, ""
}

var docExt = regexp.MustCompile(`(?i)\.(pdf|docx?|xlsx?|png|jpe?g)$`)

func registerStudioBuilderRoutes(se *core.ServeEvent) {
	r := se.Router

	// Auction Info → real columns (title, dates, time zone, type, description, approval, hide bidders, stagger) + the extra settings in builder.info.
	r.POST("/api/bma/admin/auction-update", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID           string         `json:"id"`
			Title        string         `json:"title"`
			StartsAt     string         `json:"startsAt"`
			EndsAt       string         `json:"endsAt"`
			Timezone     string         `json:"timezone"`
			AuctionType  string         `json:"auctionType"`
			Description  string         `json:"description"`
			ApprovalMode string         `json:"approvalMode"`
			HideBidders  bool           `json:"hideBidders"`
			Stagger      bool           `json:"stagger"`
			Extras       map[string]any `json:"extras"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		a, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		title := strings.TrimSpace(in.Title)
		starts, err1 := time.Parse(time.RFC3339, in.StartsAt)
		ends, err2 := time.Parse(time.RFC3339, in.EndsAt)
		if title == "" || err1 != nil || err2 != nil || !ends.After(starts) {
			return e.BadRequestError("Title, a start time and a later end time are required", nil)
		}
		if _, err := time.LoadLocation(in.Timezone); err != nil {
			return e.BadRequestError("Unknown time zone", nil)
		}
		if in.AuctionType != "RESERVE" && in.AuctionType != "ABSOLUTE" && in.AuctionType != "SUBJECT" {
			return e.BadRequestError("Unknown auction type", nil)
		}
		if in.ApprovalMode != "AUTO" && in.ApprovalMode != "MANUAL" {
			return e.BadRequestError("Unknown approval mode", nil)
		}
		// "Editing rules": while the sale is upcoming / running, edits can be switched off (switching them back on is always allowed)
		b := builderOf(a)
		oldInfo, _ := b["info"].(map[string]any)
		allowed := func(m map[string]any, k string) bool { v, ok := m[k].(bool); return !ok || v }
		if a.GetBool("published") {
			now := time.Now()
			cs, ce := a.GetDateTime("startsAt").Time(), a.GetDateTime("endsAt").Time()
			if now.Before(cs) && !allowed(oldInfo, "up") && !allowed(in.Extras, "up") {
				return e.BadRequestError("Editing is switched off while this auction is upcoming. Turn it on in Editing rules first.", nil)
			}
			if !now.Before(cs) && now.Before(ce) && !allowed(oldInfo, "run") && !allowed(in.Extras, "run") {
				return e.BadRequestError("Editing is switched off while this auction is running. Turn it on in Editing rules first.", nil)
			}
		}
		if _, ok := softCloseWindowOf(in.Extras); !ok {
			return e.BadRequestError("Soft close must be a number from 0 up to 24 hours (1440 minutes).", nil)
		}
		typeChanged := a.GetString("auctionType") != in.AuctionType
		a.Set("title", title)
		a.Set("startsAt", starts.UTC())
		a.Set("endsAt", ends.UTC())
		a.Set("timezone", in.Timezone)
		a.Set("auctionType", in.AuctionType)
		a.Set("description", strings.TrimSpace(sanitizeHTML(in.Description)))
		a.Set("approvalMode", in.ApprovalMode)
		a.Set("hideBidders", in.HideBidders)
		a.Set("stagger", in.Stagger)
		b["info"] = in.Extras
		a.Set("builder", b)
		if err := e.App.Save(a); err != nil {
			return e.BadRequestError("Could not save the auction", err)
		}
		if typeChanged { // Absolute auctions ignore reserves: refresh the public reserve flags
			lots, _ := e.App.FindRecordsByFilter("lots", "auction = {:a}", "", 0, 0, dbx.Params{"a": a.Id})
			for _, l := range lots {
				syncReserveFlags(a, l)
				_ = e.App.Save(l)
			}
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	// One Builder section (everything except Auction Info, which has real columns). `data` is validated per section.
	r.POST("/api/bma/admin/builder-save", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID      string `json:"id"`
			Section string `json:"section"`
			Data    any    `json:"data"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		a, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		if raw, _ := json.Marshal(in.Data); len(raw) > 200*1024 {
			return e.BadRequestError("Too much data for one section", nil)
		}
		bad := func(m string) error { return e.BadRequestError(m, nil) }
		b := builderOf(a)
		result := map[string]any{"ok": true}
		var clean any
		switch in.Section {
		case "contacts":
			list, _ := in.Data.([]any)
			if len(list) > 50 {
				return bad("At most 50 contacts")
			}
			have := map[string]bool{}
			for _, n := range a.GetStringSlice("contactFiles") {
				have[n] = true
			}
			keep, out := map[string]bool{}, []any{}
			for _, it := range list {
				c, _ := it.(map[string]any)
				name, _ := c["name"].(string)
				email, _ := c["email"].(string)
				if strings.TrimSpace(name) == "" || !emailRe.MatchString(strings.TrimSpace(email)) {
					return bad("Every contact needs a name and a valid email")
				}
				if av, _ := c["avatar"].(string); av != "" {
					if !have[av] {
						c["avatar"] = ""
					} else {
						keep[av] = true
					}
				}
				out = append(out, c)
			}
			orphans := []string{}
			for n := range have {
				if !keep[n] {
					orphans = append(orphans, n)
				}
			}
			if len(orphans) > 0 {
				a.Set("contactFiles-", orphans)
			}
			clean = out
		case "address":
			list, _ := in.Data.([]any)
			if len(list) > 20 {
				return bad("At most 20 locations")
			}
			for _, it := range list {
				l, _ := it.(map[string]any)
				if s, _ := l["label"].(string); strings.TrimSpace(s) == "" {
					return bad("Every location needs a label")
				}
				if s, _ := l["l1"].(string); strings.TrimSpace(s) == "" {
					return bad("Every location needs an address line 1")
				}
				for k, lim := range map[string]float64{"lat": 90, "lng": 180} {
					if s, _ := l[k].(string); strings.TrimSpace(s) != "" {
						if f, ok := num(s); !ok || f < -lim || f > lim {
							return bad("Latitude must be within ±90 and longitude within ±180")
						}
					}
				}
			}
			clean = list
		case "registration":
			list, _ := in.Data.([]any)
			if len(list) > 30 {
				return bad("At most 30 questions")
			}
			seen := map[string]bool{}
			for _, it := range list {
				q, _ := it.(map[string]any)
				id, _ := q["id"].(string)
				text, _ := q["text"].(string)
				if id == "" || seen[id] || strings.TrimSpace(text) == "" || utf8.RuneCountInString(text) > 300 {
					return bad("Every question needs text (300 characters max)")
				}
				seen[id] = true
			}
			clean = list
		case "commission":
			m, _ := in.Data.(map[string]any)
			for _, k := range []string{"fed", "st"} {
				if s, _ := m[k].(string); strings.TrimSpace(s) != "" {
					if f, ok := num(s); !ok || f < 0 || f > 100 {
						return bad("Tax must be a number between 0 and 100")
					}
				}
			}
			clean = m
		case "legal": // the policy this auction uses = one entry of Auction House → Legal Policies (house.legal)
			m, _ := in.Data.(map[string]any)
			id, _ := m["policyId"].(string)
			id = strings.TrimSpace(id)
			clean = map[string]any{"policyId": ""}
			if id != "" {
				name, found := "", false
				if h := findHouseRecord(e.App); h != nil {
					if v, ok := decodeSection(h.GetRaw("legal")); ok {
						list, _ := v.([]any)
						for _, it := range list {
							if p, _ := it.(map[string]any); p != nil && p["id"] == id {
								name, _ = p["name"].(string)
								found = true
								break
							}
						}
					}
				}
				if !found {
					return bad("That policy no longer exists in Auction House → Legal Policies")
				}
				clean = map[string]any{"policyId": id, "name": name}
			}
		case "bank": // payout bank = one entry of Company → Bank (last 4 digits only, never a full account number)
			m, _ := in.Data.(map[string]any)
			id, _ := m["bankId"].(string)
			id = strings.TrimSpace(id)
			clean = map[string]any{"bankId": ""}
			if id != "" {
				name, last4, found := "", "", false
				if c := findCompany(e.App); c != nil {
					if v, ok := decodeSection(c.GetRaw("banks")); ok {
						list, _ := v.([]any)
						for _, it := range list {
							if b, _ := it.(map[string]any); b != nil && b["id"] == id {
								name, _ = b["name"].(string)
								last4, _ = b["last4"].(string)
								found = true
								break
							}
						}
					}
				}
				if !found {
					return bad("That bank no longer exists in Company → Bank")
				}
				clean = map[string]any{"bankId": id, "name": name, "last4": last4}
			}
		case "payment":
			m, _ := in.Data.(map[string]any)
			en, _ := m["enabled"].(bool)
			clean = map[string]any{"enabled": en}
		case "catalog":
			m, _ := in.Data.(map[string]any)
			list, _ := m["emails"].([]any)
			if len(list) > 500 {
				return bad("At most 500 recipients")
			}
			seen, emails := map[string]bool{}, []any{}
			for _, it := range list {
				s, _ := it.(string)
				s = strings.ToLower(strings.TrimSpace(s))
				if !emailRe.MatchString(s) {
					return bad("Invalid email: " + s)
				}
				if !seen[s] {
					seen[s] = true
					emails = append(emails, s)
				}
			}
			out := map[string]any{"emails": emails}
			if old, ok := b["catalog"].(map[string]any); ok { // keep the "last sent" record
				for _, k := range []string{"sentAt", "sentCount"} {
					if v, ok := old[k]; ok {
						out[k] = v
					}
				}
			}
			clean = out
		case "bid":
			m, _ := in.Data.(map[string]any)
			st, ok := num(m["start"])
			if !ok || st < 0 {
				return bad("Starting bid must be 0 or more")
			}
			strategy := "single"
			if m["strategy"] == "tiered" {
				strategy = "tiered"
			}
			inc, _ := num(m["increment"])
			if strategy == "single" && inc <= 0 {
				return bad("Increment must be more than 0")
			}
			if strategy == "tiered" {
				if d := companyBidDefaults(e.App); len(d.Tiers) == 0 {
					return bad("No tiered increments are set in Company → Lot Bid Details")
				}
			}
			clean = map[string]any{"start": st, "increment": inc, "strategy": strategy}
			if apply, _ := m["applyExisting"].(bool); apply {
				lots, _ := e.App.FindRecordsByFilter("lots", "auction = {:a} && bidCount = 0", "", 0, 0, dbx.Params{"a": a.Id})
				applied, skipped := 0, 0
				for _, l := range lots {
					if rv := l.GetFloat("reserve"); rv > 0 && rv < st { // never push the starting bid above a lot's reserve
						skipped++
						continue
					}
					applyBidDefaults(e.App, l, clean.(map[string]any))
					if err := e.App.Save(l); err != nil {
						return e.InternalServerError("", err)
					}
					applied++
				}
				result["applied"], result["skipped"] = applied, skipped
			}
		default:
			return bad("Unknown section")
		}
		b[in.Section] = clean
		a.Set("builder", b)
		if err := e.App.Save(a); err != nil {
			return e.BadRequestError("Could not save", err)
		}
		return e.JSON(200, result)
	})

	// Documents (kind=document) and contact avatars (kind=avatar): add files and/or remove names.
	r.POST("/api/bma/admin/builder-file", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if err := e.Request.ParseMultipartForm(64 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		field := "documents"
		if formVal(e, "kind") == "avatar" {
			field = "contactFiles"
		}
		a, err := e.App.FindRecordById("auctions", formVal(e, "id"))
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		before := map[string]bool{}
		for _, n := range a.GetStringSlice(field) {
			before[n] = true
		}
		if rm := e.Request.MultipartForm.Value["remove"]; len(rm) > 0 {
			a.Set(field+"-", rm)
			if err := e.App.Save(a); err != nil {
				return e.InternalServerError("", err)
			}
		}
		files, err := multipartFiles(e, "files")
		if err != nil {
			return e.BadRequestError("Invalid file", nil)
		}
		if field == "documents" {
			for _, f := range files {
				if !docExt.MatchString(f.OriginalName) {
					return e.BadRequestError(f.OriginalName+": use a PDF, Word, Excel, PNG or JPG file.", nil)
				}
			}
		}
		if len(files) > 0 {
			a.Set(field+"+", files)
			if err := e.App.Save(a); err != nil { // PocketBase re-checks size, count and MIME against the field rules
				return e.BadRequestError("Upload rejected (check the file type and size)", err)
			}
		}
		a, _ = e.App.FindRecordById("auctions", a.Id)
		added := []string{}
		for _, n := range a.GetStringSlice(field) {
			if !before[n] {
				added = append(added, n)
			}
		}
		return e.JSON(200, map[string]any{"files": fileURLs(a, field), "added": added})
	})

	// Email the Catalog Notification recipients about this (published) auction, one message each.
	r.POST("/api/bma/admin/catalog-notify", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID string `json:"id"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		a, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		if !a.GetBool("published") {
			return e.BadRequestError("Publish the auction before notifying suppliers", nil)
		}
		b := builderOf(a)
		cat, _ := b["catalog"].(map[string]any)
		list, _ := cat["emails"].([]any)
		if len(list) == 0 {
			return e.BadRequestError("Add and save at least one recipient first", nil)
		}
		meta := e.App.Settings().Meta
		if meta.SenderAddress == "" {
			return e.BadRequestError("Email isn't configured: set the sender address and SMTP in the PocketBase settings", nil)
		}
		tz, err := time.LoadLocation(a.GetString("timezone"))
		if err != nil {
			tz = time.UTC
		}
		lotCount, _ := e.App.CountRecords("lots", dbx.NewExp("auction = {:a} AND draft != true", dbx.Params{"a": a.Id}))
		layout := "2 Jan 2006, 15:04"
		link := ""
		if site := strings.TrimRight(os.Getenv("BMA_SITE_URL"), "/"); site != "" {
			link = fmt.Sprintf(`<p><a href="%s/auctions/%s">View the catalog</a></p>`, html.EscapeString(site), html.EscapeString(a.GetString("slug")))
		}
		title := a.GetString("title")
		body := fmt.Sprintf(`<p>A new catalog has been published.</p><p><b>%s</b><br>%d lots<br>Bidding opens %s and closes %s (%s)</p>%s<p>You are receiving this because you were added as a catalog notification recipient.</p>`,
			html.EscapeString(title), lotCount, a.GetDateTime("startsAt").Time().In(tz).Format(layout), a.GetDateTime("endsAt").Time().In(tz).Format(layout), html.EscapeString(tz.String()), link)
		client := e.App.NewMailClient()
		sent, failed := 0, 0
		var lastErr error
		for _, it := range list {
			to, _ := it.(string)
			err := client.Send(&mailer.Message{
				From: mail.Address{Name: meta.SenderName, Address: meta.SenderAddress}, To: []mail.Address{{Address: to}},
				Subject: "New catalog: " + title, HTML: body,
			})
			if err != nil {
				failed++
				lastErr = err
				if sent == 0 && failed >= 3 { // nothing is getting through: stop instead of retrying hundreds of times
					break
				}
				continue
			}
			sent++
		}
		if sent == 0 {
			return e.BadRequestError("No emails could be sent. Check the SMTP settings.", lastErr)
		}
		cat["sentAt"], cat["sentCount"] = time.Now().UTC().Format(time.RFC3339), sent
		b["catalog"] = cat
		a.Set("builder", b)
		_ = e.App.Save(a)
		return e.JSON(200, map[string]any{"ok": true, "sent": sent, "failed": failed, "sentAt": cat["sentAt"]})
	})
}
