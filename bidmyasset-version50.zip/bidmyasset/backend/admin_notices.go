package main

import (
	"encoding/json"
	"sort"
	"strings"
	"time"

	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/types"
)

// Admin bell: notices are derived from live data (nothing extra is stored), newest first, at most 30.
// GET /api/bma/admin/notices (X-BMA-Admin-Key; Next checks the caller is an admin first).
func registerAdminNoticeRoutes(se *core.ServeEvent) {
	se.Router.GET("/api/bma/admin/notices", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		type notice struct {
			ID    string `json:"id"`
			Title string `json:"title"`
			Body  string `json:"body"`
			At    string `json:"at"`
			Link  string `json:"link"`
			Read  bool   `json:"read"`
			t     time.Time
		}
		var out []notice
		add := func(id, title, body, link string, rec *core.Record, field string) {
			t := rec.GetDateTime(field).Time()
			out = append(out, notice{ID: id, Title: title, Body: body, Link: link, At: t.UTC().Format(time.RFC3339), t: t})
		}
		personName := func(u *core.Record) string {
			if u == nil {
				return "A bidder"
			}
			n := strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
			if n == "" {
				n = u.GetString("email")
			}
			return n
		}

		// registrations still waiting for approval
		if regs, err := e.App.FindRecordsByFilter("registrations", "status = 'PENDING'", "-created", 15, 0); err == nil {
			for _, r := range regs {
				u, _ := e.App.FindRecordById("users", r.GetString("user"))
				title := "an auction"
				if a, err := e.App.FindRecordById("auctions", r.GetString("auction")); err == nil {
					title = a.GetString("title")
				}
				add("reg-"+r.Id, "Registration awaiting approval", personName(u)+" registered for "+title+".", "/admin/auction-studio/"+r.GetString("auction")+"?tab=reg", r, "created")
			}
		}
		// contact form / enquiries
		if msgs, err := e.App.FindRecordsByFilter("contact_messages", "id != ''", "-created", 10, 0); err == nil {
			for _, m := range msgs {
				who := m.GetString("name")
				if who == "" {
					who = m.GetString("email")
				}
				k := m.GetString("kind")
				if k == "" {
					k = "message"
				}
				add("msg-"+m.Id, "New "+k+" from "+who, strings.TrimSpace(m.GetString("message")), "/admin/crm-hub", m, "created")
			}
		}
		// bidder accounts created in the last 14 days
		since := time.Now().AddDate(0, 0, -14).UTC().Format("2006-01-02 15:04:05")
		if us, err := e.App.FindRecordsByFilter("users", "isAdmin != true && created >= {:s}", "-created", 10, 0, map[string]any{"s": since}); err == nil {
			for _, u := range us {
				add("usr-"+u.Id, "New bidder account", personName(u)+" ("+u.GetString("email")+") signed up.", "/admin/bidders", u, "created")
			}
		}
		// account deletion requests
		if us, err := e.App.FindRecordsByFilter("users", "deleteRequestedAt != ''", "-deleteRequestedAt", 10, 0); err == nil {
			for _, u := range us {
				add("del-"+u.Id+"-"+u.GetDateTime("deleteRequestedAt").Time().UTC().Format("20060102150405"), "Account deletion request", personName(u)+" asked to delete their account.", "/admin/bidders", u, "deleteRequestedAt")
			}
		}

		sort.Slice(out, func(i, j int) bool { return out[i].t.After(out[j].t) })
		if len(out) > 30 {
			out = out[:30]
		}
		// which of these this admin (?uid=) has already read, kept in users.noticeRead
		if uid := e.Request.URL.Query().Get("uid"); uid != "" {
			if u, err := e.App.FindRecordById("users", uid); err == nil {
				seen := map[string]bool{}
				for _, id := range readNoticeIDs(u) {
					seen[id] = true
				}
				for i := range out {
					out[i].Read = seen[out[i].ID]
				}
			}
		}
		if out == nil {
			out = []notice{}
		}
		return e.JSON(200, map[string]any{"items": out})
	})
}

func readNoticeIDs(u *core.Record) []string {
	var ids []string
	_ = json.Unmarshal([]byte(u.GetString("noticeRead")), &ids)
	return ids
}

// POST /api/bma/admin/notices/read {uid, ids} (X-BMA-Admin-Key; Next checks the caller is that admin first).
// Adds the ids to the admin's read list (kept to the newest 300), so "mark all read" holds across browsers and devices.
func registerAdminNoticeReadRoute(se *core.ServeEvent) {
	se.Router.POST("/api/bma/admin/notices/read", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var body struct {
			UID string   `json:"uid"`
			IDs []string `json:"ids"`
		}
		if err := e.BindBody(&body); err != nil || body.UID == "" {
			return e.BadRequestError("uid and ids required", nil)
		}
		u, err := e.App.FindRecordById("users", body.UID)
		if err != nil || !u.GetBool("isAdmin") {
			return e.ForbiddenError("Forbidden", nil)
		}
		have := readNoticeIDs(u)
		seen := map[string]bool{}
		for _, id := range have {
			seen[id] = true
		}
		for _, id := range body.IDs {
			if id = strings.TrimSpace(id); id != "" && len(id) <= 80 && !seen[id] {
				seen[id] = true
				have = append(have, id)
			}
		}
		if len(have) > 300 {
			have = have[len(have)-300:]
		}
		raw, _ := json.Marshal(have)
		u.Set("noticeRead", types.JSONRaw(raw))
		if err := e.App.Save(u); err != nil {
			return e.InternalServerError("Could not save", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
}
