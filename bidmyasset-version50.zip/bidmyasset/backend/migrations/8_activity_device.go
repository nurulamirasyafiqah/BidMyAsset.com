package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// admin_activity.device: "Desktop" / "Mobile" / "Tablet" for login events (shown in User Activity).
func init() {
	m.Register(func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("admin_activity")
		if err != nil {
			return err
		}
		c.Fields.Add(&core.TextField{Name: "device", Max: 20})
		return app.Save(c)
	}, func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("admin_activity")
		if err != nil {
			return err
		}
		c.Fields.RemoveByName("device")
		return app.Save(c)
	})
}
