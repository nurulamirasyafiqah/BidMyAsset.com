package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Fields the v50–v52 backend reads that the original schema did not have:
//
//	invoices.hammer, invoices.commission   hammer price staff enter + the auctioneer commission computed from it
//	lots.incrementMatrix                   tiered bid increments [{from, increment}] (empty = single increment)
//
// Runs after 99_zz_house_fee_theme.go (which adds invoices.internetFee). Safe to run twice.
func init() {
	m.Register(func(app core.App) error {
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil {
			changed := false
			for _, n := range []string{"hammer", "commission"} {
				if inv.Fields.GetByName(n) == nil {
					inv.Fields.Add(&core.NumberField{Name: n})
					changed = true
				}
			}
			if changed {
				if err := app.Save(inv); err != nil {
					return err
				}
			}
		}
		if lots, err := app.FindCollectionByNameOrId("lots"); err == nil && lots.Fields.GetByName("incrementMatrix") == nil {
			lots.Fields.Add(&core.JSONField{Name: "incrementMatrix", MaxSize: 64 << 10})
			return app.Save(lots)
		}
		return nil
	}, func(app core.App) error {
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil {
			inv.Fields.RemoveByName("hammer")
			inv.Fields.RemoveByName("commission")
			if err := app.Save(inv); err != nil {
				return err
			}
		}
		if lots, err := app.FindCollectionByNameOrId("lots"); err == nil {
			lots.Fields.RemoveByName("incrementMatrix")
			return app.Save(lots)
		}
		return nil
	})
}
