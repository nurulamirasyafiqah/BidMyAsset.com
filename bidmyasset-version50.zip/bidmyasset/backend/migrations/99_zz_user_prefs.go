package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// users.prefs: the signed-in user's account preferences (language, display timezone, theme, notification toggles),
// one JSON object per scope: {"portal": {...}, "admin": {...}}. Only GET/PUT /api/bma/me/preferences write it
// (validated in preferences.go), so it cannot be set at sign-up or through the plain record API.
// Named 99_zz_* so it runs after 99_zz_user_disabled.go, which also sets these rules.
func init() {
	m.Register(func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		if users.Fields.GetByName("prefs") == nil {
			users.Fields.Add(&core.JSONField{Name: "prefs", MaxSize: 20000})
		}
		users.CreateRule = rule("@request.body.isAdmin:isset = false && @request.body.disabled:isset = false && @request.body.prefs:isset = false")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false && @request.body.isAdmin:isset = false && @request.body.disabled:isset = false && @request.body.prefs:isset = false")
		return app.Save(users)
	}, func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.RemoveByName("prefs")
		users.CreateRule = rule("@request.body.isAdmin:isset = false && @request.body.disabled:isset = false")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false && @request.body.isAdmin:isset = false && @request.body.disabled:isset = false")
		return app.Save(users)
	})
}
