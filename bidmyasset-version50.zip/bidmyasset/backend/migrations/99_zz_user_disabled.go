package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// users.disabled: set by Admin → Company → Consignors (the account toggle). A disabled user cannot sign in, refresh a
// session or call the API (consignor_access.go). Only the server sets it: it cannot be written at sign-up or by the user.
// Named 99_zz_* so it runs after 3_admin_flag.go, which also sets these rules.
func init() {
	m.Register(func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		if users.Fields.GetByName("disabled") == nil {
			users.Fields.Add(&core.BoolField{Name: "disabled"})
		}
		users.CreateRule = rule("@request.body.isAdmin:isset = false && @request.body.disabled:isset = false")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false && @request.body.isAdmin:isset = false && @request.body.disabled:isset = false")
		return app.Save(users)
	}, func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.RemoveByName("disabled")
		users.CreateRule = rule("@request.body.isAdmin:isset = false")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false && @request.body.isAdmin:isset = false")
		return app.Save(users)
	})
}
