package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction House → Fees & Commissions + Theming & Config become real settings.
//
//	house.fee            internet buying fee structure ({kind, rate, cap, ...}; null = none configured)
//	house.theme          {primary, secondary, ratings, buttons{primary,secondary,outline}, dialog}
//	invoices.internetFee the internet buying fee charged on an invoice (computed from house.fee when `hammer` is set)
//
// `house` is public-read (branding is shown on the public site), so the fee schedule and the theme are readable
// by the website without a secret. They can only be written through PUT /api/bma/admin/house/settings (admin key),
// which validates every value. SMTP / payment secrets are NOT stored here.
// File name starts with 99_zz so it sorts after 5_house and 1_init (PocketBase runs migrations in file-name order).
func init() {
	m.Register(func(app core.App) error {
		house, err := app.FindCollectionByNameOrId("house")
		if err != nil {
			return err
		}
		changed := false
		for _, k := range []string{"fee", "theme"} {
			if house.Fields.GetByName(k) == nil {
				house.Fields.Add(&core.JSONField{Name: k, MaxSize: 64 << 10})
				changed = true
			}
		}
		if changed {
			if err := app.Save(house); err != nil {
				return err
			}
		}
		inv, err := app.FindCollectionByNameOrId("invoices")
		if err != nil {
			return err
		}
		if inv.Fields.GetByName("internetFee") == nil {
			inv.Fields.Add(&core.NumberField{Name: "internetFee"})
			return app.Save(inv)
		}
		return nil
	}, func(app core.App) error {
		if house, err := app.FindCollectionByNameOrId("house"); err == nil {
			house.Fields.RemoveByName("fee")
			house.Fields.RemoveByName("theme")
			if err := app.Save(house); err != nil {
				return err
			}
		}
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil {
			inv.Fields.RemoveByName("internetFee")
			return app.Save(inv)
		}
		return nil
	})
}
