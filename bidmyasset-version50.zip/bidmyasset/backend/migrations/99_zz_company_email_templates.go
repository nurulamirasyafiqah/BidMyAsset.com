package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Admin → Email Templates are saved on the company record (company.emailTemplates, JSON text). Safe to run twice.
func init() {
	m.Register(func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("company")
		if err != nil || c.Fields.GetByName("emailTemplates") != nil {
			return nil
		}
		c.Fields.Add(&core.TextField{Name: "emailTemplates", Max: 400000})
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("company"); err == nil {
			c.Fields.RemoveByName("emailTemplates")
			return app.Save(c)
		}
		return nil
	})
}
