package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction cover images + lot photos. Files live in PocketBase storage (disk or S3) and are served from
// /api/files/<collection>/<id>/<file>. Writes only through /api/bma/admin/* (admin key, called by Next).
// The first image is the cover / main photo.
func init() {
	photos := []string{"image/png", "image/jpeg", "image/webp"}
	m.Register(func(app core.App) error {
		auctions, err := app.FindCollectionByNameOrId("auctions")
		if err != nil {
			return err
		}
		auctions.Fields.Add(&core.FileField{Name: "images", MaxSelect: 10, MaxSize: 10 << 20, MimeTypes: photos})
		if err := app.Save(auctions); err != nil {
			return err
		}
		lots, err := app.FindCollectionByNameOrId("lots")
		if err != nil {
			return err
		}
		lots.Fields.Add(&core.FileField{Name: "images", MaxSelect: 30, MaxSize: 10 << 20, MimeTypes: photos})
		return app.Save(lots)
	}, func(app core.App) error {
		for _, n := range []string{"auctions", "lots"} {
			c, err := app.FindCollectionByNameOrId(n)
			if err != nil {
				return err
			}
			c.Fields.RemoveByName("images")
			if err := app.Save(c); err != nil {
				return err
			}
		}
		return nil
	})
}
