package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction House settings stored as JSON text on the existing `house` record:
// fee (buyer commission), theme (colours/buttons/dialog), legal (privacy/terms policies), categories (selected library).
// They are validated and sanitized by Next before they get here. No secrets live in these fields (the collection is publicly readable).
func init() {
	fields := []string{"fee", "theme", "legal", "categories"}
	m.Register(func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("house")
		if err != nil {
			return err
		}
		for _, n := range fields {
			if c.Fields.GetByName(n) == nil {
				c.Fields.Add(&core.TextField{Name: n, Max: 200000})
			}
		}
		return app.Save(c)
	}, func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("house")
		if err != nil {
			return nil
		}
		for _, n := range fields {
			c.Fields.RemoveByName(n)
		}
		return app.Save(c)
	})
}
