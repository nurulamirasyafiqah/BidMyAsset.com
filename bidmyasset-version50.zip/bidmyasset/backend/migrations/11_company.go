package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Admin → Company (single record). Every section is one JSON document stored as text, like the `house` settings.
// No public rules: only GET/PUT /api/bma/admin/company (admin key, called by Next after an admin check) reads or writes it.
// Banks keep only the last 4 digits of the account number.
func init() {
	sections := []string{"company", "consignors", "banks", "taxes", "contacts", "bidSettings", "locations", "questionnaires"}
	m.Register(func(app core.App) error {
		if _, err := app.FindCollectionByNameOrId("company"); err == nil {
			return nil
		}
		c := core.NewBaseCollection("company")
		for _, n := range sections {
			c.Fields.Add(&core.TextField{Name: n, Max: 400000})
		}
		c.Fields.Add(&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true})
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("company"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
