package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
	"github.com/pocketbase/pocketbase/tools/types"
)

func rule(s string) *string { return types.Pointer(s) }

func init() {
	m.Register(func(app core.App) error {
		// ---------- users (built-in auth collection, extended) ----------
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.Add(
			&core.TextField{Name: "firstName", Max: 100},
			&core.TextField{Name: "lastName", Max: 100},
			&core.TextField{Name: "phone", Max: 40},
			&core.SelectField{Name: "accountType", Values: []string{"INDIVIDUAL", "COMPANY"}, MaxSelect: 1},
			&core.TextField{Name: "company", Max: 200},
			&core.TextField{Name: "designation", Max: 120},
			&core.TextField{Name: "website", Max: 200},
			&core.TextField{Name: "signatureName", Max: 120},
			&core.TextField{Name: "address1", Max: 200},
			&core.TextField{Name: "address2", Max: 200},
			&core.TextField{Name: "city", Max: 100},
			&core.TextField{Name: "state", Max: 100},
			&core.TextField{Name: "postalCode", Max: 20},
			&core.TextField{Name: "country", Max: 100},
			&core.JSONField{Name: "prefs", MaxSize: 20000},
			&core.DateField{Name: "deleteRequestedAt"},
		)
		users.OTP.Enabled = true // "Login with OTP"
		users.OTP.Length = 6
		users.OTP.Duration = 300
		users.PasswordAuth.Enabled = true
		// Self-registration is allowed; users can only read/update themselves.
		users.CreateRule = rule("")
		users.ListRule = rule("id = @request.auth.id")
		users.ViewRule = rule("id = @request.auth.id")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false")
		users.DeleteRule = nil
		if err := app.Save(users); err != nil {
			return err
		}

		// ---------- auctions ----------
		auctions := core.NewBaseCollection("auctions")
		auctions.Fields.Add(
			&core.TextField{Name: "slug", Required: true},
			&core.NumberField{Name: "sequence"},
			&core.TextField{Name: "title", Required: true},
			&core.DateField{Name: "startsAt", Required: true},
			&core.DateField{Name: "endsAt", Required: true},
			&core.TextField{Name: "timezone", Required: true}, // IANA, per auction
			&core.TextField{Name: "currency", Required: true}, // ISO 4217, per auction
			&core.TextField{Name: "city"},
			&core.TextField{Name: "region"},
			&core.NumberField{Name: "lat"},
			&core.NumberField{Name: "lng"},
			&core.NumberField{Name: "lotCount"},
			&core.NumberField{Name: "bidCount"},
			&core.NumberField{Name: "imageCount"},
			&core.NumberField{Name: "tone"},
			&core.TextField{Name: "category"},
			&core.TextField{Name: "subcategory"},
			&core.BoolField{Name: "published"},
			&core.AutodateField{Name: "created", OnCreate: true},
			&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
		)
		auctions.AddIndex("idx_auctions_slug", true, "slug", "")
		auctions.ListRule = rule("published = true")
		auctions.ViewRule = rule("published = true")
		if err := app.Save(auctions); err != nil {
			return err
		}

		// ---------- lots ----------
		lots := core.NewBaseCollection("lots")
		lots.Fields.Add(
			&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.NumberField{Name: "lotNumber", Required: true},
			&core.TextField{Name: "title", Required: true},
			&core.TextField{Name: "description", Max: 10000},
			&core.TextField{Name: "category"},
			&core.TextField{Name: "subcategory"},
			&core.TextField{Name: "sku"},
			&core.NumberField{Name: "quantity"},
			&core.NumberField{Name: "startingBid"},
			&core.NumberField{Name: "increment"},
			&core.NumberField{Name: "currentBid"},
			&core.NumberField{Name: "bidCount"},
			&core.NumberField{Name: "addedOrder"},
			// Current leader is never exposed to the public API.
			&core.RelationField{Name: "leader", CollectionId: users.Id, MaxSelect: 1, Hidden: true},
			&core.AutodateField{Name: "created", OnCreate: true},
			&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
		)
		lots.AddIndex("idx_lots_auction_number", true, "auction, lotNumber", "")
		lots.ListRule = rule("")
		lots.ViewRule = rule("")
		if err := app.Save(lots); err != nil {
			return err
		}

		// ---------- bids (written only by POST /api/bma/bids) ----------
		bids := core.NewBaseCollection("bids")
		bids.Fields.Add(
			&core.RelationField{Name: "lot", CollectionId: lots.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "bidder", CollectionId: users.Id, MaxSelect: 1, Required: true},
			&core.NumberField{Name: "amount", Required: true},
			&core.SelectField{Name: "state", Values: []string{"LEADING", "OUTBID", "TRACKED", "WON"}, MaxSelect: 1, Required: true},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		bids.AddIndex("idx_bids_bidder", false, "bidder", "")
		bids.AddIndex("idx_bids_lot", false, "lot", "")
		bids.ListRule = rule("bidder = @request.auth.id")
		bids.ViewRule = rule("bidder = @request.auth.id")
		if err := app.Save(bids); err != nil {
			return err
		}

		// ---------- registrations (create via API, approve in dashboard) ----------
		regs := core.NewBaseCollection("registrations")
		regs.Fields.Add(
			&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "user", CollectionId: users.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.SelectField{Name: "status", Values: []string{"PENDING", "APPROVED", "REJECTED"}, MaxSelect: 1, Required: true},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		regs.AddIndex("idx_regs_unique", true, "auction, user", "")
		regs.ListRule = rule("user = @request.auth.id")
		regs.ViewRule = rule("user = @request.auth.id")
		if err := app.Save(regs); err != nil {
			return err
		}

		// ---------- favourites ----------
		favs := core.NewBaseCollection("favourites")
		favs.Fields.Add(
			&core.RelationField{Name: "user", CollectionId: users.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "lot", CollectionId: lots.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		favs.AddIndex("idx_favs_unique", true, "user, lot", "")
		favs.ListRule = rule("user = @request.auth.id")
		favs.ViewRule = rule("user = @request.auth.id")
		favs.CreateRule = rule("@request.auth.id != '' && @request.body.user = @request.auth.id")
		favs.DeleteRule = rule("user = @request.auth.id")
		if err := app.Save(favs); err != nil {
			return err
		}

		// ---------- invoices (issued by staff in the dashboard) ----------
		inv := core.NewBaseCollection("invoices")
		inv.Fields.Add(
			&core.RelationField{Name: "user", CollectionId: users.Id, MaxSelect: 1, Required: true},
			&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1},
			&core.RelationField{Name: "lot", CollectionId: lots.Id, MaxSelect: 1},
			&core.TextField{Name: "number", Required: true},
			&core.TextField{Name: "currency"},
			&core.NumberField{Name: "amount"},
			&core.SelectField{Name: "status", Values: []string{"UNPAID", "PAID"}, MaxSelect: 1, Required: true},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		inv.AddIndex("idx_invoices_number", true, "number", "")
		inv.ListRule = rule("user = @request.auth.id")
		inv.ViewRule = rule("user = @request.auth.id")
		if err := app.Save(inv); err != nil {
			return err
		}

		// ---------- notifications ----------
		notes := core.NewBaseCollection("notifications")
		notes.Fields.Add(
			&core.RelationField{Name: "user", CollectionId: users.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.TextField{Name: "title", Required: true},
			&core.TextField{Name: "body"},
			&core.BoolField{Name: "read"},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		notes.ListRule = rule("user = @request.auth.id")
		notes.ViewRule = rule("user = @request.auth.id")
		// a user may only flip "read"
		notes.UpdateRule = rule("user = @request.auth.id && @request.body.user:isset = false && @request.body.title:isset = false && @request.body.body:isset = false")
		if err := app.Save(notes); err != nil {
			return err
		}

		// ---------- contact + newsletter (public forms, written via API) ----------
		contact := core.NewBaseCollection("contact_messages")
		contact.Fields.Add(
			&core.TextField{Name: "kind"},
			&core.TextField{Name: "name"},
			&core.EmailField{Name: "email", Required: true},
			&core.TextField{Name: "phone"},
			&core.TextField{Name: "message", Max: 5000},
			&core.JSONField{Name: "payload", MaxSize: 20000},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		if err := app.Save(contact); err != nil {
			return err
		}

		subs := core.NewBaseCollection("subscribers")
		subs.Fields.Add(
			&core.EmailField{Name: "email", Required: true},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		subs.AddIndex("idx_subscribers_email", true, "email", "")
		return app.Save(subs)
	}, func(app core.App) error {
		for _, n := range []string{"subscribers", "contact_messages", "notifications", "invoices", "favourites", "registrations", "bids", "lots", "auctions"} {
			if c, err := app.FindCollectionByNameOrId(n); err == nil {
				if err := app.Delete(c); err != nil {
					return err
				}
			}
		}
		return nil
	})
}
