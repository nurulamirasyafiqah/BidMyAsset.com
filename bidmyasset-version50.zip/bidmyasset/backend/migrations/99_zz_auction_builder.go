package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction Studio → Auction Builder storage:
//
//	auctions.builder       JSON, one key per section: info (extra settings), bid, contacts, address, registration, commission, payment, catalog
//	auctions.documents     supporting documents for bidders (Builder → Documents)
//	auctions.contactFiles  contact avatars (referenced by name from builder.contacts)
func init() {
	m.Register(func(app core.App) error {
		auctions, err := app.FindCollectionByNameOrId("auctions")
		if err != nil {
			return err
		}
		for _, f := range []core.Field{
			&core.JSONField{Name: "builder", MaxSize: 512 * 1024},
			&core.FileField{Name: "documents", MaxSelect: 30, MaxSize: 25 << 20, MimeTypes: []string{
				"application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				"application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "image/png", "image/jpeg"}},
			&core.FileField{Name: "contactFiles", MaxSelect: 60, MaxSize: 5 << 20, MimeTypes: []string{"image/png", "image/jpeg", "image/webp"}},
		} {
			if auctions.Fields.GetByName(f.GetName()) == nil {
				auctions.Fields.Add(f)
			}
		}
		return app.Save(auctions)
	}, func(app core.App) error {
		auctions, err := app.FindCollectionByNameOrId("auctions")
		if err != nil {
			return err
		}
		for _, n := range []string{"builder", "documents", "contactFiles"} {
			auctions.Fields.RemoveByName(n)
		}
		return app.Save(auctions)
	})
}
