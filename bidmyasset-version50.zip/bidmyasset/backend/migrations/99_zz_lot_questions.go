package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// lot_questions: bidder questions about a lot, reviewed in Auction Studio → Questions & Review.
//
//	status  PENDING (new, not public) | PUBLISHED (question + answer may be shown publicly) | HIDDEN
//
// Bidders create rows through POST /api/bma/questions; only the admin-key routes read or change them.
// Named 99_zz_* so it runs after auctions, lots and users exist.
func init() {
	m.Register(func(app core.App) error {
		if _, err := app.FindCollectionByNameOrId("lot_questions"); err == nil {
			return nil
		}
		auctions, err := app.FindCollectionByNameOrId("auctions")
		if err != nil {
			return err
		}
		lots, err := app.FindCollectionByNameOrId("lots")
		if err != nil {
			return err
		}
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		c := core.NewBaseCollection("lot_questions")
		c.Fields.Add(
			&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "lot", CollectionId: lots.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
			&core.RelationField{Name: "user", CollectionId: users.Id, MaxSelect: 1, CascadeDelete: false},
			&core.TextField{Name: "question", Required: true, Max: 1000},
			&core.TextField{Name: "answer", Max: 4000},
			&core.SelectField{Name: "status", Values: []string{"PENDING", "PUBLISHED", "HIDDEN"}, MaxSelect: 1, Required: true},
			&core.DateField{Name: "answeredAt"},
			&core.AutodateField{Name: "created", OnCreate: true},
			&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
		)
		// no API rules = superuser/admin-key access only; the app never exposes the collection directly
		c.AddIndex("idx_lot_questions_auction", false, "auction,status", "")
		return app.Save(c)
	}, func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("lot_questions")
		if err != nil {
			return nil
		}
		return app.Delete(c)
	})
}
