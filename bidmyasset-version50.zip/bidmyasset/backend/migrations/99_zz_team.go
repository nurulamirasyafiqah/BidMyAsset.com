package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Leadership page people (Leadership Team, Strategic Advisors, Management Team) + their photos.
// Public read of visible people only (the /leadership page is public); no browser writes:
// everything is saved through POST /api/bma/admin/team*, called server-side by Next after an admin check.
// The first run seeds the people that used to be hard-coded in src/lib/content.ts.
func init() {
	type seed struct{ group, name, role string }
	people := []seed{
		{"leadership", "Jeevan Muniandy", "Group Managing Director"},
		{"leadership", "Shaik Othman", "Group Executive Director"},
		{"leadership", "Dato Mohd Hashim", "Group Director"},
		{"leadership", "Siraj A. Razack", "Group Director"},
		{"leadership", "A. Safwan Rashdan", "Group Technical Director"},
		{"leadership", "Kevin Parmar", "Managing Director, BidMyAsset"},
		{"leadership", "Amirul Annuar", "Regional Director, East Malaysia"},
		{"leadership", "Nirmal Kumar", "India Coordinator"},
		{"advisor", "A. Vijayasuria", "Finance & Compliance Strategic Advisor"},
		{"advisor", "Ashvin", "Business Processes Advisor"},
		{"advisor", "JP Vincent", "MNC Strategic Advisor"},
		{"management", "S.N Janaki", "Operations & General Manager"},
		{"management", "Wattanapong Sangkavadee", "Project & Decommissioning Manager"},
		{"management", "Nur Dalila", "Project Manager"},
		{"management", "Abdul Rahman Omar", "Technical Operations Manager"},
		{"management", "Nurhayatee Arong", "Digital Presence Manager"},
		{"management", "Arvindran Sandrasagran", "Business Development Manager"},
		{"management", "Rajeev Rao", "Marketing & Communications Manager"},
		{"management", "Nurul Mardhiya", "Sales & Marketing Executive"},
		{"management", "Ira Fardina", "Sales & Marketing Executive"},
		{"management", "Lekha Suresh", "Digital Platform & Systems Executive"},
	}
	m.Register(func(app core.App) error {
		if _, err := app.FindCollectionByNameOrId("team_members"); err == nil {
			return nil
		}
		c := core.NewBaseCollection("team_members")
		c.Fields.Add(
			&core.TextField{Name: "name", Required: true, Max: 120},
			&core.TextField{Name: "role", Max: 160},
			&core.SelectField{Name: "grp", Required: true, MaxSelect: 1, Values: []string{"leadership", "advisor", "management"}},
			&core.FileField{Name: "photo", MaxSelect: 1, MaxSize: 2 << 20, MimeTypes: []string{"image/png", "image/jpeg", "image/webp"}},
			&core.TextField{Name: "linkedin", Max: 300},
			&core.NumberField{Name: "sort"},
			&core.BoolField{Name: "visible"},
			&core.AutodateField{Name: "created", OnCreate: true},
			&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
		)
		c.ListRule = rule("visible = true")
		c.ViewRule = rule("visible = true")
		if err := app.Save(c); err != nil {
			return err
		}
		order := map[string]int{}
		for _, p := range people {
			order[p.group]++
			rec := core.NewRecord(c)
			rec.Set("name", p.name)
			rec.Set("role", p.role)
			rec.Set("grp", p.group)
			rec.Set("sort", order[p.group]*10)
			rec.Set("visible", true)
			if err := app.Save(rec); err != nil {
				return err
			}
		}
		return nil
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("team_members"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
