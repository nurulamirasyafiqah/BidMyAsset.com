package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// CRM Hub: career applications (contact_messages + subscribers already exist).
func init() {
	m.Register(func(app core.App) error {
		c := core.NewBaseCollection("career_applications")
		c.Fields.Add(
			&core.TextField{Name: "name"},
			&core.EmailField{Name: "email", Required: true},
			&core.TextField{Name: "phone"},
			&core.TextField{Name: "subject"}, // position applied for
			&core.TextField{Name: "message", Max: 5000},
			&core.FileField{Name: "document", MaxSelect: 1, MaxSize: 10 << 20},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		return app.Save(c) // rules stay nil = superuser only
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("career_applications"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
