package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// invoices.tax            Company → Taxes (federal + state %) charged on hammer + commission + internet buying fee
// registrations.answers   the bidder's answers to the active Company → Questionnaire: [{id, question, answer}]
func init() {
	m.Register(func(app core.App) error {
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil && inv.Fields.GetByName("tax") == nil {
			inv.Fields.Add(&core.NumberField{Name: "tax"})
			if err := app.Save(inv); err != nil {
				return err
			}
		}
		if regs, err := app.FindCollectionByNameOrId("registrations"); err == nil && regs.Fields.GetByName("answers") == nil {
			regs.Fields.Add(&core.JSONField{Name: "answers", MaxSize: 200 << 10})
			return app.Save(regs)
		}
		return nil
	}, func(app core.App) error {
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil {
			inv.Fields.RemoveByName("tax")
			if err := app.Save(inv); err != nil {
				return err
			}
		}
		if regs, err := app.FindCollectionByNameOrId("registrations"); err == nil {
			regs.Fields.RemoveByName("answers")
			return app.Save(regs)
		}
		return nil
	})
}
