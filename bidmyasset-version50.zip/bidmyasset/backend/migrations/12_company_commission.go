package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Company → Auctioneer Commission has its own `commission` section on the company record.
// (It used to be saved on house.fee, which is the internet buying fee, so the commission was never applied to invoices.)
func init() {
	m.Register(func(app core.App) error {
		c, err := app.FindCollectionByNameOrId("company")
		if err != nil {
			return nil // no company collection on this install
		}
		if c.Fields.GetByName("commission") != nil {
			return nil
		}
		c.Fields.Add(&core.TextField{Name: "commission", Max: 20000})
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("company"); err == nil {
			c.Fields.RemoveByName("commission")
			return app.Save(c)
		}
		return nil
	})
}
