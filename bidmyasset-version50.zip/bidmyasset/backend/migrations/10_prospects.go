package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Admin → Bidders Directory → "Non-registered bidders": prospects captured by staff.
// Superuser-only (no API rules); read/written through Next with BMA_ADMIN_KEY.
func init() {
	m.Register(func(app core.App) error {
		c := core.NewBaseCollection("prospects")
		c.Fields.Add(
			&core.TextField{Name: "first", Required: true, Max: 100},
			&core.TextField{Name: "last", Max: 100},
			&core.EmailField{Name: "email", Required: true},
			&core.TextField{Name: "dial", Max: 8},
			&core.TextField{Name: "phone", Max: 30},
			&core.TextField{Name: "role", Max: 100},
			&core.TextField{Name: "company", Max: 150},
			&core.TextField{Name: "website", Max: 200},
			&core.TextField{Name: "l1", Max: 200},
			&core.TextField{Name: "l2", Max: 200},
			&core.TextField{Name: "city", Max: 100},
			&core.TextField{Name: "state", Max: 100},
			&core.TextField{Name: "country", Max: 100},
			&core.TextField{Name: "zip", Max: 20},
			&core.TextField{Name: "interests", Max: 300}, // comma-separated
			&core.BoolField{Name: "invited"},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		c.AddIndex("idx_prospects_email", true, "email", "")
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("prospects"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
