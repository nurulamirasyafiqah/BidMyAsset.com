package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// house_integrations: ONE record that holds the secrets of Auction House → Email Configuration (SMTP) and
// Payment Credentials (Toyyibpay). No API rules at all, so only a superuser / the Go backend can read it:
// the public `house` record is readable by everyone and must never carry a password or a secret key.
// invoices.billCode / paymentRef / paidAt: set by the Toyyibpay callback (integrations.go).
func init() {
	m.Register(func(app core.App) error {
		if _, err := app.FindCollectionByNameOrId("house_integrations"); err != nil {
			c := core.NewBaseCollection("house_integrations")
			c.Fields.Add(
				&core.TextField{Name: "smtpHost", Max: 255},
				&core.NumberField{Name: "smtpPort"},
				&core.TextField{Name: "smtpUser", Max: 255},
				&core.TextField{Name: "smtpPass", Max: 500, Hidden: true},
				&core.TextField{Name: "smtpFrom", Max: 255},
				&core.TextField{Name: "smtpFromName", Max: 120},
				&core.TextField{Name: "toyyibSecret", Max: 255, Hidden: true},
				&core.TextField{Name: "toyyibCategory", Max: 64},
				&core.BoolField{Name: "toyyibSandbox"},
			)
			if err := app.Save(c); err != nil {
				return err
			}
		}
		inv, err := app.FindCollectionByNameOrId("invoices")
		if err != nil {
			return err
		}
		if inv.Fields.GetByName("billCode") == nil {
			inv.Fields.Add(
				&core.TextField{Name: "billCode", Max: 64},
				&core.TextField{Name: "paymentRef", Max: 120},
				&core.DateField{Name: "paidAt"},
			)
		}
		return app.Save(inv)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("house_integrations"); err == nil {
			if err := app.Delete(c); err != nil {
				return err
			}
		}
		inv, err := app.FindCollectionByNameOrId("invoices")
		if err != nil {
			return err
		}
		inv.Fields.RemoveByName("billCode")
		inv.Fields.RemoveByName("paymentRef")
		inv.Fields.RemoveByName("paidAt")
		return app.Save(inv)
	})
}
