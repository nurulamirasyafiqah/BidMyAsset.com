package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// max_bids: a bidder's maximum (proxy / absentee) bid per lot. Written only by PUT/DELETE /api/bma/max-bids,
// so there are no create/update/delete rules; a bidder can read only their own. bids.auto marks bids the system
// placed on a bidder's behalf to defend or take the lead up to that maximum.
func init() {
	m.Register(func(app core.App) error {
		lots, err := app.FindCollectionByNameOrId("lots")
		if err != nil {
			return err
		}
		auctions, err := app.FindCollectionByNameOrId("auctions")
		if err != nil {
			return err
		}
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		if _, err := app.FindCollectionByNameOrId("max_bids"); err != nil {
			mb := core.NewBaseCollection("max_bids")
			mb.Fields.Add(
				&core.RelationField{Name: "lot", CollectionId: lots.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
				&core.RelationField{Name: "auction", CollectionId: auctions.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
				&core.RelationField{Name: "bidder", CollectionId: users.Id, MaxSelect: 1, Required: true, CascadeDelete: true},
				&core.NumberField{Name: "amount", Required: true},
				&core.AutodateField{Name: "created", OnCreate: true},
				&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
			)
			mb.AddIndex("idx_maxbids_unique", true, "lot, bidder", "")
			mb.AddIndex("idx_maxbids_bidder", false, "bidder", "")
			mb.ListRule = rule("bidder = @request.auth.id")
			mb.ViewRule = rule("bidder = @request.auth.id")
			if err := app.Save(mb); err != nil {
				return err
			}
		}
		bids, err := app.FindCollectionByNameOrId("bids")
		if err != nil {
			return err
		}
		if bids.Fields.GetByName("auto") == nil {
			bids.Fields.Add(&core.BoolField{Name: "auto"})
			return app.Save(bids)
		}
		return nil
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("max_bids"); err == nil {
			if err := app.Delete(c); err != nil {
				return err
			}
		}
		if bids, err := app.FindCollectionByNameOrId("bids"); err == nil {
			bids.Fields.RemoveByName("auto")
			return app.Save(bids)
		}
		return nil
	})
}
