package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction House → Legal Policies and Categories become real settings.
//
//	house.legal       [{id, name, privacy, terms}]  (HTML already cleaned by the backend on save)
//	house.categories  {"<Category>": ["<Subcategory>", ...]}  the subcategories the house offers; the public lot filter follows it
//
// Like fee/theme these live on the public-read `house` record and are written only through
// PUT /api/bma/admin/house/settings (admin key). File name sorts after 99_zz_house_fee_theme.go.
func init() {
	m.Register(func(app core.App) error {
		house, err := app.FindCollectionByNameOrId("house")
		if err != nil {
			return err
		}
		changed := false
		if house.Fields.GetByName("legal") == nil {
			house.Fields.Add(&core.JSONField{Name: "legal", MaxSize: 2 << 20})
			changed = true
		}
		if house.Fields.GetByName("categories") == nil {
			house.Fields.Add(&core.JSONField{Name: "categories", MaxSize: 256 << 10})
			changed = true
		}
		if changed {
			return app.Save(house)
		}
		return nil
	}, func(app core.App) error {
		house, err := app.FindCollectionByNameOrId("house")
		if err != nil {
			return nil
		}
		house.Fields.RemoveByName("legal")
		house.Fields.RemoveByName("categories")
		return app.Save(house)
	})
}
