package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Splits the activity log: admin_activity keeps ADMIN accounts only; everyone else (bidders)
// goes to user_activity. The Analytics page reads both. Rows already logged for non-admin
// accounts are moved over once. Superuser-only (no API rules), written via Next.
func init() {
	m.Register(func(app core.App) error {
		c := core.NewBaseCollection("user_activity")
		c.Fields.Add(
			&core.EmailField{Name: "email", Required: true},
			&core.TextField{Name: "title", Max: 300},
			&core.TextField{Name: "ip", Max: 64},
			&core.BoolField{Name: "ok"},
			&core.TextField{Name: "device", Max: 20},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		if err := app.Save(c); err != nil {
			return err
		}

		// move existing bidder rows out of admin_activity (accounts that no longer exist stay where they are)
		old, err := app.FindRecordsByFilter("admin_activity", "id != ''", "created", 0, 0)
		if err != nil {
			return nil
		}
		isBidder := map[string]bool{}
		for _, r := range old {
			email := r.GetString("email")
			v, seen := isBidder[email]
			if !seen {
				u, err := app.FindAuthRecordByEmail("users", email)
				v = err == nil && !u.GetBool("isAdmin")
				isBidder[email] = v
			}
			if !v {
				continue
			}
			nr := core.NewRecord(c)
			nr.Set("email", email)
			nr.Set("title", r.GetString("title"))
			nr.Set("ip", r.GetString("ip"))
			nr.Set("ok", r.GetBool("ok"))
			nr.Set("device", r.GetString("device"))
			nr.Set("created", r.GetDateTime("created"))
			if err := app.Save(nr); err != nil {
				continue // keep the original row if the copy failed
			}
			_ = app.Delete(r)
		}
		return nil
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("user_activity"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
