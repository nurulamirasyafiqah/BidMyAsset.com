package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// users.notificationsOff: admin/bidder can switch in-app notifications off (default = on).
// users.phoneCountry: ISO country of the phone number, so it can be shown as (+60) 123456789.
func init() {
	m.Register(func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.Add(
			&core.BoolField{Name: "notificationsOff"},
			&core.TextField{Name: "phoneCountry", Max: 4},
		)
		return app.Save(users)
	}, func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.RemoveByName("notificationsOff")
		users.Fields.RemoveByName("phoneCountry")
		return app.Save(users)
	})
}
