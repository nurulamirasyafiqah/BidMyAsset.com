package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Connects Admin → Company defaults to the bid pipeline and invoices.
//   lots.incrementMatrix  tiered bid increments snapshotted from Company → Lot Bid Details when a lot is created
//                         ([{from, increment}], absolute amounts; empty = use lots.increment)
//   invoices.hammer       winning bid; when set (and amount is empty) the invoice total is computed from it
//   invoices.commission   fee on top of the hammer price, computed from Company → Auctioneer Commission
// File name starts with 99 so it sorts after 1_init (PocketBase runs migrations in file-name order).
func init() {
	m.Register(func(app core.App) error {
		lots, err := app.FindCollectionByNameOrId("lots")
		if err != nil {
			return err
		}
		if lots.Fields.GetByName("incrementMatrix") == nil {
			lots.Fields.Add(&core.JSONField{Name: "incrementMatrix", MaxSize: 64 << 10})
			if err := app.Save(lots); err != nil {
				return err
			}
		}
		inv, err := app.FindCollectionByNameOrId("invoices")
		if err != nil {
			return err
		}
		changed := false
		for _, k := range []string{"hammer", "commission"} {
			if inv.Fields.GetByName(k) == nil {
				inv.Fields.Add(&core.NumberField{Name: k, Min: nil})
				changed = true
			}
		}
		if changed {
			return app.Save(inv)
		}
		return nil
	}, func(app core.App) error {
		if lots, err := app.FindCollectionByNameOrId("lots"); err == nil {
			lots.Fields.RemoveByName("incrementMatrix")
			if err := app.Save(lots); err != nil {
				return err
			}
		}
		if inv, err := app.FindCollectionByNameOrId("invoices"); err == nil {
			inv.Fields.RemoveByName("hammer")
			inv.Fields.RemoveByName("commission")
			return app.Save(inv)
		}
		return nil
	})
}
