package migrations

import (
	"strings"

	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// users.noticeRead: the admin-bell notice ids this admin has already read (JSON array of strings, newest last).
// Only POST /api/bma/admin/notices/read writes it, so it is blocked from the plain record API like users.prefs.
// Named 99_zz_user_read.go so it runs after 99_zz_user_prefs.go, whose rules it extends instead of replacing.
const noticeReadGuard = " && @request.body.noticeRead:isset = false"

func init() {
	m.Register(func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		if users.Fields.GetByName("noticeRead") == nil {
			users.Fields.Add(&core.JSONField{Name: "noticeRead", MaxSize: 20000})
		}
		for _, r := range []**string{&users.CreateRule, &users.UpdateRule} {
			if *r != nil && !strings.Contains(**r, "noticeRead") {
				*r = rule(**r + noticeReadGuard)
			}
		}
		return app.Save(users)
	}, func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.RemoveByName("noticeRead")
		for _, r := range []**string{&users.CreateRule, &users.UpdateRule} {
			if *r != nil {
				*r = rule(strings.ReplaceAll(**r, noticeReadGuard, ""))
			}
		}
		return app.Save(users)
	})
}
