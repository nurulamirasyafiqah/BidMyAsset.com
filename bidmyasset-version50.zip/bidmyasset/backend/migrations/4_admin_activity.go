package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Activity log for admin accounts (login, logout, admin actions). Superuser-only; written via Next.
func init() {
	m.Register(func(app core.App) error {
		c := core.NewBaseCollection("admin_activity")
		c.Fields.Add(
			&core.EmailField{Name: "email", Required: true},
			&core.TextField{Name: "title", Max: 300},
			&core.TextField{Name: "ip", Max: 64},
			&core.BoolField{Name: "ok"},
			&core.AutodateField{Name: "created", OnCreate: true},
		)
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("admin_activity"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
