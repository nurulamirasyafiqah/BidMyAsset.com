package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Admin console access: users.isAdmin can only be set by a superuser in the dashboard (/_/).
func init() {
	m.Register(func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.Add(&core.BoolField{Name: "isAdmin"})
		// nobody can grant themselves admin, neither at sign-up nor later
		users.CreateRule = rule("@request.body.isAdmin:isset = false")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false && @request.body.isAdmin:isset = false")
		return app.Save(users)
	}, func(app core.App) error {
		users, err := app.FindCollectionByNameOrId("users")
		if err != nil {
			return err
		}
		users.Fields.RemoveByName("isAdmin")
		users.CreateRule = rule("")
		users.UpdateRule = rule("id = @request.auth.id && @request.body.deleteRequestedAt:isset = false")
		return app.Save(users)
	})
}
