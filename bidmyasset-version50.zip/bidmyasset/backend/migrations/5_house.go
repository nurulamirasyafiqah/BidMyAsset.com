package migrations

import (
	"github.com/pocketbase/pocketbase/core"
	m "github.com/pocketbase/pocketbase/migrations"
)

// Auction house settings (single record) + branding uploads (logo, favicon, banners).
// Files are stored by PocketBase (disk or S3) and served from /api/files/house/<id>/<file>.
// Public read (branding is shown on the public site); no browser writes: only
// POST /api/bma/admin/house, called server-side by Next after an admin check.
func init() {
	imgs := []string{"image/png", "image/jpeg", "image/webp", "image/svg+xml"}
	m.Register(func(app core.App) error {
		c := core.NewBaseCollection("house")
		c.Fields.Add(
			&core.TextField{Name: "name", Max: 200},
			&core.TextField{Name: "website", Max: 300},
			&core.TextField{Name: "supportEmail", Max: 200},
			&core.TextField{Name: "supportPhone", Max: 40},
			&core.TextField{Name: "facebook", Max: 300},
			&core.TextField{Name: "twitter", Max: 300},
			&core.TextField{Name: "linkedin", Max: 300},
			&core.TextField{Name: "whatsapp", Max: 40},
			&core.TextField{Name: "gaId", Max: 40},
			&core.TextField{Name: "description", Max: 5000},
			&core.FileField{Name: "logo", MaxSelect: 1, MaxSize: 2 << 20, MimeTypes: imgs},
			&core.FileField{Name: "favicon", MaxSelect: 1, MaxSize: 2 << 20, MimeTypes: imgs},
			&core.FileField{Name: "banners", MaxSelect: 10, MaxSize: 2 << 20, MimeTypes: imgs[:3]},
			&core.AutodateField{Name: "updated", OnCreate: true, OnUpdate: true},
		)
		c.ListRule = rule("")
		c.ViewRule = rule("")
		return app.Save(c)
	}, func(app core.App) error {
		if c, err := app.FindCollectionByNameOrId("house"); err == nil {
			return app.Delete(c)
		}
		return nil
	})
}
