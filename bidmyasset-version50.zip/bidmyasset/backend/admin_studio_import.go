package main

import (
	"archive/zip"
	"bytes"
	"encoding/csv"
	"encoding/xml"
	"fmt"
	"io"
	"math"
	"mime/multipart"
	"net/http"
	"path"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/filesystem"
)

// Auction Studio → Lot Builder: spreadsheet import (CSV / XLSX), image ZIP import and staggered closing.
// Same rules as the single-lot editor (POST /lots): closing times stay inside the auction window, reserves
// can't be lower than the starting bid and Absolute auctions have none.

const (
	maxSheetBytes = 10 << 20
	maxSheetRows  = 2000
	maxZipBytes   = 100 << 20
	maxZipEntries = 5000
	maxImageBytes = 10 << 20
	maxLotImages  = 30 // matches lots.images MaxSelect
)

// ---------- tiers ----------

type tierIn struct {
	From      float64 `json:"from"`
	Increment float64 `json:"increment"`
}

// cleanTiers validates a tier list from the admin UI: amounts ≥ 0, increments > 0, no repeated "from"; sorted by "from".
func cleanTiers(in []tierIn) ([]bidTier, string) {
	out := make([]bidTier, 0, len(in))
	seen := map[float64]bool{}
	for _, t := range in {
		if math.IsNaN(t.From) || math.IsInf(t.From, 0) || math.IsNaN(t.Increment) || math.IsInf(t.Increment, 0) {
			return nil, "Increment tiers must be numbers"
		}
		if t.From < 0 {
			return nil, "A tier can't start below 0"
		}
		if t.Increment <= 0 {
			return nil, "Every tier needs an increment above 0"
		}
		if seen[t.From] {
			return nil, "Two tiers start at the same amount"
		}
		seen[t.From] = true
		out = append(out, bidTier{From: t.From, Increment: t.Increment})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].From < out[j].From })
	return out, ""
}

// ---------- new lots ----------

// newLotRecord is a draft lot that starts with Company → Lot Bid Details, then the auction's own Builder → Lot Bid Details.
func newLotRecord(app core.App, au *core.Record, n int) *core.Record {
	lot := core.NewRecord(mustCol(app, "lots"))
	lot.Set("auction", au.Id)
	lot.Set("lotNumber", n)
	lot.Set("addedOrder", n)
	lot.Set("quantity", 1)
	lot.Set("startingBid", 0)
	lot.Set("increment", 0)
	lot.Set("draft", true)
	if d := companyBidDefaults(app); d.Set {
		lot.Set("startingBid", d.Start)
		if len(d.Tiers) > 0 {
			lot.Set("increment", d.Tiers[0].Increment)
			lot.Set("incrementMatrix", tiersAny(d.Tiers))
		} else if d.Increment > 0 {
			lot.Set("increment", d.Increment)
		}
	}
	if bd, ok := builderOf(au)["bid"].(map[string]any); ok {
		applyBidDefaults(app, lot, bd)
	}
	return lot
}

func auctionLoc(au *core.Record) *time.Location {
	if loc, err := time.LoadLocation(au.GetString("timezone")); err == nil {
		return loc
	}
	if loc, err := time.LoadLocation("Asia/Kuala_Lumpur"); err == nil {
		return loc
	}
	return time.UTC
}

// ---------- reading spreadsheets ----------

func readUpload(h *multipart.FileHeader, limit int64) ([]byte, error) {
	if h.Size > limit {
		return nil, fmt.Errorf("%s is too large", h.Filename)
	}
	f, err := h.Open()
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return io.ReadAll(io.LimitReader(f, limit+1))
}

func readSheet(name string, data []byte) ([][]string, error) {
	switch strings.ToLower(path.Ext(name)) {
	case ".csv", ".txt", ".tsv":
		return readCSV(data)
	case ".xlsx":
		return readXLSX(data)
	}
	return nil, fmt.Errorf("use a .csv or .xlsx file")
}

func readCSV(data []byte) ([][]string, error) {
	data = bytes.TrimPrefix(data, []byte("\xef\xbb\xbf"))
	first := data
	if i := bytes.IndexByte(data, '\n'); i >= 0 {
		first = data[:i]
	}
	comma := ','
	best := bytes.Count(first, []byte(","))
	for _, d := range []rune{';', '\t'} {
		if c := bytes.Count(first, []byte(string(d))); c > best {
			best, comma = c, d
		}
	}
	r := csv.NewReader(bytes.NewReader(data))
	r.Comma = comma
	r.FieldsPerRecord = -1
	r.LazyQuotes = true
	rows, err := r.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("could not read the CSV: %v", err)
	}
	return rows, nil
}

type xText struct {
	T string   `xml:"t"`
	R []xRun   `xml:"r"`
}
type xRun struct {
	T string `xml:"t"`
}

func (t xText) text() string {
	if len(t.R) == 0 {
		return t.T
	}
	var b strings.Builder
	for _, r := range t.R {
		b.WriteString(r.T)
	}
	return b.String()
}

type xSST struct {
	SI []xText `xml:"si"`
}
type xCell struct {
	R  string `xml:"r,attr"`
	T  string `xml:"t,attr"`
	V  string `xml:"v"`
	IS xText  `xml:"is"`
}
type xRow struct {
	C []xCell `xml:"c"`
}
type xSheet struct {
	Rows []xRow `xml:"sheetData>row"`
}
type xWorkbook struct {
	Sheets []struct {
		Name string `xml:"name,attr"`
		RID  string `xml:"id,attr"` // r:id
	} `xml:"sheets>sheet"`
}
type xRels struct {
	Rel []struct {
		ID     string `xml:"Id,attr"`
		Target string `xml:"Target,attr"`
	} `xml:"Relationship"`
}

func zipFile(zr *zip.Reader, name string) *zip.File {
	for _, f := range zr.File {
		if strings.EqualFold(f.Name, name) {
			return f
		}
	}
	return nil
}

func zipXML(zr *zip.Reader, name string, v any) error {
	f := zipFile(zr, name)
	if f == nil {
		return fmt.Errorf("missing %s", name)
	}
	if f.UncompressedSize64 > 64<<20 {
		return fmt.Errorf("%s is too large", name)
	}
	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	return xml.NewDecoder(io.LimitReader(rc, 64<<20)).Decode(v)
}

// colIndex turns the letters of a cell reference ("C12") into a 0-based column.
func colIndex(ref string) int {
	n := 0
	for _, c := range ref {
		if c >= 'A' && c <= 'Z' {
			n = n*26 + int(c-'A'+1)
		} else if c >= 'a' && c <= 'z' {
			n = n*26 + int(c-'a'+1)
		} else {
			break
		}
	}
	return n - 1
}

func readXLSX(data []byte) ([][]string, error) {
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, fmt.Errorf("could not open the workbook")
	}
	var shared []string
	var sst xSST
	if zipFile(zr, "xl/sharedStrings.xml") != nil {
		if err := zipXML(zr, "xl/sharedStrings.xml", &sst); err != nil {
			return nil, fmt.Errorf("could not read the workbook")
		}
		for _, s := range sst.SI {
			shared = append(shared, s.text())
		}
	}
	// first sheet in workbook order; fall back to sheet1.xml
	sheetPath := "xl/worksheets/sheet1.xml"
	var wb xWorkbook
	var rels xRels
	if zipXML(zr, "xl/workbook.xml", &wb) == nil && zipXML(zr, "xl/_rels/workbook.xml.rels", &rels) == nil && len(wb.Sheets) > 0 {
		for _, rl := range rels.Rel {
			if rl.ID == wb.Sheets[0].RID {
				t := strings.TrimPrefix(rl.Target, "/")
				if !strings.HasPrefix(t, "xl/") {
					t = "xl/" + t
				}
				sheetPath = t
			}
		}
	}
	var sh xSheet
	if err := zipXML(zr, sheetPath, &sh); err != nil {
		return nil, fmt.Errorf("could not read the first sheet")
	}
	rows := make([][]string, 0, len(sh.Rows))
	for _, r := range sh.Rows {
		var row []string
		for i, c := range r.C {
			col := i
			if c.R != "" {
				col = colIndex(c.R)
			}
			if col < 0 || col > 200 {
				continue
			}
			for len(row) <= col {
				row = append(row, "")
			}
			switch c.T {
			case "s":
				if idx, err := strconv.Atoi(strings.TrimSpace(c.V)); err == nil && idx >= 0 && idx < len(shared) {
					row[col] = shared[idx]
				}
			case "inlineStr":
				row[col] = c.IS.text()
			case "b":
				row[col] = map[string]string{"1": "TRUE", "0": "FALSE"}[strings.TrimSpace(c.V)]
			default:
				row[col] = strings.TrimSpace(c.V)
			}
		}
		rows = append(rows, row)
	}
	return rows, nil
}

// ---------- parsing cells ----------

var nonAlnum = regexp.MustCompile(`[^a-z0-9]+`)

// column key for every header name we accept
var sheetCols = map[string]string{
	"lotnumber": "no", "lotno": "no", "lot": "no", "no": "no", "number": "no",
	"title": "title", "name": "title", "lottitle": "title",
	"sku": "sku", "inventorycode": "sku",
	"quantity": "qty", "qty": "qty",
	"category": "category", "subcategory": "category",
	"startingbid": "start", "startbid": "start", "startingprice": "start",
	"reserveprice": "reserve", "reserve": "reserve",
	"increment": "inc", "bidincrement": "inc",
	"description": "desc", "overview": "desc",
	"hashtags": "tags", "tags": "tags",
	"highlights": "hl",
	"consignor": "consignor",
	"address":   "address",
	"closingdate": "cdate", "enddate": "cdate", "closedate": "cdate",
	"closingtime": "ctime", "endtime": "ctime", "closetime": "ctime",
}

func cleanNumber(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	var b strings.Builder
	for _, c := range s {
		if (c >= '0' && c <= '9') || c == '.' || c == '-' {
			b.WriteRune(c)
		}
	}
	f, err := strconv.ParseFloat(b.String(), 64)
	if err != nil || math.IsNaN(f) || math.IsInf(f, 0) {
		return 0, false
	}
	return f, true
}

var excelEpoch = time.Date(1899, 12, 30, 0, 0, 0, 0, time.UTC)

// parseSheetDate understands yyyy-mm-dd, dd/mm/yyyy, "12 Jan 2026" and Excel serial numbers.
func parseSheetDate(s string) (y int, m time.Month, d int, ok bool) {
	s = strings.TrimSpace(s)
	for _, layout := range []string{"2006-01-02", "2/1/2006", "2-1-2006", "2.1.2006", "2 Jan 2006", "2 January 2006", "Jan 2, 2006", "2006/1/2"} {
		if t, err := time.Parse(layout, s); err == nil {
			return t.Year(), t.Month(), t.Day(), true
		}
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil && f > 20000 && f < 80000 {
		t := excelEpoch.Add(time.Duration(math.Floor(f)) * 24 * time.Hour)
		return t.Year(), t.Month(), t.Day(), true
	}
	return 0, 0, 0, false
}

// parseSheetTime understands hh:mm[:ss], "4:00 PM" and Excel fractions of a day (0.5 = 12:00).
func parseSheetTime(s string) (h, mi, sec int, ok bool) {
	s = strings.TrimSpace(s)
	for _, layout := range []string{"15:04:05", "15:04", "3:04:05 PM", "3:04 PM", "3:04PM", "3:04:05PM"} {
		if t, err := time.Parse(layout, strings.ToUpper(s)); err == nil {
			return t.Hour(), t.Minute(), t.Second(), true
		}
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil && f >= 0 && f < 1 {
		total := int(math.Round(f * 86400))
		return total / 3600, (total % 3600) / 60, total % 60, true
	}
	return 0, 0, 0, false
}

// ---------- import: spreadsheet ----------

type sheetErr struct {
	Row     int    `json:"row"`
	Message string `json:"message"`
}

type pendingLot struct {
	row      int
	rec      *core.Record
	isNew    bool
	no       int
	hasNo    bool
	cells    map[string]string
	existing bool
}

func registerStudioImportRoutes(se *core.ServeEvent) {
	r := se.Router

	// POST multipart: auction, sheet (.csv / .xlsx). Creates new draft lots and updates lots with a matching lot number.
	// All or nothing: if any row is invalid nothing is saved and every problem is listed.
	r.POST("/api/bma/admin/lots-import", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if err := e.Request.ParseMultipartForm(32 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		fail := func(msg string, errs []sheetErr) error {
			return e.JSON(http.StatusBadRequest, map[string]any{"message": msg, "errors": errs})
		}
		au, err := e.App.FindRecordById("auctions", formVal(e, "auction"))
		if err != nil {
			return fail("Unknown auction", nil)
		}
		hs := e.Request.MultipartForm.File["sheet"]
		if len(hs) == 0 {
			return fail("Choose a .csv or .xlsx file", nil)
		}
		data, err := readUpload(hs[0], maxSheetBytes)
		if err != nil {
			return fail("The spreadsheet must be 10 MB or smaller", nil)
		}
		rows, err := readSheet(hs[0].Filename, data)
		if err != nil {
			return fail("Could not read the spreadsheet: "+err.Error(), nil)
		}

		// header row = first row that has a recognised "title" column
		head, hdr := -1, map[string]int{}
		for i, row := range rows {
			m := map[string]int{}
			for c, cell := range row {
				if k, ok := sheetCols[nonAlnum.ReplaceAllString(strings.ToLower(cell), "")]; ok {
					if _, dup := m[k]; !dup {
						m[k] = c
					}
				}
			}
			if _, ok := m["title"]; ok {
				head, hdr = i, m
				break
			}
			if i > 20 {
				break
			}
		}
		if head < 0 {
			return fail("No header row found. The first row needs a Title column (download the template to see every column).", nil)
		}
		if len(rows)-head-1 > maxSheetRows {
			return fail(fmt.Sprintf("Too many rows: import up to %d lots at a time", maxSheetRows), nil)
		}
		cell := func(row []string, k string) string {
			if i, ok := hdr[k]; ok && i < len(row) {
				return strings.TrimSpace(row[i])
			}
			return ""
		}

		loc := auctionLoc(au)
		aStart, aEnd := au.GetDateTime("startsAt").Time(), au.GetDateTime("endsAt").Time()
		absolute := au.GetString("auctionType") == "ABSOLUTE"

		existing := map[int]*core.Record{}
		used := map[int]bool{}
		maxNo := 0
		if recs, err := e.App.FindRecordsByFilter("lots", "auction = {:a}", "lotNumber", 0, 0, dbx.Params{"a": au.Id}); err == nil {
			for _, l := range recs {
				existing[l.GetInt("lotNumber")] = l
				used[l.GetInt("lotNumber")] = true
				if n := l.GetInt("lotNumber"); n > maxNo {
					maxNo = n
				}
			}
		}

		var errs []sheetErr
		bad := func(row int, m string) { errs = append(errs, sheetErr{row, m}) }
		var todo []*pendingLot
		sheetNos := map[int]int{}
		blank := 0

		// pass 1: read + validate every row
		for i := head + 1; i < len(rows); i++ {
			row, rn := rows[i], i+1
			empty := true
			for _, c := range row {
				if strings.TrimSpace(c) != "" {
					empty = false
					break
				}
			}
			if empty || (len(row) > 0 && strings.HasPrefix(strings.TrimSpace(row[0]), "#")) {
				blank++
				continue
			}
			p := &pendingLot{row: rn, cells: map[string]string{}}
			for k := range hdr {
				p.cells[k] = cell(row, k)
			}
			if raw := p.cells["no"]; raw != "" {
				n, ok := cleanNumber(raw)
				if !ok || n != math.Trunc(n) || n < 1 {
					bad(rn, "Lot number must be a whole number of 1 or more")
					continue
				}
				p.no, p.hasNo = int(n), true
				if prev, dup := sheetNos[p.no]; dup {
					bad(rn, fmt.Sprintf("Lot number %d is already used on row %d", p.no, prev))
					continue
				}
				sheetNos[p.no] = rn
				used[p.no] = true
			}
			todo = append(todo, p)
		}
		if len(todo) == 0 && len(errs) == 0 {
			return fail("The spreadsheet has no lots to import", nil)
		}

		// pass 2: numbers for rows without one, then build + validate records
		next := maxNo
		takeNo := func() int {
			for {
				next++
				if !used[next] {
					used[next] = true
					return next
				}
			}
		}
		created, updated := 0, 0
		var recs []*core.Record
		for _, p := range todo {
			if !p.hasNo {
				p.no = takeNo()
			}
			if l, ok := existing[p.no]; ok && p.hasNo {
				p.rec, p.existing = l, true
			} else {
				p.rec, p.isNew = newLotRecord(e.App, au, p.no), true
			}
			l := p.rec
			c := p.cells
			if p.isNew && c["title"] == "" {
				bad(p.row, "Title is required")
				continue
			}
			if c["title"] != "" {
				l.Set("title", c["title"])
			}
			if v, ok := c["sku"]; ok && v != "" {
				l.Set("sku", v)
			}
			if v := c["qty"]; v != "" {
				q, ok := cleanNumber(v)
				if !ok || q < 1 || q != math.Trunc(q) {
					bad(p.row, "Quantity must be a whole number of 1 or more")
					continue
				}
				l.Set("quantity", q)
			}
			if v := c["category"]; v != "" {
				l.Set("category", v)
			}
			if v := c["start"]; v != "" {
				n, ok := cleanNumber(v)
				if !ok || n < 0 {
					bad(p.row, "Starting bid must be a number of 0 or more")
					continue
				}
				l.Set("startingBid", n)
			}
			if v := c["inc"]; v != "" {
				n, ok := cleanNumber(v)
				if !ok || n <= 0 {
					bad(p.row, "Increment must be a number above 0")
					continue
				}
				l.Set("increment", n)
				l.Set("incrementMatrix", nil) // a single increment replaces any tiers
			}
			if v := c["reserve"]; v != "" {
				n, ok := cleanNumber(v)
				if !ok || n < 0 {
					bad(p.row, "Reserve price must be a number of 0 or more")
					continue
				}
				if n > 0 && absolute {
					bad(p.row, "Absolute auctions have no reserve price")
					continue
				}
				l.Set("reserve", n)
			}
			if rsv := l.GetFloat("reserve"); rsv > 0 && rsv < l.GetFloat("startingBid") {
				bad(p.row, "Reserve price can't be lower than the starting bid")
				continue
			}
			if v := c["desc"]; v != "" {
				l.Set("description", v)
			}
			if v := c["tags"]; v != "" {
				l.Set("hashtags", v)
			}
			if v := c["hl"]; v != "" {
				l.Set("highlights", v)
			}
			if v := c["consignor"]; v != "" {
				l.Set("consignor", v)
			}
			if v := c["address"]; v != "" {
				l.Set("address", v)
			}
			// closing time, wall-clock in the auction's time zone
			if dv, tv := c["cdate"], c["ctime"]; dv != "" || tv != "" {
				if dv == "" {
					bad(p.row, "A closing time needs a closing date too")
					continue
				}
				y, mo, d, ok := parseSheetDate(dv)
				if !ok {
					bad(p.row, "Closing date not understood (use dd/mm/yyyy or yyyy-mm-dd)")
					continue
				}
				h, mi, s := aEnd.In(loc).Hour(), aEnd.In(loc).Minute(), aEnd.In(loc).Second()
				if tv != "" {
					if h, mi, s, ok = parseSheetTime(tv); !ok {
						bad(p.row, "Closing time not understood (use hh:mm or hh:mm:ss)")
						continue
					}
				}
				t := time.Date(y, mo, d, h, mi, s, 0, loc)
				if t.Before(aStart) || t.After(aEnd) {
					bad(p.row, "A lot's closing time must fall between its auction's start and end")
					continue
				}
				if t.Unix() == aEnd.Unix() {
					l.Set("endsAt", "") // closes with the auction
				} else {
					l.Set("endsAt", t.UTC().Format("2006-01-02 15:04:05.000Z"))
				}
			}
			syncReserveFlags(au, l)
			recs = append(recs, l)
			if p.isNew {
				created++
			} else {
				updated++
			}
		}
		if len(errs) > 0 {
			sort.Slice(errs, func(i, j int) bool { return errs[i].Row < errs[j].Row })
			return fail(fmt.Sprintf("Nothing was imported: %d row%s need fixing.", len(errs), plural(len(errs))), errs)
		}

		if err := e.App.RunInTransaction(func(tx core.App) error {
			for _, l := range recs {
				if err := tx.Save(l); err != nil {
					return err
				}
			}
			return nil
		}); err != nil {
			return fail("Could not save the lots: "+err.Error(), nil)
		}
		recount(e.App, au.Id)
		return e.JSON(200, map[string]any{"created": created, "updated": updated, "skipped": blank})
	})

	// POST multipart: auction, zip. Photos are matched to lots by file or folder name (lot number or SKU) and appended.
	r.POST("/api/bma/admin/lots-images-zip", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if err := e.Request.ParseMultipartForm(32 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		fail := func(msg string) error { return e.JSON(http.StatusBadRequest, map[string]any{"message": msg}) }
		au, err := e.App.FindRecordById("auctions", formVal(e, "auction"))
		if err != nil {
			return fail("Unknown auction")
		}
		hs := e.Request.MultipartForm.File["zip"]
		if len(hs) == 0 {
			return fail("Choose a .zip file")
		}
		if hs[0].Size > maxZipBytes {
			return fail("The ZIP must be 100 MB or smaller")
		}
		f, err := hs[0].Open()
		if err != nil {
			return fail("Could not open the ZIP")
		}
		defer f.Close()
		zr, err := zip.NewReader(f, hs[0].Size)
		if err != nil {
			return fail("That file is not a valid ZIP")
		}
		if len(zr.File) > maxZipEntries {
			return fail("The ZIP has too many files")
		}

		lots, err := e.App.FindRecordsByFilter("lots", "auction = {:a}", "lotNumber", 0, 0, dbx.Params{"a": au.Id})
		if err != nil || len(lots) == 0 {
			return fail("This auction has no lots yet. Add or import lots first.")
		}
		byNo := map[int]*core.Record{}
		bySKU := map[string]*core.Record{}
		for _, l := range lots {
			byNo[l.GetInt("lotNumber")] = l
			if s := strings.ToLower(strings.TrimSpace(l.GetString("sku"))); s != "" {
				bySKU[s] = l
			}
		}

		type pic struct {
			key  string
			name string
			data []byte
		}
		perLot := map[string][]pic{}
		var unmatched, skipped []string
		for _, zf := range zr.File {
			if zf.FileInfo().IsDir() {
				continue
			}
			name := zf.Name
			base := path.Base(name)
			if strings.HasPrefix(name, "__MACOSX/") || strings.HasPrefix(base, ".") || strings.EqualFold(base, "Thumbs.db") {
				continue
			}
			ext := strings.ToLower(path.Ext(base))
			if ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".webp" {
				skipped = append(skipped, name+" (not a JPG, PNG or WebP image)")
				continue
			}
			if zf.UncompressedSize64 > maxImageBytes {
				skipped = append(skipped, name+" (over 10 MB)")
				continue
			}
			lot := matchLot(name, byNo, bySKU)
			if lot == nil {
				unmatched = append(unmatched, name)
				continue
			}
			rc, err := zf.Open()
			if err != nil {
				skipped = append(skipped, name+" (unreadable)")
				continue
			}
			b, err := io.ReadAll(io.LimitReader(rc, maxImageBytes+1))
			rc.Close()
			if err != nil || len(b) > maxImageBytes {
				skipped = append(skipped, name+" (unreadable or over 10 MB)")
				continue
			}
			if ct := http.DetectContentType(b); ct != "image/jpeg" && ct != "image/png" && ct != "image/webp" {
				skipped = append(skipped, name+" (not a real image)")
				continue
			}
			perLot[lot.Id] = append(perLot[lot.Id], pic{name: name, key: naturalKey(name), data: b})
		}

		added, matched := 0, 0
		for _, l := range lots {
			ps := perLot[l.Id]
			if len(ps) == 0 {
				continue
			}
			sort.Slice(ps, func(i, j int) bool { return ps[i].key < ps[j].key })
			room := maxLotImages - len(l.GetStringSlice("images"))
			if room <= 0 {
				for _, p := range ps {
					skipped = append(skipped, p.name+fmt.Sprintf(" (lot %d already has %d photos)", l.GetInt("lotNumber"), maxLotImages))
				}
				continue
			}
			if len(ps) > room {
				for _, p := range ps[room:] {
					skipped = append(skipped, p.name+fmt.Sprintf(" (lot %d is limited to %d photos)", l.GetInt("lotNumber"), maxLotImages))
				}
				ps = ps[:room]
			}
			files := make([]*filesystem.File, 0, len(ps))
			for _, p := range ps {
				ff, err := filesystem.NewFileFromBytes(p.data, path.Base(p.name))
				if err != nil {
					skipped = append(skipped, p.name+" (unreadable)")
					continue
				}
				files = append(files, ff)
			}
			if len(files) == 0 {
				continue
			}
			l.Set("images+", files)
			if err := e.App.Save(l); err != nil {
				for _, p := range ps {
					skipped = append(skipped, p.name+" (rejected when saving lot "+strconv.Itoa(l.GetInt("lotNumber"))+")")
				}
				continue
			}
			matched++
			added += len(files)
		}
		recount(e.App, au.Id)
		if len(unmatched) > 50 {
			unmatched = append(unmatched[:50], fmt.Sprintf("…and %d more", len(unmatched)-50))
		}
		if len(skipped) > 50 {
			skipped = append(skipped[:50], fmt.Sprintf("…and %d more", len(skipped)-50))
		}
		return e.JSON(200, map[string]any{"lots": matched, "images": added, "unmatched": unmatched, "skipped": skipped})
	})

	// POST json {auction, ids?, gapSeconds, reverse?, unit?, gap?}. Spreads closing times by a fixed gap, ending at the auction's end:
	// lot order = lot number; the last lot closes with the auction (or the first, when reverse). All lots or none.
	r.POST("/api/bma/admin/lots-stagger", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			Auction    string   `json:"auction"`
			IDs        []string `json:"ids"`
			GapSeconds int      `json:"gapSeconds"`
			Reverse    bool     `json:"reverse"`
			Unit       string   `json:"unit"`
			Gap        float64  `json:"gap"`
		}
		if err := e.BindBody(&in); err != nil || in.Auction == "" {
			return e.BadRequestError("auction required", nil)
		}
		if in.GapSeconds < 1 || in.GapSeconds > 7*24*3600 {
			return e.BadRequestError("The gap must be between 1 second and 7 days", nil)
		}
		au, err := e.App.FindRecordById("auctions", in.Auction)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		all, err := e.App.FindRecordsByFilter("lots", "auction = {:a}", "lotNumber", 0, 0, dbx.Params{"a": au.Id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		pick := map[string]bool{}
		for _, id := range in.IDs {
			pick[id] = true
		}
		aStart, aEnd, now := au.GetDateTime("startsAt").Time(), au.GetDateTime("endsAt").Time(), time.Now()
		var lots []*core.Record
		for _, l := range all {
			if len(pick) > 0 && !pick[l.Id] {
				continue
			}
			end := aEnd
			if le := l.GetDateTime("endsAt"); !le.IsZero() && le.Time().Before(end) {
				end = le.Time()
			}
			if !end.After(now) && !l.GetBool("draft") { // already closed: leave it alone
				continue
			}
			lots = append(lots, l)
		}
		if len(lots) == 0 {
			return e.BadRequestError("There are no open lots to stagger", nil)
		}
		gap := time.Duration(in.GapSeconds) * time.Second
		n := len(lots)
		times := make([]time.Time, n)
		for k := range lots {
			back := n - 1 - k // sequential: lot 1 closes first, the last lot closes with the auction
			if in.Reverse {
				back = k // reverse: lot 1 closes with the auction, later lots close earlier
			}
			times[k] = aEnd.Add(-time.Duration(back) * gap)
		}
		earliest := times[0]
		if in.Reverse {
			earliest = times[n-1]
		}
		if earliest.Before(aStart) {
			return e.BadRequestError(fmt.Sprintf("%d lots × this gap doesn't fit: the first lot would close before the auction starts. Use a smaller gap.", n), nil)
		}
		if !earliest.After(now) {
			return e.BadRequestError("This gap would make a lot close in the past. Use a smaller gap.", nil)
		}
		if err := e.App.RunInTransaction(func(tx core.App) error {
			for k, l := range lots {
				if times[k].Unix() == aEnd.Unix() {
					l.Set("endsAt", "")
				} else {
					l.Set("endsAt", times[k].UTC().Format("2006-01-02 15:04:05.000Z"))
				}
				if err := tx.Save(l); err != nil {
					return err
				}
			}
			au.Set("stagger", true)
			b := builderOf(au)
			info, _ := b["info"].(map[string]any)
			if info == nil {
				info = map[string]any{}
			}
			if in.Unit == "Seconds" || in.Unit == "Minutes" || in.Unit == "Hours" {
				info["unit"] = in.Unit
				info["gap"] = strconv.FormatFloat(in.Gap, 'f', -1, 64)
			}
			b["info"] = info
			au.Set("builder", b)
			return tx.Save(au)
		}); err != nil {
			return e.BadRequestError("Could not stagger the lots", err)
		}
		return e.JSON(200, map[string]any{"lots": n})
	})
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

var (
	lotPrefix = regexp.MustCompile(`(?i)^lot[\s_\-]*`)
	numSuffix = regexp.MustCompile(`[\s_\-]*\(?\d+\)?$`)
	digitRun  = regexp.MustCompile(`\d+`)
)

// matchLot finds the lot a photo belongs to from its folder or file name:
//
//	12.jpg · 12_2.jpg · Lot 12 (3).png · lot-12/front.jpg · ABC-123.jpg · ABC-123_2.jpg  (lot number or SKU)
func matchLot(name string, byNo map[int]*core.Record, bySKU map[string]*core.Record) *core.Record {
	parts := strings.Split(name, "/")
	base := strings.TrimSuffix(parts[len(parts)-1], path.Ext(parts[len(parts)-1]))
	var keys []string
	if len(parts) > 1 { // a folder per lot wins over the file name
		keys = append(keys, parts[len(parts)-2])
	}
	keys = append(keys, base)
	try := func(k string) *core.Record {
		k = strings.TrimSpace(k)
		if k == "" {
			return nil
		}
		if n, err := strconv.Atoi(lotPrefix.ReplaceAllString(k, "")); err == nil {
			if l, ok := byNo[n]; ok {
				return l
			}
		}
		return bySKU[strings.ToLower(k)]
	}
	for _, k := range keys {
		if l := try(k); l != nil {
			return l
		}
		if s := numSuffix.ReplaceAllString(k, ""); s != k {
			if l := try(s); l != nil {
				return l
			}
		}
	}
	return nil
}

// naturalKey sorts "img2" before "img10".
func naturalKey(s string) string {
	return digitRun.ReplaceAllStringFunc(strings.ToLower(s), func(d string) string {
		if len(d) >= 8 {
			return d
		}
		return strings.Repeat("0", 8-len(d)) + d
	})
}
