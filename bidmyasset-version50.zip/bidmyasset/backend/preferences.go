package main

import (
	"encoding/json"
	"time"

	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/router"
	"github.com/pocketbase/pocketbase/tools/types"
)

// Account preferences per user and scope ("portal" = bidder site, "admin" = admin console).
// Stored in users.prefs as {"portal": {...}, "admin": {...}}; every value is validated here.

type notifyChannels struct {
	InApp bool `json:"inApp"`
	Email bool `json:"email"`
}

type userPrefs struct {
	Language string                    `json:"language"`
	Timezone string                    `json:"timezone"`
	Theme    string                    `json:"theme"`
	Notify   map[string]notifyChannels `json:"notify"`
}

// Same keys as lib/preferences.ts. A locked key is transactional / security: always on, cannot be switched off.
var prefNotifyKeys = map[string]map[string]bool{
	"portal": {"outbid": false, "won": false, "registration": true, "invoice": true, "auctionReminder": false, "marketing": false},
	"admin":  {"newRegistration": false, "newBid": false, "auctionEnding": false, "invoicePaid": false, "systemAlerts": true},
}

func validatePrefs(scope string, in userPrefs) (userPrefs, string) {
	if in.Language != "en" && in.Language != "ms" {
		return in, "Unknown language"
	}
	if in.Theme != "light" && in.Theme != "dark" && in.Theme != "system" {
		return in, "Unknown theme"
	}
	if in.Timezone != "auto" {
		if _, err := time.LoadLocation(in.Timezone); err != nil || in.Timezone == "" || in.Timezone == "Local" {
			return in, "Unknown timezone"
		}
	}
	clean := map[string]notifyChannels{}
	for k, ch := range in.Notify {
		locked, ok := prefNotifyKeys[scope][k]
		if !ok {
			continue // drop keys we do not know
		}
		if locked {
			ch = notifyChannels{InApp: true, Email: true}
		}
		clean[k] = ch
	}
	in.Notify = clean
	return in, ""
}

func registerPreferenceRoutes(auth *router.RouterGroup[*core.RequestEvent]) {
	// GET /api/bma/me/preferences?scope=portal|admin  ->  {"prefs": {...} | null}  (null = nothing saved yet)
	auth.GET("/me/preferences", func(e *core.RequestEvent) error {
		scope := e.Request.URL.Query().Get("scope")
		if _, ok := prefNotifyKeys[scope]; !ok {
			return e.BadRequestError("scope must be portal or admin", nil)
		}
		var all map[string]json.RawMessage
		_ = json.Unmarshal([]byte(e.Auth.GetString("prefs")), &all)
		if raw, ok := all[scope]; ok {
			return e.JSON(200, map[string]any{"prefs": raw})
		}
		return e.JSON(200, map[string]any{"prefs": nil})
	})

	// PUT /api/bma/me/preferences  {scope, prefs}
	auth.PUT("/me/preferences", func(e *core.RequestEvent) error {
		var in struct {
			Scope string    `json:"scope"`
			Prefs userPrefs `json:"prefs"`
		}
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		if _, ok := prefNotifyKeys[in.Scope]; !ok {
			return e.BadRequestError("scope must be portal or admin", nil)
		}
		if in.Scope == "admin" && !e.Auth.GetBool("isAdmin") {
			return e.ForbiddenError("Forbidden", nil)
		}
		clean, msg := validatePrefs(in.Scope, in.Prefs)
		if msg != "" {
			return e.BadRequestError(msg, nil)
		}
		var all map[string]json.RawMessage
		_ = json.Unmarshal([]byte(e.Auth.GetString("prefs")), &all)
		if all == nil {
			all = map[string]json.RawMessage{}
		}
		raw, _ := json.Marshal(clean)
		all[in.Scope] = raw
		out, _ := json.Marshal(all)
		e.Auth.Set("prefs", types.JSONRaw(out))
		if err := e.App.Save(e.Auth); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"prefs": clean})
	})
}
