# BidMyAsset backend — Go + PocketBase

PocketBase is used as a **Go framework**, so one binary gives you: SQLite database, auth (password, OTP, password reset),
realtime (SSE) and the admin dashboard — plus our own routes in `routes.go`.

## Run
```bash
cd backend
go mod tidy                 # first time: downloads PocketBase
export BMA_AUTO_APPROVE=1   # dev only (see .env.example)
export BMA_ADMIN_KEY=$(openssl rand -hex 32)   # required; use the SAME value in the Next.js .env.local
go run . serve              # API + dashboard on http://127.0.0.1:8090
```
`serve` refuses to start when `BMA_ADMIN_KEY` is missing, is a placeholder (`change-me` …) or is shorter than 16 characters:
every `/api/bma/admin/*` route trusts this shared key. (`superuser` and `migrate` commands do not need it.)
1. Open the link PocketBase prints (`/_/#/pbinstal/...`) to create the **superuser** (staff login for the dashboard `/_/`).
2. The database starts empty: no demo auctions are created. Add auctions in Admin → Auction Studio.
3. Email (OTP codes, reset links): dashboard → Settings → Mail settings → configure SMTP. Without SMTP, no email is delivered.

Then run the website (repo root): copy `.env.local.example` → `.env.local`, `npm install`, `npm run dev`.

## Collections (`migrations/1_init.go`)
`house` (settings + file uploads) · `users` (auth, extended) · `auctions` · `lots` · `bids` · `registrations` · `favourites` · `invoices` · `notifications` · `contact_messages` · `subscribers`

Rules: auctions + lots are public-read. Everything personal is "own records only". `bids`, `registrations`, `invoices`
cannot be written from the browser — bids/registrations only through the custom routes, invoices by staff in the dashboard.
`lots.leader` is a hidden field (never returned by the public API).

## Custom routes
| Route | Auth | What it does |
|---|---|---|
| `GET /api/bma/time` | – | server clock |
| `POST /api/bma/bids` | user | one DB transaction: time window → approved registration → min bid + increment → demote old leader + notify → save bid, update lot/auction counters |
| `POST /api/bma/registrations` | user | request to join an auction (PENDING; `BMA_AUTO_APPROVE=1` approves instantly) |
| `GET /api/bma/me/export` | user | JSON of everything held on the user |
| `POST /api/bma/me/delete-request` | user | needs password; blocked by unpaid invoices / leading bids; sets `deleteRequestedAt` (no hard delete) |
| `POST /api/bma/contact`, `/subscribe` | – | store the public forms |
| `GET /api/bma/admin/studio`, `POST …/auctions` (create draft + cover images), `…/auction-publish`, `…/lots` (create/update), `…/lots-delete`, `…/images` (add/remove photos), `…/images-order` | admin key | Auction Studio: real auctions + lots; **photos** of auctions (`auctions.images`, ≤10) and lots (`lots.images`, ≤30), JPG/PNG/WebP ≤10 MB, first = cover. Served at `/api/files/<auctions|lots>/<id>/<file>` |
| `GET/POST /api/bma/admin/house` | admin key | auction house profile + **branding uploads** (`logo`, `favicon`, `banners`; multipart, ≤2 MB, PNG/JPG/WebP/SVG). Stored by PocketBase in collection `house`; served at `/api/files/house/<id>/<file>` (website: `/api/pb/api/files/house/...`) |

Auth endpoints are PocketBase's own (`/api/collections/users/auth-with-password`, `request-otp`, `auth-with-otp`, `request-password-reset`, …).

## Staff workflow (until the admin UI is connected)
Approve a bidder: dashboard → `registrations` → set status `APPROVED`. Issue an invoice: `invoices` → New record.

## Not done yet
Anti-sniping / auto-extend, proxy (max) bids, realtime lot updates in the UI (PocketBase SSE is ready), 
the `/admin` section of the website (still mock), payments.

| `GET/PUT /api/bma/admin/house/settings` | admin key | Auction House **internet buying fee** (`house.fee`, one of 6 structures or `null` to remove) and **theme** (`house.theme`), **legal policies** (`house.legal`, HTML cleaned on save) and **categories** (`house.categories`). PUT body `{fee?, theme?, legal?, categories?}`; values are validated (numbers ≥ 0, % ≤ 100, CSS allow-list) and the response carries a worked example for a 100,000 hammer. `house` is public-read, so the website reads both directly. |
| `GET /api/bma/fee-quote?amount=N` | – | what a buyer pays on a hammer price: `{hammer, commission, internetFee, fees, total}` (Company commission + Auction House internet buying fee). Used by the bid stepper. |

**Invoices** (`bidding.go`): with a `hammer` price, `commission` (Company), `internetFee` (Auction House) and `amount = hammer + commission + internetFee` are filled in; all six structures are supported now (`computeFee` in `house_settings.go`).
