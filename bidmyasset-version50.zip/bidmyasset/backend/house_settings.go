package main

import (
	"encoding/json"
	"io"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/pocketbase/pocketbase/core"
)

// Auction House → Fees & Commissions (internet buying fee) and Theming & Config.
//
//	PUT /api/bma/admin/house/settings   admin key   body {"fee": {...}|null, "theme": {...}, "legal": [...], "categories": {...}|null}  (any of them)
//	GET /api/bma/fee-quote?amount=N     public      what a buyer pays on top of a hammer price
//
// The fee and the theme live on the public-read `house` record (migrations/99_zz_house_fee_theme.go), so the
// website reads them directly. Every value is validated here, because theme values end up inside CSS on
// the public site (same allow-list as isCssValue / isColor in src/lib/auctionHouse.ts).

type feeField struct {
	Key string
	Pct bool
}

// The six structures of src/lib/auctionHouse.ts FEE_DEFS.
var feeFields = map[string][]feeField{
	"flat_pct":        {{"rate", true}},
	"flat_cap":        {{"rate", true}, {"cap", false}},
	"flat_cap_online": {{"rate", true}, {"cap", false}, {"online", true}},
	"tier_pct":        {{"first", true}, {"upTo", false}, {"balance", true}},
	"tier_pct_cap":    {{"first", true}, {"upTo", false}, {"balance", true}, {"cap", false}},
	"tier_flat":       {{"first", true}, {"upTo", false}, {"second", true}, {"from", false}},
}

var (
	hexColorRe = regexp.MustCompile(`^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$`)
	cssColorRe = regexp.MustCompile(`(?i)^(transparent|none|rgba?\([0-9\s.,%]+\))$`)
	cssValueRe = regexp.MustCompile(`^[#a-zA-Z0-9\s.,%()\-+/]*$`)
	cssBadRe   = regexp.MustCompile(`(?i)url\s*\(|expression\s*\(|import`)
)

func okHex(v string) bool   { return hexColorRe.MatchString(v) }
func okColor(v string) bool { return okHex(v) || cssColorRe.MatchString(v) }
func okCSS(v string) bool {
	return len(v) <= 80 && cssValueRe.MatchString(v) && !cssBadRe.MatchString(v)
}

var (
	btnColorKeys = []string{"background", "text", "border", "hoverBackground", "hoverText", "hoverBorder"}
	btnCSSKeys   = []string{"radius", "fontSize", "fontWeight", "padding", "shadow", "hoverShadow"}
	dlgColorKeys = []string{"background", "border", "text"}
	dlgCSSKeys   = []string{"radius", "shadow", "headerPadding", "headerGap", "titleFontSize", "titleFontWeight", "contentPadding", "footerPadding", "footerGap"}
)

// cleanStyle copies only the known keys of a button / dialog style, rejecting anything that is not a safe value.
func cleanStyle(label string, in any, colorKeys, cssKeys []string) (map[string]any, string) {
	m, ok := in.(map[string]any)
	if !ok {
		return nil, label + ": unexpected format."
	}
	out := map[string]any{}
	for _, k := range colorKeys {
		if v, present := m[k]; present {
			s, isStr := v.(string)
			s = strings.TrimSpace(s)
			if !isStr || (s != "" && !okColor(s)) {
				return nil, label + "." + k + ": not a valid colour."
			}
			out[k] = s
		}
	}
	for _, k := range cssKeys {
		if v, present := m[k]; present {
			s, isStr := v.(string)
			s = strings.TrimSpace(s)
			if !isStr || !okCSS(s) {
				return nil, label + "." + k + ": not a valid value."
			}
			out[k] = s
		}
	}
	return out, ""
}

// sanitizeTheme returns the cleaned theme, or why it is rejected.
func sanitizeTheme(v any) (map[string]any, string) {
	m, ok := v.(map[string]any)
	if !ok {
		return nil, "theme: unexpected format."
	}
	out := map[string]any{}
	for _, k := range []string{"primary", "secondary"} {
		if raw, present := m[k]; present {
			s, isStr := raw.(string)
			s = strings.TrimSpace(s)
			if !isStr || (s != "" && !okHex(s)) {
				return nil, "theme." + k + ": use a hex colour like #0037E1."
			}
			out[k] = s
		}
	}
	if raw, present := m["ratings"]; present {
		b, isBool := raw.(bool)
		if !isBool {
			return nil, "theme.ratings: must be true or false."
		}
		out["ratings"] = b
	}
	if raw, present := m["buttons"]; present {
		bm, ok := raw.(map[string]any)
		if !ok {
			return nil, "theme.buttons: unexpected format."
		}
		buttons := map[string]any{}
		for _, k := range []string{"primary", "secondary", "outline"} {
			if sv, present := bm[k]; present {
				c, msg := cleanStyle("theme.buttons."+k, sv, btnColorKeys, btnCSSKeys)
				if msg != "" {
					return nil, msg
				}
				buttons[k] = c
			}
		}
		out["buttons"] = buttons
	}
	if raw, present := m["dialog"]; present {
		c, msg := cleanStyle("theme.dialog", raw, dlgColorKeys, dlgCSSKeys)
		if msg != "" {
			return nil, msg
		}
		out["dialog"] = c
	}
	return out, ""
}

// sanitizeFee returns the cleaned fee structure ({kind, ...numbers}), or why it is rejected.
func sanitizeFee(v any) (map[string]any, string) {
	m, ok := v.(map[string]any)
	if !ok {
		return nil, "fee: unexpected format."
	}
	kind, _ := m["kind"].(string)
	fields, known := feeFields[kind]
	if !known {
		return nil, "fee: unknown structure."
	}
	out := map[string]any{"kind": kind}
	for _, f := range fields {
		n, isNum := m[f.Key].(float64)
		if !isNum || math.IsNaN(n) || math.IsInf(n, 0) || n < 0 {
			return nil, "fee." + f.Key + ": enter a number of 0 or more."
		}
		if f.Pct && n > 100 {
			return nil, "fee." + f.Key + ": a percentage can’t be more than 100."
		}
		if n > 1e12 {
			return nil, "fee." + f.Key + ": number is too large."
		}
		out[f.Key] = n
	}
	return out, ""
}

// sanitizeLegal validates the whole list of legal policies ([{id, name, privacy, terms}]) and cleans the HTML.
func sanitizeLegal(v any) ([]map[string]any, string) {
	list, ok := v.([]any)
	if !ok {
		return nil, "legal: unexpected format."
	}
	if len(list) > 20 {
		return nil, "legal: at most 20 policies."
	}
	out := make([]map[string]any, 0, len(list))
	seen := map[string]bool{}
	for i, it := range list {
		m, ok := it.(map[string]any)
		if !ok {
			return nil, "legal: unexpected format."
		}
		str := func(k string) string { s, _ := m[k].(string); return s }
		name := strings.TrimSpace(str("name"))
		if name == "" || utf8.RuneCountInString(name) > 120 {
			return nil, "legal: a policy needs a name of up to 120 characters."
		}
		privacy, terms := str("privacy"), str("terms")
		if utf8.RuneCountInString(privacy) > 60000 || utf8.RuneCountInString(terms) > 60000 {
			return nil, "legal: each text can be at most 60,000 characters."
		}
		privacy, terms = strings.TrimSpace(sanitizeHTML(privacy)), strings.TrimSpace(sanitizeHTML(terms))
		if privacy == "" && terms == "" {
			return nil, "legal: “" + name + "” needs a privacy policy, terms of use, or both."
		}
		id := strings.TrimSpace(str("id"))
		if id == "" || len(id) > 64 || seen[id] {
			id = "lp-" + strconv.Itoa(i+1) + "-" + strconv.FormatInt(int64(len(name))*7919+int64(len(privacy)+len(terms)), 36)
		}
		seen[id] = true
		out = append(out, map[string]any{"id": id, "name": name, "privacy": privacy, "terms": terms})
	}
	return out, ""
}

// sanitizeCategories validates {"Category": ["Sub", ...]}: trimmed, de-duplicated, sorted. An empty list means "none of this category".
func sanitizeCategories(v any) (map[string]any, string) {
	m, ok := v.(map[string]any)
	if !ok {
		return nil, "categories: unexpected format."
	}
	if len(m) > 100 {
		return nil, "categories: too many categories."
	}
	out := map[string]any{}
	for cat, raw := range m {
		cat = strings.TrimSpace(cat)
		list, ok := raw.([]any)
		if cat == "" || utf8.RuneCountInString(cat) > 100 || !ok || len(list) > 500 {
			return nil, "categories: unexpected format."
		}
		seen := map[string]bool{}
		subs := []string{}
		for _, x := range list {
			s, ok := x.(string)
			s = strings.TrimSpace(s)
			if !ok || s == "" || utf8.RuneCountInString(s) > 100 {
				return nil, "categories: unexpected format."
			}
			if !seen[s] {
				seen[s] = true
				subs = append(subs, s)
			}
		}
		sort.Strings(subs)
		out[cat] = subs
	}
	return out, ""
}

func findHouseRecord(app core.App) *core.Record {
	recs, err := app.FindRecordsByFilter("house", "", "-updated", 1, 0)
	if err != nil || len(recs) == 0 {
		return nil
	}
	return recs[0]
}

// houseSettingsDoc: the fee + theme of a house record as plain JSON (nil when not configured).
func houseSettingsDoc(rec *core.Record) map[string]any {
	out := map[string]any{"fee": nil, "theme": nil, "legal": []any{}, "categories": nil}
	if rec == nil {
		return out
	}
	for _, k := range []string{"fee", "theme", "categories"} {
		if v, ok := decodeSection(rec.GetRaw(k)); ok {
			if m, isMap := v.(map[string]any); isMap && m != nil {
				out[k] = m
			}
		}
	}
	if v, ok := decodeSection(rec.GetRaw("legal")); ok {
		if l, isList := v.([]any); isList && l != nil {
			out["legal"] = l
		}
	}
	return out
}

// houseInternetFee returns the configured internet buying fee structure, if any.
func houseInternetFee(app core.App) (map[string]any, bool) {
	doc := houseSettingsDoc(findHouseRecord(app))
	m, ok := doc["fee"].(map[string]any)
	return m, ok && m != nil
}

// computeFee applies one fee structure to an amount. Returns false for an unknown structure.
//
//	flat_pct         amount × rate%
//	flat_cap         amount × rate%, at most cap
//	flat_cap_online  (amount × rate%, at most cap) + amount × online%
//	tier_pct         first × first% up to `upTo`, the balance × balance%
//	tier_pct_cap     tier_pct, at most cap
//	tier_flat        the whole amount × first%, or × second% once the amount is above `upTo` and at least `from`
func computeFee(c map[string]any, amount float64) (float64, bool) {
	f := func(k string) float64 { v, _ := c[k].(float64); return v }
	kind, _ := c["kind"].(string)
	var fee float64
	switch kind {
	case "flat_pct":
		fee = amount * f("rate") / 100
	case "flat_cap":
		fee = math.Min(amount*f("rate")/100, f("cap"))
	case "flat_cap_online":
		fee = math.Min(amount*f("rate")/100, f("cap")) + amount*f("online")/100
	case "tier_pct", "tier_pct_cap":
		first := math.Min(amount, f("upTo"))
		fee = first*f("first")/100 + (amount-first)*f("balance")/100
		if kind == "tier_pct_cap" {
			fee = math.Min(fee, f("cap"))
		}
	case "tier_flat":
		if amount > f("upTo") && amount >= f("from") {
			fee = amount * f("second") / 100
		} else {
			fee = amount * f("first") / 100
		}
	default:
		return 0, false
	}
	return round2(fee), true
}

// quoteFees: what a buyer pays on a hammer price = hammer + auctioneer commission (Company) + internet buying fee (Auction House) + tax (Company → Taxes).
func quoteFees(app core.App, hammer float64) map[string]any {
	var commission, internet float64
	if c, ok := companyCommission(app); ok {
		if fee, ok := computeFee(c, hammer); ok {
			commission = fee
		}
	}
	if c, ok := houseInternetFee(app); ok {
		if fee, ok := computeFee(c, hammer); ok {
			internet = fee
		}
	}
	tax := round2((hammer + commission + internet) * companyTaxRate(app) / 100) // Company → Taxes
	return map[string]any{
		"hammer":      round2(hammer),
		"commission":  commission,
		"internetFee": internet,
		"tax":         tax,
		"fees":        round2(commission + internet + tax),
		"total":       round2(hammer + commission + internet + tax),
	}
}

func registerHouseSettingsRoutes(se *core.ServeEvent) {
	r := se.Router

	// Public: the website shows "+ buyer's fees ≈ …" next to the bid, always from the server's numbers.
	r.GET("/api/bma/fee-quote", func(e *core.RequestEvent) error {
		amount, err := strconv.ParseFloat(strings.TrimSpace(e.Request.URL.Query().Get("amount")), 64)
		if err != nil || math.IsNaN(amount) || math.IsInf(amount, 0) || amount <= 0 || amount > 1e12 {
			return e.BadRequestError("Enter an amount greater than 0.", nil)
		}
		return e.JSON(200, quoteFees(e.App, amount))
	})

	r.GET("/api/bma/admin/house/settings", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		return e.JSON(200, houseSettingsDoc(findHouseRecord(e.App)))
	})

	r.PUT("/api/bma/admin/house/settings", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		body, err := io.ReadAll(io.LimitReader(e.Request.Body, 3<<20))
		if err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		var in map[string]json.RawMessage
		if err := json.Unmarshal(body, &in); err != nil || len(in) == 0 {
			return e.BadRequestError("Invalid request", nil)
		}
		rec := findHouseRecord(e.App)
		if rec == nil {
			rec = core.NewRecord(mustCol(e.App, "house"))
			rec.Set("name", "BidMyAsset")
		}
		for key, raw := range in {
			var v any
			if err := json.Unmarshal(raw, &v); err != nil {
				return e.BadRequestError(key+": unexpected format.", nil)
			}
			switch key {
			case "fee":
				if v == nil { // null clears the fee
					setSection(rec, "fee", nil)
					continue
				}
				clean, msg := sanitizeFee(v)
				if msg != "" {
					return e.BadRequestError(msg, nil)
				}
				setSection(rec, "fee", clean)
			case "theme":
				clean, msg := sanitizeTheme(v)
				if msg != "" {
					return e.BadRequestError(msg, nil)
				}
				setSection(rec, "theme", clean)
			case "legal":
				clean, msg := sanitizeLegal(v)
				if msg != "" {
					return e.BadRequestError(msg, nil)
				}
				setSection(rec, "legal", clean)
			case "categories":
				if v == nil { // null = not configured: the public filter shows every category again
					setSection(rec, "categories", nil)
					continue
				}
				clean, msg := sanitizeCategories(v)
				if msg != "" {
					return e.BadRequestError(msg, nil)
				}
				setSection(rec, "categories", clean)
			default:
				return e.BadRequestError("Unknown setting: "+key, nil)
			}
		}
		if err := e.App.Save(rec); err != nil {
			return e.BadRequestError("Could not save the settings.", err)
		}
		doc := houseSettingsDoc(rec)
		// a worked example so the admin can see the fee is really applied
		doc["example"] = quoteFees(e.App, 100000)
		return e.JSON(200, doc)
	})
}
