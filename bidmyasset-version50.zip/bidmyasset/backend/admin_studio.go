package main

import (
	"crypto/subtle"
	"io"
	"math/rand"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/filesystem"
)

// Auction Studio (admin console): real auctions + lots, image uploads, publish switch.
// All routes need X-BMA-Admin-Key; Next checks the caller is an admin first.

func adminOK(e *core.RequestEvent) bool {
	key := os.Getenv("BMA_ADMIN_KEY")
	return key != "" && subtle.ConstantTimeCompare([]byte(e.Request.Header.Get("X-BMA-Admin-Key")), []byte(key)) == 1
}

func fileURLs(rec *core.Record, field string) []map[string]string {
	out := []map[string]string{}
	for _, n := range rec.GetStringSlice(field) {
		out = append(out, map[string]string{"name": n, "url": "/api/files/" + rec.Collection().Name + "/" + rec.Id + "/" + n})
	}
	return out
}

func isoTime(rec *core.Record, f string) string {
	return rec.GetDateTime(f).Time().UTC().Format(time.RFC3339)
}

// optISO returns "" for an unset date field (PocketBase stores it as a zero time).
func optISO(rec *core.Record, f string) string {
	if rec.GetDateTime(f).IsZero() {
		return ""
	}
	return isoTime(rec, f)
}

// companyName is the name saved in Admin → Company (empty when none).
func companyName(app core.App) string {
	rec := findCompany(app)
	if rec == nil {
		return ""
	}
	if raw, ok := decodeSection(rec.GetRaw("company")); ok {
		if m, ok := raw.(map[string]any); ok {
			if n, _ := m["name"].(string); strings.TrimSpace(n) != "" {
				return strings.TrimSpace(n)
			}
		}
	}
	return ""
}

// reserveOf is the reserve that actually applies to a lot: none in an Absolute auction.
func reserveOf(auction, lot *core.Record) float64 {
	if auction != nil && auction.GetString("auctionType") == "ABSOLUTE" {
		return 0
	}
	return lot.GetFloat("reserve")
}

// syncReserveFlags keeps the public lots.hasReserve / lots.reserveMet flags in line with the (hidden) reserve and the highest bid.
func syncReserveFlags(auction, lot *core.Record) {
	r := reserveOf(auction, lot)
	lot.Set("hasReserve", r > 0)
	lot.Set("reserveMet", r > 0 && lot.GetInt("bidCount") > 0 && lot.GetFloat("currentBid") >= r)
}

var nonSlug = regexp.MustCompile(`[^a-z0-9]+`)

func slugify(s string) string {
	s = strings.Trim(nonSlug.ReplaceAllString(strings.ToLower(s), "-"), "-")
	if s == "" {
		s = "auction"
	}
	if len(s) > 80 {
		s = strings.Trim(s[:80], "-")
	}
	return s
}

// recount keeps auctions.lotCount / imageCount truthful (the public site reads them).
func recount(app core.App, auctionID string) {
	a, err := app.FindRecordById("auctions", auctionID)
	if err != nil {
		return
	}
	n, _ := app.CountRecords("lots", dbx.NewExp("auction = {:a} AND COALESCE(draft, 0) = 0", dbx.Params{"a": auctionID}))
	a.Set("lotCount", n)
	a.Set("imageCount", len(a.GetStringSlice("images")))
	_ = app.Save(a)
}

func multipartFiles(e *core.RequestEvent, field string) ([]*filesystem.File, error) {
	out := []*filesystem.File{}
	for _, h := range e.Request.MultipartForm.File[field] {
		f, err := filesystem.NewFileFromMultipart(h)
		if err != nil {
			return nil, err
		}
		out = append(out, f)
	}
	return out, nil
}

func formVal(e *core.RequestEvent, k string) string {
	if v := e.Request.MultipartForm.Value[k]; len(v) > 0 {
		return strings.TrimSpace(v[0])
	}
	return ""
}

// copyFiles reads the stored files of one record field so they can be attached to a copy of it.
func copyFiles(app core.App, src *core.Record, field string) []*filesystem.File {
	out := []*filesystem.File{}
	names := src.GetStringSlice(field)
	if len(names) == 0 {
		return out
	}
	fsys, err := app.NewFilesystem()
	if err != nil {
		return out
	}
	defer fsys.Close()
	for _, n := range names {
		r, err := fsys.GetReader(src.BaseFilesPath() + "/" + n)
		if err != nil {
			continue
		}
		b, err := io.ReadAll(r)
		r.Close()
		if err != nil {
			continue
		}
		if f, err := filesystem.NewFileFromBytes(b, n); err == nil {
			out = append(out, f)
		}
	}
	return out
}

func registerStudioRoutes(se *core.ServeEvent) {
	r := se.Router
	registerStudioActivityRoutes(se)
	registerStudioBuilderRoutes(se)
	registerAdminNoticeRoutes(se)
	registerAdminNoticeReadRoute(se)
	registerAdminInvoiceRoutes(se)
	registerStudioImportRoutes(se)

	r.GET("/api/bma/admin/studio", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		auctions, err := e.App.FindRecordsByFilter("auctions", "", "-sequence", 0, 0)
		if err != nil {
			return e.InternalServerError("", err)
		}
		lots, err := e.App.FindRecordsByFilter("lots", "", "lotNumber", 0, 0)
		if err != nil {
			return e.InternalServerError("", err)
		}
		as := []map[string]any{}
		for _, a := range auctions {
			as = append(as, map[string]any{
				"id": a.Id, "slug": a.GetString("slug"), "sequence": a.GetInt("sequence"), "title": a.GetString("title"),
				"published": a.GetBool("published"), "paused": a.GetBool("paused"), "updated": isoTime(a, "updated"),
				"auctionType": a.GetString("auctionType"), "description": a.GetString("description"), "approvalMode": a.GetString("approvalMode"),
				"hideBidders": a.GetBool("hideBidders"), "stagger": a.GetBool("stagger"), "category": a.GetString("category"), "subcategory": a.GetString("subcategory"), "startsAt": isoTime(a, "startsAt"), "endsAt": isoTime(a, "endsAt"),
				"timezone": a.GetString("timezone"), "currency": a.GetString("currency"), "images": fileURLs(a, "images"),
				"builder": builderOf(a), "documents": fileURLs(a, "documents"), "contactFiles": fileURLs(a, "contactFiles"),
			})
		}
		ls := []map[string]any{}
		for _, l := range lots {
			ls = append(ls, map[string]any{
				"id": l.Id, "auction": l.GetString("auction"), "lotNumber": l.GetInt("lotNumber"), "title": l.GetString("title"),
				"sku": l.GetString("sku"), "quantity": l.GetInt("quantity"), "category": l.GetString("category"),
				"startingBid": l.GetFloat("startingBid"), "increment": l.GetFloat("increment"),
				"description": l.GetString("description"), "images": fileURLs(l, "images"),
				"reserve": l.GetFloat("reserve"), "endsAt": optISO(l, "endsAt"), "hashtags": l.GetString("hashtags"), "highlights": l.GetString("highlights"),
				"consignor": l.GetString("consignor"), "address": l.GetString("address"), "draft": l.GetBool("draft"),
				"incrementMatrix": tiersAny(lotTiers(l)),
			})
		}
		return e.JSON(200, map[string]any{"auctions": as, "lots": ls, "company": companyName(e.App), "companyBid": companyBidJSON(e.App)})
	})

	// Create a (draft, unpublished) auction, optionally with cover images, from the "Add auction" wizard.
	r.POST("/api/bma/admin/auctions", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if err := e.Request.ParseMultipartForm(128 << 20); err != nil {
			return e.BadRequestError("Expected multipart/form-data", nil)
		}
		title := formVal(e, "title")
		starts, err1 := time.Parse(time.RFC3339, formVal(e, "startsAt"))
		ends, err2 := time.Parse(time.RFC3339, formVal(e, "endsAt"))
		if title == "" || err1 != nil || err2 != nil || ends.Before(starts) {
			return e.BadRequestError("Title and a valid start/end time are required", nil)
		}
		tz, cur := formVal(e, "timezone"), strings.ToUpper(formVal(e, "currency"))
		if tz == "" {
			tz = "Asia/Kuala_Lumpur"
		}
		if _, err := time.LoadLocation(tz); err != nil {
			return e.BadRequestError("Unknown time zone", nil)
		}
		if cur == "" {
			cur = "MYR"
		}
		if len(cur) != 3 {
			return e.BadRequestError("Currency must be a 3-letter code", nil)
		}
		typ := formVal(e, "auctionType")
		if typ != "" && typ != "RESERVE" && typ != "ABSOLUTE" && typ != "SUBJECT" {
			return e.BadRequestError("Unknown auction type", nil)
		}
		approval := formVal(e, "approvalMode")
		if approval != "" && approval != "AUTO" && approval != "MANUAL" {
			return e.BadRequestError("Unknown approval mode", nil)
		}
		slug := slugify(title)
		if _, err := e.App.FindFirstRecordByFilter("auctions", "slug = {:s}", dbx.Params{"s": slug}); err == nil {
			slug += "-" + time.Now().Format("060102150405")
		}
		seq := 1000
		if recs, err := e.App.FindRecordsByFilter("auctions", "", "-sequence", 1, 0); err == nil && len(recs) > 0 {
			seq = recs[0].GetInt("sequence") + 1
		}
		rec := core.NewRecord(mustCol(e.App, "auctions"))
		rec.Set("slug", slug)
		rec.Set("sequence", seq)
		rec.Set("title", title)
		rec.Set("startsAt", starts.UTC().Format("2006-01-02 15:04:05.000Z"))
		rec.Set("endsAt", ends.UTC().Format("2006-01-02 15:04:05.000Z"))
		rec.Set("timezone", tz)
		rec.Set("currency", cur)
		rec.Set("tone", rand.Intn(8))
		rec.Set("category", formVal(e, "category"))
		rec.Set("subcategory", formVal(e, "subcategory"))
		rec.Set("auctionType", typ)
		rec.Set("approvalMode", approval)
		rec.Set("description", formVal(e, "description"))
		rec.Set("hideBidders", formVal(e, "hideBidders") == "true")
		rec.Set("stagger", formVal(e, "stagger") == "true")
		rec.Set("published", false)
		files, err := multipartFiles(e, "images")
		if err != nil {
			return e.BadRequestError("Invalid image", nil)
		}
		if len(files) > 0 {
			rec.Set("images", files)
			rec.Set("imageCount", len(files))
		}
		if err := e.App.Save(rec); err != nil {
			return e.BadRequestError("Could not create auction", err)
		}
		return e.JSON(200, map[string]any{"id": rec.Id, "slug": slug, "images": fileURLs(rec, "images")})
	})

	// Duplicate an auction as a new unpublished draft: its settings, cover images and (optionally) all its lots with their
	// photos and bid setup. Bids, registrations, invoices and the paused/published state are never copied.
	// Lots that had their own closing time keep the same distance from the auction end when it still fits the new window.
	r.POST("/api/bma/admin/auction-clone", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID       string `json:"id"`
			Title    string `json:"title"`
			StartsAt string `json:"startsAt"`
			EndsAt   string `json:"endsAt"`
			Lots     bool   `json:"lots"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("Invalid body", nil)
		}
		src, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		title := strings.TrimSpace(in.Title)
		starts, err1 := time.Parse(time.RFC3339, in.StartsAt)
		ends, err2 := time.Parse(time.RFC3339, in.EndsAt)
		if title == "" || err1 != nil || err2 != nil || ends.Before(starts) {
			return e.BadRequestError("Title and a valid start/end time are required", nil)
		}
		slug := slugify(title)
		if _, err := e.App.FindFirstRecordByFilter("auctions", "slug = {:s}", dbx.Params{"s": slug}); err == nil {
			slug += "-" + time.Now().Format("060102150405")
		}
		seq := 1000
		if recs, err := e.App.FindRecordsByFilter("auctions", "", "-sequence", 1, 0); err == nil && len(recs) > 0 {
			seq = recs[0].GetInt("sequence") + 1
		}
		delta := ends.Sub(src.GetDateTime("endsAt").Time())
		copied := 0
		var newID string
		err = e.App.RunInTransaction(func(tx core.App) error {
			a := core.NewRecord(mustCol(tx, "auctions"))
			for _, f := range []string{"timezone", "currency", "city", "region", "lat", "lng", "tone", "category", "subcategory",
				"auctionType", "description", "approvalMode", "hideBidders", "stagger"} {
				a.Set(f, src.Get(f))
			}
			a.Set("slug", slug)
			a.Set("sequence", seq)
			a.Set("title", title)
			a.Set("startsAt", starts.UTC().Format("2006-01-02 15:04:05.000Z"))
			a.Set("endsAt", ends.UTC().Format("2006-01-02 15:04:05.000Z"))
			a.Set("published", false)
			if imgs := copyFiles(tx, src, "images"); len(imgs) > 0 {
				a.Set("images", imgs)
				a.Set("imageCount", len(imgs))
			}
			if err := tx.Save(a); err != nil {
				return err
			}
			newID = a.Id
			if !in.Lots {
				return nil
			}
			lots, err := tx.FindRecordsByFilter("lots", "auction = {:a}", "addedOrder", 0, 0, dbx.Params{"a": src.Id})
			if err != nil {
				return err
			}
			for _, l := range lots {
				n := core.NewRecord(mustCol(tx, "lots"))
				for _, f := range []string{"lotNumber", "addedOrder", "title", "description", "category", "subcategory", "sku", "quantity", "startingBid",
					"increment", "reserve", "hashtags", "highlights", "consignor", "address", "hasReserve"} {
					n.Set(f, l.Get(f))
				}
				if m := l.Get("incrementMatrix"); m != nil {
					n.Set("incrementMatrix", m)
				}
				n.Set("auction", a.Id)
				n.Set("draft", true) // staff review the copy and set lots Live themselves
				if !l.GetDateTime("endsAt").IsZero() {
					if t := l.GetDateTime("endsAt").Time().Add(delta); !t.Before(starts) && !t.After(ends) {
						n.Set("endsAt", t.UTC().Format("2006-01-02 15:04:05.000Z"))
					}
				}
				if imgs := copyFiles(tx, l, "images"); len(imgs) > 0 {
					n.Set("images", imgs)
				}
				if err := tx.Save(n); err != nil {
					return err
				}
				copied++
			}
			return nil
		})
		if err != nil {
			return e.BadRequestError("Could not clone the auction", err)
		}
		if newID != "" {
			recount(e.App, newID)
		}
		return e.JSON(200, map[string]any{"id": newID, "slug": slug, "lots": copied})
	})

	r.POST("/api/bma/admin/auction-publish", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID        string `json:"id"`
			Published bool   `json:"published"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		a, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		a.Set("published", in.Published)
		if err := e.App.Save(a); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true, "published": in.Published})
	})

	// Pause / resume bidding on a published auction. Persisted on auctions.paused and enforced by place-bid.
	r.POST("/api/bma/admin/auction-pause", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID     string `json:"id"`
			Paused bool   `json:"paused"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		a, err := e.App.FindRecordById("auctions", in.ID)
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		a.Set("paused", in.Paused)
		if err := e.App.Save(a); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true, "paused": in.Paused})
	})

	// Create or update a lot (id empty = create).
	r.POST("/api/bma/admin/lots", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID          string   `json:"id"`
			Auction     string   `json:"auction"`
			Title       string   `json:"title"`
			SKU         *string  `json:"sku"`
			Quantity    *float64 `json:"quantity"`
			Category    *string  `json:"category"`
			StartingBid *float64 `json:"startingBid"`
			Increment   *float64 `json:"increment"`
			IncrementMatrix *[]tierIn `json:"incrementMatrix"` // tiered increments; [] = back to a single increment
			Description *string  `json:"description"`
			LotNumber   *int     `json:"lotNumber"`
			Reserve     *float64 `json:"reserve"`
			EndsAt      *string  `json:"endsAt"` // RFC3339; "" = close with the auction
			Hashtags    *string  `json:"hashtags"`
			Highlights  *string  `json:"highlights"`
			Consignor   *string  `json:"consignor"`
			Address     *string  `json:"address"`
			Draft       *bool    `json:"draft"`
		}
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid body", nil)
		}
		var lot *core.Record
		if in.ID != "" {
			l, err := e.App.FindRecordById("lots", in.ID)
			if err != nil {
				return e.NotFoundError("Lot not found", nil)
			}
			lot = l
		} else {
			au, err := e.App.FindRecordById("auctions", in.Auction)
			if err != nil {
				return e.BadRequestError("Unknown auction", nil)
			}
			n := 0
			if recs, err := e.App.FindRecordsByFilter("lots", "auction = {:a}", "-lotNumber", 1, 0, dbx.Params{"a": in.Auction}); err == nil && len(recs) > 0 {
				n = recs[0].GetInt("lotNumber")
			}
			// new lots start with Company → Lot Bid Details, then the auction's Builder → Lot Bid Details (see newLotRecord)
			lot = newLotRecord(e.App, au, n+1)
		}
		if t := strings.TrimSpace(in.Title); t != "" {
			lot.Set("title", t)
		}
		if in.SKU != nil {
			lot.Set("sku", *in.SKU)
		}
		if in.Quantity != nil {
			lot.Set("quantity", *in.Quantity)
		}
		if in.Category != nil {
			lot.Set("category", *in.Category)
		}
		if in.StartingBid != nil {
			lot.Set("startingBid", *in.StartingBid)
		}
		if in.Increment != nil {
			lot.Set("increment", *in.Increment)
		}
		if in.IncrementMatrix != nil {
			tiers, msg := cleanTiers(*in.IncrementMatrix)
			if msg != "" {
				return e.BadRequestError(msg, nil)
			}
			if len(tiers) == 0 {
				lot.Set("incrementMatrix", nil)
			} else {
				lot.Set("incrementMatrix", tiersAny(tiers))
				lot.Set("increment", tiers[0].Increment)
			}
		}
		if in.Description != nil {
			lot.Set("description", *in.Description)
		}
		if in.Hashtags != nil {
			lot.Set("hashtags", strings.TrimSpace(*in.Hashtags))
		}
		if in.Highlights != nil {
			lot.Set("highlights", strings.TrimSpace(*in.Highlights))
		}
		if in.Consignor != nil {
			lot.Set("consignor", strings.TrimSpace(*in.Consignor))
		}
		if in.Address != nil {
			lot.Set("address", strings.TrimSpace(*in.Address))
		}
		if in.LotNumber != nil && *in.LotNumber != lot.GetInt("lotNumber") {
			if *in.LotNumber < 1 {
				return e.BadRequestError("Lot number must be 1 or higher", nil)
			}
			if _, err := e.App.FindFirstRecordByFilter("lots", "auction = {:a} && lotNumber = {:n} && id != {:i}",
				dbx.Params{"a": lot.GetString("auction"), "n": *in.LotNumber, "i": lot.Id}); err == nil {
				return e.BadRequestError("Lot number "+strconv.Itoa(*in.LotNumber)+" is already used in this auction", nil)
			}
			lot.Set("lotNumber", *in.LotNumber)
		}
		if in.Reserve != nil {
			if *in.Reserve < 0 {
				return e.BadRequestError("Reserve price can't be negative", nil)
			}
			lot.Set("reserve", *in.Reserve)
		}
		var parent *core.Record
		if lot.GetString("auction") != "" {
			parent, _ = e.App.FindRecordById("auctions", lot.GetString("auction"))
		}
		if in.Reserve != nil && *in.Reserve > 0 && parent != nil && parent.GetString("auctionType") == "ABSOLUTE" {
			return e.BadRequestError("Absolute auctions have no reserve price", nil)
		}
		if in.Reserve != nil || in.StartingBid != nil {
			if r := lot.GetFloat("reserve"); r > 0 && r < lot.GetFloat("startingBid") {
				return e.BadRequestError("Reserve price can't be lower than the starting bid", nil)
			}
		}
		if in.EndsAt != nil {
			if strings.TrimSpace(*in.EndsAt) == "" {
				lot.Set("endsAt", "")
			} else {
				t, err := time.Parse(time.RFC3339, strings.TrimSpace(*in.EndsAt))
				if err != nil {
					return e.BadRequestError("Invalid closing time", nil)
				}
				if au, err := e.App.FindRecordById("auctions", lot.GetString("auction")); err == nil {
					if t.Before(au.GetDateTime("startsAt").Time()) || t.After(au.GetDateTime("endsAt").Time()) {
						return e.BadRequestError("A lot's closing time must fall between its auction's start and end", nil)
					}
				}
				lot.Set("endsAt", t.UTC().Format("2006-01-02 15:04:05.000Z"))
			}
		}
		if in.Draft != nil {
			if *in.Draft && lot.Id != "" {
				if n, _ := e.App.CountRecords("bids", dbx.HashExp{"lot": lot.Id}); n > 0 {
					return e.BadRequestError("Lot "+lot.GetString("title")+" already has bids and can't go back to draft.", nil)
				}
			}
			lot.Set("draft", *in.Draft)
		}
		syncReserveFlags(parent, lot)
		if err := e.App.Save(lot); err != nil {
			return e.BadRequestError("Could not save lot", err)
		}
		recount(e.App, lot.GetString("auction"))
		return e.JSON(200, map[string]any{"id": lot.Id, "lotNumber": lot.GetInt("lotNumber"), "images": fileURLs(lot, "images")})
	})

	r.POST("/api/bma/admin/lots-delete", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			IDs []string `json:"ids"`
		}
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid body", nil)
		}
		seen := map[string]bool{}
		for _, id := range in.IDs {
			if l, err := e.App.FindRecordById("lots", id); err == nil {
				if n, _ := e.App.CountRecords("bids", dbx.HashExp{"lot": id}); n > 0 {
					return e.BadRequestError("Lot "+l.GetString("title")+" already has bids and can't be deleted.", nil)
				}
				seen[l.GetString("auction")] = true
				if err := e.App.Delete(l); err != nil {
					return e.InternalServerError("", err)
				}
			}
		}
		for a := range seen {
			recount(e.App, a)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	// Reorder photos (first = cover/main). Only names that already exist are kept, in the given order.
	r.POST("/api/bma/admin/images-order", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			Kind  string   `json:"kind"`
			ID    string   `json:"id"`
			Order []string `json:"order"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("Invalid body", nil)
		}
		col := "auctions"
		if in.Kind == "lot" {
			col = "lots"
		}
		rec, err := e.App.FindRecordById(col, in.ID)
		if err != nil {
			return e.NotFoundError("Record not found", nil)
		}
		have := map[string]bool{}
		for _, n := range rec.GetStringSlice("images") {
			have[n] = true
		}
		next := []string{}
		for _, n := range in.Order {
			if have[n] {
				next = append(next, n)
				delete(have, n)
			}
		}
		for _, n := range rec.GetStringSlice("images") { // anything not mentioned keeps its place at the end
			if have[n] {
				next = append(next, n)
			}
		}
		rec.Set("images", next)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"id": rec.Id, "images": fileURLs(rec, "images")})
	})

	// Add / remove photos of an auction (kind=auction, cover images) or a lot (kind=lot).
	r.POST("/api/bma/admin/images", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		if err := e.Request.ParseMultipartForm(128 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		col := "auctions"
		if formVal(e, "kind") == "lot" {
			col = "lots"
		}
		rec, err := e.App.FindRecordById(col, formVal(e, "id"))
		if err != nil {
			return e.NotFoundError("Record not found", nil)
		}
		if rm := e.Request.MultipartForm.Value["remove"]; len(rm) > 0 {
			rec.Set("images-", rm)
			if err := e.App.Save(rec); err != nil {
				return e.InternalServerError("", err)
			}
		}
		files, err := multipartFiles(e, "images")
		if err != nil {
			return e.BadRequestError("Invalid image", nil)
		}
		if len(files) > 0 {
			rec.Set("images+", files)
			// PocketBase re-checks size, count and MIME (sniffed from content) against the field rules
			if err := e.App.Save(rec); err != nil {
				return e.BadRequestError("Upload rejected", err)
			}
		}
		auctionID := rec.Id
		if col == "lots" {
			auctionID = rec.GetString("auction")
		}
		recount(e.App, auctionID)
		rec, _ = e.App.FindRecordById(col, rec.Id)
		return e.JSON(200, map[string]any{"id": rec.Id, "images": fileURLs(rec, "images")})
	})
}
