package main

import (
	"errors"
	"fmt"
	"log"
	"math"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/router"
)

// Max (proxy / absentee) bidding.
//
// A bidder can store a maximum for a lot (max_bids). The system then bids for them, one step at a time, only as far as
// needed to stay ahead, never above that maximum:
//   - a bidder's maximum is never shown to anyone else; the price only moves to one step above the best competing amount;
//   - when two maximums compete, the higher one leads; on equal maximums the earlier one (the current leader) keeps the lead;
//   - amounts always sit on the lot's increment ladder (single or tiered increments), the same ladder manual bids use;
//   - a maximum set before the auction opens is an absentee bid: it opens the lot at the starting bid when bidding starts.
//
// Everything runs inside the caller's transaction, through the same place() step a manual bid uses, so soft close,
// reserve flags, bid counts and outbid notices behave the same for automatic bids.

type bidEngine struct {
	tx       core.App
	auction  *core.Record
	lot      *core.Record
	tiers    []bidTier
	now      time.Time
	lotEnd   time.Time // the lot's closing time; moves forward when soft close extends it
	extended bool
}

func newBidEngine(tx core.App, auction, lot *core.Record, now time.Time) *bidEngine {
	lotEnd := auction.GetDateTime("endsAt").Time() // a lot may close earlier than its auction (lots.endsAt)
	if le := lot.GetDateTime("endsAt"); !le.IsZero() && le.Time().Before(lotEnd) {
		lotEnd = le.Time()
	}
	return &bidEngine{tx: tx, auction: auction, lot: lot, tiers: lotTiers(lot), now: now, lotEnd: lotEnd}
}

const ladderLimit = 2_000_000

// minBid is the lowest amount a new bid can be right now.
func (b *bidEngine) minBid() float64 {
	if b.lot.GetInt("bidCount") == 0 {
		return b.lot.GetFloat("startingBid")
	}
	cur := b.lot.GetFloat("currentBid")
	return cur + bidIncrement(b.lot, b.tiers, cur)
}

// after is the next amount on the ladder above p.
func (b *bidEngine) after(p float64) float64 { return round2(p + bidIncrement(b.lot, b.tiers, p)) }

// floorCap is the highest ladder amount that does not exceed x. Below the minimum bid there is none, so the
// current bid is returned (a bidder who has only bid manually can defend no higher than what they bid).
func (b *bidEngine) floorCap(x float64) float64 {
	p := b.minBid()
	if p > x+1e-9 {
		if b.lot.GetInt("bidCount") == 0 {
			return 0
		}
		return b.lot.GetFloat("currentBid")
	}
	for i := 0; i < ladderLimit; i++ {
		n := b.after(p)
		if n > x+1e-9 {
			break
		}
		p = n
	}
	return p
}

func (b *bidEngine) maxOf(bidder string) float64 {
	rec, err := b.tx.FindFirstRecordByFilter("max_bids", "lot = {:l} && bidder = {:b}", dbx.Params{"l": b.lot.Id, "b": bidder})
	if err != nil {
		return 0
	}
	return rec.GetFloat("amount")
}

// place records one accepted bid (manual or automatic) and updates the lot, exactly like the manual bid pipeline.
// notify=false skips the outbid notice for the previous leader (used for the short-lived step in a defence).
func (b *bidEngine) place(bidder string, amount float64, notify, auto bool) error {
	tx, lot := b.tx, b.lot
	prev := lot.GetString("leader")
	if prev != "" {
		olds, _ := tx.FindRecordsByFilter("bids", "lot = {:l} && state = 'LEADING'", "", 0, 0, dbx.Params{"l": lot.Id})
		for _, o := range olds {
			o.Set("state", "OUTBID")
			if err := tx.Save(o); err != nil {
				return err
			}
		}
		// respect the bidder's notification switch (users.notificationsOff)
		if notify && prev != bidder {
			if pu, perr := tx.FindRecordById("users", prev); perr != nil || !pu.GetBool("notificationsOff") {
				n := core.NewRecord(mustCol(tx, "notifications"))
				n.Set("user", prev)
				n.Set("title", "You’ve been outbid")
				n.Set("body", fmt.Sprintf("Another bidder surpassed your bid on %s.", lot.GetString("title")))
				if err := tx.Save(n); err != nil {
					return err
				}
			}
		}
	}

	bid := core.NewRecord(mustCol(tx, "bids"))
	bid.Set("lot", lot.Id)
	bid.Set("auction", b.auction.Id)
	bid.Set("bidder", bidder)
	bid.Set("amount", amount)
	bid.Set("state", "LEADING")
	bid.Set("auto", auto)
	if err := tx.Save(bid); err != nil {
		return err
	}

	lot.Set("currentBid", amount)
	lot.Set("bidCount", lot.GetInt("bidCount")+1)
	lot.Set("leader", bidder)
	syncReserveFlags(b.auction, lot)
	// Soft close: a bid inside the last N minutes of this lot pushes its closing time out (Auction Builder → Auction Info)
	closesAt, extended, err := applySoftClose(tx, b.auction, lot, b.now, b.lotEnd)
	if err != nil {
		return err
	}
	if extended {
		b.lotEnd, b.extended = closesAt, true
	}
	if err := tx.Save(lot); err != nil {
		return err
	}
	b.auction.Set("bidCount", b.auction.GetInt("bidCount")+1)
	return tx.Save(b.auction)
}

// resolve lets stored maximums compete until nobody can top the leader any more.
func (b *bidEngine) resolve() error {
	for i := 0; i < 500; i++ {
		leader := b.lot.GetString("leader")
		filter := "lot = {:l} && amount >= {:m}"
		params := dbx.Params{"l": b.lot.Id, "m": b.minBid()}
		if leader != "" {
			filter += " && bidder != {:b}"
			params["b"] = leader
		}
		cands, err := b.tx.FindRecordsByFilter("max_bids", filter, "-amount,created", 1, 0, params)
		if err != nil || len(cands) == 0 {
			return err
		}
		c := cands[0]
		challenger := c.GetString("bidder")
		// a maximum only counts while its owner is still approved for this auction
		if _, err := b.tx.FindFirstRecordByFilter("registrations", "auction = {:a} && user = {:u} && status = 'APPROVED'",
			dbx.Params{"a": b.auction.Id, "u": challenger}); err != nil {
			if err := b.tx.Delete(c); err != nil {
				return err
			}
			continue
		}
		cf := b.floorCap(c.GetFloat("amount")) // the challenger's highest usable amount

		if leader == "" { // nobody has bid yet: the highest maximum opens the lot at the starting bid
			if err := b.place(challenger, b.minBid(), false, true); err != nil {
				return err
			}
			continue
		}
		lf := b.floorCap(math.Max(b.lot.GetFloat("currentBid"), b.maxOf(leader))) // the leader's highest usable amount
		if cf > lf+1e-9 {
			// the challenger's maximum beats the leader's: take the lead one step above it
			if err := b.place(challenger, b.after(lf), true, true); err != nil {
				return err
			}
			continue
		}
		// the leader's maximum holds: the challenger bids up to their maximum, the leader answers one step above it (or at their own cap)
		if err := b.place(challenger, cf, false, true); err != nil {
			return err
		}
		answer := math.Min(lf, b.after(cf))
		if err := b.place(leader, answer, true, true); err != nil {
			return err
		}
	}
	return errors.New("max bid resolution did not settle")
}

// ---------------------------------------------------------------- routes

func registerMaxBidRoutes(auth *router.RouterGroup[*core.RequestEvent]) {
	// GET /api/bma/max-bids  ->  {"items": [{"lot": id, "amount": n}]}  (the signed-in bidder's own maximums)
	auth.GET("/max-bids", func(e *core.RequestEvent) error {
		rows, _ := e.App.FindRecordsByFilter("max_bids", "bidder = {:u}", "-updated", 0, 0, dbx.Params{"u": e.Auth.Id})
		items := make([]map[string]any, 0, len(rows))
		for _, r := range rows {
			items = append(items, map[string]any{"lot": r.GetString("lot"), "amount": r.GetFloat("amount")})
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	// PUT /api/bma/max-bids {lot, amount}: set or raise (or lower) the bidder's maximum for a lot.
	// Allowed before the auction opens (absentee bid) and while the lot is open; applied straight away once bidding is open.
	auth.PUT("/max-bids", func(e *core.RequestEvent) error {
		var in struct {
			Lot    string  `json:"lot"`
			Amount float64 `json:"amount"`
		}
		if err := e.BindBody(&in); err != nil || in.Lot == "" || !(in.Amount > 0) || math.IsInf(in.Amount, 0) {
			return e.BadRequestError("lot and a maximum amount are required", nil)
		}
		in.Amount = round2(in.Amount)

		var result map[string]any
		err := e.App.RunInTransaction(func(tx core.App) error {
			lot, err := tx.FindRecordById("lots", in.Lot)
			if err != nil || lot.GetBool("draft") {
				return userError("Lot not found")
			}
			auction, err := tx.FindRecordById("auctions", lot.GetString("auction"))
			if err != nil || !auction.GetBool("published") {
				return userError("Auction not found")
			}
			now := time.Now()
			eng := newBidEngine(tx, auction, lot, now)
			if !now.Before(eng.lotEnd) {
				return userError("Bidding is closed")
			}
			if auction.GetBool("paused") {
				return userError("Bidding is paused for this auction. Please try again shortly.")
			}
			if _, err := tx.FindFirstRecordByFilter("registrations", "auction = {:a} && user = {:u} && status = 'APPROVED'",
				dbx.Params{"a": auction.Id, "u": e.Auth.Id}); err != nil {
				return userError("Your registration for this auction is not approved")
			}
			isLeader := lot.GetString("leader") == e.Auth.Id
			if isLeader {
				if cur := lot.GetFloat("currentBid"); in.Amount < cur {
					return userError(fmt.Sprintf("Your maximum must be at least your current bid of %.2f", cur))
				}
			} else if min := eng.minBid(); in.Amount < min {
				return userError(fmt.Sprintf("Your maximum must be at least %.2f", min))
			}

			rec, ferr := tx.FindFirstRecordByFilter("max_bids", "lot = {:l} && bidder = {:b}", dbx.Params{"l": lot.Id, "b": e.Auth.Id})
			if ferr != nil {
				rec = core.NewRecord(mustCol(tx, "max_bids"))
				rec.Set("lot", lot.Id)
				rec.Set("auction", auction.Id)
				rec.Set("bidder", e.Auth.Id)
			}
			rec.Set("amount", in.Amount)
			if err := tx.Save(rec); err != nil {
				return err
			}

			state := "SCHEDULED" // saved; becomes active when bidding opens
			if !now.Before(auction.GetDateTime("startsAt").Time()) {
				if err := eng.resolve(); err != nil {
					return err
				}
				state = "OUTBID"
				if lot.GetString("leader") == e.Auth.Id {
					state = "LEADING"
				}
			}
			result = map[string]any{
				"ok": true, "lot": lot.Id, "maxBid": in.Amount, "state": state,
				"currentBid": lot.GetFloat("currentBid"), "bidCount": lot.GetInt("bidCount"), "reserveMet": lot.GetBool("reserveMet"),
				"nextMin": eng.minBid(), "endsAt": eng.lotEnd.UTC().Format(time.RFC3339), "extended": eng.extended,
			}
			return nil
		})
		if err != nil {
			var ue userError
			if errors.As(err, &ue) {
				return e.BadRequestError(ue.Error(), nil)
			}
			return e.InternalServerError("", err)
		}
		return e.JSON(200, result)
	})

	// DELETE /api/bma/max-bids?lot=ID: remove the bidder's maximum. A bid already placed stays.
	auth.DELETE("/max-bids", func(e *core.RequestEvent) error {
		lotID := e.Request.URL.Query().Get("lot")
		if lotID == "" {
			return e.BadRequestError("lot is required", nil)
		}
		if rec, err := e.App.FindFirstRecordByFilter("max_bids", "lot = {:l} && bidder = {:b}", dbx.Params{"l": lotID, "b": e.Auth.Id}); err == nil {
			if err := e.App.Delete(rec); err != nil {
				return e.InternalServerError("", err)
			}
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
}

// runAbsenteeBids opens lots that were waiting only on absentee maximums: once an auction has started, any lot with
// maximums but no bids yet gets its first bid. Called every minute (see main.go).
func runAbsenteeBids(app core.App) {
	var ids []string
	err := app.DB().NewQuery(`SELECT DISTINCT m.lot FROM max_bids m
		JOIN lots l ON l.id = m.lot JOIN auctions a ON a.id = l.auction
		WHERE l.bidCount = 0 AND a.startsAt <= {:now}`).
		Bind(dbx.Params{"now": time.Now().UTC().Format("2006-01-02 15:04:05.000Z")}).Column(&ids)
	if err != nil {
		log.Println("absentee bids:", err)
		return
	}
	for _, id := range ids {
		err := app.RunInTransaction(func(tx core.App) error {
			lot, err := tx.FindRecordById("lots", id)
			if err != nil || lot.GetBool("draft") || lot.GetInt("bidCount") > 0 {
				return nil
			}
			auction, err := tx.FindRecordById("auctions", lot.GetString("auction"))
			if err != nil || !auction.GetBool("published") || auction.GetBool("paused") {
				return nil
			}
			now := time.Now()
			eng := newBidEngine(tx, auction, lot, now)
			if !now.Before(eng.lotEnd) || now.Before(auction.GetDateTime("startsAt").Time()) {
				return nil
			}
			return eng.resolve()
		})
		if err != nil {
			log.Println("absentee bids:", id, err)
		}
	}
}
