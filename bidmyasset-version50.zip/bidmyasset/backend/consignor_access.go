package main

import (
	"strings"

	"github.com/pocketbase/pocketbase/core"
)

// Consignor access (Admin → Company → Consignors).
//
// The account toggle stores `disabled: true` on the consignor row (company.consignors). That used to be only a flag.
// Now every save of the consignor list is mirrored onto the registered user (users.disabled), and a disabled user:
//   - cannot sign in (password, OTP) or refresh a session      → OnRecordAuthRequest below
//   - cannot call any API with a token they already hold       → router middleware below
//   - cannot register later if their consignor row is disabled → set on create below
// Admins are never disabled this way, so an admin can't lock themselves (or a colleague) out of the console.

const accountDisabledMsg = "This account has been disabled. Please contact your administrator."

// accessError is a problem with the request itself (shown to the admin), not a server fault.
type accessError string

func (a accessError) Error() string { return string(a) }

func str(v any) string { s, _ := v.(string); return strings.TrimSpace(s) }

// consignorList reads company.consignors as a list of rows.
func consignorList(raw any) []any {
	v, ok := decodeSection(raw)
	if !ok {
		return nil
	}
	l, _ := v.([]any)
	return l
}

// consignorRow finds the row for an email (case-insensitive).
func consignorRow(list []any, email string) map[string]any {
	email = strings.ToLower(strings.TrimSpace(email))
	for _, it := range list {
		if c, ok := it.(map[string]any); ok && strings.ToLower(str(c["email"])) == email {
			return c
		}
	}
	return nil
}

func consignorDisabled(app core.App, email string) bool {
	rec := findCompany(app)
	if rec == nil || strings.TrimSpace(email) == "" {
		return false
	}
	c := consignorRow(consignorList(rec.GetRaw("consignors")), email)
	off, _ := c["disabled"].(bool)
	return c != nil && off
}

// syncConsignorAccess mirrors the new consignor list onto users.disabled (call inside the same transaction as the save).
// Consignors removed from the list get their access back; users who aren't consignors are never touched.
func syncConsignorAccess(app core.App, old, next []any) error {
	setDisabled := func(email string, off bool) error {
		u, err := app.FindAuthRecordByEmail("users", strings.ToLower(strings.TrimSpace(email)))
		if err != nil || u == nil {
			return nil // not registered yet: handled when they register
		}
		if u.GetBool("isAdmin") { // admins are managed under Auctioneers / Admin Users, never from the consignor list
			if off {
				return accessError(email + " is an admin and can't be disabled as a consignor.")
			}
			return nil
		}
		if u.GetBool("disabled") == off {
			return nil
		}
		u.Set("disabled", off)
		return app.Save(u)
	}
	for _, it := range next {
		c, ok := it.(map[string]any)
		if !ok || str(c["email"]) == "" {
			continue
		}
		off, _ := c["disabled"].(bool)
		if err := setDisabled(str(c["email"]), off); err != nil {
			return err
		}
	}
	for _, it := range old {
		c, ok := it.(map[string]any)
		if !ok || str(c["email"]) == "" || consignorRow(next, str(c["email"])) != nil {
			continue
		}
		if err := setDisabled(str(c["email"]), false); err != nil {
			return err
		}
	}
	return nil
}

// registerConsignorAccess binds the hooks (call before app.Start).
func registerConsignorAccess(app core.App) {
	// Every successful auth response: password, OTP and auth-refresh (the Next app refreshes on each page load).
	app.OnRecordAuthRequest("users").BindFunc(func(e *core.RecordAuthRequestEvent) error {
		if e.Record.GetBool("disabled") {
			return e.ForbiddenError(accountDisabledMsg, nil)
		}
		return e.Next()
	})
	// A consignor an admin already disabled starts out disabled when they register.
	app.OnRecordCreate("users").BindFunc(func(e *core.RecordEvent) error {
		if consignorDisabled(e.App, e.Record.Email()) {
			e.Record.Set("disabled", true)
		}
		return e.Next()
	})
}

func registerConsignorRoutes(se *core.ServeEvent) {
	// Runs after PocketBase has loaded the auth token (default middlewares use negative priorities), so e.Auth is set.
	se.Router.BindFunc(func(e *core.RequestEvent) error {
		if a := e.Auth; a != nil && a.Collection().Name == "users" && a.GetBool("disabled") {
			return e.ForbiddenError(accountDisabledMsg, nil)
		}
		return e.Next()
	})
}
