package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/mail"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/mailer"
)

// Auction House → Email Configuration (SMTP) and Payment Credentials (Toyyibpay).
//
//	GET  /api/bma/admin/house/integrations      admin key   → what is configured (never the password / secret key)
//	PUT  /api/bma/admin/house/integrations      admin key   body {"smtp": {...}, "payment": {...}} (either part)
//	POST /api/bma/admin/house/smtp-test         admin key   body {"to": "name@example.com"}
//	POST /api/bma/invoices/{id}/pay             signed in   → {"url": "<Toyyibpay payment page>"}
//	POST /api/bma/payments/toyyibpay/callback   public      called by Toyyibpay; the payment is re-checked with Toyyibpay before the invoice is marked PAID
//
// Secrets live in the `house_integrations` collection (no API rules). Saving SMTP also writes PocketBase's own mail
// settings, which is what sends the OTP / reset-password emails and the Catalog Notification emails.

const integrationsCollection = "house_integrations"

func findIntegrations(app core.App) *core.Record {
	rec, err := app.FindFirstRecordByFilter(integrationsCollection, "id != ''")
	if err != nil {
		return nil
	}
	return rec
}

func integrationsDoc(rec *core.Record) map[string]any {
	smtp := map[string]any{"host": "", "port": "", "username": "", "passwordSet": false, "from": "", "fromName": ""}
	pay := map[string]any{"defaultGateway": true, "secretSet": false, "categoryCode": "", "sandbox": false}
	if rec != nil {
		port := ""
		if p := rec.GetInt("smtpPort"); p > 0 {
			port = strconv.Itoa(p)
		}
		smtp = map[string]any{
			"host": rec.GetString("smtpHost"), "port": port, "username": rec.GetString("smtpUser"),
			"passwordSet": rec.GetString("smtpPass") != "", "from": rec.GetString("smtpFrom"), "fromName": rec.GetString("smtpFromName"),
		}
		pay = map[string]any{
			"defaultGateway": true, "secretSet": rec.GetString("toyyibSecret") != "",
			"categoryCode": rec.GetString("toyyibCategory"), "sandbox": rec.GetBool("toyyibSandbox"),
		}
	}
	return map[string]any{"smtp": smtp, "payment": pay}
}

// applySMTP copies the saved SMTP values into PocketBase's mail settings (empty host = email off).
func applySMTP(app core.App, rec *core.Record) error {
	s := app.Settings()
	host := strings.TrimSpace(rec.GetString("smtpHost"))
	s.SMTP.Enabled = host != ""
	s.SMTP.Host = host
	s.SMTP.Port = rec.GetInt("smtpPort")
	s.SMTP.Username = rec.GetString("smtpUser")
	s.SMTP.Password = rec.GetString("smtpPass")
	s.SMTP.TLS = rec.GetInt("smtpPort") == 465 // 465 = implicit TLS; 587 / 25 upgrade with STARTTLS automatically
	if from := strings.TrimSpace(rec.GetString("smtpFrom")); from != "" {
		s.Meta.SenderAddress = from
	}
	if name := strings.TrimSpace(rec.GetString("smtpFromName")); name != "" {
		s.Meta.SenderName = name
	}
	return app.Save(s)
}

func toyyibBase(rec *core.Record) string {
	if rec != nil && rec.GetBool("toyyibSandbox") {
		return "https://dev.toyyibpay.com"
	}
	return "https://toyyibpay.com"
}

func siteURL() string {
	for _, k := range []string{"BMA_SITE_URL", "BMA_WEB_URL"} {
		if v := strings.TrimRight(strings.TrimSpace(os.Getenv(k)), "/"); v != "" {
			return v
		}
	}
	return "http://localhost:3000"
}

// publicBackendURL is where Toyyibpay can reach this backend (it cannot reach localhost: use a tunnel while developing).
func publicBackendURL() string {
	if v := strings.TrimRight(strings.TrimSpace(os.Getenv("BMA_PUBLIC_URL")), "/"); v != "" {
		return v
	}
	return "http://127.0.0.1:8090"
}

var toyyibClient = &http.Client{Timeout: 20 * time.Second}

func toyyibPost(endpoint string, form url.Values) ([]byte, error) {
	res, err := toyyibClient.PostForm(endpoint, form)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	if res.StatusCode != 200 {
		return nil, fmt.Errorf("Toyyibpay answered %d", res.StatusCode)
	}
	return b, nil
}

func clip(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n])
	}
	return s
}

func registerIntegrationsRoutes(se *core.ServeEvent) {
	r := se.Router

	r.GET("/api/bma/admin/house/integrations", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		return e.JSON(200, integrationsDoc(findIntegrations(e.App)))
	})

	r.PUT("/api/bma/admin/house/integrations", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			SMTP *struct {
				Host     string  `json:"host"`
				Port     any     `json:"port"`
				Username string  `json:"username"`
				Password *string `json:"password"` // nil / "" = keep the saved one
				From     string  `json:"from"`
				FromName string  `json:"fromName"`
			} `json:"smtp"`
			Payment *struct {
				Secret       *string `json:"secret"` // nil / "" = keep the saved one
				CategoryCode string  `json:"categoryCode"`
				Sandbox      bool    `json:"sandbox"`
			} `json:"payment"`
		}
		body, err := io.ReadAll(io.LimitReader(e.Request.Body, 64<<10))
		if err != nil || json.Unmarshal(body, &in) != nil || (in.SMTP == nil && in.Payment == nil) {
			return e.BadRequestError("Invalid request", nil)
		}
		rec := findIntegrations(e.App)
		if rec == nil {
			rec = core.NewRecord(mustCol(e.App, integrationsCollection))
		}
		smtpChanged := false
		if s := in.SMTP; s != nil {
			host := strings.TrimSpace(s.Host)
			if len(host) > 255 || strings.ContainsAny(host, " /\\@") {
				return e.BadRequestError("SMTP host: enter a host name such as smtp.example.com.", nil)
			}
			port := 0
			switch v := s.Port.(type) {
			case float64:
				port = int(v)
			case string:
				if strings.TrimSpace(v) != "" {
					p, err := strconv.Atoi(strings.TrimSpace(v))
					if err != nil {
						return e.BadRequestError("SMTP port must be a number (465, 587 or 25).", nil)
					}
					port = p
				}
			}
			if host != "" && (port < 1 || port > 65535) {
				return e.BadRequestError("SMTP port must be between 1 and 65535 (usually 465 or 587).", nil)
			}
			from := strings.TrimSpace(s.From)
			if from != "" && !validEmail(from) {
				return e.BadRequestError("Sender address is not a valid email.", nil)
			}
			if host != "" && from == "" && strings.TrimSpace(e.App.Settings().Meta.SenderAddress) == "" {
				if validEmail(s.Username) { // a username that is an email is a sensible sender
					from = strings.TrimSpace(s.Username)
				} else {
					return e.BadRequestError("Enter the sender address (the From email).", nil)
				}
			}
			rec.Set("smtpHost", host)
			rec.Set("smtpPort", port)
			rec.Set("smtpUser", strings.TrimSpace(s.Username))
			if s.Password != nil && *s.Password != "" {
				rec.Set("smtpPass", *s.Password)
			}
			if host == "" {
				rec.Set("smtpPass", "")
			}
			rec.Set("smtpFrom", from)
			rec.Set("smtpFromName", clip(strings.TrimSpace(s.FromName), 120))
			smtpChanged = true
		}
		if p := in.Payment; p != nil {
			code := strings.TrimSpace(p.CategoryCode)
			if len(code) > 64 || strings.ContainsAny(code, " /\\") {
				return e.BadRequestError("Category code: paste the code exactly as shown in Toyyibpay.", nil)
			}
			if p.Secret != nil && *p.Secret != "" {
				rec.Set("toyyibSecret", strings.TrimSpace(*p.Secret))
			}
			rec.Set("toyyibCategory", code)
			rec.Set("toyyibSandbox", p.Sandbox)
		}
		if err := e.App.Save(rec); err != nil {
			return e.BadRequestError("Could not save the settings.", err)
		}
		if smtpChanged {
			if err := applySMTP(e.App, rec); err != nil {
				return e.BadRequestError("Saved, but PocketBase refused the email settings: "+err.Error(), nil)
			}
		}
		return e.JSON(200, integrationsDoc(rec))
	})

	r.POST("/api/bma/admin/house/smtp-test", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			To      string `json:"to"`
			Subject string `json:"subject"` // optional: Email Templates sends its own subject / body as the test
			HTML    string `json:"html"`
		}
		if err := e.BindBody(&in); err != nil || !validEmail(in.To) {
			return e.BadRequestError("Enter a valid email address to send the test to.", nil)
		}
		s := e.App.Settings()
		if !s.SMTP.Enabled || s.Meta.SenderAddress == "" {
			return e.BadRequestError("Email is not set up yet: save the SMTP host, port and sender address first.", nil)
		}
		subject, body := clip(strings.TrimSpace(in.Subject), 200), sanitizeHTML(in.HTML)
		if subject == "" {
			subject = "BidMyAsset test email"
		}
		if strings.TrimSpace(body) == "" {
			body = "<p>This is a test email from BidMyAsset. Your SMTP settings work.</p>"
		}
		err := e.App.NewMailClient().Send(&mailer.Message{
			From:    mail.Address{Name: s.Meta.SenderName, Address: s.Meta.SenderAddress},
			To:      []mail.Address{{Address: strings.TrimSpace(in.To)}},
			Subject: subject,
			HTML:    body,
		})
		if err != nil {
			return e.BadRequestError("The mail server rejected the message: "+err.Error(), nil)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	// Start a Toyyibpay payment for one of the signed-in user's unpaid invoices.
	r.POST("/api/bma/invoices/{id}/pay", func(e *core.RequestEvent) error {
		if e.Auth == nil {
			return e.UnauthorizedError("Sign in first", nil)
		}
		inv, err := e.App.FindRecordById("invoices", e.Request.PathValue("id"))
		if err != nil || inv.GetString("user") != e.Auth.Id {
			return e.NotFoundError("Invoice not found", nil)
		}
		if inv.GetString("status") == "PAID" {
			return e.BadRequestError("This invoice is already paid.", nil)
		}
		cfg := findIntegrations(e.App)
		if cfg == nil || cfg.GetString("toyyibSecret") == "" || cfg.GetString("toyyibCategory") == "" {
			return e.BadRequestError("Online payment is not available yet. Please contact the auction house.", nil)
		}
		amount := inv.GetFloat("amount")
		if amount < 1 { // Toyyibpay's minimum bill is RM 1.00
			return e.BadRequestError("This invoice amount cannot be paid online. Please contact the auction house.", nil)
		}
		if cur := strings.ToUpper(strings.TrimSpace(inv.GetString("currency"))); cur != "" && cur != "MYR" && cur != "RM" {
			return e.BadRequestError("Toyyibpay only accepts Malaysian ringgit (MYR). Please contact the auction house to pay this invoice.", nil)
		}
		phone := strings.TrimSpace(e.Auth.GetString("phone"))
		if phone == "" {
			phone = "0123456789"
		}
		number := inv.GetString("number")
		form := url.Values{
			"userSecretKey":           {cfg.GetString("toyyibSecret")},
			"categoryCode":            {cfg.GetString("toyyibCategory")},
			"billName":                {clip("Invoice "+number, 30)},
			"billDescription":         {clip("Payment for invoice "+number, 100)},
			"billPriceSetting":        {"1"},
			"billPayorInfo":           {"1"},
			"billAmount":              {strconv.FormatInt(int64(amount*100+0.5), 10)}, // in cents
			"billReturnUrl":           {siteURL() + "/my-invoices?paid=" + url.QueryEscape(number)},
			"billCallbackUrl":         {publicBackendURL() + "/api/bma/payments/toyyibpay/callback"},
			"billExternalReferenceNo": {number},
			"billTo":                  {clip(e.Auth.GetString("name"), 100)},
			"billEmail":               {e.Auth.GetString("email")},
			"billPhone":               {phone},
			"billPaymentChannel":      {"2"}, // FPX + card
			"billChargeToCustomer":    {"1"},
		}
		raw, err := toyyibPost(toyyibBase(cfg)+"/index.php/api/createBill", form)
		if err != nil {
			return e.BadRequestError("Could not reach Toyyibpay: "+err.Error(), nil)
		}
		var out []struct {
			BillCode string `json:"BillCode"`
		}
		if json.Unmarshal(raw, &out) != nil || len(out) == 0 || out[0].BillCode == "" {
			return e.BadRequestError("Toyyibpay refused the bill. Check the secret key and category code in Auction House.", nil)
		}
		inv.Set("billCode", out[0].BillCode)
		if err := e.App.Save(inv); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"url": toyyibBase(cfg) + "/" + out[0].BillCode})
	})

	// Toyyibpay calls this after a payment. The posted values are NOT trusted: the bill is looked up at Toyyibpay again.
	r.POST("/api/bma/payments/toyyibpay/callback", func(e *core.RequestEvent) error {
		if err := e.Request.ParseForm(); err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		billCode := strings.TrimSpace(e.Request.PostForm.Get("billcode"))
		if billCode == "" || e.Request.PostForm.Get("status_id") != "1" {
			return e.JSON(200, map[string]any{"ok": true}) // pending / failed: nothing to do
		}
		inv, err := e.App.FindFirstRecordByFilter("invoices", "billCode = {:b}", dbx.Params{"b": billCode})
		if err != nil {
			return e.NotFoundError("Unknown bill", nil)
		}
		if inv.GetString("status") == "PAID" {
			return e.JSON(200, map[string]any{"ok": true})
		}
		cfg := findIntegrations(e.App)
		if cfg == nil || cfg.GetString("toyyibSecret") == "" {
			return e.InternalServerError("", nil)
		}
		raw, err := toyyibPost(toyyibBase(cfg)+"/index.php/api/getBillTransactions", url.Values{"billCode": {billCode}, "billpaymentStatus": {"1"}})
		if err != nil {
			return e.InternalServerError("", err)
		}
		var txs []struct {
			Status string `json:"billpaymentStatus"`
			Ref    string `json:"billpaymentInvoiceNo"`
			Amount string `json:"billpaymentAmount"`
		}
		if json.Unmarshal(raw, &txs) != nil {
			return e.InternalServerError("", nil)
		}
		for _, t := range txs {
			if t.Status != "1" {
				continue
			}
			if paid, perr := strconv.ParseFloat(strings.TrimSpace(t.Amount), 64); perr == nil && paid+0.005 < inv.GetFloat("amount") {
				continue // paid less than the invoice
			}
			inv.Set("status", "PAID")
			inv.Set("paymentRef", clip(t.Ref, 120))
			inv.Set("paidAt", time.Now().UTC().Format("2006-01-02 15:04:05.000Z"))
			if err := e.App.Save(inv); err != nil {
				return e.InternalServerError("", err)
			}
			n := core.NewRecord(mustCol(e.App, "notifications"))
			n.Set("user", inv.GetString("user"))
			n.Set("title", "Payment received")
			n.Set("body", fmt.Sprintf("Thank you. Invoice %s is now marked as paid.", inv.GetString("number")))
			_ = e.App.Save(n)
			break
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
}
