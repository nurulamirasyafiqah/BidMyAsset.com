package main

import (
	"strings"

	"golang.org/x/net/html"
)

// sanitizeHTML keeps a small allow-list of formatting tags (for legal policies) and drops everything else:
// <script>/<style> with their content, event handlers, inline styles, and any link that is not http(s), mailto, "/" or "#".
// Output is rebuilt from tokens, never copied from the input.
var (
	htmlAllowed = map[string]bool{
		"p": true, "br": true, "hr": true, "b": true, "strong": true, "i": true, "em": true, "u": true, "small": true,
		"sub": true, "sup": true, "ul": true, "ol": true, "li": true, "h1": true, "h2": true, "h3": true, "h4": true,
		"h5": true, "h6": true, "blockquote": true, "span": true, "div": true, "a": true, "code": true, "pre": true,
		"table": true, "thead": true, "tbody": true, "tr": true, "th": true, "td": true,
	}
	htmlVoid        = map[string]bool{"br": true, "hr": true}
	htmlDropContent = map[string]bool{"script": true, "style": true, "iframe": true, "object": true, "embed": true, "noscript": true, "template": true, "textarea": true, "title": true}
)

func safeHref(v string) bool {
	v = strings.TrimSpace(v)
	l := strings.ToLower(v)
	for _, r := range v {
		if r < 0x20 || r == 0x7f {
			return false
		}
	}
	switch {
	case strings.HasPrefix(l, "https://"), strings.HasPrefix(l, "http://"), strings.HasPrefix(l, "mailto:"), strings.HasPrefix(l, "#"):
		return true
	case strings.HasPrefix(l, "/") && !strings.HasPrefix(l, "//"):
		return true
	}
	return false
}

func sanitizeHTML(in string) string {
	z := html.NewTokenizer(strings.NewReader(in))
	var b strings.Builder
	skip := 0
	for {
		tt := z.Next()
		if tt == html.ErrorToken {
			break
		}
		switch tt {
		case html.TextToken:
			if skip == 0 {
				b.WriteString(html.EscapeString(string(z.Text())))
			}
		case html.StartTagToken, html.SelfClosingTagToken:
			nameB, hasAttr := z.TagName()
			name := string(nameB)
			if htmlDropContent[name] {
				if tt == html.StartTagToken {
					skip++
				}
				continue
			}
			if skip > 0 || !htmlAllowed[name] {
				continue
			}
			b.WriteString("<" + name)
			if name == "a" && hasAttr {
				for {
					k, v, more := z.TagAttr()
					if string(k) == "href" && safeHref(string(v)) {
						b.WriteString(` href="` + html.EscapeString(strings.TrimSpace(string(v))) + `" rel="noopener noreferrer nofollow" target="_blank"`)
					}
					if !more {
						break
					}
				}
			}
			b.WriteString(">")
		case html.EndTagToken:
			nameB, _ := z.TagName()
			name := string(nameB)
			if htmlDropContent[name] {
				if skip > 0 {
					skip--
				}
				continue
			}
			if skip == 0 && htmlAllowed[name] && !htmlVoid[name] {
				b.WriteString("</" + name + ">")
			}
		}
	}
	return b.String()
}
