package main

import (
	"fmt"
	"math/rand"
	"time"

	"github.com/pocketbase/pocketbase/core"
)

// Seed data = the former mock data in the frontend (src/lib/data.ts),
// so the site looks the same on first run. Dates are relative to first start.

type seedAuction struct {
	slug, title, city, region, tz, cur, cat, sub string
	seq, tone, imgs                              int
	lat, lng                                     float64
	startDays, startHour, endDays, endHour       int
	offset                                       int // hours east of UTC for the wall-clock hours above
}

func at(days, hour, offset int) time.Time {
	now := time.Now().UTC().Add(time.Duration(offset) * time.Hour)
	d := time.Date(now.Year(), now.Month(), now.Day()+days, hour, 0, 0, 0, time.UTC)
	return d.Add(-time.Duration(offset) * time.Hour)
}

func seedIfEmpty(app core.App) error {
	n, err := app.CountRecords("auctions")
	if err != nil || n > 0 {
		return err
	}
	const (
		KL  = "Asia/Kuala_Lumpur"
		BKK = "Asia/Bangkok"
		PM  = "Plant & Machinery"
		HE  = "Heavy Equipment"
	)
	list := []seedAuction{
		{"industrial-textile-production-machinery", "Industrial Textile Production Machinery", "Matang", "Perak", KL, "MYR", PM, "Textile Machinery", 1012, 0, 1, 4.83, 100.65, 8, 20, 38, 12, 8},
		{"forestry-heavy-machinery", "Forestry Heavy Machinery", "Miri", "Sarawak", KL, "MYR", HE, "Excavators", 1007, 1, 1, 4.3995, 113.9914, -36, 9, 39, 12, 8},
		{"portal-crane-dual-rail-system", "Portal Crane (Dual Rail System)", "Yannawa", "Bangkok", BKK, "THB", HE, "Cranes", 1015, 2, 4, 13.69, 100.54, -3, 9, 12, 12, 7},
		{"taihei-roller-jet-dryer-5000", "Taihei Roller Jet Dryer 5000", "Bukit Mertajam", "Penang", KL, "MYR", PM, "General Machinery", 1011, 3, 1, 5.36, 100.46, 8, 20, 38, 12, 8},
		{"yacht", "YACHT", "Kota Kinabalu", "Sabah", KL, "MYR", "Marine", "Yachts", 1004, 4, 1, 5.98, 116.07, -37, 9, 8, 20, 8},
		{"plastic-crusher-machine", "Plastic Crusher Machine", "Yannawa", "Bangkok", BKK, "THB", PM, "General Machinery", 1016, 5, 5, 13.69, 100.54, -3, 9, 12, 12, 7},
		{"big-slitter-sg-machine-no-2", "Big Slitter SG Machine No.2 – Full Set Slitting Line, Year 2002", "Yannawa", "Bangkok", BKK, "THB", PM, "General Machinery", 1017, 6, 5, 13.69, 100.54, -3, 9, 12, 12, 7},
		{"dry-ice-cleaner", "Dry Ice Cleaner", "Yannawa", "Bangkok", BKK, "THB", PM, "General Machinery", 1018, 7, 5, 13.69, 100.54, -3, 9, 12, 12, 7},
		// archive (already closed)
		{"steel-metal-machine", "Steel & Metal Machine", "Puchong", "Selangor", KL, "MYR", PM, "General Machinery", 1010, 0, 1, 0, 0, -100, 9, -70, 12, 8},
		{"aeroplane-for-sale", "Aeroplane for Sale", "Senai", "Johor", KL, "MYR", PM, "General Machinery", 1009, 1, 1, 0, 0, -100, 9, -85, 12, 8},
		{"synthetic-rubber-chemical-tank-accessories", "Synthetic Rubber Chemical Tank & Accessories", "Pasir Gudang", "Johor", KL, "MYR", PM, "General Machinery", 1008, 2, 1, 0, 0, -100, 9, -40, 12, 8},
		{"cnc-milling-drilling-machine", "CNC milling drilling machine", "Yan Nawa", "Bangkok", BKK, "THB", PM, "General Machinery", 1006, 3, 2, 0, 0, -120, 9, -90, 12, 7},
	}
	aCol := mustCol(app, "auctions")
	ids := map[string]string{}
	for _, s := range list {
		r := core.NewRecord(aCol)
		r.Set("slug", s.slug)
		r.Set("sequence", s.seq)
		r.Set("title", s.title)
		r.Set("startsAt", at(s.startDays, s.startHour, s.offset))
		r.Set("endsAt", at(s.endDays, s.endHour, s.offset))
		r.Set("timezone", s.tz)
		r.Set("currency", s.cur)
		r.Set("city", s.city)
		r.Set("region", s.region)
		r.Set("lat", s.lat)
		r.Set("lng", s.lng)
		r.Set("imageCount", s.imgs)
		r.Set("tone", s.tone)
		r.Set("category", s.cat)
		r.Set("subcategory", s.sub)
		r.Set("published", true)
		if err := app.Save(r); err != nil {
			return fmt.Errorf("seed auction %s: %w", s.slug, err)
		}
		ids[s.slug] = r.Id
	}

	lCol := mustCol(app, "lots")
	counts := map[string]int{}
	addLot := func(slug string, num int, title, desc, cat, sub, sku string, start, inc float64, order int) error {
		l := core.NewRecord(lCol)
		l.Set("auction", ids[slug])
		l.Set("lotNumber", num)
		l.Set("title", title)
		l.Set("description", desc)
		l.Set("category", cat)
		l.Set("subcategory", sub)
		l.Set("sku", sku)
		l.Set("quantity", 1)
		l.Set("startingBid", start)
		l.Set("increment", inc)
		l.Set("addedOrder", order)
		counts[slug]++
		return app.Save(l)
	}

	// Forestry: shuffled lot numbers like the mock.
	mix := []struct {
		cat, sub string
		count    int
		models   []string
	}{
		{HE, "Dozers", 38, []string{"CAT D6DLS", "KOM D155A-2", "CAT 527"}},
		{HE, "Excavators", 19, []string{"CAT 320C", "CAT 330C", "KOM PC200-8"}},
		{HE, "Motor Graders", 4, []string{"CAT 140H"}},
		{HE, "Wheel Loaders", 11, []string{"CAT 966G-II", "KOM WA380"}},
		{"Trucks", "Dump Trucks", 7, []string{"Hino 700 Dump", "Isuzu FVZ Dump"}},
		{"Trucks", "Service Trucks", 1, []string{"Isuzu NPR Service"}},
		{"Trucks", "Utility Trucks", 20, []string{"Mitsubishi Canter", "Toyota Hilux 4x4"}},
	}
	rng := rand.New(rand.NewSource(1007))
	nums := rng.Perm(230)
	k := 0
	for _, g := range mix {
		for i := 0; i < g.count; i++ {
			model := g.models[rng.Intn(len(g.models))]
			serial := 1000 + rng.Intn(8999)
			if err := addLot("forestry-heavy-machinery", nums[k]+1, fmt.Sprintf("%s#%d", model, serial), "", g.cat, g.sub, fmt.Sprint(serial), 30000, 500, k); err != nil {
				return err
			}
			k++
		}
	}
	if err := addLot("taihei-roller-jet-dryer-5000", 1,
		"Taihei S56-AC 6-Deck Roller Jet Veneer Dryer (5000mm Width x 10S + C2)",
		"An excellent opportunity to acquire a high-capacity, Japanese-engineered Taihei S56-AC Roller Jet Veneer Dryer line. Originally designed for Ta Ann Plywood Sdn. Bhd., this massive industrial dryer is built for continuous, high-volume veneer sheet drying. Known for exceptional mechanical longevity and precise flat-sheet processing.",
		PM, "Whole Manufacturing Plant", "S56-AC (5000 × 6D × 10S × C2)", 10000, 500, 0); err != nil {
		return err
	}
	small := map[string]int{"industrial-textile-production-machinery": 2, "yacht": 1, "steel-metal-machine": 4, "aeroplane-for-sale": 2, "synthetic-rubber-chemical-tank-accessories": 1}
	for _, s := range list {
		c, ok := small[s.slug]
		if !ok {
			continue
		}
		for i := 1; i <= c; i++ {
			title := s.title
			if c > 1 {
				title = fmt.Sprintf("%s — Lot %d", s.title, i)
			}
			if err := addLot(s.slug, i, title, "", s.cat, s.sub, fmt.Sprintf("%d-%d", s.seq, i), 10000, 500, i-1); err != nil {
				return err
			}
		}
	}
	// denormalised lot counts
	for slug, c := range counts {
		a, err := app.FindRecordById("auctions", ids[slug])
		if err != nil {
			return err
		}
		a.Set("lotCount", c)
		if err := app.Save(a); err != nil {
			return err
		}
	}
	app.Logger().Info("seeded demo auctions and lots")
	return nil
}
