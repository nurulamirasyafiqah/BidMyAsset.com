package main

import (
	"fmt"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/apis"
	"github.com/pocketbase/pocketbase/core"
)

// Auction Studio → Bid History and Questions & Review.
// Admin routes need X-BMA-Admin-Key (Next checks the caller is an admin first); the bidder route needs a logged-in user.

func personOf(app core.App, cache map[string]*core.Record, id string) (name, email string) {
	if id == "" {
		return "—", ""
	}
	u, ok := cache[id]
	if !ok {
		u, _ = app.FindRecordById("users", id)
		cache[id] = u
	}
	if u == nil {
		return "Deleted user", ""
	}
	email = u.GetString("email")
	name = strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
	if name == "" {
		name = email
	}
	return name, email
}

func lotOf(app core.App, cache map[string]*core.Record, id string) (no int, title string) {
	l, ok := cache[id]
	if !ok {
		l, _ = app.FindRecordById("lots", id)
		cache[id] = l
	}
	if l == nil {
		return 0, "Deleted lot"
	}
	return l.GetInt("lotNumber"), l.GetString("title")
}

func registerStudioActivityRoutes(se *core.ServeEvent) {
	r := se.Router

	// Every bid placed in one auction, newest first (capped at 2000 rows).
	r.GET("/api/bma/admin/studio-bids", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		id := e.Request.URL.Query().Get("auction")
		if id == "" {
			return e.BadRequestError("auction is required", nil)
		}
		bids, err := e.App.FindRecordsByFilter("bids", "auction = {:a}", "-created", 2000, 0, dbx.Params{"a": id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		users, lots := map[string]*core.Record{}, map[string]*core.Record{}
		items := []map[string]any{}
		for _, b := range bids {
			name, email := personOf(e.App, users, b.GetString("bidder"))
			no, title := lotOf(e.App, lots, b.GetString("lot"))
			items = append(items, map[string]any{
				"id": b.Id, "lot": b.GetString("lot"), "lotNo": no, "lotTitle": title, "bidder": name, "email": email,
				"amount": b.GetFloat("amount"), "state": b.GetString("state"), "at": isoTime(b, "created"), "auto": b.GetBool("auto"),
			})
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	// Maximum (proxy / absentee) bids stored for the lots of one auction, newest first.
	r.GET("/api/bma/admin/studio-max-bids", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		id := e.Request.URL.Query().Get("auction")
		if id == "" {
			return e.BadRequestError("auction is required", nil)
		}
		rows, err := e.App.FindRecordsByFilter("max_bids", "auction = {:a}", "-created", 2000, 0, dbx.Params{"a": id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		users, lots := map[string]*core.Record{}, map[string]*core.Record{}
		items := []map[string]any{}
		for _, m := range rows {
			name, email := personOf(e.App, users, m.GetString("bidder"))
			no, title := lotOf(e.App, lots, m.GetString("lot"))
			items = append(items, map[string]any{
				"id": m.Id, "lot": m.GetString("lot"), "lotNo": no, "lotTitle": title, "bidder": name, "email": email,
				"amount": m.GetFloat("amount"), "at": isoTime(m, "created"),
			})
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	// Questions asked about the lots of one auction, newest first.
	r.GET("/api/bma/admin/studio-questions", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		id := e.Request.URL.Query().Get("auction")
		if id == "" {
			return e.BadRequestError("auction is required", nil)
		}
		qs, err := e.App.FindRecordsByFilter("lot_questions", "auction = {:a}", "-created", 1000, 0, dbx.Params{"a": id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		users, lots := map[string]*core.Record{}, map[string]*core.Record{}
		items := []map[string]any{}
		for _, q := range qs {
			name, email := personOf(e.App, users, q.GetString("user"))
			no, title := lotOf(e.App, lots, q.GetString("lot"))
			items = append(items, map[string]any{
				"id": q.Id, "lotNo": no, "lotTitle": title, "asker": name, "email": email, "question": q.GetString("question"),
				"answer": q.GetString("answer"), "status": q.GetString("status"), "at": isoTime(q, "created"),
			})
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	// Answer / publish / hide a question. A question can only be published once it has an answer.
	r.POST("/api/bma/admin/question-review", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID     string `json:"id"`
			Answer string `json:"answer"`
			Status string `json:"status"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		if in.Status != "PENDING" && in.Status != "PUBLISHED" && in.Status != "HIDDEN" {
			return e.BadRequestError("Unknown status", nil)
		}
		answer := strings.TrimSpace(in.Answer)
		if in.Status == "PUBLISHED" && answer == "" {
			return e.BadRequestError("Write an answer before publishing", nil)
		}
		if utf8.RuneCountInString(answer) > 4000 {
			return e.BadRequestError("Answer is too long (4000 characters max)", nil)
		}
		q, err := e.App.FindRecordById("lot_questions", in.ID)
		if err != nil {
			return e.NotFoundError("Question not found", nil)
		}
		if answer != q.GetString("answer") {
			q.Set("answeredAt", time.Now().UTC())
		}
		q.Set("answer", answer)
		q.Set("status", in.Status)
		if err := e.App.Save(q); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true, "status": in.Status})
	})

	// Bidder registrations for one auction (the real `registrations` collection), newest first.
	r.GET("/api/bma/admin/studio-registrations", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		id := e.Request.URL.Query().Get("auction")
		if id == "" {
			return e.BadRequestError("auction is required", nil)
		}
		regs, err := e.App.FindRecordsByFilter("registrations", "auction = {:a}", "-created", 2000, 0, dbx.Params{"a": id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		users := map[string]*core.Record{}
		items := []map[string]any{}
		for _, g := range regs {
			name, email := personOf(e.App, users, g.GetString("user"))
			phone := ""
			if u := users[g.GetString("user")]; u != nil {
				phone = u.GetString("phone")
			}
			items = append(items, map[string]any{
				"id": g.Id, "status": g.GetString("status"), "name": name, "email": email, "phone": phone,
				"at": isoTime(g, "created"), "answers": g.Get("answers"),
			})
		}
		qs := []map[string]any{}
		if au, err := e.App.FindRecordById("auctions", id); err == nil {
			for _, q := range auctionQuestions(au) {
				qs = append(qs, map[string]any{"id": q.ID, "text": q.Text})
			}
		}
		return e.JSON(200, map[string]any{"items": items, "questions": qs})
	})

	// Approve / reject (or put back to pending) one registration. This is what lets a bidder bid: place-bid only accepts APPROVED.
	// Rejecting an approved bidder does not remove bids already placed; the response says how many are still leading.
	r.POST("/api/bma/admin/registration-review", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID     string `json:"id"`
			Status string `json:"status"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		if in.Status != "PENDING" && in.Status != "APPROVED" && in.Status != "REJECTED" {
			return e.BadRequestError("Unknown status", nil)
		}
		g, err := e.App.FindRecordById("registrations", in.ID)
		if err != nil {
			return e.NotFoundError("Registration not found", nil)
		}
		prev := g.GetString("status")
		if prev == in.Status {
			return e.JSON(200, map[string]any{"ok": true, "status": in.Status, "leadingBids": 0})
		}
		g.Set("status", in.Status)
		if err := e.App.Save(g); err != nil {
			return e.InternalServerError("", err)
		}
		userID, auctionID := g.GetString("user"), g.GetString("auction")
		title := "this auction"
		if a, err := e.App.FindRecordById("auctions", auctionID); err == nil {
			title = a.GetString("title")
		}
		// tell the bidder (best effort, and only if they have notifications on)
		if in.Status != "PENDING" {
			if u, err := e.App.FindRecordById("users", userID); err == nil && !u.GetBool("notificationsOff") {
				n := core.NewRecord(mustCol(e.App, "notifications"))
				n.Set("user", userID)
				if in.Status == "APPROVED" {
					n.Set("title", "Registration approved")
					n.Set("body", fmt.Sprintf("You can now bid in %s.", title))
				} else {
					n.Set("title", "Registration not approved")
					n.Set("body", fmt.Sprintf("Your registration for %s was not approved.", title))
				}
				_ = e.App.Save(n)
			}
		}
		leading := 0
		if prev == "APPROVED" {
			n, _ := e.App.CountRecords("bids", dbx.NewExp("auction = {:a} AND bidder = {:u} AND state = 'LEADING'", dbx.Params{"a": auctionID, "u": userID}))
			leading = int(n)
		}
		return e.JSON(200, map[string]any{"ok": true, "status": in.Status, "leadingBids": leading})
	})

	// A bidder asks a question about a lot of a published auction; it stays hidden until staff publish an answer.
	au := r.Group("/api/bma")
	au.Bind(apis.RequireAuth("users"))
	au.POST("/questions", func(e *core.RequestEvent) error {
		var in struct {
			Lot      string `json:"lot"` // lot record id
			Question string `json:"question"`
		}
		if err := e.BindBody(&in); err != nil || in.Lot == "" {
			return e.BadRequestError("lot and question are required", nil)
		}
		text := strings.TrimSpace(in.Question)
		if n := utf8.RuneCountInString(text); n < 5 || n > 1000 {
			return e.BadRequestError("Questions must be between 5 and 1000 characters", nil)
		}
		lot, err := e.App.FindRecordById("lots", in.Lot)
		if err != nil || lot.GetBool("draft") {
			return e.NotFoundError("Lot not found", nil)
		}
		a, err := e.App.FindRecordById("auctions", lot.GetString("auction"))
		if err != nil || !a.GetBool("published") {
			return e.NotFoundError("Lot not found", nil)
		}
		if n, _ := e.App.CountRecords("lot_questions", dbx.NewExp("user = {:u} AND status = 'PENDING'", dbx.Params{"u": e.Auth.Id})); n >= 10 {
			return e.BadRequestError("You have several questions waiting for an answer already. Please wait for a reply.", nil)
		}
		rec := core.NewRecord(mustCol(e.App, "lot_questions"))
		rec.Set("auction", a.Id)
		rec.Set("lot", lot.Id)
		rec.Set("user", e.Auth.Id)
		rec.Set("question", text)
		rec.Set("status", "PENDING")
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
}
