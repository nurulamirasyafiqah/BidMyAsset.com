package main

import (
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
)

// Bidder ranking and bidder history on a lot (Auction Builder → Auction Info).
//
//	GET /api/bma/lots/{id}/bids      public (the session, when there is one, only marks "mine")
//
// Saved by Auction Info in builder.info:
//
//	ranking  "Show top 10 bidders" | "Show top 3 bidders" | "Show all bidders" | "Hide ranking"   (default: top 10)
//	history  "Always" | "After close" | "Never"                                                    (default: Always)
//
// The bids collection is private to each bidder (API rules), so everybody else only ever sees what this endpoint
// returns: amounts and times, with bidders as "Bidder 1, 2, …" numbered by who bid first on the lot. When the auction
// has "hide bidder names" (auctions.hideBidders) off, a bidder is shown as first name + last initial instead.
// The signed-in bidder always sees "You" on their own rows.

const (
	rankTop10 = "Show top 10 bidders"
	rankTop3  = "Show top 3 bidders"
	rankAll   = "Show all bidders"
	rankHide  = "Hide ranking"

	histAlways = "Always"
	histAfter  = "After close"
	histNever  = "Never"
)

// rankingLimit: how many ranked rows are shown (0 = ranking hidden, -1 = everyone).
func rankingLimit(setting string) int {
	switch setting {
	case rankHide:
		return 0
	case rankTop3:
		return 3
	case rankAll:
		return -1
	default:
		return 10
	}
}

func historyVisible(setting string, closed bool) bool {
	switch setting {
	case histNever:
		return false
	case histAfter:
		return closed
	default:
		return true
	}
}

// bidderLabel is what other people see for a bidder.
func bidderLabel(u *core.Record, n int, named bool) string {
	if named && u != nil {
		first := strings.TrimSpace(u.GetString("firstName"))
		last := []rune(strings.TrimSpace(u.GetString("lastName")))
		switch {
		case first != "" && len(last) > 0:
			return first + " " + string(last[0]) + "."
		case first != "":
			return first
		}
	}
	return "Bidder " + strconv.Itoa(n)
}

func registerBidActivityRoute(se *core.ServeEvent) {
	se.Router.GET("/api/bma/lots/{id}/bids", func(e *core.RequestEvent) error {
		lot, err := e.App.FindRecordById("lots", e.Request.PathValue("id"))
		if err != nil || lot.GetBool("draft") {
			return e.NotFoundError("Lot not found", nil)
		}
		auction, err := e.App.FindRecordById("auctions", lot.GetString("auction"))
		if err != nil || !auction.GetBool("published") {
			return e.NotFoundError("Lot not found", nil)
		}
		info, _ := builderOf(auction)["info"].(map[string]any)
		rankSetting, _ := info["ranking"].(string)
		histSetting, _ := info["history"].(string)

		lotEnd := auction.GetDateTime("endsAt").Time()
		if le := lot.GetDateTime("endsAt"); !le.IsZero() && le.Time().Before(lotEnd) {
			lotEnd = le.Time()
		}
		closed := !time.Now().Before(lotEnd)
		limit := rankingLimit(rankSetting)
		showHistory := historyVisible(histSetting, closed)

		out := map[string]any{
			"ranking": []map[string]any{}, "history": []map[string]any{},
			"rankingShown": limit != 0, "historyShown": showHistory,
			"historyNote": "", "totalBids": lot.GetInt("bidCount"),
		}
		if !showHistory {
			if histSetting == histAfter {
				out["historyNote"] = "The bid history is shown after bidding closes."
			} else {
				out["historyNote"] = "The bid history is not shown for this auction."
			}
		}
		if limit == 0 && !showHistory {
			return e.JSON(200, out)
		}

		bids, err := e.App.FindRecordsByFilter("bids", "lot = {:l}", "created", 0, 0, dbx.Params{"l": lot.Id})
		if err != nil {
			return e.InternalServerError("", err)
		}
		mine := ""
		if e.Auth != nil {
			mine = e.Auth.Id
		}
		named := !auction.GetBool("hideBidders")
		number := map[string]int{} // bidder id → 1, 2, 3 … in order of first bid
		users := map[string]*core.Record{}
		who := func(id string) string {
			if id == mine && id != "" {
				return "You"
			}
			if _, ok := number[id]; !ok {
				number[id] = len(number) + 1
			}
			if named {
				if _, ok := users[id]; !ok {
					u, _ := e.App.FindRecordById("users", id)
					users[id] = u
				}
			}
			return bidderLabel(users[id], number[id], named)
		}
		type row struct {
			bidder string
			uid    string
			amount float64
			at     time.Time
		}
		rows := make([]row, 0, len(bids))
		best := map[string]row{}
		for _, b := range bids { // oldest first, so Bidder numbers follow who bid first
			uid := b.GetString("bidder")
			r := row{bidder: who(uid), uid: uid, amount: b.GetFloat("amount"), at: b.GetDateTime("created").Time()}
			rows = append(rows, r)
			if cur, ok := best[uid]; !ok || r.amount > cur.amount {
				best[uid] = r
			}
		}

		if limit != 0 {
			ranked := make([]row, 0, len(best))
			for _, r := range best {
				ranked = append(ranked, r)
			}
			sort.Slice(ranked, func(i, j int) bool {
				if ranked[i].amount != ranked[j].amount {
					return ranked[i].amount > ranked[j].amount
				}
				return ranked[i].at.Before(ranked[j].at) // the earlier bid wins a tie
			})
			if limit > 0 && len(ranked) > limit {
				ranked = ranked[:limit]
			}
			list := make([]map[string]any, 0, len(ranked))
			for i, r := range ranked {
				list = append(list, map[string]any{"rank": i + 1, "bidder": r.bidder, "amount": r.amount, "mine": r.uid == mine && mine != ""})
			}
			out["ranking"] = list
		}
		if showHistory {
			list := make([]map[string]any, 0, len(rows))
			for i := len(rows) - 1; i >= 0; i-- { // newest first
				r := rows[i]
				list = append(list, map[string]any{"bidder": r.bidder, "amount": r.amount, "at": r.at.UTC().Format(time.RFC3339), "mine": r.uid == mine && mine != ""})
			}
			if len(list) > 200 {
				list = list[:200]
			}
			out["history"] = list
		}
		return e.JSON(200, out)
	})
}
