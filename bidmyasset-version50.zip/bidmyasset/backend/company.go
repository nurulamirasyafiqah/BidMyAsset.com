package main

import (
	"encoding/json"
	"errors"
	"io"
	"regexp"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/pocketbase/pocketbase/core"
)

// Admin → Company, saved on the single `company` record (migrations/11_company.go).
//
//	GET /api/bma/admin/company   → {company, consignors, banks, taxes, contacts, bidSettings, locations, questionnaires, commission}
//	PUT /api/bma/admin/company   {<section>: value | null, ...} → same document
//
// Policies are not here: Company → Policies and Auction House → Legal Policies share `house.legal`.
// Auctioneer commission is its own section here (`commission`); the internet buying fee is `house.fee` (Auction House).
// commission = {kind, ...numbers} validated by sanitizeFee; invoices charge it next to the internet buying fee.
// bidSettings = {v:{start,reserve,estStart,estEnd,strategy,method,inc}, matrix:[{from,increment}]} is read by bidding.go.

var companySections = map[string]string{
	"company": "object", "consignors": "array", "banks": "array", "taxes": "object",
	"contacts": "array", "bidSettings": "object", "locations": "array", "questionnaires": "array", "emailTemplates": "object",
	"commission": "object", // auctioneer commission: same structures as the internet buying fee, applied to invoices (bidding.go)
}

var nonDigit = regexp.MustCompile(`\D`)

func cleanCompanySection(key string, v any) (any, string) {
	if v == nil {
		return nil, ""
	}
	switch companySections[key] {
	case "array":
		if _, ok := v.([]any); !ok {
			return nil, key + ": expected a list."
		}
	case "object":
		if _, ok := v.(map[string]any); !ok {
			return nil, key + ": unexpected format."
		}
	}
	if key == "commission" {
		clean, msg := sanitizeFee(v)
		if msg != "" {
			return nil, "commission: " + strings.TrimPrefix(msg, "fee.")
		}
		return clean, ""
	}
	if key == "consignors" {
		return sanitizeConsignors(v.([]any))
	}
	if key == "banks" { // never keep more than the last 4 digits of an account number
		out := []any{}
		for _, it := range v.([]any) {
			b, ok := it.(map[string]any)
			if !ok {
				return nil, "banks: unexpected format."
			}
			name, _ := b["name"].(string)
			id, _ := b["id"].(string)
			last4, _ := b["last4"].(string)
			last4 = nonDigit.ReplaceAllString(last4, "")
			if len(last4) > 4 {
				last4 = last4[len(last4)-4:]
			}
			def, _ := b["isDefault"].(bool)
			out = append(out, map[string]any{"id": id, "name": strings.TrimSpace(name), "last4": last4, "isDefault": def})
		}
		return out, ""
	}
	if key == "emailTemplates" { // {<template key>: {subject, body, enabled}}: plain text subject, sanitized HTML body
		out := map[string]any{}
		for k, it := range v.(map[string]any) {
			t, ok := it.(map[string]any)
			if !ok || len(k) > 80 {
				return nil, "emailTemplates: unexpected format."
			}
			subject, _ := t["subject"].(string)
			body, _ := t["body"].(string)
			enabled, _ := t["enabled"].(bool)
			if len(subject) > 300 || len(body) > 100000 {
				return nil, "emailTemplates: subject or body is too long."
			}
			out[k] = map[string]any{"subject": strings.TrimSpace(subject), "body": sanitizeHTML(body), "enabled": enabled}
		}
		return out, ""
	}
	return v, ""
}

// sanitizeConsignors keeps only the fields the app uses (status is computed on read) and rejects bad rows,
// so a hand-made request can't store duplicates, bad emails or out-of-range commission rates.
func sanitizeConsignors(list []any) (any, string) {
	if len(list) > 5000 {
		return nil, "consignors: too many entries."
	}
	out := make([]any, 0, len(list))
	seen := map[string]bool{}
	for _, it := range list {
		c, ok := it.(map[string]any)
		if !ok {
			return nil, "consignors: unexpected format."
		}
		first, last, email := str(c["first"]), str(c["last"]), str(c["email"])
		if first == "" || last == "" {
			return nil, "consignors: first and last name are required."
		}
		if !validEmail(email) {
			return nil, "consignors: " + email + " is not a valid email address."
		}
		key := strings.ToLower(email)
		if seen[key] {
			return nil, "consignors: " + email + " is listed twice."
		}
		seen[key] = true
		commission := str(c["commission"])
		if commission != "" {
			if n, err := strconv.ParseFloat(commission, 64); err != nil || n < 0 || n > 100 {
				return nil, "consignors: commission must be a number between 0 and 100."
			}
		}
		row := map[string]any{"id": str(c["id"]), "first": first, "last": last, "email": email, "commission": commission, "registered": str(c["registered"])}
		if off, _ := c["disabled"].(bool); off {
			row["disabled"] = true
		}
		if at := str(c["invitedAt"]); at != "" {
			row["invitedAt"] = at
		}
		out = append(out, row)
	}
	return out, ""
}

// companyDoc returns every section as decoded JSON (nil/empty when never saved).
// Consignor status is computed: Onboarded once someone registered with that email, otherwise Invited.
func companyDoc(app core.App, rec *core.Record) map[string]any {
	out := map[string]any{}
	for k := range companySections {
		out[k] = nil
		if rec == nil {
			continue
		}
		if v, ok := decodeSection(rec.GetRaw(k)); ok {
			out[k] = v
		}
	}
	if list, ok := out["consignors"].([]any); ok {
		for _, it := range list {
			c, ok := it.(map[string]any)
			if !ok {
				continue
			}
			email, _ := c["email"].(string)
			if u, err := app.FindAuthRecordByEmail("users", strings.ToLower(strings.TrimSpace(email))); err == nil && u != nil {
				c["status"] = "Onboarded"
				c["registered"] = u.GetDateTime("created").Time().UTC().Format("01/02/2006") // real sign-up date (MM/DD/YYYY, like the add date)
			} else {
				c["status"] = "Invited"
			}
		}
	}
	return out
}

func registerCompanyRoutes(se *core.ServeEvent) {
	r := se.Router

	// Public: the questions shown on the "Register to Bid" form (the active template of Company → Questionnaire).
	r.GET("/api/bma/questionnaire", func(e *core.RequestEvent) error {
		name, qs := activeQuestionnaire(e.App)
		out := []map[string]any{}
		for _, q := range qs {
			opts := q.Options
			if opts == nil {
				opts = []string{}
			}
			out = append(out, map[string]any{"id": q.ID, "text": q.Text, "type": q.Type, "required": q.Required, "options": opts})
		}
		return e.JSON(200, map[string]any{"name": name, "questions": out})
	})

	// Public: company name, contacts and locations (Company → Contacts / Locations) for the website's contact section.
	r.GET("/api/bma/company-public", func(e *core.RequestEvent) error {
		doc := companyDoc(e.App, findCompany(e.App))
		str := func(m map[string]any, k string) string { s, _ := m[k].(string); return strings.TrimSpace(s) }
		name := ""
		if m, ok := doc["company"].(map[string]any); ok {
			name = str(m, "name")
		}
		contacts, locations := []map[string]any{}, []map[string]any{}
		if list, ok := doc["contacts"].([]any); ok {
			for _, it := range list {
				if m, ok := it.(map[string]any); ok && str(m, "name") != "" {
					contacts = append(contacts, map[string]any{"name": str(m, "name"), "email": str(m, "email"), "iso": str(m, "iso"), "phone": str(m, "phone")})
				}
			}
		}
		if list, ok := doc["locations"].([]any); ok {
			for _, it := range list {
				if m, ok := it.(map[string]any); ok && str(m, "name") != "" {
					addr := str(m, "formatted")
					if addr == "" {
						parts := []string{}
						for _, k := range []string{"line1", "line2", "city", "state"} {
							if v := str(m, k); v != "" {
								parts = append(parts, v)
							}
						}
						if pc := strings.TrimSpace(str(m, "postal") + " " + str(m, "country")); pc != "" {
							parts = append(parts, pc)
						}
						addr = strings.Join(parts, ", ")
					}
					locations = append(locations, map[string]any{"name": str(m, "name"), "address": addr, "phone": str(m, "phone")})
				}
			}
		}
		return e.JSON(200, map[string]any{"name": name, "contacts": contacts, "locations": locations})
	})

	r.GET("/api/bma/admin/company", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		return e.JSON(200, companyDoc(e.App, findCompany(e.App)))
	})

	r.PUT("/api/bma/admin/company", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		body, err := io.ReadAll(io.LimitReader(e.Request.Body, 3<<20))
		if err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		var in map[string]json.RawMessage
		if err := json.Unmarshal(body, &in); err != nil || len(in) == 0 {
			return e.BadRequestError("Invalid request", nil)
		}
		rec := findCompany(e.App)
		if rec == nil {
			rec = core.NewRecord(mustCol(e.App, "company"))
		}
		oldConsignors := consignorList(rec.GetRaw("consignors"))
		var newConsignors []any
		consignorsChanged := false
		for key, raw := range in {
			if _, ok := companySections[key]; !ok {
				return e.BadRequestError("Unknown section: "+key, nil)
			}
			var v any
			if err := json.Unmarshal(raw, &v); err != nil {
				return e.BadRequestError(key+": unexpected format.", nil)
			}
			clean, msg := cleanCompanySection(key, v)
			if msg != "" {
				return e.BadRequestError(msg, nil)
			}
			setSection(rec, key, clean)
			if key == "consignors" {
				consignorsChanged = true
				newConsignors, _ = clean.([]any)
			}
		}
		// Saving the consignor list also applies each account's disabled switch to the registered user, all or nothing.
		if err := e.App.RunInTransaction(func(tx core.App) error {
			if consignorsChanged {
				if err := syncConsignorAccess(tx, oldConsignors, newConsignors); err != nil {
					return err
				}
			}
			return tx.Save(rec)
		}); err != nil {
			var ae accessError
			if errors.As(err, &ae) {
				return e.BadRequestError(string(ae), nil)
			}
			return e.BadRequestError("Could not save.", err)
		}
		return e.JSON(200, companyDoc(e.App, rec))
	})
}

// ---------- Taxes ----------

// companyTaxRate is Company → Taxes: federal + state percentage. 0 when nothing is configured.
func companyTaxRate(app core.App) float64 {
	rec := findCompany(app)
	if rec == nil {
		return 0
	}
	raw, ok := decodeSection(rec.GetRaw("taxes"))
	if !ok {
		return 0
	}
	m, _ := raw.(map[string]any)
	pct := func(k string) float64 {
		var n float64
		switch v := m[k].(type) {
		case float64:
			n = v
		case string:
			n, _ = strconv.ParseFloat(strings.TrimSpace(v), 64)
		}
		if n < 0 || n > 100 {
			return 0
		}
		return n
	}
	return pct("federal") + pct("state")
}

// ---------- Questionnaire ----------

type question struct {
	ID       string
	Text     string
	Type     string // short | long | yesno | single | multi
	Required bool
	Options  []string
}

// activeQuestionnaire returns the template marked "Active" in Company → Questionnaire (name + its questions).
func activeQuestionnaire(app core.App) (string, []question) {
	rec := findCompany(app)
	if rec == nil {
		return "", nil
	}
	raw, ok := decodeSection(rec.GetRaw("questionnaires"))
	if !ok {
		return "", nil
	}
	list, _ := raw.([]any)
	for _, it := range list {
		t, _ := it.(map[string]any)
		if t == nil {
			continue
		}
		if act, _ := t["active"].(bool); !act {
			continue
		}
		name, _ := t["name"].(string)
		qs := []question{}
		items, _ := t["questions"].([]any)
		for _, qi := range items {
			m, _ := qi.(map[string]any)
			if m == nil {
				continue
			}
			q := question{}
			q.ID, _ = m["id"].(string)
			q.Text, _ = m["text"].(string)
			q.Type, _ = m["type"].(string)
			q.Required, _ = m["required"].(bool)
			if opts, ok := m["options"].([]any); ok {
				for _, o := range opts {
					if s, ok := o.(string); ok && strings.TrimSpace(s) != "" {
						q.Options = append(q.Options, s)
					}
				}
			}
			if q.ID == "" || strings.TrimSpace(q.Text) == "" {
				continue
			}
			qs = append(qs, q)
		}
		return name, qs
	}
	return "", nil
}

// validateAnswers checks a bidder's answers against the active questions and returns what is stored on the registration.
func validateAnswers(qs []question, in map[string]any) ([]map[string]any, string) {
	out := []map[string]any{}
	for _, q := range qs {
		v := in[q.ID]
		var answer any
		empty := true
		switch q.Type {
		case "multi":
			picked := []string{}
			if list, ok := v.([]any); ok {
				for _, x := range list {
					s, _ := x.(string)
					if !contains(q.Options, s) {
						return nil, "“" + q.Text + "”: choose from the listed options."
					}
					if !contains(picked, s) {
						picked = append(picked, s)
					}
				}
			}
			empty, answer = len(picked) == 0, picked
		default:
			s, _ := v.(string)
			s = strings.TrimSpace(s)
			if s != "" {
				switch q.Type {
				case "yesno":
					if s != "Yes" && s != "No" {
						return nil, "“" + q.Text + "”: answer Yes or No."
					}
				case "single":
					if !contains(q.Options, s) {
						return nil, "“" + q.Text + "”: choose from the listed options."
					}
				default:
					if utf8.RuneCountInString(s) > 2000 {
						return nil, "“" + q.Text + "”: at most 2,000 characters."
					}
				}
			}
			empty, answer = s == "", s
		}
		if empty {
			if q.Required {
				return nil, "Please answer: " + q.Text
			}
			continue
		}
		out = append(out, map[string]any{"id": q.ID, "question": q.Text, "answer": answer})
	}
	return out, ""
}

func contains(list []string, s string) bool {
	for _, x := range list {
		if x == s {
			return true
		}
	}
	return false
}
