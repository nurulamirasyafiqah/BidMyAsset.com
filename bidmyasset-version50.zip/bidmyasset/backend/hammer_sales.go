package main

import (
	"sort"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
)

// Admin → Hammer Sales: closed auctions with their hammer activity.
//
//	GET /api/bma/admin/hammer-sales → {items: [...]}   (filtering, sorting and paging happen in the browser)
//
// An auction is closed once endsAt has passed. A lot is "awarded" when it received at least one bid
// (its highest bid is the hammer price). Wrap-up flow: "done" = every awarded lot has an invoice,
// "action" = some awarded lots still have none, "none" = nothing was awarded.
func registerHammerSalesRoutes(se *core.ServeEvent) {
	se.Router.GET("/api/bma/admin/hammer-sales", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		const dbFmt = "2006-01-02 15:04:05.000Z"
		now := time.Now().UTC().Format(dbFmt)
		auctions, err := e.App.FindRecordsByFilter("auctions", "endsAt < {:now}", "-endsAt", 500, 0, dbx.Params{"now": now})
		if err != nil {
			return e.JSON(200, map[string]any{"items": []any{}})
		}
		items := make([]map[string]any, 0, len(auctions))
		for _, a := range auctions {
			lots, _ := e.App.FindRecordsByFilter("lots", "auction = {:a} && bidCount > 0", "", 0, 0, dbx.Params{"a": a.Id})
			hammer := 0.0
			for _, l := range lots {
				hammer += l.GetFloat("currentBid")
			}
			invoices, _ := e.App.CountRecords("invoices", dbx.HashExp{"auction": a.Id})
			awarded := len(lots)
			flow := "none"
			if awarded > 0 {
				flow = "action"
				if int(invoices) >= awarded {
					flow = "done"
				}
			}
			items = append(items, map[string]any{
				"id": a.Id, "slug": a.GetString("slug"), "title": a.GetString("title"), "sequence": a.GetInt("sequence"),
				"startsAt": isoTime(a, "startsAt"), "endsAt": isoTime(a, "endsAt"), "timezone": a.GetString("timezone"),
				"currency": a.GetString("currency"), "type": "timed",
				"lotCount": a.GetInt("lotCount"), "bidCount": a.GetInt("bidCount"),
				"lotsAwarded": awarded, "hammerTotal": round2(hammer), "invoices": int(invoices), "flow": flow,
			})
		}
		sort.SliceStable(items, func(i, j int) bool { return items[i]["endsAt"].(string) > items[j]["endsAt"].(string) })
		return e.JSON(200, map[string]any{"items": items})
	})
}
