package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/mail"
	"net/url"
	"os"
	"regexp"
	"sort"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/apis"
	"github.com/pocketbase/pocketbase/core"
	"github.com/pocketbase/pocketbase/tools/filesystem"
	"github.com/pocketbase/pocketbase/tools/types"
)

// userError is shown to the client as a 400 with its message.
type userError string

func (e userError) Error() string { return string(e) }

var gaIDRe = regexp.MustCompile(`(?i)^(G|UA|GTM)-[A-Z0-9-]+$`)

func registerRoutes(se *core.ServeEvent) {
	r := se.Router

	// Server clock is the authority for countdowns (blueprint §15).
	r.GET("/api/bma/time", func(e *core.RequestEvent) error {
		return e.JSON(200, map[string]any{"now": time.Now().UnixMilli()})
	})

	r.POST("/api/bma/subscribe", func(e *core.RequestEvent) error {
		var in struct {
			Email string `json:"email"`
		}
		if err := e.BindBody(&in); err != nil || !validEmail(in.Email) {
			return e.BadRequestError("Valid email required", nil)
		}
		email := strings.ToLower(strings.TrimSpace(in.Email))
		if _, err := e.App.FindFirstRecordByFilter("subscribers", "email = {:e}", dbx.Params{"e": email}); err == nil {
			return e.JSON(200, map[string]any{"ok": true})
		}
		rec := core.NewRecord(mustCol(e.App, "subscribers"))
		rec.Set("email", email)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	r.POST("/api/bma/contact", func(e *core.RequestEvent) error {
		var in map[string]any
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid body", nil)
		}
		email, _ := in["email"].(string)
		if !validEmail(email) {
			return e.BadRequestError("Valid email required", nil)
		}
		str := func(k string) string { s, _ := in[k].(string); return strings.TrimSpace(s) }
		rec := core.NewRecord(mustCol(e.App, "contact_messages"))
		rec.Set("kind", str("kind"))
		rec.Set("name", str("name"))
		rec.Set("email", strings.ToLower(email))
		rec.Set("phone", str("phone"))
		rec.Set("message", str("message"))
		rec.Set("payload", in) // keep every submitted field
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	// CRM Hub feed for the admin console (called server-side by Next with BMA_ADMIN_KEY).
	r.GET("/api/bma/admin/crm", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		type entry struct {
			Type     string `json:"type"`
			ID       string `json:"id"`
			Name     string `json:"name"`
			Email    string `json:"email"`
			Phone    string `json:"phone"`
			Subject  string `json:"subject"`
			Message  string `json:"message"`
			Document string `json:"document"`
			Created  string `json:"created"`
		}
		out := []entry{}
		load := func(col, typ string) error {
			recs, err := e.App.FindAllRecords(col)
			if err != nil {
				return err
			}
			for _, rc := range recs {
				en := entry{Type: typ, ID: rc.Id, Name: rc.GetString("name"), Email: rc.GetString("email"),
					Phone: rc.GetString("phone"), Message: rc.GetString("message"), Created: rc.GetDateTime("created").String()}
				if typ == "contact" {
					if p, ok := rc.Get("payload").(types.JSONRaw); ok {
						var m map[string]any
						if json.Unmarshal(p, &m) == nil {
							en.Subject, _ = m["subject"].(string)
						}
					}
				}
				if typ == "career" {
					en.Subject = rc.GetString("subject")
					if f := rc.GetString("document"); f != "" {
						en.Document = "/api/files/" + col + "/" + rc.Id + "/" + f
					}
				}
				out = append(out, en)
			}
			return nil
		}
		for _, c := range [][2]string{{"contact_messages", "contact"}, {"subscribers", "subscription"}, {"career_applications", "career"}} {
			if err := load(c[0], c[1]); err != nil {
				return e.InternalServerError("", err)
			}
		}
		sort.Slice(out, func(i, j int) bool { return out[i].Created > out[j].Created })
		return e.JSON(200, map[string]any{"items": out})
	})

	// Admin team management (called server-side by Next, which also checks the caller is an admin).
	adminKey := adminOK // constant-time compare, see admin_studio.go
	r.GET("/api/bma/admin/users", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		recs, err := e.App.FindRecordsByFilter("users", "isAdmin = true", "-created", 0, 0)
		if err != nil {
			return e.InternalServerError("", err)
		}
		items := []map[string]any{}
		for _, u := range recs {
			name := strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
			if name == "" {
				name = u.GetString("email")
			}
			items = append(items, map[string]any{"id": u.Id, "name": name, "email": u.GetString("email"), "created": u.GetDateTime("created").String(), "disabled": u.GetBool("disabled")})
		}
		return e.JSON(200, map[string]any{"items": items})
	})
	r.POST("/api/bma/admin/users", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			Email    string `json:"email"`
			IsAdmin  bool   `json:"isAdmin"`
			Disabled *bool  `json:"disabled"` // present = switch this auctioneer's account off/on (isAdmin is ignored)
		}
		if err := e.BindBody(&in); err != nil || !validEmail(in.Email) {
			return e.BadRequestError("Valid email required", nil)
		}
		u, err := e.App.FindAuthRecordByEmail("users", strings.ToLower(strings.TrimSpace(in.Email)))
		if err != nil {
			return e.BadRequestError("No account with this email. They need to register on the website first.", nil)
		}
		if in.Disabled != nil {
			if !u.GetBool("isAdmin") {
				return e.BadRequestError("This account is not an auctioneer.", nil)
			}
			if *in.Disabled && !u.GetBool("disabled") {
				// never leave the console without an enabled admin
				n, _ := e.App.CountRecords("users", dbx.NewExp("[[isAdmin]] = 1 AND [[disabled]] = 0"))
				if n <= 1 {
					return e.BadRequestError("You can't disable the last active admin.", nil)
				}
			}
			u.Set("disabled", *in.Disabled)
			if err := e.App.Save(u); err != nil {
				return e.InternalServerError("", err)
			}
			return e.JSON(200, map[string]any{"ok": true, "disabled": *in.Disabled})
		}
		if !in.IsAdmin {
			n, _ := e.App.CountRecords("users", dbx.HashExp{"isAdmin": true})
			if u.GetBool("isAdmin") && n <= 1 {
				return e.BadRequestError("You can't remove the last admin.", nil)
			}
		}
		u.Set("isAdmin", in.IsAdmin)
		if !in.IsAdmin { // no longer an auctioneer: only a consignor switch can keep the account disabled
			u.Set("disabled", consignorDisabled(e.App, u.Email()))
		}
		if err := e.App.Save(u); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})

	// Auction house profile + branding uploads (multipart). Next checks the caller is an admin first.
	houseJSON := func(app core.App, rec *core.Record) map[string]any {
		if rec == nil {
			return map[string]any{"id": ""}
		}
		url := func(f string) string { return "/api/files/house/" + rec.Id + "/" + f }
		urls := func(fs []string) []string {
			out := []string{}
			for _, f := range fs {
				out = append(out, url(f))
			}
			return out
		}
		m := map[string]any{"id": rec.Id, "updated": rec.GetDateTime("updated").String()}
		for _, k := range []string{"name", "website", "supportEmail", "supportPhone", "facebook", "twitter", "linkedin", "whatsapp", "gaId", "description"} {
			m[k] = rec.GetString(k)
		}
		m["logoName"], m["faviconName"] = rec.GetString("logo"), rec.GetString("favicon")
		m["logoUrl"], m["faviconUrl"] = "", ""
		if f := rec.GetString("logo"); f != "" {
			m["logoUrl"] = url(f)
		}
		if f := rec.GetString("favicon"); f != "" {
			m["faviconUrl"] = url(f)
		}
		m["bannerUrls"] = urls(rec.GetStringSlice("banners"))
		for k, v := range houseSettingsDoc(rec) { // fee + theme (Fees & Commissions, Theming & Config)
			m[k] = v
		}
		return m
	}
	findHouse := func(app core.App) *core.Record {
		recs, err := app.FindRecordsByFilter("house", "", "-updated", 1, 0)
		if err != nil || len(recs) == 0 {
			return nil
		}
		return recs[0]
	}
	r.GET("/api/bma/admin/house", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		return e.JSON(200, houseJSON(e.App, findHouse(e.App)))
	})
	r.POST("/api/bma/admin/house", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		rec := findHouse(e.App)
		if rec == nil {
			rec = core.NewRecord(mustCol(e.App, "house"))
		}
		if !strings.HasPrefix(e.Request.Header.Get("Content-Type"), "multipart/form-data") {
			return e.BadRequestError("Expected multipart/form-data", nil)
		}
		if err := e.Request.ParseMultipartForm(32 << 20); err != nil {
			return e.BadRequestError("Upload too large or malformed", nil)
		}
		for _, k := range []string{"name", "website", "supportEmail", "supportPhone", "facebook", "twitter", "linkedin", "whatsapp", "gaId", "description"} {
			if v, ok := e.Request.MultipartForm.Value[k]; ok && len(v) > 0 {
				val := strings.TrimSpace(v[0])
				switch k {
				case "description": // admin-entered HTML: same sanitizer as the legal policies
					val = strings.TrimSpace(sanitizeHTML(val))
				case "website":
					if u, err := url.Parse(val); val != "" && (err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "") {
						return e.BadRequestError("website: enter a full URL starting with https://", nil)
					}
				case "supportEmail":
					if val != "" && !validEmail(val) {
						return e.BadRequestError("supportEmail: enter a valid email address.", nil)
					}
				case "gaId":
					if val != "" && !gaIDRe.MatchString(val) {
						return e.BadRequestError("gaId: use a format like G-XXXXXXXXXX.", nil)
					}
				}
				rec.Set(k, val)
			}
		}
		// Files: PocketBase re-validates size + MIME (sniffed from content) against the field rules.
		for _, k := range []string{"logo", "favicon"} {
			if fs := e.Request.MultipartForm.File[k]; len(fs) > 0 {
				f, err := filesystem.NewFileFromMultipart(fs[0])
				if err != nil {
					return e.BadRequestError("Invalid "+k+" file", nil)
				}
				rec.Set(k, f)
			}
		}
		// Removal (only when no replacement file was sent for that field): removeLogo=1, removeFavicon=1, removeBanner=<file name> (repeatable).
		form := e.Request.MultipartForm
		for flag, field := range map[string]string{"removeLogo": "logo", "removeFavicon": "favicon"} {
			if v := form.Value[flag]; len(v) > 0 && v[0] == "1" && len(form.File[field]) == 0 {
				if cur := rec.GetString(field); cur != "" {
					rec.Set(field+"-", cur) // PocketBase "field-" modifier: delete this file
				}
			}
		}
		if names := form.Value["removeBanner"]; len(names) > 0 && len(form.File["banners"]) == 0 {
			have := map[string]bool{}
			for _, b := range rec.GetStringSlice("banners") {
				have[b] = true
			}
			drop := []string{}
			for _, n := range names {
				if have[n] {
					drop = append(drop, n)
				}
			}
			if len(drop) > 0 {
				rec.Set("banners-", drop)
			}
		}
		if fs := e.Request.MultipartForm.File["banners"]; len(fs) > 0 {
			// replace semantics: the UI says "current banners will be replaced when you save"
			files := []*filesystem.File{}
			for _, h := range fs {
				f, err := filesystem.NewFileFromMultipart(h)
				if err != nil {
					return e.BadRequestError("Invalid banner file", nil)
				}
				files = append(files, f)
			}
			rec.Set("banners", files)
		}
		if err := e.App.Save(rec); err != nil {
			// type/size violations are validation errors -> 400 with {data:{logo:{message}}}
			return e.BadRequestError("Upload rejected", err)
		}
		return e.JSON(200, houseJSON(e.App, rec))
	})

	// Registered bidders for the admin Bidders Directory (all non-admin accounts, with bid/registration counts).
	r.GET("/api/bma/admin/bidders", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		type cnt struct {
			ID string `db:"id"`
			N  int    `db:"n"`
		}
		counts := func(q string) map[string]int {
			var rows []cnt
			m := map[string]int{}
			if err := e.App.DB().NewQuery(q).All(&rows); err == nil {
				for _, r := range rows {
					m[r.ID] = r.N
				}
			}
			return m
		}
		bids := counts("SELECT bidder AS id, COUNT(*) AS n FROM bids GROUP BY bidder")
		regs := counts("SELECT user AS id, COUNT(*) AS n FROM registrations GROUP BY user")
		users, err := e.App.FindRecordsByFilter("users", "isAdmin != true", "-created", 0, 0)
		if err != nil {
			return e.InternalServerError("", err)
		}
		items := []map[string]any{}
		for _, u := range users {
			name := strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
			if name == "" {
				name = u.GetString("email")
			}
			complete := u.GetString("firstName") != "" && u.GetString("lastName") != "" && u.GetString("phone") != "" && u.GetString("address1") != "" && u.GetString("country") != ""
			items = append(items, map[string]any{
				"id": u.Id, "name": name, "email": u.GetString("email"), "phone": u.GetString("phone"),
				"created": u.GetDateTime("created").String(), "bids": bids[u.Id], "registrations": regs[u.Id], "completed": complete,
				"phoneCountry": u.GetString("phoneCountry"), "country": u.GetString("country"), "notify": !u.GetBool("notificationsOff"),
			})
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	r.POST("/api/bma/admin/bidders", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID     string `json:"id"`
			Notify bool   `json:"notify"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		u, err := e.App.FindRecordById("users", in.ID)
		if err != nil {
			return e.NotFoundError("Bidder not found", nil)
		}
		u.Set("notificationsOff", !in.Notify)
		if err := e.App.Save(u); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true, "email": u.GetString("email")})
	})
	// ---------------- Non-registered bidders (prospects) ----------------
	prospectJSON := func(p *core.Record) map[string]any {
		interests := []string{}
		for _, v := range strings.Split(p.GetString("interests"), ",") {
			if v = strings.TrimSpace(v); v != "" {
				interests = append(interests, v)
			}
		}
		return map[string]any{
			"id": p.Id, "first": p.GetString("first"), "last": p.GetString("last"), "email": p.GetString("email"),
			"dial": p.GetString("dial"), "phone": p.GetString("phone"), "role": p.GetString("role"), "company": p.GetString("company"),
			"website": p.GetString("website"), "l1": p.GetString("l1"), "l2": p.GetString("l2"), "city": p.GetString("city"),
			"state": p.GetString("state"), "country": p.GetString("country"), "zip": p.GetString("zip"),
			"interests": interests, "addedAt": p.GetDateTime("created").Time().UTC().Format(time.RFC3339), "invited": p.GetBool("invited"),
		}
	}
	r.GET("/api/bma/admin/prospects", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		recs, err := e.App.FindRecordsByFilter("prospects", "id != ''", "-created", 0, 0)
		if err != nil {
			return e.InternalServerError("", err)
		}
		items := []map[string]any{}
		for _, p := range recs {
			items = append(items, prospectJSON(p))
		}
		return e.JSON(200, map[string]any{"items": items})
	})
	r.POST("/api/bma/admin/prospects", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			First, Last, Email, Dial, Phone, Role, Company, Website string
			L1, L2, City, State, Country, Zip                       string
			Interests                                               []string
		}
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		clip := func(v string, n int) string {
			v = strings.TrimSpace(v)
			if r := []rune(v); len(r) > n {
				return string(r[:n])
			}
			return v
		}
		first, email := clip(in.First, 100), strings.ToLower(strings.TrimSpace(in.Email))
		if first == "" {
			return e.BadRequestError("First name is required.", nil)
		}
		if !validEmail(email) {
			return e.BadRequestError("Enter a valid email address.", nil)
		}
		website := clip(in.Website, 200)
		if website != "" && !strings.HasPrefix(website, "http://") && !strings.HasPrefix(website, "https://") {
			return e.BadRequestError("Use a full URL starting with http:// or https://", nil)
		}
		if _, err := e.App.FindFirstRecordByFilter("prospects", "email = {:e}", dbx.Params{"e": email}); err == nil {
			return e.BadRequestError("A prospect with this email already exists.", nil)
		}
		interests := []string{}
		for _, v := range in.Interests {
			if v = clip(strings.ReplaceAll(v, ",", " "), 40); v != "" && len(interests) < 10 {
				interests = append(interests, v)
			}
		}
		rec := core.NewRecord(mustCol(e.App, "prospects"))
		rec.Set("first", first)
		rec.Set("last", clip(in.Last, 100))
		rec.Set("email", email)
		rec.Set("dial", clip(in.Dial, 8))
		rec.Set("phone", clip(in.Phone, 30))
		rec.Set("role", clip(in.Role, 100))
		rec.Set("company", clip(in.Company, 150))
		rec.Set("website", website)
		rec.Set("l1", clip(in.L1, 200))
		rec.Set("l2", clip(in.L2, 200))
		rec.Set("city", clip(in.City, 100))
		rec.Set("state", clip(in.State, 100))
		rec.Set("country", clip(in.Country, 100))
		rec.Set("zip", clip(in.Zip, 20))
		rec.Set("interests", strings.Join(interests, ","))
		rec.Set("invited", false)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"item": prospectJSON(rec)})
	})
	r.POST("/api/bma/admin/prospects/invite", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID string `json:"id"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		rec, err := e.App.FindRecordById("prospects", in.ID)
		if err != nil {
			return e.NotFoundError("Prospect not found", nil)
		}
		rec.Set("invited", true)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"item": prospectJSON(rec)})
	})
	r.POST("/api/bma/admin/prospects/remove", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID string `json:"id"`
		}
		if err := e.BindBody(&in); err != nil || in.ID == "" {
			return e.BadRequestError("id required", nil)
		}
		rec, err := e.App.FindRecordById("prospects", in.ID)
		if err != nil {
			return e.NotFoundError("Prospect not found", nil)
		}
		email := rec.GetString("email")
		if err := e.App.Delete(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true, "email": email})
	})
	r.POST("/api/bma/admin/activity", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			Email  string `json:"email"`
			Title  string `json:"title"`
			IP     string `json:"ip"`
			OK     bool   `json:"ok"`
			Device string `json:"device"`
		}
		if err := e.BindBody(&in); err != nil || !validEmail(in.Email) {
			return e.BadRequestError("Valid email required", nil)
		}
		email := strings.ToLower(strings.TrimSpace(in.Email))
		// only existing accounts are logged (unknown emails from failed logins are ignored)
		acct, err := e.App.FindAuthRecordByEmail("users", email)
		if err != nil {
			return e.JSON(200, map[string]any{"ok": true, "skipped": true})
		}
		// admin accounts -> admin_activity, everyone else (bidders) -> user_activity
		logCol := "user_activity"
		if acct.GetBool("isAdmin") {
			logCol = "admin_activity"
		}
		rec := core.NewRecord(mustCol(e.App, logCol))
		rec.Set("email", email)
		rec.Set("title", in.Title)
		rec.Set("ip", in.IP)
		rec.Set("ok", in.OK)
		rec.Set("device", in.Device)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
	// Platform-wide user activity feed (last ~31 days): logins/logouts + bids, registrations, watchlist adds, new accounts.
	r.GET("/api/bma/admin/user-activity", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		type entry struct {
			ID        string   `json:"id"`
			User      string   `json:"user"`
			Email     string   `json:"email"`
			Action    string   `json:"action"`
			Category  string   `json:"category"`
			Details   string   `json:"details"`
			Device    string   `json:"device"`
			Amount    *float64 `json:"amount"`
			Currency  string   `json:"currency"`
			At        string   `json:"at"`
			IP        string   `json:"ip"`
			LotID     string   `json:"lotId,omitempty"`
			AuctionID string   `json:"auctionId,omitempty"`
		}
		params := dbx.Params{"s": time.Now().UTC().AddDate(0, 0, -31).Format("2006-01-02 15:04:05.000Z")}
		users, lots, auctions := map[string]*core.Record{}, map[string]*core.Record{}, map[string]*core.Record{}
		find := func(cache map[string]*core.Record, col, id string) *core.Record {
			if rc, ok := cache[id]; ok {
				return rc
			}
			rc, _ := e.App.FindRecordById(col, id)
			cache[id] = rc
			return rc
		}
		nameOf := func(u *core.Record) (string, string) {
			if u == nil {
				return "Unknown user", ""
			}
			n := strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
			if n == "" {
				n = u.GetString("email")
			}
			return n, u.GetString("email")
		}
		stamp := func(rc *core.Record) string { return rc.GetDateTime("created").Time().UTC().Format(time.RFC3339) }
		out := []entry{}
		list := func(col string) []*core.Record {
			recs, _ := e.App.FindRecordsByFilter(col, "created >= {:s}", "-created", 1500, 0, params)
			return recs
		}

		// account events from admin_activity: auth, self-service account actions, and admin console actions.
		// Page views ("Viewed ...") are excluded in the query so they cannot crowd real events out of the row limit.
		var recs []*core.Record
		for _, col := range []string{"admin_activity", "user_activity"} {
			rs, _ := e.App.FindRecordsByFilter(col, "created >= {:s} && title !~ 'Viewed'", "-created", 1500, 0, params)
			recs = append(recs, rs...)
		}
		for _, l := range recs {
			title := strings.TrimSpace(l.GetString("title"))
			action, category, details := "", "Authentication", title
			switch {
			case title == "":
				continue
			case title == "Successfully logged in":
				action = "Logged In"
			case title == "Logged out":
				action, details = "Logged Out", "Successfully logged out"
			case title == "Failed login attempt":
				action = "Failed Login"
			case title == "Updated profile":
				action, category = "Update Profile", "Account"
			case title == "Changed password":
				action, category = "Change Password", "Account"
			case title == "Requested account deletion":
				action, category = "Request Deletion", "Account"
			case title == "Exported personal data":
				action, category = "Export Data", "Account"
			case strings.HasPrefix(title, "Removed from watchlist"):
				action, category = "Remove Watchlist", "Watchlist"
			default: // anything else reported by the admin console (granted access, edited auction house, studio changes...)
				action, category = "Admin Action", "Admin"
			}
			email := l.GetString("email")
			name := email
			if u, err := e.App.FindAuthRecordByEmail("users", email); err == nil {
				name, _ = nameOf(u)
			}
			out = append(out, entry{ID: "l-" + l.Id, User: name, Email: email, Action: action, Category: category, Details: details,
				Device: l.GetString("device"), At: stamp(l), IP: l.GetString("ip")})
		}
		// bids
		for _, b := range list("bids") {
			name, email := nameOf(find(users, "users", b.GetString("bidder")))
			lt, at, cur := "", "", ""
			if lot := find(lots, "lots", b.GetString("lot")); lot != nil {
				lt = lot.GetString("title")
			}
			if au := find(auctions, "auctions", b.GetString("auction")); au != nil {
				at, cur = au.GetString("title"), au.GetString("currency")
			}
			amt := b.GetFloat("amount")
			out = append(out, entry{ID: "b-" + b.Id, User: name, Email: email, Action: "Place Bid", Category: "Bidding",
				Details: fmt.Sprintf("Bid on %s · %s", lt, at), Amount: &amt, Currency: cur, At: stamp(b),
				LotID: b.GetString("lot"), AuctionID: b.GetString("auction")})
		}
		// auction registrations
		for _, g := range list("registrations") {
			name, email := nameOf(find(users, "users", g.GetString("user")))
			at := ""
			if au := find(auctions, "auctions", g.GetString("auction")); au != nil {
				at = au.GetString("title")
			}
			out = append(out, entry{ID: "r-" + g.Id, User: name, Email: email, Action: "Register Auction", Category: "Registration",
				Details: "Registered for auction: " + at, At: stamp(g), AuctionID: g.GetString("auction")})
		}
		// watchlist adds
		for _, f := range list("favourites") {
			name, email := nameOf(find(users, "users", f.GetString("user")))
			lt, aid := "", ""
			if lot := find(lots, "lots", f.GetString("lot")); lot != nil {
				lt, aid = lot.GetString("title"), lot.GetString("auction")
			}
			out = append(out, entry{ID: "f-" + f.Id, User: name, Email: email, Action: "Add Watchlist", Category: "Watchlist",
				Details: "Added to watchlist: " + lt, At: stamp(f), LotID: f.GetString("lot"), AuctionID: aid})
		}
		// new accounts
		for _, u := range list("users") {
			name, email := nameOf(u)
			out = append(out, entry{ID: "u-" + u.Id, User: name, Email: email, Action: "Account Created", Category: "Account",
				Details: "New account registered", At: stamp(u)})
		}
		sort.Slice(out, func(i, j int) bool { return out[i].At > out[j].At })
		if len(out) > 3000 {
			out = out[:3000]
		}
		return e.JSON(200, map[string]any{"items": out})
	})
	r.GET("/api/bma/admin/activity", func(e *core.RequestEvent) error {
		if !adminKey(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		email := strings.ToLower(strings.TrimSpace(e.Request.URL.Query().Get("email")))
		items := []map[string]any{}
		for _, col := range []string{"admin_activity", "user_activity"} {
			recs, err := e.App.FindRecordsByFilter(col, "email = {:e}", "-created", 500, 0, dbx.Params{"e": email})
			if err != nil {
				return e.InternalServerError("", err)
			}
			for _, a := range recs {
				items = append(items, map[string]any{"id": a.Id, "title": a.GetString("title"), "ip": a.GetString("ip"), "ok": a.GetBool("ok"), "at": a.GetDateTime("created").String()})
			}
		}
		sort.Slice(items, func(i, j int) bool { return items[i]["at"].(string) > items[j]["at"].(string) })
		return e.JSON(200, map[string]any{"items": items})
	})

	// ---------------- authenticated routes ----------------
	auth := r.Group("/api/bma")
	auth.Bind(apis.RequireAuth("users"))

	registerPreferenceRoutes(auth)
	registerMaxBidRoutes(auth)

	// Request to join an auction. Staff approve in the dashboard (/_/),
	// or set BMA_AUTO_APPROVE=1 for local development.
	auth.POST("/registrations", func(e *core.RequestEvent) error {
		var in struct {
			Auction string         `json:"auction"` // slug
			Answers map[string]any `json:"answers"` // answers to the active Company → Questionnaire, by question id
		}
		if err := e.BindBody(&in); err != nil || in.Auction == "" {
			return e.BadRequestError("auction is required", nil)
		}
		a, err := e.App.FindFirstRecordByFilter("auctions", "slug = {:s} && published = true", dbx.Params{"s": in.Auction})
		if err != nil {
			return e.NotFoundError("Auction not found", nil)
		}
		if ex, err := e.App.FindFirstRecordByFilter("registrations", "auction = {:a} && user = {:u}", dbx.Params{"a": a.Id, "u": e.Auth.Id}); err == nil {
			return e.JSON(200, map[string]any{"status": ex.GetString("status")})
		}
		// Builder → Bidder Registration: the auction's own questions replace the company questionnaire when it has any
		var answers any
		hasAnswers, msg := false, ""
		if qs := auctionQuestions(a); len(qs) > 0 {
			m, em := validateAuctionAnswers(qs, in.Answers)
			answers, msg, hasAnswers = m, em, len(m) > 0
		} else {
			_, questions := activeQuestionnaire(e.App)
			m, em := validateAnswers(questions, in.Answers)
			answers, msg, hasAnswers = m, em, len(m) > 0
		}
		if msg != "" {
			return e.BadRequestError(msg, nil)
		}
		status := "PENDING"
		// the auction's own approval mode (Add auction → Bidder approval workflow) wins; empty = BMA_AUTO_APPROVE
		if am := a.GetString("approvalMode"); am == "AUTO" || (am == "" && os.Getenv("BMA_AUTO_APPROVE") == "1") {
			status = "APPROVED"
		}
		rec := core.NewRecord(mustCol(e.App, "registrations"))
		rec.Set("auction", a.Id)
		rec.Set("user", e.Auth.Id)
		rec.Set("status", status)
		if hasAnswers {
			rec.Set("answers", answers)
		}
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"status": status})
	})

	// Watchlist: add a lot to the signed-in bidder's favourites (idempotent). Removing goes through
	// DELETE /api/collections/favourites/records/:id (the Next proxy logs "Removed from watchlist").
	auth.POST("/favourites", func(e *core.RequestEvent) error {
		var in struct {
			Lot string `json:"lot"` // lot record id
		}
		if err := e.BindBody(&in); err != nil || in.Lot == "" {
			return e.BadRequestError("lot is required", nil)
		}
		lot, err := e.App.FindRecordById("lots", in.Lot)
		if err != nil {
			return e.NotFoundError("Lot not found", nil)
		}
		if a, err := e.App.FindRecordById("auctions", lot.GetString("auction")); err != nil || !a.GetBool("published") {
			return e.NotFoundError("Lot not found", nil)
		}
		if ex, err := e.App.FindFirstRecordByFilter("favourites", "lot = {:l} && user = {:u}", dbx.Params{"l": lot.Id, "u": e.Auth.Id}); err == nil {
			return e.JSON(200, map[string]any{"id": ex.Id})
		}
		rec := core.NewRecord(mustCol(e.App, "favourites"))
		rec.Set("user", e.Auth.Id)
		rec.Set("lot", lot.Id)
		if err := e.App.Save(rec); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"id": rec.Id})
	})

	// The bid pipeline (blueprint: auth → qualification → time check → increment check).
	auth.POST("/bids", func(e *core.RequestEvent) error {
		var in struct {
			Lot    string  `json:"lot"` // lot record id
			Amount float64 `json:"amount"`
		}
		if err := e.BindBody(&in); err != nil || in.Lot == "" {
			return e.BadRequestError("lot and amount are required", nil)
		}

		var result map[string]any
		err := e.App.RunInTransaction(func(tx core.App) error {
			lot, err := tx.FindRecordById("lots", in.Lot)
			if err != nil {
				return userError("Lot not found")
			}
			auction, err := tx.FindRecordById("auctions", lot.GetString("auction"))
			if err != nil || !auction.GetBool("published") {
				return userError("Auction not found")
			}
			if lot.GetBool("draft") {
				return userError("Lot not found")
			}
			// 1. time check — server clock only
			now := time.Now()
			lotEnd := auction.GetDateTime("endsAt").Time() // a lot may close earlier than its auction (lots.endsAt)
			if le := lot.GetDateTime("endsAt"); !le.IsZero() && le.Time().Before(lotEnd) {
				lotEnd = le.Time()
			}
			if now.Before(auction.GetDateTime("startsAt").Time()) {
				return userError("Bidding has not started yet")
			}
			if !now.Before(lotEnd) {
				return userError("Bidding is closed")
			}
			if auction.GetBool("paused") {
				return userError("Bidding is paused for this auction. Please try again shortly.")
			}
			// 2. qualification — approved registration for this auction
			if _, err := tx.FindFirstRecordByFilter("registrations",
				"auction = {:a} && user = {:u} && status = 'APPROVED'",
				dbx.Params{"a": auction.Id, "u": e.Auth.Id}); err != nil {
				return userError("Your registration for this auction is not approved")
			}
			// 3. increment check
			start := lot.GetFloat("startingBid")
			tiers := lotTiers(lot) // tiered increments (Company → Lot Bid Details), empty = single increment
			cur := start
			if lot.GetInt("bidCount") > 0 {
				cur = lot.GetFloat("currentBid")
			}
			inc := bidIncrement(lot, tiers, cur)
			min := start
			if lot.GetInt("bidCount") > 0 {
				min = cur + inc
			}
			if in.Amount < min {
				return userError(fmt.Sprintf("Minimum bid is %.2f", min))
			}
			// single increment: steps count from the starting bid; tiered: from the minimum bid
			base := start
			if len(tiers) > 0 {
				base = min
			}
			if math.Abs(math.Mod(in.Amount-base, inc)) > 1e-9 {
				return userError(fmt.Sprintf("Bids go up in steps of %.2f", inc))
			}
			prev := lot.GetString("leader")
			if prev == e.Auth.Id {
				return userError("You are already the highest bidder")
			}

			// accept the bid, then let stored maximum (proxy) bids answer it
			eng := newBidEngine(tx, auction, lot, now)
			if err := eng.place(e.Auth.Id, in.Amount, true, false); err != nil {
				return err
			}
			if err := eng.resolve(); err != nil {
				return err
			}
			state := "OUTBID" // a higher maximum bid can answer immediately
			if lot.GetString("leader") == e.Auth.Id {
				state = "LEADING"
			}

			result = map[string]any{
				"ok": true, "lot": lot.Id, "amount": in.Amount, "currentBid": lot.GetFloat("currentBid"),
				"bidCount": lot.GetInt("bidCount"), "state": state, "reserveMet": lot.GetBool("reserveMet"),
				"nextMin": eng.minBid(),
				"endsAt":  eng.lotEnd.UTC().Format(time.RFC3339), "extended": eng.extended,
			}
			return nil
		})
		if err != nil {
			var ue userError
			if errors.As(err, &ue) {
				return e.BadRequestError(ue.Error(), nil)
			}
			return e.InternalServerError("", err)
		}
		return e.JSON(200, result)
	})

	// GDPR-style export of everything we hold on the signed-in user.
	auth.GET("/me/export", func(e *core.RequestEvent) error {
		get := func(col string, field string) []*core.Record {
			rs, _ := e.App.FindRecordsByFilter(col, field+" = {:u}", "-created", 0, 0, dbx.Params{"u": e.Auth.Id})
			return rs
		}
		prof := map[string]any{"id": e.Auth.Id, "email": e.Auth.Email()}
		for _, f := range []string{"firstName", "lastName", "phone", "accountType", "company", "designation", "website",
			"address1", "address2", "city", "state", "postalCode", "country", "prefs"} {
			prof[f] = e.Auth.Get(f)
		}
		return e.JSON(200, map[string]any{
			"exportedAt":    time.Now().UTC().Format(time.RFC3339),
			"profile":       prof,
			"bids":          get("bids", "bidder"),
			"registrations": get("registrations", "user"),
			"favourites":    get("favourites", "user"),
			"invoices":      get("invoices", "user"),
			"notifications": get("notifications", "user"),
		})
	})

	// Delete request: needs password, blocked while money/bids are outstanding.
	// Records are retained/anonymised by staff (no hard delete here).
	auth.POST("/me/delete-request", func(e *core.RequestEvent) error {
		var in struct {
			Password string `json:"password"`
		}
		if err := e.BindBody(&in); err != nil || !e.Auth.ValidatePassword(in.Password) {
			return e.BadRequestError("Password is incorrect", nil)
		}
		if _, err := e.App.FindFirstRecordByFilter("invoices", "user = {:u} && status = 'UNPAID'", dbx.Params{"u": e.Auth.Id}); err == nil {
			return e.BadRequestError("You have unpaid invoices", nil)
		}
		if _, err := e.App.FindFirstRecordByFilter("bids", "bidder = {:u} && state = 'LEADING'", dbx.Params{"u": e.Auth.Id}); err == nil {
			return e.BadRequestError("You are currently leading one or more bids", nil)
		}
		e.Auth.Set("deleteRequestedAt", types.NowDateTime())
		if err := e.App.Save(e.Auth); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"ok": true})
	})
}

// Reset links must point at the Next.js site, not the PocketBase dashboard.
func configureUsers(app core.App) error {
	web := strings.TrimRight(os.Getenv("BMA_WEB_URL"), "/")
	if web == "" {
		web = "http://localhost:3000"
	}
	users, err := app.FindCollectionByNameOrId("users")
	if err != nil {
		return err
	}
	body := fmt.Sprintf(`<p>Hello,</p><p>Click the button below to reset your BidMyAsset password.</p><p><a class="btn" href="%s/reset-password?token={TOKEN}" target="_blank" rel="noopener">Reset password</a></p><p>If you did not request this, you can ignore this email.</p>`, web)
	if users.ResetPasswordTemplate.Body == body {
		return nil
	}
	users.ResetPasswordTemplate.Subject = "Reset your BidMyAsset password"
	users.ResetPasswordTemplate.Body = body
	return app.Save(users)
}

func mustCol(app core.App, name string) *core.Collection {
	c, err := app.FindCollectionByNameOrId(name)
	if err != nil {
		panic(err)
	}
	return c
}

func validEmail(s string) bool {
	a, err := mail.ParseAddress(strings.TrimSpace(s))
	return err == nil && a.Address == strings.TrimSpace(s)
}
