package main

import (
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
)

// Admin → Invoice Management. All routes need X-BMA-Admin-Key (Next checks the caller is an admin first).
//
//	GET  /api/bma/admin/invoices            every invoice, newest first
//	GET  /api/bma/admin/invoice-candidates  awarded lots (they have bids) per auction, with the leading bidder and whether an invoice exists
//	POST /api/bma/admin/invoices            {auction, lot?, email, hammer}: the invoice hook (bidding.go) adds commission, internet fee, tax and the total
//	POST /api/bma/admin/invoice-status      {id, status: PAID|UNPAID}: staff confirm a payment received outside the site
func registerAdminInvoiceRoutes(se *core.ServeEvent) {
	r := se.Router

	name := func(u *core.Record) string {
		if u == nil {
			return ""
		}
		n := strings.TrimSpace(u.GetString("firstName") + " " + u.GetString("lastName"))
		if n == "" {
			n = u.GetString("email")
		}
		return n
	}

	r.GET("/api/bma/admin/invoices", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		recs, err := e.App.FindRecordsByFilter("invoices", "id != ''", "-created", 1000, 0)
		if err != nil {
			return e.JSON(200, map[string]any{"items": []any{}})
		}
		users, auctions, lots := map[string]*core.Record{}, map[string]*core.Record{}, map[string]*core.Record{}
		find := func(cache map[string]*core.Record, col, id string) *core.Record {
			if id == "" {
				return nil
			}
			if r, ok := cache[id]; ok {
				return r
			}
			r, _ := e.App.FindRecordById(col, id)
			cache[id] = r
			return r
		}
		items := make([]map[string]any, 0, len(recs))
		for _, iv := range recs {
			u := find(users, "users", iv.GetString("user"))
			a := find(auctions, "auctions", iv.GetString("auction"))
			l := find(lots, "lots", iv.GetString("lot"))
			it := map[string]any{
				"id": iv.Id, "auction": iv.GetString("auction"), "number": iv.GetString("number"), "status": iv.GetString("status"), "currency": iv.GetString("currency"),
				"hammer": iv.GetFloat("hammer"), "commission": iv.GetFloat("commission"), "internetFee": iv.GetFloat("internetFee"),
				"tax": iv.GetFloat("tax"), "amount": iv.GetFloat("amount"), "created": isoTime(iv, "created"),
				"bidder": name(u), "email": "", "auctionTitle": "", "lotNumber": 0, "lotTitle": "",
			}
			if u != nil {
				it["email"] = u.GetString("email")
			}
			if a != nil {
				it["auctionTitle"] = a.GetString("title")
			}
			if l != nil {
				it["lotNumber"], it["lotTitle"] = l.GetInt("lotNumber"), l.GetString("title")
			}
			items = append(items, it)
		}
		return e.JSON(200, map[string]any{"items": items})
	})

	r.GET("/api/bma/admin/invoice-candidates", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		lots, err := e.App.FindRecordsByFilter("lots", "bidCount > 0", "auction, lotNumber", 2000, 0)
		if err != nil || len(lots) == 0 {
			return e.JSON(200, map[string]any{"auctions": []any{}})
		}
		invoiced := map[string]bool{}
		if ivs, err := e.App.FindRecordsByFilter("invoices", "lot != ''", "", 0, 0); err == nil {
			for _, iv := range ivs {
				invoiced[iv.GetString("lot")] = true
			}
		}
		type lotOut = map[string]any
		order := []string{}
		byAuction := map[string][]lotOut{}
		meta := map[string]*core.Record{}
		users := map[string]*core.Record{}
		for _, l := range lots {
			aid := l.GetString("auction")
			if _, ok := meta[aid]; !ok {
				a, err := e.App.FindRecordById("auctions", aid)
				if err != nil {
					continue
				}
				meta[aid] = a
				order = append(order, aid)
			}
			var u *core.Record
			if id := l.GetString("leader"); id != "" {
				if cu, ok := users[id]; ok {
					u = cu
				} else {
					u, _ = e.App.FindRecordById("users", id)
					users[id] = u
				}
			}
			email := ""
			if u != nil {
				email = u.GetString("email")
			}
			byAuction[aid] = append(byAuction[aid], lotOut{
				"id": l.Id, "lotNumber": l.GetInt("lotNumber"), "title": l.GetString("title"), "hammer": l.GetFloat("currentBid"),
				"bidder": name(u), "email": email, "invoiced": invoiced[l.Id],
			})
		}
		out := []map[string]any{}
		for _, aid := range order {
			a := meta[aid]
			out = append(out, map[string]any{"id": aid, "title": a.GetString("title"), "currency": a.GetString("currency"), "lots": byAuction[aid]})
		}
		return e.JSON(200, map[string]any{"auctions": out})
	})

	r.POST("/api/bma/admin/invoices", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			Auction string  `json:"auction"`
			Lot     string  `json:"lot"`
			Email   string  `json:"email"`
			Hammer  float64 `json:"hammer"`
		}
		if err := e.BindBody(&in); err != nil {
			return e.BadRequestError("Invalid request", nil)
		}
		if in.Hammer <= 0 || in.Hammer > 1e9 || math.IsNaN(in.Hammer) || math.IsInf(in.Hammer, 0) {
			return e.BadRequestError("Enter a hammer price above zero", nil)
		}
		auction, err := e.App.FindRecordById("auctions", in.Auction)
		if err != nil {
			return e.BadRequestError("Choose an auction", nil)
		}
		var lot *core.Record
		if in.Lot != "" {
			if lot, err = e.App.FindRecordById("lots", in.Lot); err != nil || lot.GetString("auction") != auction.Id {
				return e.BadRequestError("That lot is not part of this auction", nil)
			}
			if _, err := e.App.FindFirstRecordByFilter("invoices", "lot = {:l}", dbx.Params{"l": lot.Id}); err == nil {
				return e.BadRequestError("This lot already has an invoice", nil)
			}
		}
		email := strings.ToLower(strings.TrimSpace(in.Email))
		bidder, err := e.App.FindAuthRecordByEmail("users", email)
		if err != nil {
			return e.BadRequestError("No bidder account uses that email", nil)
		}

		col := mustCol(e.App, "invoices")
		prefix := fmt.Sprintf("INV-%d-", nowYear())
		seq, _ := e.App.CountRecords("invoices", dbx.NewExp("number LIKE {:p}", dbx.Params{"p": prefix + "%"}))
		var rec *core.Record
		var saveErr error
		for try := 1; try <= 8; try++ { // the number is unique: if two staff save at once, take the next one
			rec = core.NewRecord(col)
			rec.Set("user", bidder.Id)
			rec.Set("auction", auction.Id)
			if lot != nil {
				rec.Set("lot", lot.Id)
			}
			rec.Set("number", fmt.Sprintf("%s%04d", prefix, int(seq)+try))
			rec.Set("currency", auction.GetString("currency"))
			rec.Set("hammer", math.Round(in.Hammer*100)/100)
			rec.Set("status", "UNPAID")
			if saveErr = e.App.Save(rec); saveErr == nil {
				break
			}
		}
		if saveErr != nil {
			return e.InternalServerError("", saveErr)
		}

		// in-app notice for the bidder (best effort)
		what := auction.GetString("title")
		if lot != nil {
			what = fmt.Sprintf("Lot %d · %s", lot.GetInt("lotNumber"), lot.GetString("title"))
		}
		if n := core.NewRecord(mustCol(e.App, "notifications")); n != nil {
			n.Set("user", bidder.Id)
			n.Set("title", "New invoice "+rec.GetString("number"))
			n.Set("body", "An invoice was issued for "+what+". You can view it under My Invoices.")
			_ = e.App.Save(n)
		}
		return e.JSON(200, map[string]any{"id": rec.Id, "number": rec.GetString("number"), "amount": rec.GetFloat("amount")})
	})

	r.POST("/api/bma/admin/invoice-status", func(e *core.RequestEvent) error {
		if !adminOK(e) {
			return e.ForbiddenError("Forbidden", nil)
		}
		var in struct {
			ID     string `json:"id"`
			Status string `json:"status"`
		}
		if err := e.BindBody(&in); err != nil || (in.Status != "PAID" && in.Status != "UNPAID") {
			return e.BadRequestError("status must be PAID or UNPAID", nil)
		}
		iv, err := e.App.FindRecordById("invoices", in.ID)
		if err != nil {
			return e.NotFoundError("Invoice not found", nil)
		}
		iv.Set("status", in.Status)
		if err := e.App.Save(iv); err != nil {
			return e.InternalServerError("", err)
		}
		return e.JSON(200, map[string]any{"id": iv.Id, "number": iv.GetString("number"), "status": in.Status})
	})
}

func nowYear() int { return time.Now().Year() }
