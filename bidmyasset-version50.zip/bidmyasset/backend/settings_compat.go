package main

import (
	"encoding/json"
	"strings"

	"github.com/pocketbase/pocketbase/core"
)

// Helpers shared by house_settings.go and bidding.go.
//
// The `house` settings (fee, theme, legal, categories) were created as TEXT fields by 9_house_settings.go,
// so an existing database holds them as JSON strings. A fresh patch-style schema would use JSON fields.
// These helpers read and write both, so policies already saved in Admin → Auction House / Company → Policies
// keep working after the upgrade.

// decodeSection turns a stored setting (JSON text, raw JSON bytes or an already-decoded value) into plain Go values.
func decodeSection(raw any) (any, bool) {
	switch v := raw.(type) {
	case nil:
		return nil, false
	case string:
		s := strings.TrimSpace(v)
		if s == "" || s == "null" {
			return nil, false
		}
		var out any
		if err := json.Unmarshal([]byte(s), &out); err != nil {
			return nil, false
		}
		return out, out != nil
	case []byte:
		return decodeSection(string(v))
	case json.RawMessage:
		return decodeSection(string(v))
	default:
		// types.JSONRaw and friends: marshal then parse
		b, err := json.Marshal(v)
		if err != nil {
			return nil, false
		}
		return decodeSection(string(b))
	}
}

// setSection stores a cleaned setting on the record whichever field type the column has.
// nil clears it.
func setSection(rec *core.Record, key string, value any) {
	f := rec.Collection().Fields.GetByName(key)
	if f != nil && f.Type() == core.FieldTypeText {
		if value == nil {
			rec.Set(key, "")
			return
		}
		b, err := json.Marshal(value)
		if err != nil {
			rec.Set(key, "")
			return
		}
		rec.Set(key, string(b))
		return
	}
	rec.Set(key, value)
}

// findCompany returns the Company settings record (Admin → Company), or nil when this install has no `company`
// collection yet. Company-driven defaults (bid increments, auctioneer commission) are then simply skipped.
func findCompany(app core.App) *core.Record {
	col, err := app.FindCollectionByNameOrId("company")
	if err != nil || col == nil {
		return nil
	}
	recs, err := app.FindRecordsByFilter(col, "", "-updated", 1, 0)
	if err != nil || len(recs) == 0 {
		return nil
	}
	return recs[0]
}
