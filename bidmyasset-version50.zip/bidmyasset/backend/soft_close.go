package main

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/pocketbase/dbx"
	"github.com/pocketbase/pocketbase/core"
)

// Soft close (Auction Builder → Auction Info → Soft close).
//
// A bid accepted inside the last N minutes (or seconds) of a lot pushes THAT lot's closing time out to bid time + N.
// The window is saved by Auction Info in builder.info as {soft: "5", softUnit: "Minutes"|"Seconds"}; 0 = off.
//
// A lot closes at the earlier of its own `lots.endsAt` and `auctions.endsAt` (see the bid pipeline), so:
//   - new closing time <= auction end: only lots.endsAt of this lot moves;
//   - new closing time  > auction end: the auction end moves too. Every other open lot that was simply following the
//     auction end is first pinned to the OLD end (lots.endsAt), so they do not get extra time they did not earn.
//
// Runs inside the bid transaction; the caller saves `lot` and `auction` afterwards.

const softCloseMax = 24 * time.Hour

// softCloseWindowOf reads the window from builder.info. ok=false when the saved value is not a valid number.
func softCloseWindowOf(info map[string]any) (time.Duration, bool) {
	if info == nil {
		return 0, true
	}
	var n float64
	switch v := info["soft"].(type) {
	case nil:
		return 0, true
	case float64:
		n = v
	case string:
		s := strings.TrimSpace(v)
		if s == "" {
			return 0, true
		}
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return 0, false
		}
		n = f
	default:
		return 0, false
	}
	if n != n || n < 0 { // NaN or negative
		return 0, false
	}
	unit := time.Minute
	if u, _ := info["softUnit"].(string); u == "Seconds" {
		unit = time.Second
	}
	if n*float64(unit) > float64(softCloseMax) {
		return 0, false
	}
	return time.Duration(n * float64(unit)), true
}

func softCloseWindow(auction *core.Record) time.Duration {
	info, _ := builderOf(auction)["info"].(map[string]any)
	w, ok := softCloseWindowOf(info)
	if !ok {
		return 0
	}
	return w
}

// applySoftClose moves the closing time when the accepted bid fell inside the window.
// lotEnd is the lot's closing time as checked for this bid. Returns the lot's new closing time and whether it moved.
func applySoftClose(tx core.App, auction, lot *core.Record, now, lotEnd time.Time) (time.Time, bool, error) {
	win := softCloseWindow(auction)
	if win <= 0 || lotEnd.Sub(now) >= win {
		return lotEnd, false, nil
	}
	const layout = "2006-01-02 15:04:05.000Z"
	newEnd := now.Add(win)
	auctionEnd := auction.GetDateTime("endsAt").Time()

	if !newEnd.After(auctionEnd) { // this lot has its own, earlier closing time
		lot.Set("endsAt", newEnd.UTC().Format(layout))
		return newEnd, true, nil
	}

	others, err := tx.FindRecordsByFilter("lots", "auction = {:a}", "", 0, 0, dbx.Params{"a": auction.Id})
	if err != nil {
		return lotEnd, false, err
	}
	pin := auctionEnd.UTC().Format(layout)
	for _, o := range others {
		if o.Id == lot.Id || o.GetBool("draft") || !o.GetDateTime("endsAt").IsZero() {
			continue // this lot, drafts and lots that already have their own closing time are left alone
		}
		o.Set("endsAt", pin)
		if err := tx.Save(o); err != nil {
			return lotEnd, false, fmt.Errorf("soft close: %w", err)
		}
	}
	lot.Set("endsAt", "") // follows the (extended) auction end
	auction.Set("endsAt", newEnd.UTC().Format(layout))
	return newEnd, true, nil
}
