package main

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"github.com/pocketbase/pocketbase/core"
)

// Realtime lot updates (Server-Sent Events).
//
//	GET /api/bma/stream   public; one event per accepted bid / closing-time change on any lot:
//	                      data: {"lot","currentBid","bidCount","endsAt","reserveMet"}
//
// Only fields the lot pages already show publicly are sent (never the leader, a reserve amount or anyone's maximum bid).
// Events are published by a hook after a lot is saved (after the bid transaction commits), then fanned out in memory
// to every open connection. A slow client simply misses events; the browser falls back to its periodic refresh.

type liveBroker struct {
	mu   sync.Mutex
	subs map[chan []byte]struct{}
}

var liveLots = &liveBroker{subs: map[chan []byte]struct{}{}}

func (b *liveBroker) subscribe() chan []byte {
	ch := make(chan []byte, 64)
	b.mu.Lock()
	b.subs[ch] = struct{}{}
	b.mu.Unlock()
	return ch
}

func (b *liveBroker) unsubscribe(ch chan []byte) {
	b.mu.Lock()
	delete(b.subs, ch)
	b.mu.Unlock()
}

func (b *liveBroker) publish(msg []byte) {
	b.mu.Lock()
	defer b.mu.Unlock()
	for ch := range b.subs {
		select {
		case ch <- msg:
		default: // slow client: drop
		}
	}
}

func registerLiveRoutes(se *core.ServeEvent) {
	se.App.OnRecordAfterUpdateSuccess("lots").BindFunc(func(e *core.RecordEvent) error {
		lot := e.Record
		if !lot.GetBool("draft") {
			end := lot.GetDateTime("endsAt").Time()
			if a, err := e.App.FindRecordById("auctions", lot.GetString("auction")); err == nil {
				if ae := a.GetDateTime("endsAt").Time(); end.IsZero() || ae.Before(end) {
					end = ae // a lot closes at the earlier of its own end and the auction end
				}
			}
			ev := map[string]any{
				"lot": lot.Id, "currentBid": lot.GetFloat("currentBid"), "bidCount": lot.GetInt("bidCount"),
				"endsAt": end.UTC().Format(time.RFC3339), "reserveMet": lot.GetBool("reserveMet"),
			}
			if msg, err := json.Marshal(ev); err == nil {
				liveLots.publish(msg)
			}
		}
		return e.Next()
	})

	se.Router.GET("/api/bma/stream", func(e *core.RequestEvent) error {
		h := e.Response.Header()
		h.Set("Content-Type", "text/event-stream")
		h.Set("Cache-Control", "no-cache, no-transform")
		h.Set("X-Accel-Buffering", "no") // do not let a reverse proxy buffer the stream
		e.Response.WriteHeader(200)

		ch := liveLots.subscribe()
		defer liveLots.unsubscribe(ch)
		fmt.Fprint(e.Response, "retry: 3000\n\n")
		if err := e.Flush(); err != nil {
			return nil
		}
		tick := time.NewTicker(25 * time.Second) // keeps idle connections open through proxies
		defer tick.Stop()
		for {
			select {
			case <-e.Request.Context().Done():
				return nil
			case msg := <-ch:
				fmt.Fprintf(e.Response, "data: %s\n\n", msg)
			case <-tick.C:
				fmt.Fprint(e.Response, ": ping\n\n")
			}
			if err := e.Flush(); err != nil {
				return nil
			}
		}
	})
}
