# BidMyAsset — website + backend

Next.js 15 (App Router) + TypeScript + Tailwind v4. Follows `BIDMYASSET_WEBSITE_DESIGN.docx`
and the Blueprint v0.1. **Bidder/buyer portal added (UI + mock data). Seller portal is not included.**

## Backend (Go + PocketBase) — added in v19
See `backend/README.md`. Start it first (`cd backend && go mod tidy && go run . serve`), then:
```bash
cp .env.local.example .env.local   # PB_URL=http://127.0.0.1:8090
```
The browser only talks to Next.js: `/api/pb/*` proxies to PocketBase and keeps the session token in an httpOnly cookie.
Wired to the backend: auctions + lots (public and `/timed`), register, login (password + OTP), forgot/reset password,
portal guard + logout, register-to-bid, place bid, my bids / registrations / favourites / invoices / notifications,
profile + password change, data export + delete request, contact + subscribe.
Still mock: parts of `/admin/*` (see "What is mock / TODO"). The heart on a lot card is real: it saves via `POST /api/bma/favourites` and removes via `DELETE /api/collections/favourites/records/:id`.

## Run (frontend)
```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
```

## Routes
| Route | Design page |
|---|---|
| `/` | Home |
| `/about` | About |
| `/leadership` | Leadership |
| `/login`, `/register` | Auth (UI only, 3-step bidder registration) |
| `/auctions` · `/auctions/archive` | Timed Auctions (Live & Upcoming / Archive) |
| `/auctions/[slug]` | Auction → lot grid with search / sort / category / price filters |
| `/auctions/[slug]/lot/[lot]` | Lot detail (blueprint §21 share-able per-lot URL) |

## Bidder portal (after login)
| Route | Page |
|---|---|
| `/dashboard` | My Dashboard (stat cards, bidding momentum, bid status, shortlist, auction highlights) |
| `/my-bids` · `/favourites` · `/my-registrations` · `/my-invoices` | Lists with empty states |
| `/auction-calendar` | Month view + open/close dates (auction's own timezone) |
| `/notifications` · `/settings` · `/profile` | Notifications inbox; Settings = profile, password, **notification toggles, preferences (language / timezone / theme), export + delete-account request** |

- Login and Login-with-OTP currently redirect straight to `/dashboard` (mock, no real auth).
- A new account simply shows empty lists (there is no demo mode).
- Mock data: `src/lib/portal.ts`. The `(portal)` layout has a TODO to guard routes with real auth.
- Sidebar: icon rail on desktop, labelled drawer on mobile. "Timed Auctions" links to the public `/auctions`.

## Blueprint rules already reflected
- **Currency + timezone per auction**, never global (`lib/format.ts`, `Auction.currency/timezone`).
- **Server clock is authority** for countdowns (`components/Countdown.tsx`) — browser clock only used as a tick offset.
- Lot URL = `/auctions/<auction-slug>/lot/<n>`; Share menu: copy link, WhatsApp, Facebook, LinkedIn, X, Telegram, Email.
- Exact location hidden publicly; "Use My Location" distance (§22–24).
- Register has Individual / Company account type (§9).
- Taxonomy (Category → Subcategory) drives the lot filter; data-driven, not hard-coded in UI.

## What is mock / TODO
- `src/lib/data.ts` is **mock data** → swap for API calls (Project → Auction → Lot).
- Photos: placeholders (`PlaceholderImage`, leadership initials) — supply real images.
- Leadership page people are now managed in Admin → Team (see "Team" below); `src/lib/content.ts` only keeps a fallback list for when the backend is down.
- Leadership "Regional map" is a real OpenStreetMap (Leaflet) with one pin per region (`regionPoints` in `src/lib/content.ts`).
- Login / Register / Place Bid / Contact / Subscribe: UI only (`/api/contact`, `/api/subscribe` are stubs).
- Blog link is `#`. Privacy / Terms open `/privacy` and `/terms` (v50).

## Account settings (v17)
- Bidder `/settings` and admin `/admin/settings`: per-event **In-app / Email** toggles (`lib/preferences.ts`; security + transactional events are locked on). Email *wording* stays in Admin → Email Templates.
- Preferences: language (Bahasa Malaysia / English: `src/lib/i18n.ts`, `<T>` and `useT()`; any string without a translation stays English), personal **display** timezone (notice times only; auctions keep their own timezone per blueprint), light / dark / system theme (`globals.css` palette remap, no-flash boot script in `app/layout.tsx`).
- Portal only: **Export my data** (JSON) and **Delete account** request (password + type DELETE; blocked while unpaid invoices / leading bids; records retained/anonymised, no hard delete). Admin has no export/delete — admin accounts are managed in Admin Users.
- Preferences (language, display timezone, theme, notification toggles) are saved on the account: `users.prefs` (migration `99_zz_user_prefs.go`) via `GET/PUT /api/bma/me/preferences` (`backend/preferences.go`, validates every value; locked events stay on; the `admin` scope needs an admin). `localStorage` is only a cache and what the no-flash theme script reads; a browser that already had saved choices uploads them the first time it connects. Export / delete-request are real (`/api/bma/me/export`, `/api/bma/me/delete-request`).

## Branding (v35)
Admin → Auction House → Edit uploads logo / favicon / banners to PocketBase (`house` collection). The public site reads them
(`lib/brand.ts`, cached 30 s): header/portal/auth **logo**, browser-tab **favicon**, **home hero banners** (cross-fade), footer
support phone/email and site name. Empty = built-in defaults (`/logo.png`, `lib/content.ts`).

## Images (v36)
Admin → Auction Studio now reads real auctions/lots from PocketBase (`lib/studioApi.tsx`; there is no demo data, an empty database shows empty lists).
- **Add auction** wizard creates a *draft* auction with cover images; **Publish** (auction page header) makes it visible on the website.
- **Auction Builder → Cover images** and **Lot Builder → Media** upload/delete/reorder photos (`components/admin/ImageManager.tsx`) → PocketBase `auctions.images` / `lots.images`.
- Public site shows them: auction cards, lot cards, lot page gallery (`components/Gallery.tsx`); placeholder when none.
- Not persisted yet: other Studio fields (dates, rules, contacts incl. contact avatar, documents, bid settings) and Auction Intelligence screens (still mock).

## Auction House → Fees & Commissions + Theming & Config (v49) — now real
Both are stored on the PocketBase `house` record (`fee`, `theme` JSON fields, migration `99_zz_house_fee_theme.go`; on this build the columns are the existing text fields from `9_house_settings.go`, stored as JSON text — both forms are read)) and saved through
`PUT /api/admin/house/settings` (Next, admin only) → `PUT /api/bma/admin/house/settings` (Go, validates every value again).

**Internet buying fee** (six structures, `lib/auctionHouse.ts` FEE_DEFS ⇄ `computeFee` in `backend/house_settings.go`):
- Invoices: when staff create an invoice with a `hammer` price (PocketBase dashboard → `invoices`), the backend fills `commission`
  (Company → Auctioneer Commission), `internetFee` (this fee) and `amount = hammer + commission + internetFee`. A non-zero fee typed by hand is kept.
- Bids: `GET /api/bma/fee-quote?amount=N` (public) returns the server's numbers; the bid stepper shows "+ buyer's fees … · est. total …".
- Portal → My Invoices shows hammer + commission + internet fee.
- "Flat with cap + online fee" = min(rate% , cap) + online%. "Tiered flat %" = whole amount × first%, or × second% once the amount is above "up to" and at least "from".

**Theme** (`lib/themeCss.ts`, injected by `app/layout.tsx` as `<style id="bma-theme">`):
- Primary / secondary colour → `--color-primary` (+ darker hover, soft tint) and `--color-brand`, so every `bg-primary` / `text-primary` / hero gradient follows.
- Button theme → buttons marked `data-btn="primary|secondary|outline"`; dialog theme → dialogs marked `data-dialog` (+ `data-dialog-title`, `data-dialog-footer`).
  Only values that differ from the defaults are emitted, and button/dialog rules apply in light mode only. Dialog: container colours/radius/shadow, title size/weight, footer gap
  and the header padding (as the dialog's padding) are applied; header gap, content padding and footer padding have no separate region in these dialogs yet.
- "Allow questions & rating" hides/shows the lot ratings block and the star row on lot cards.
- The public site re-reads the record every 30 s; saving in the admin refreshes it immediately (`revalidateTag("house")`).

Still mock in Auction House: SMTP, payment credentials.

## Invoice Management (now real)
Admin → Invoice Management lists every invoice (`GET /api/bma/admin/invoices`), issues new ones from an awarded lot (`POST /api/bma/admin/invoices`, candidates from `GET /api/bma/admin/invoice-candidates`; the invoice hook still adds commission, internet fee, tax and the total) and marks them Paid / Unpaid (`POST /api/bma/admin/invoice-status`, for payments received outside the site). Numbers are `INV-<year>-<0001>`; a lot can only be invoiced once; the bidder gets an in-app notice. Statuses are Unpaid / Paid (no draft state). There is still no online payment.

## Legal Policies + Categories (v50) — now real
Both are stored on the `house` record (`legal`, `categories` JSON fields, migration `99_zz_house_legal_categories.go`) and saved through the same `PUT /api/admin/house/settings`.
- **Legal policies**: Admin → Auction House → Legal Policies → Add / Remove. HTML is cleaned by the backend on save (`backend/html_sanitize.go`, uses `golang.org/x/net/html`; run `go mod tidy`).
  Published at `/privacy` and `/terms` (`components/LegalPage.tsx`, inside the `(site)` group so the footer stays; newest policy that has that text).
  **Company → Policies is the same list** (`LegalPoliciesCard` in `CompanySections.tsx`, saved through `lib/houseClient.ts` → `PUT /api/admin/house/settings`). The register form and the register-to-bid dialog link to them.
  Any other `href="#"` for Privacy / Terms (footer, auth layout, admin footer) should point to `/privacy` and `/terms` too.
- **Categories**: Admin → Auction House → Categories → **Save changes**. Saved as `{category: [enabled subcategories]}`. The category filter on the public lot browser
  (`LotBrowser`, via `useBrand().categories`) only lists enabled subcategories. Nothing saved yet = every category shown; a category missing from the saved selection is shown in full.
  Lots themselves are not hidden, only the filter options.

## Theming stays up to date (v51)
`components/ThemeSync.tsx` (mounted in `app/layout.tsx`) checks `/api/brand/version` every 30 s, when the tab regains focus, and right after an admin save.
When the house record changed it drops the cached copy and calls `router.refresh()`, so open pages pick up new colours, buttons, dialogs, ratings, categories and logo without a reload.
Theme colour variables are emitted as `:root:root{…}` so they always win over Tailwind's defaults.

## Merge notes (v52 patch into this build)
- `GET/PUT /api/bma/admin/house/settings` + `GET /api/bma/fee-quote` are new; `POST /api/admin/house` still handles profile text + logo/favicon/banners only.
- `backend/settings_compat.go`: `decodeSection`, `setSection` (writes JSON text or JSON field), `findCompany` (returns nil when there is no `company` collection).
- `99_zz_invoice_lot_fields.go` adds `invoices.hammer`, `invoices.commission`, `lots.incrementMatrix` (the patch reads them).
- Admin → Company is now stored in PocketBase (`company` record, migration `11_company.go`, `backend/company.go`, Next `/api/admin/company`, hook `lib/companyClient.ts`): profile, consignors, banks (last 4 digits only), taxes, contacts, lot bid details, locations, questionnaires. Policies = `house.legal`; Auctioneer Commission = `house.fee` (same as Auction House → Fees & Commissions), so the fee is never charged twice.
- Lot Bid Details feed new lots created in Auction Studio (starting bid, single or tiered increment) and the bid pipeline.
- Company → Auctioneers is the admin-account list (same as Admin Users).

- All demo/mock data has been removed: no seeded auctions (backend starts empty), no sample company/consignors/banks/contacts, no demo portal mode, no sample admin notices. Email Templates are saved on the company record.

## Auction Intelligence — now real
Every screen is computed from the auction's own records (`lib/intelData.ts`): lots (Studio), every bid (`GET /api/bma/admin/studio-bids`), registrations and the invoices issued for the auction.
- **Reports** (`IntelligenceReports.tsx`): winning bids, sales, bidding transcripts, underbids, logged-in bidders (from the activity feed, which keeps 31 days), absentee bids, reserves, no-sales, pending, booklets, catalog and the summary. **Excel** is a real `.xlsx` (`lib/xlsx.ts`, no dependency); PDF uses the browser's print.
- **KPI analytics, Unified analytics, Analytics dashboard, Bidder analysis** (`IntelligenceAnalytics.tsx`): KPI cards, bids over time, lot outcomes, category and per-lot tables, bidder table with Excel export.
- **Recordings** is a bid-by-bid replay rebuilt from the bid log. These are timed auctions, so no live audio/video exists to record.
- Definitions (one place, `intelData.ts`): SOLD = closed + bids + reserve met (or none); PENDING = closed, reserve not met, auction is "Subject to Confirmation"; NO_SALE = closed with no bids, or reserve not met in a Reserve auction; Absolute auctions ignore reserve. Bidder no. = registration order in that auction.
- Not available because the data does not exist yet: chat transcripts (no chat), absentee/proxy bids (not supported), consignor-side commission. Tax and fees in the summary come from issued invoices.

## Auction Calendar → Location Lots
`listLocationLots()` (`lib/api-data.ts`) returns non-draft lots that have an address, in auctions that have not closed. The calendar shows each one on the days between the auction opening and the lot's closing time. Only the auction's city / region is shown, never the street address.

## Soft close (Auction Builder → Auction Info)
`backend/soft_close.go`, called from the bid pipeline (`POST /api/bma/bids`). Set **Soft close** to N minutes or seconds (0 = off, max 24 hours; checked again on save in `auction-update`).
- A bid accepted in the last N of a lot moves **that lot's** closing time to bid time + N (repeats on every new bid in the window).
- A lot closes at the earlier of `lots.endsAt` and `auctions.endsAt`. When the new time is later than the auction end, the auction end moves too, and every other open lot that was only following the auction end is first pinned to the old end (`lots.endsAt`), so they get no extra time.
- The bid response carries `endsAt` and `extended`; the bid box then calls `router.refresh()` so the countdown shows the new time.
- Bidder ranking and "show bidder history" are still saved but not applied.

## Still open
SMTP + payment credentials are not stored (Auction House), so no email is sent and there is no online payment (Toyyibpay) yet.

## v6 additions
- **Email (SMTP) and payment (Toyyibpay)** — Admin → Auction House → Edit. Saved by `backend/integrations.go` in `house_integrations` (no API rules; the password / secret key never go back to the browser). Saving SMTP also writes PocketBase's own mail settings, so OTP, reset-password and Catalog Notification emails start working; "Send a test email" is in the SMTP dialog and in Email Templates.
  Bidders pay unpaid invoices with **Pay now** (My Invoices): `POST /api/bma/invoices/{id}/pay` creates a Toyyibpay bill; the callback `/api/bma/payments/toyyibpay/callback` re-checks the bill with Toyyibpay before marking the invoice PAID. Toyyibpay must reach the backend: set `BMA_PUBLIC_URL` (a tunnel such as ngrok on localhost) and `BMA_SITE_URL` (where the bidder returns to). MYR only, minimum RM 1.00. Use Sandbox mode for testing.
- **Bidder ranking + bid history** — enforced by `GET /api/bma/lots/{id}/bids` (`backend/bid_activity.go`) from Auction Builder → Auction Info; shown by `components/BidActivity.tsx` on the lot page.
- **Maps** — Address preview already live; the public lot page shows a wide-area map (no pin, exact spot stays hidden); Leadership has the regional map.
- **Language** — see Preferences above.


## Team (Admin → Team → public /leadership)
Admin → Team lists the Leadership Team, Strategic Advisors and Management Team. Add / edit / remove a person, upload or remove a photo
(PNG, JPG or WebP, up to 2 MB), change name, position, section and LinkedIn link, hide a person without deleting, and reorder with the arrows.
- Stored in PocketBase `team_members` (migration `99_zz_team.go`; the first run seeds the 21 people that used to be hard-coded). Public read of visible people only.
- Backend: `backend/team.go` (`GET/POST /api/bma/admin/team`, `POST …/team-delete`, `POST …/team-order`, admin key). Next: `/api/admin/team` (admin check, then revalidates `/leadership`).
- Public page: `src/app/(site)/leadership/page.tsx` reads `lib/team.ts` (30 s cache, refreshed immediately on save). Photos are served through `/api/pb/api/files/team_members/...`.
- After copying these files, restart the backend once so the migration runs (`go run . serve`).
